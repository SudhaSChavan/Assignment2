import mongoose from 'mongoose';
import { logger } from '@tradeling/core';

export async function closeDbConnection() {
  logger.info('Closing database connection');

  await mongoose.connection.close();
}
