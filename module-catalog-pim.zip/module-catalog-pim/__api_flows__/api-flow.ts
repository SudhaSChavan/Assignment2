import { closeDbConnection } from './helpers';

async function runAPIFlow(): Promise<void> {
  console.log('started api-flow');
  await closeDbConnection();
  console.log('implement your api flow here');

  console.log('finished api-flow');
}

runAPIFlow().then(() => {
  process.exit();
});
