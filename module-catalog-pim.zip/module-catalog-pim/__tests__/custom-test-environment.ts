import { appConfig } from '@src/config/env';
import NodeEnvironment from 'jest-environment-node';
import { cloneDeep } from 'lodash';

const originalEnv: any = cloneDeep(process.env);
const originalAppConfig: any = cloneDeep(appConfig);
// custom environment to share appConfig and process env for test modules
export default class CustomEnvironment extends NodeEnvironment {
  async setup() {
    await super.setup();
    this.global.process.env = process.env;
    this.global['appConfig'] = appConfig;
  }

  async teardown() {
    process.env = cloneDeep(originalEnv);
    Object.assign(appConfig, cloneDeep(originalAppConfig));
    await super.teardown();
  }
}
