/// <reference path="../../../src/types/modules/swagger.d.ts"/>
import {
  cartesian,
  formatPackagingInfo,
  semiColonSeparated,
} from '@express/modules/upload/helpers';
import xor from 'lodash/xor';

describe('Cartesian helper', () => {
  it.each([
    //
    {
      values: [
        ['Red', 'Green', 'Blue'],
        ['Small', 'Large', 'X-Large'],
      ],
      expect: [
        ['Red', 'Small'],
        ['Red', 'Large'],
        ['Red', 'X-Large'],
        ['Blue', 'Small'],
        ['Blue', 'Large'],
        ['Blue', 'X-Large'],
        ['Green', 'Small'],
        ['Green', 'Large'],
        ['Green', 'X-Large'],
      ],
    },
    {
      values: [
        ['Red', 'Blue'],
        ['SM', 'XL', '2XL'],
        ['ABC', 'DEF'],
      ],
      expect: [
        ['Red', 'SM', 'ABC'],
        ['Red', 'SM', 'DEF'],
        ['Red', 'XL', 'ABC'],
        ['Red', 'XL', 'DEF'],
        ['Red', '2XL', 'ABC'],
        ['Red', '2XL', 'DEF'],
        ['Blue', 'SM', 'ABC'],
        ['Blue', 'SM', 'DEF'],
        ['Blue', 'XL', 'ABC'],
        ['Blue', 'XL', 'DEF'],
        ['Blue', '2XL', 'ABC'],
        ['Blue', '2XL', 'DEF'],
      ],
    },
  ])('should should return all possible combinations: %p', (param: any) => {
    const generatedCombinations: any[] = [
      ...cartesian(...param.values),
    ].map((value: string[]) => value.join('-'));
    const expectedSize: number = param.values.reduce(
      (acc: number, arr: any) => acc * arr.length,
      1,
    );

    expect(generatedCombinations.length).toBe(expectedSize);
    // compare generated values irrespective of their order
    expect(
      xor(
        generatedCombinations,
        param.expect.map((value: string[]) => value.join('-')),
      ).length,
    ).toBe(0);
  });
});

describe('Semi colon separated', () => {
  it('should return array when i pass a numbers', () => {
    const string: string = '405.7;400.9';
    const array: string[] = semiColonSeparated(string);
    expect(array.map((item) => parseFloat(item))).toEqual([405.7, 400.9]);
  });

  it('should return array when i pass a ids', () => {
    const string: string = '611236d96957adbe18a0ffc1;611236f4107e31ec39b0f674';
    const array: string[] = semiColonSeparated(string);
    expect(array).toEqual([
      '611236d96957adbe18a0ffc1',
      '611236f4107e31ec39b0f674',
    ]);
  });

  it('should return array when i pass a numbers', () => {
    const string: string = '405.7;;;;;400.9';
    const array: string[] = semiColonSeparated(string);
    expect(array.map((item) => parseFloat(item))).toEqual([405.7, 400.9]);
  });
});

describe('Formatting Package Info', () => {
  it.each([
    {
      params: {
        priceUnitOfMeasure: 'piece',
        packaging: {
          unit: 'carton',
          size: 10,
          unitsPerCarton: 10,
        },
      },
      expected: '10 pcs x 10 cartons',
    },
    {
      params: {
        priceUnitOfMeasure: 'piece',
        packaging: {
          unit: 'box',
          size: 1,
          unitsPerCarton: 1,
        },
      },
      expected: '1 pc x 1 box',
    },
    {
      params: {
        priceUnitOfMeasure: 'piece',
        packaging: {
          unit: 'box',
          size: 0.5,
          unitsPerCarton: 1,
        },
      },
      expected: '1 pc x 0.5 box',
    },
    {
      params: {
        priceUnitOfMeasure: 'carton',
        packaging: {
          unit: 'box',
          size: 1,
          unitsPerCarton: 1,
        },
      },
      expected: 'Carton: 1 x 1 box',
    },
    {
      params: {
        priceUnitOfMeasure: 'pack',
        packaging: {
          unit: 'piece',
          size: 10,
          unitsPerCarton: 1,
        },
      },
      expected: 'Pack: 1 x 10 pcs',
    },
    {
      params: {
        priceUnitOfMeasure: 'pack',
        packaging: {
          unit: 'piece',
          size: 0.5,
          unitsPerCarton: 1,
        },
      },
      expected: 'Pack: 1 x 0.5 pc',
    },
    {
      params: {
        priceUnitOfMeasure: 'box',
        packaging: {
          unit: 'box',
          size: 1,
          unitsPerCarton: 1,
        },
      },
      expected: '1 box',
    },
    {
      params: {
        priceUnitOfMeasure: 'piece',
        packaging: {
          unit: 'piece',
          size: 12,
          unitsPerCarton: 1,
        },
      },
      expected: '12 pcs',
    },
    {
      params: {
        priceUnitOfMeasure: 'piece',
        packaging: {
          unit: 'piece',
          size: 1,
          unitsPerCarton: 11,
        },
      },
      expected: '11 pcs',
    },
  ])(
    'should return valid packaging information',
    async ({ params, expected }) => {
      const { priceUnitOfMeasure, packaging } = params;
      const formattedPackaging: string = formatPackagingInfo(
        priceUnitOfMeasure,
        packaging,
      );
      expect(formattedPackaging).toEqual(expected);
    },
  );
});
