import { appConfig, IConfig } from '@src/config/env';

function convertPropToGetter(obj: Record<string, any>, prop: string) {
  const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
  if (descriptor?.get) return;
  const newDescriptor = {
    ...descriptor,
    configurable: true,
    get() {
      return descriptor?.value;
    },
    set(v: any) {
      (<any>this).prop = v;
    },
  };
  delete newDescriptor.writable;
  delete newDescriptor.value;
  Object.defineProperty(obj, prop, newDescriptor);
}

export function mockObjProperty(
  obj: Record<string, any>,
  prop: string,
  mockValue: any,
) {
  convertPropToGetter(obj, prop);
  return jest.spyOn(obj, prop, 'get').mockReturnValue(mockValue);
}

export function mockConfigProp<T extends keyof IConfig>(
  prop: T,
  value: IConfig[T],
) {
  // for unit testing
  mockObjProperty(appConfig, prop, value);
  // appConfig for API testing is shared in the custom environment file ./custom-test-environment.ts
  return mockObjProperty((<any>global).appConfig, prop, value);
}

export function mockEnvVariable(prop: string, value: string) {
  return mockObjProperty(process.env, prop, value);
}
