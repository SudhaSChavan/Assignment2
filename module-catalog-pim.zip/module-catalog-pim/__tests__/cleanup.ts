import { mongoConnection } from '../commands/utils/db';

beforeAll(async () => {
  await mongoConnection;
});
