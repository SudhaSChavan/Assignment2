import supertest from 'supertest';
import { app } from '@src/config/server/server';

describe('POST /v1-list-collection-backoffice', () => {
  it('should return 200', async () => {
    const params: Paths.V1ListCollectionBackofficeAction.RequestBody = {};
    const { status } = await supertest(app)
      .post('/v1-list-collection-backoffice')
      .send(params);
    expect(status).toBe(200);
  });
});
