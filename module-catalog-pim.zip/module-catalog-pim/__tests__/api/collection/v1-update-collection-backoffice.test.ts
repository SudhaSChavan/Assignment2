import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { collectionModel } from '@express/modules/collection/model-collection';

describe('POST /v1-update-collection-backoffice', () => {
  beforeEach(async () => {
    await collectionModel.deleteMany({});
  });

  afterAll(async () => {
    await collectionModel.deleteMany({});
  });

  it('should return 200', async () => {
    const { _id } = await collectionModel.create({ name: 'cool' });
    const params: Paths.V1UpdateCollectionBackofficeAction.RequestBody = {
      id: _id,
      name: 'cool updated',
    };
    const { status } = await supertest(app)
      .post('/v1-update-collection-backoffice')
      .send(params);
    expect(status).toBe(200);
  });
});
