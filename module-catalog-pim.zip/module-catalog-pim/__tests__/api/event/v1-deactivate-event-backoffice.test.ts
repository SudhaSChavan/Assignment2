import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { eventModel } from '@express/modules/event/model-event';

describe('POST /v1-deactivate-event-backoffice', () => {
  it('should return 200', async () => {
    const { _id } = await eventModel.create({
      name: 'the event',
      discountType: ['percentage_off'],
      discountVerticals: 'order_discount',
      validFrom: new Date().toISOString(),
      description: 'description',
      needApproval: true,
    });
    const params: Paths.V1DeactivateEventBackofficeAction.RequestBody = {
      id: _id,
    };
    const { body, status } = await supertest(app)
      .post('/v1-deactivate-event-backoffice')
      .send(params);
    expect(status).toBe(200);
  });
});
