import supertest from 'supertest';
import { app } from '@src/config/server/server';

describe('POST /v1-create-event-backoffice', () => {
  it('should return 200', async () => {
    const params: Paths.V1CreateEventBackofficeAction.RequestBody = {
      name: 'the event',
      discountType: ['percentage_off'],
      discountVerticals: 'order_discount',
      validFrom: new Date().toISOString(),
      description: 'description',
      needApproval: true,
    };
    const { status } = await supertest(app)
      .post('/v1-create-event-backoffice')
      .send(params);
    expect(status).toBe(200);
  });
});
