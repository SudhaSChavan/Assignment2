import supertest from 'supertest';
import { app } from '@src/config/server/server';

describe('POST /v1-list-media-backoffice', () => {
  it('should return 200', async () => {
    const params: Paths.V1ListMediaBoBackofficeAction.RequestBody = {};
    const { body, status } = await supertest(app)
      .post('/v1-list-media-backoffice')
      .send(params);
    expect(status).toBe(200);
  });
});
