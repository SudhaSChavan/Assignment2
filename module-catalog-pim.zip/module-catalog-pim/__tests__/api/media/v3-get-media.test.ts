import supertest from 'supertest';

import { app } from '@src/config/server/server';
import {
  createCategory,
  createProductV3,
  uploadMedia,
  validateMedia,
} from '../helpers';
import { categoryModel } from '@express/modules/category/model-category';
import { productModelV3 } from '@express/modules/product/model-product-v3';
import { offerModelV3 } from '@express/modules/offer/model-offers-v3';

describe('POST /v3-get-media', () => {
  let category: Components.Schemas.V1Category;

  beforeAll(async () => {
    category = await createCategory();
  });

  afterAll(async () => {
    await productModelV3.deleteMany({});
    await offerModelV3.deleteMany({});
    await categoryModel.deleteMany({});
  });

  it.each([[{}], [{ id: 'sorry' }]])(
    'should return 400 Bad Request on invalid request parameters: %p',
    async (params: any) => {
      await supertest(app)
        .post('/v3-get-media')
        .send(params)
        .expect(400)
        .expect('Content-Type', /json/);
    },
  );

  it('should return 404 if no media for given id', async () => {
    await supertest(app)
      .post('/v3-get-media')
      .send({ id: '5e4e8cfc123ac0e4c0d96f1f' })
      .expect(404)
      .expect('Content-Type', /json/);
  });

  it('should return media', async () => {
    const media: Components.Schemas.V1MediaItem = await uploadMedia();
    const { body } = await supertest(app)
      .post('/v3-get-media')
      .send({ id: media._id })
      .expect(200)
      .expect('Content-Type', /json/);

    validateMedia(body.media);
    expect(body.products).toEqual([]);
  });

  it('should return media with linked products', async () => {
    const media: Components.Schemas.V1MediaItem = await uploadMedia();
    const product: Components.Schemas.V3Product = await createProductV3({
      media: [{ id: media._id, type: 'image', sort: 1 }],
      categoryId: category._id,
    });

    const { body } = await supertest(app)
      .post('/v3-get-media')
      .send({ id: media._id })
      .expect(200)
      .expect('Content-Type', /json/);
    validateMedia(body.media);
  });
});
