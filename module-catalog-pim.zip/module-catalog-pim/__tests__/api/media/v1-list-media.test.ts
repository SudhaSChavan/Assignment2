import supertest from 'supertest';

import { app } from '@src/config/server/server';
import mongoose from 'mongoose';
import { deleteMedia, uploadMedia } from '../helpers';

describe('POST /v1-list-media', () => {
  beforeEach(async () => {
    await mongoose.models.Media.deleteMany({});
  });

  it.each([
    [{ page: 'asdsd' }],
    [{ page: -1 }],
    [{ size: 0 }],
    [{ size: 1e6 }],
    [{ filter: { ids: {} } }],
    [{ filter: { term: {} } }],
  ])(
    'should return 400 Bad Request on invalid request parameters: %p',
    async (params: any) => {
      await supertest(app)
        .post('/v1-list-media')
        .send(params)
        .expect(400)
        .expect('Content-Type', /json/);
    },
  );

  it('should return empty media list', async () => {
    const { body } = await supertest(app)
      .post('/v1-list-media')
      .send({})
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body).toEqual({
      currentPage: 1,
      totalPages: 0,
      totalRecords: 0,
      size: 3,
      items: [],
    });
  });

  it('should return one media', async () => {
    const media: Components.Schemas.V1MediaItem = await uploadMedia();

    const { body } = await supertest(app)
      .post('/v1-list-media')
      .send({})
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body).toEqual({
      currentPage: 1,
      totalPages: 1,
      totalRecords: 1,
      size: 3,
      items: [media],
    });
  });

  it('should not return deleted media', async () => {
    const media: Components.Schemas.V1MediaItem = await uploadMedia();
    const deletedMedia: Components.Schemas.V1MediaItem = await uploadMedia();

    const { body } = await supertest(app)
      .post('/v1-list-media')
      .send({})
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body).toEqual({
      currentPage: 1,
      totalPages: 1,
      totalRecords: 2,
      size: 3,
      items: [deletedMedia, media],
    });

    await deleteMedia(deletedMedia._id);

    const { body: newBody } = await supertest(app)
      .post('/v1-list-media')
      .send({})
      .expect(200)
      .expect('Content-Type', /json/);

    expect(newBody).toEqual({
      currentPage: 1,
      totalPages: 1,
      totalRecords: 1,
      size: 3,
      items: [media],
    });
  });
});
