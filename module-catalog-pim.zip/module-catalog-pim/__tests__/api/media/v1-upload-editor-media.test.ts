import supertest from 'supertest';
import { pngFile400px, randomString } from '../helpers';
import { app } from '@src/config/server/server';

describe('POST /v1-upload-editor-media', () => {
  it.each([
    [{ filename: '' }],
    [{ filename: 'a.b' }],
    [{ filename: 'file.xxx' }], //
  ])(
    'should return 400 Bad Request on invalid file name/extension: %p',
    async (params) => {
      await supertest(app)
        .post('/v1-upload-editor-media')
        .attach('files[]', pngFile400px, { filename: params.filename })
        .expect(400)
        .expect('Content-Type', /json/);
    },
  );

  it('should return 400 Bad Request when no file provided', async () => {
    await supertest(app)
      .post('/v1-upload-editor-media')
      .expect(400)
      .expect('Content-Type', /json/);
  });

  it('should upload png image', async () => {
    const { body } = await supertest(app)
      .post('/v1-upload-editor-media')
      .attach('files[]', pngFile400px, { filename: `${randomString()}.png` })
      .expect(200)
      .expect('Content-Type', /json/);

    expect(typeof body.link).toBe('string');
    expect(typeof body.path).toBe('string');
    expect(typeof body.name).toBe('string');
  });
});
