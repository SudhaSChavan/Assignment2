import supertest from 'supertest';

import { app } from '@src/config/server/server';
import {
  createCategory,
  createProductV3,
  getMedia,
  getProduct,
  uploadMedia,
} from '../helpers';
import { categoryModel } from '@express/modules/category/model-category';

describe('POST /v3-delete-media', () => {
  let category: Components.Schemas.V1Category;

  beforeAll(async () => {
    category = await createCategory();
  });

  afterAll(async () => {
    await categoryModel.deleteMany({});
  });

  it.each([
    [{}],
    [{ ids: 'sorry' }],
    [{ ids: [] }],
    [{ ids: ['sorry'] }],
    [{ ids: ['5e2ecb5ad3d66b512d173953'] }],
    [
      {
        ids: [
          '5e2ecb5ad3d66b512d173953',
          '5e2ecb5c7dd83b640eb220d9',
          '5e2ecb75a0dc6fff63a4a96d',
          '5e2ecb7d0884005d0d74baea',
          '5e2ecb84567d16a1d216ed23',
        ],
      },
    ],
  ])(
    'should return 400 Bad Request on invalid request parameters: %p',
    async (params: any) => {
      await supertest(app)
        .post('/v3-delete-media')
        .send(params)
        .expect(400)
        .expect('Content-Type', /json/);
    },
  );

  it('should delete media (no products linked)', async () => {
    const media: Components.Schemas.V1MediaItem = await uploadMedia();
    const { body } = await supertest(app)
      .post('/v3-delete-media')
      .send({ ids: [media._id] })
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body.isDeleted).toBe(true);
    const data: Paths.V3GetMediaAction.Responses.$200 = await getMedia(
      media._id,
    );
    expect(data.media._id).toEqual(media._id);
    expect(typeof data.media.deletedAt).toBe('string');
    expect(data.products).toEqual([]);
  });

  it('should delete media and change product state if product have only one media', async () => {
    const media: Components.Schemas.V1MediaItem = await uploadMedia();
    const product: Components.Schemas.V3Product = await createProductV3({
      media: [{ id: media._id, type: 'image', sort: 1 }],
      categoryId: category._id,
    });
    expect(product.state).toBe('offline');

    await supertest(app)
      .post('/v3-delete-media')
      .send({ ids: [media._id] })
      .expect(200)
      .expect('Content-Type', /json/);

    const data: Paths.V3GetMediaAction.Responses.$200 = await getMedia(
      media._id,
    );
    expect(typeof data.media.deletedAt).toBe('string');
    expect(data.products).toEqual([]);
  });

  it('should delete media and not change product state if product have more than one media', async () => {
    const media: Components.Schemas.V1MediaItem = await uploadMedia();
    const media2: Components.Schemas.V1MediaItem = await uploadMedia();
    const product: Components.Schemas.V3Product = await createProductV3({
      media: [
        { id: media._id, type: 'image', sort: 1 },
        { id: media2._id, type: 'image', sort: 2 },
      ],
      categoryId: category._id,
    });

    expect(product.state).toBe('offline');

    await supertest(app)
      .post('/v3-delete-media')
      .send({ ids: [media._id] })
      .expect(200)
      .expect('Content-Type', /json/);

    const data: Paths.V3GetMediaAction.Responses.$200 = await getMedia(
      media._id,
    );
    expect(typeof data.media.deletedAt).toBe('string');
    expect(data.products).toEqual([]);

    const data2: Paths.V3GetMediaAction.Responses.$200 = await getMedia(
      media2._id,
    );
    expect(data2.media.deletedAt).toBeFalsy();

    const productCheck: Components.Schemas.V3Product = await getProduct(
      product._id,
    );
    expect(productCheck.state).toBe('offline');
  });
});
