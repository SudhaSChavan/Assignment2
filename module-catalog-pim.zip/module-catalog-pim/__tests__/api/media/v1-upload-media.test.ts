import supertest from 'supertest';
import {
  createCategory,
  getFileBuffer,
  pngFile400px,
  randomString,
  validateMedia,
} from '../helpers';
import { app } from '@src/config/server/server';
import { categoryModel } from '@express/modules/category/model-category';
describe('POST /v1-upload-media', () => {
  let category: Components.Schemas.V1Category;

  beforeAll(async () => {
    category = await createCategory();
  });

  afterAll(async () => {
    await categoryModel.deleteMany({});
  });

  it.each([
    [{ filename: '' }],
    [{ filename: 'a.b' }],
    [{ filename: 'file.xxx' }],
  ])(
    'should return 400 Bad Request on invalid file name/extension: %p',
    async (params) => {
      await supertest(app)
        .post('/v1-upload-media')
        .attach('files[]', pngFile400px, { filename: params.filename })
        .expect(400)
        .expect('Content-Type', /json/);
    },
  );

  it('should return 400 Bad Request when no file provided', async () => {
    await supertest(app)
      .post('/v1-upload-media')
      .expect(400)
      .expect('Content-Type', /json/);
  });

  it('should upload png image', async () => {
    const { body } = await supertest(app)
      .post('/v1-upload-media')
      .attach('files[]', pngFile400px, { filename: `${randomString()}.png` })
      .expect(200)
      .expect('Content-Type', /json/);

    expect(Array.isArray(body)).toBe(true);
    validateMedia(body[0]);
  });

  it('should upload png image with existing name and return old one (check for idempotence)', async () => {
    const filename: string = `${randomString()}.png`;

    const {
      body: [file],
    } = await supertest(app)
      .post('/v1-upload-media')
      .attach('files[]', pngFile400px, { filename })
      .expect(200)
      .expect('Content-Type', /json/);

    validateMedia(file);

    const { body: files } = await supertest(app)
      .post('/v1-upload-media')
      .attach('files[]', pngFile400px, { filename: `${randomString()}.png` })
      .attach('files[]', pngFile400px, { filename })
      .expect(200)
      .expect('Content-Type', /json/);

    expect(files.length).toBe(2);
    files.forEach(validateMedia);
    expect(files.find((f: any) => f._id === file._id)).toEqual(file);
  });

  it('should upload png image with skuGroup', async () => {
    const sku: string = 'TEST-SKU';
    const filename: string = `${sku}_image.png`;
    const {
      body: [image],
    } = await supertest(app)
      .post('/v1-upload-media')
      .attach('files[]', pngFile400px, { filename })
      .field('skuSeparator', '_')
      .expect(200)
      .expect('Content-Type', /json/);

    validateMedia(image);
    expect(image.skuGroup).toEqual(sku);
  });

  it.each([
    [
      {
        file: getFileBuffer('../fixtures/media/pngFile1175x75.png'),
        extension: 'gif',
      },
    ],
  ])(
    'should return 400 Bad Request when file uploaded has invalid dimensions: %p',
    async (params) => {
      await supertest(app)
        .post('/v1-upload-media')
        .attach('files[]', params.file, {
          filename: `${randomString()}.${params.extension}`,
        })
        .expect(400)
        .expect('Content-Type', /json/)
        .expect(/dimension_invalid/);
    },
  );

  it.each([
    [
      {
        file: getFileBuffer('../fixtures/media/pngFile400x600.png'),
        extension: 'png',
      },
    ],
    [
      {
        file: getFileBuffer('../fixtures/media/pngFile400x400.png'),
        extension: 'png',
      },
    ],
    [
      {
        file: getFileBuffer('../fixtures/media/pngFile500x505.png'),
        extension: 'png',
      },
    ],
    [
      {
        file: getFileBuffer('../fixtures/media/docFile.docx'),
        extension: 'docx',
      },
    ],
    [
      {
        file: getFileBuffer('../fixtures/media/movFile.mov'),
        extension: 'mov',
      },
    ],
  ])(
    'should return 200 OK for videos, documents and valid dimensions images: %p',
    async (params) => {
      await supertest(app)
        .post('/v1-upload-media')
        .attach('files[]', params.file, {
          filename: `${randomString()}.${params.extension}`,
        })
        .expect(200)
        .expect('Content-Type', /json/);
    },
  );

  it('should return 400 if files count > 1 and replaceMediaId is provided', async () => {
    await supertest(app)
      .post('/v1-upload-media')
      .attach('files[]', pngFile400px, { filename: `${randomString()}.png` })
      .attach('files[]', pngFile400px, { filename: `${randomString()}.png` })
      .field('replaceMediaId', '5e4e8cfc123ac0e4c0d96f1f')
      .expect(400)
      .expect('Content-Type', /json/);
  });

  it('should return 400 on invalid replace media id', async () => {
    await supertest(app)
      .post('/v1-upload-media')
      .attach('files[]', pngFile400px, { filename: `${randomString()}.png` })
      .field('replaceMediaId', '123')
      .expect(400)
      .expect('Content-Type', /json/);
  });

  it('should return 404 on unknown replace media id', async () => {
    await supertest(app)
      .post('/v1-upload-media')
      .attach('files[]', pngFile400px, { filename: `${randomString()}.png` })
      .field('replaceMediaId', '5e4e8cfc123ac0e4c0d96f1f')
      .expect(404)
      .expect('Content-Type', /json/);
  });

  it('should return 400 on replace media type mismatch', async () => {
    const {
      body: [media],
    } = await supertest(app)
      .post('/v1-upload-media')
      .attach('files[]', pngFile400px, { filename: `${randomString()}.png` })
      .expect(200)
      .expect('Content-Type', /json/);

    await supertest(app)
      .post('/v1-upload-media')
      .attach('files[]', getFileBuffer('../fixtures/media/docFile.docx'), {
        filename: `${randomString()}.docx`,
      })
      .field('replaceMediaId', media._id)
      .expect(400)
      .expect('Content-Type', /json/);
  });

  it('should replace media', async () => {
    const {
      body: [media],
    } = await supertest(app)
      .post('/v1-upload-media')
      .attach('files[]', pngFile400px, { filename: `${randomString()}.png` })
      .expect(200)
      .expect('Content-Type', /json/);

    validateMedia(media);

    const {
      body: [replacedMedia],
    } = await supertest(app)
      .post('/v1-upload-media')
      .attach('files[]', pngFile400px, { filename: `${randomString()}.png` })
      .field('replaceMediaId', media._id)
      .expect(200)
      .expect('Content-Type', /json/);

    validateMedia(replacedMedia);
    expect(replacedMedia._id).toEqual(media._id);
    expect(replacedMedia.name).not.toEqual(media.name);
    expect(replacedMedia.url).not.toEqual(media.url);
  });
});
