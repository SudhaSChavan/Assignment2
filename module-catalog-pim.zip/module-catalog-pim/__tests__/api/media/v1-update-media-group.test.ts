import supertest from 'supertest';

import { getMedia, getMongoId, uploadMedia } from '../helpers';
import { app } from '@src/config/server/server';

describe('POST /v1-update-media-group', () => {
  it.each([
    [{ id: getMongoId() }],
    [{ id: getMongoId(), group: 1 }],
    [{ id: 1, group: 'group name' }], //
  ])(
    'should return 400 Bad Request on invalid file name/extension: %p',
    async (params) => {
      await supertest(app)
        .post('/v1-update-media-group')
        .send(params)
        .expect(400)
        .expect('Content-Type', /json/);
    },
  );

  it('should return 404 Bad Request when media not found', async () => {
    await supertest(app)
      .post('/v1-update-media-group')
      .send({ id: getMongoId(), group: 'name' })
      .expect(404)
      .expect('Content-Type', /json/);
  });

  it('should update media group', async () => {
    const media: Components.Schemas.V1MediaItem = await uploadMedia();
    expect(media.group).toEqual('');

    const { body } = await supertest(app)
      .post('/v1-update-media-group')
      .send({ id: media._id, group: 'test group' })
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body.isUpdated).toBe(true);

    const sameMedia: Paths.V3GetMediaAction.Responses.$200 = await getMedia(
      media._id,
    );
    expect(sameMedia.media.group).toEqual('test group');
  });
});
