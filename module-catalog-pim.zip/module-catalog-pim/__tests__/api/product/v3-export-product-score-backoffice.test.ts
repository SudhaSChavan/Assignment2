import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { createCategory } from '../helpers';
import { V1InternalGetProductAction } from '@tradeling/tradeling-sdk/catalog-search/v1-internal-get-product-action';
import { categoryModel } from '@express/modules/category/model-category';

jest.mock(
  '@tradeling/tradeling-sdk/catalog-search/v1-internal-get-product-action',
);
const mockV1GetProductAction: jest.MockedFunction<
  typeof V1InternalGetProductAction
> = <jest.MockedFunction<typeof V1InternalGetProductAction>>(
  (V1InternalGetProductAction as any)
);

mockV1GetProductAction.mockImplementation(async (request) => {
  return {
    status: 200,
    data: [],
  } as any;
});

describe('POST /v3-export-product-score-backoffice', () => {
  afterEach(async () => {
    await categoryModel.deleteMany({});
  });

  it('should return 200', async () => {
    const category: Components.Schemas.V1Category = await createCategory();
    const params: Paths.V3ExportProductScoreBackofficeAction.RequestBody = {
      categoryId: category._id,
    };
    const { body, status } = await supertest(app)
      .post('/v3-export-product-score-backoffice')
      .send(params);
    expect(status).toBe(200);
  });
});
