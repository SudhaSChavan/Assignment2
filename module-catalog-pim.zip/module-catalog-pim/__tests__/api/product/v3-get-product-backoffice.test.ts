import supertest from 'supertest';
import { app } from '@src/config/server/server';
import {
  createCategory,
  validateProduct,
  createProductHelper,
  cleanUpV3,
} from '../helpers';
import { mockStoreByStoreId } from '@__tests__/api/product/mocks/www-sdk.mock';
import { mockV1InternalListUsers } from '@__tests__/api/product/mocks/account-sdk.mock';

describe('POST /v3-get-product-backoffice', () => {
  let category: Components.Schemas.V1Category;
  let product: Components.Schemas.V3Product;

  beforeAll(async () => {
    mockStoreByStoreId();
    mockV1InternalListUsers();
    category = await createCategory();
    product = await createProductHelper(category);
  });

  afterAll(async () => {
    await cleanUpV3();
  });

  it.each([[{ id: '' }], [{ id: 'sorry' }], [{ sku: '' }]])(
    'should return 400 Bad Request on invalid request parameters: %p',
    async (params: any) => {
      const { body } = await supertest(app)
        .post('/v3-get-product-backoffice')
        .send(params)
        .expect(400)
        .expect('Content-Type', /json/);
    },
  );

  it('should return product by sku', async () => {
    const { body } = await supertest(app)
      .post('/v3-get-product-backoffice')
      .send({ sku: product.sku })
      .expect(200)
      .expect('Content-Type', /json/);
    validateProduct(body);
  });

  it('should return 404 Not Found on unknown sku', async () => {
    await supertest(app)
      .post('/v3-get-product-backoffice')
      .send({ sku: 'who cares?' })
      .expect(404)
      .expect('Content-Type', /json/);
  });
});
