import supertest from 'supertest';
import {
  cleanUpV3,
  createCategory,
  getProduct,
  getSingleProductParamsWithOffer,
  randomString,
  uploadMedia,
} from '../helpers';
import { app } from '@src/config/server/server';
import V1MediaItem = Components.Schemas.V1MediaItem;
import { mediaModel } from '@express/modules/media/model-media';
import { mockStoreByStoreId } from '@__tests__/api/product/mocks/www-sdk.mock';
import { mockV1InternalListUsers } from '@__tests__/api/product/mocks/account-sdk.mock';

describe('POST /v3-reassign-media-by-sku', () => {
  let category: Components.Schemas.V1Category;
  let productParamsWithOffer: Partial<Components.RequestBodies.V3CreateProduct>;

  beforeAll(async () => {
    await cleanUpV3();
    await mediaModel.deleteMany({});
    mockStoreByStoreId();
    mockV1InternalListUsers();
  });

  afterEach(async () => {
    await cleanUpV3();
    await mediaModel.deleteMany({});
  });

  beforeEach(async () => {
    category = await createCategory();
    productParamsWithOffer = getSingleProductParamsWithOffer({
      categoryId: category._id,
    });
  });
  it('should assign media by sku group', async () => {
    const sku: string = randomString();

    const params: Partial<Components.RequestBodies.V3CreateProduct> = getSingleProductParamsWithOffer(
      {
        categoryId: category._id,
        sku,
      },
    );
    const { body: product } = await supertest(app)
      .post('/v3-create-product')
      .set('x-store-id', 'tcom-ae')
      .send(params)
      .expect(200)
      .expect('Content-Type', /json/);

    const media: V1MediaItem = await uploadMedia(sku);

    const { body } = await supertest(app)
      .post('/v3-reassign-media-by-sku')
      .send({ id: product._id })
      .expect(200)
      .expect('Content-Type', /json/);

    const newProductData: Components.Schemas.V3Product = await getProduct(
      product._id,
    );

    expect(newProductData.media[0].id).toBe(media._id);
  });

  it('should assign additional media by sku group and set max sort', async () => {
    const firstMedia: Components.Schemas.V1MediaItem = await uploadMedia();
    const sku: string = randomString();

    const params: Partial<Components.RequestBodies.V3CreateProduct> = getSingleProductParamsWithOffer(
      {
        categoryId: category._id,
        sku,
        media: [
          {
            id: firstMedia._id,
            type: firstMedia.type,
            sort: 100,
            title: firstMedia.originalName,
          },
        ],
      },
    );
    const { body: product } = await supertest(app)
      .post('/v3-create-product')
      .set('x-store-id', 'tcom-ae')
      .send(params)
      .expect(200)
      .expect('Content-Type', /json/);

    const newMedia: V1MediaItem = await uploadMedia(sku);

    await supertest(app)
      .post('/v3-reassign-media-by-sku')
      .send({ id: product._id })
      .expect(200)
      .expect('Content-Type', /json/);

    const newProductData: Components.Schemas.V3Product = await getProduct(
      product._id,
    );
    expect(newProductData.media[0].id).toBe(firstMedia._id);
    expect(newProductData.media[0].sort).toBe(100);
    expect(newProductData.media[1].id).toBe(newMedia._id);
    expect(newProductData.media[1].sort).toBeGreaterThan(
      newProductData.media[0].sort,
    );
  });
});
