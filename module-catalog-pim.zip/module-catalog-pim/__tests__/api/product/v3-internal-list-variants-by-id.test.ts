import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { cleanUpV3, insertProductData } from '../helpers';
import { getInternalApiSecret } from '@tradeling/web-js-utils';
import { appConfig } from '@src/config/env';
import { IProductModelV3 } from '@express/modules/product/model-product-v3';

type RequestBody = Paths.V3InternalListVariantsByIdAction.RequestBody;
describe('POST /v3-internal-list-variants-by-id', () => {
  beforeAll(async () => {
    await cleanUpV3();
    process.env[`IN_FROM_MODULE_1`] = 'secret';
    process.env[`OUT_TO_MODULE_CATALOG_PIM`] = 'secret';
  });

  afterAll(async () => {
    await cleanUpV3();
  });

  // invalid filters
  const invalidFilters: RequestBody[] = [
    { ids: null },
    { ids: [] },
    { parentSkus: null },
    { parentSkus: [] },
    { isDefault: null },
  ];
  it.each(invalidFilters)(
    'should return 400 Bad Request on invalid request parameters: %p',
    async (params) => {
      await callListProductByIdApi(params)
        .expect(400)
        .expect('Content-Type', /json/);
    },
  );

  it('should return 404 on invalid ids', async () => {
    const payload: RequestBody = { ids: ['5e2ecb5ad3d66b512d173953'] };
    const { status } = await callListProductByIdApi(payload);
    expect(status).toBe(404);
  });

  it('should return 404 on invalid parentSkus', async () => {
    const payload: RequestBody = { parentSkus: ['dummy', 'sorry'] };
    const { status } = await callListProductByIdApi(payload);
    expect(status).toBe(404);
  });

  it(`should return 200 with list of products by ids`, async () => {
    const products: IProductModelV3[] = await insertProductData(2);
    const payload: RequestBody = {
      ids: products.map((product) => product._id.toString()),
    };
    const { body, status } = await callListProductByIdApi(payload);
    expect(status).toBe(200);
    expect(body.length).toBe(2);
  });

  it(`should return 200 with list of products by parentSkus`, async () => {
    const products: IProductModelV3[] = await insertProductData(2);
    const payload: RequestBody = {
      parentSkus: products.map((product) => product.parentSku),
    };
    const { body, status } = await callListProductByIdApi(payload);
    expect(status).toBe(200);
    expect(body.length).toBe(2);
  });
});

function callListProductByIdApi(payload: RequestBody) {
  return supertest(app)
    .post('/v3-internal-list-variants-by-id')
    .set('x-is-internal-request', '1')
    .set(
      'x-t-secret',
      getInternalApiSecret({ to: appConfig.name, from: 'module-1' }),
    )
    .send(payload);
}
