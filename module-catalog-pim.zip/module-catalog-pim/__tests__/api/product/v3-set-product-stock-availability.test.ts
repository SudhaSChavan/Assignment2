import supertest from 'supertest';

import { app } from '@src/config/server/server';
import {
  cleanUpV3,
  createCategory,
  createProductHelper,
  getProduct,
} from '../helpers';
import { mockStoreByStoreId } from '@__tests__/api/product/mocks/www-sdk.mock';
import { mockV1InternalListUsers } from '@__tests__/api/product/mocks/account-sdk.mock';

describe('POST /v3-set-product-stock-availability', () => {
  let category: Components.Schemas.V1Category;

  beforeAll(async () => {
    await cleanUpV3();
    mockStoreByStoreId();
    mockV1InternalListUsers();
  });

  afterEach(async () => {
    await cleanUpV3();
  });

  beforeEach(async () => {
    category = await createCategory();
  });
  it.each([
    [{}],
    [{ ids: 'sorry' }],
    [{ ids: [] }],
    [{ ids: ['sorry'] }],
    [
      {
        ids: [
          '5e2ecb5ad3d66b512d173953',
          '5e2ecb5c7dd83b640eb220d9',
          '5e2ecb75a0dc6fff63a4a96d',
          '5e2ecb7d0884005d0d74baea',
          '5e2ecb84567d16a1d216ed23',
        ],
      },
    ],
    [{ ids: ['5e2ecb5ad3d66b512d173953'] }],
    [{ ids: ['5e2ecb5ad3d66b512d173953'], isInStock: 'Not Boolean' }],
    [{ ids: ['5e2ecb5ad3d66b512d173953'], isInStock: 2020 }],
  ])(
    'should return 400 Bad Request on invalid request parameters: `%p`',
    async (params: any) => {
      await supertest(app)
        .post('/v3-set-product-stock-availability')
        .send(params)
        .expect(400)
        .expect('Content-Type', /json/);
    },
  );

  it.each([true, false])(
    'should change products stock availability to `%p`',
    async (isInStock: boolean) => {
      const product1: Components.Schemas.V3Product = await createProductHelper(
        category,
      );
      const product2: Components.Schemas.V3Product = await createProductHelper(
        category,
      );

      const { body } = await supertest(app)
        .post('/v3-set-product-stock-availability')
        .send({ ids: [product1._id, product2._id], isInStock })
        .expect(200)
        .expect('Content-Type', /json/);

      expect(body.isUpdated).toBe(true);
      const updatedProduct1: Components.Schemas.V3Product = await getProduct(
        product1._id,
      );
      const updatedProduct2: Components.Schemas.V3Product = await getProduct(
        product1._id,
      );
      expect(updatedProduct1.isInStock).toBe(isInStock);
      expect(updatedProduct2.isInStock).toBe(isInStock);
    },
  );
});
