import nock, { Scope } from 'nock';
import { MockUserDataSource } from '@tradeling/shared';

const host: Scope = nock(/b2b.localhost|tradeling/);

export function mockV1GetSupplierCompany(): any {
  host
    .persist(true)
    .post('/api/module-account/v1-get-supplier-company', {
      id: '5e08ad5c092c1b7d8e9e3040',
    })
    .reply(200, {
      _id: '5e08ad5c092c1b7d8e9e3040',
      isActive: false,
      isVerified: true,
      status: 'accepted',
      ownerId: '5e08ad5c092c1b7d8e9e3034',
      createdAt: '2021-02-16T12:42:58.950Z',
      updatedAt: '2021-02-16T12:44:55.912Z',
      metadata: {
        isSkippedDocumentUpload: true,
      },
    });
}

export function mockV1InternalListUsers(): any {
  host
    .persist(true)
    .post('/api/module-account/v1-internal-list-users', {
      filter: {
        ids: ['5e08ad5c092c1b7d8e9e3034'],
      },
      pageSize: 1,
    })
    .reply(200, {
      data: [MockUserDataSource.mockedUsers[0]],
    });
}
