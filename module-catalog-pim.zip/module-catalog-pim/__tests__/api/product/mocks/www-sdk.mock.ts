import nock from 'nock';

const host: nock.Scope = nock(/b2b.localhost|tradeling/);

export function mockStoreByStoreId(): any {
  host
    .persist()
    .get('/api/module-www/v1/stores/store-code/tcom-ae')
    .reply(200, {
      id: '5285ca29-2bc8-4f6d-9b81-7325127b127f',
      storeKeyId: 'tcom-ae',
      storeCode: 'ae',
      name: 'Tradeling Web UAE',
      websiteId: '29cd07c0-6c8e-46ff-b6c9-7e63f440146f',
      languages: ['AR', 'EN'],
      defaultLanguage: 'AR',
      currencies: ['USD', 'AED'],
      defaultCurrency: 'AED',
      settings: {
        wms: [
          {
            warehouseLabel: 'DC1',
            closingAt: '2022-04-17T02:00:00GMTZ',
            isDefault: true,
          },
          {
            warehouseLabel: 'AABCCE',
            openingAt: '2022-04-17T02:00:00GMTZ',
            isDefault: false,
          },
        ],
      },
      createdAt: '2021-08-15T13:31:39.534Z',
      updatedAt: '2022-04-04T08:20:08.249Z',
      website: {
        id: '29cd07c0-6c8e-46ff-b6c9-7e63f440146f',
        websiteCode: 'tcom',
        label: 'Tradeling.com',
        createdAt: '2021-08-11T12:19:22.586Z',
        updatedAt: '2021-11-09T07:18:25.912Z',
      },
    });
}
