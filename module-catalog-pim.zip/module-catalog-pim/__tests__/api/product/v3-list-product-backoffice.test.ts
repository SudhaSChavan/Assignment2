import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { V1ListCompanyProfileBackofficeAction } from '@tradeling/tradeling-sdk/seller-center/v1-list-company-profile-backoffice-action';
import { cleanUpV3, insertProductData } from '../helpers';
import { IProductModelV3 } from '@express/modules/product/model-product-v3';
jest.mock(
  '@tradeling/tradeling-sdk/seller-center/v1-list-company-profile-backoffice-action',
);

const mockV1ListCompanyProfileBackofficeAction: jest.MockedFunction<
  typeof V1ListCompanyProfileBackofficeAction
> = <jest.MockedFunction<typeof V1ListCompanyProfileBackofficeAction>>(
  (V1ListCompanyProfileBackofficeAction as any)
);

mockV1ListCompanyProfileBackofficeAction.mockImplementation((request) => {
  const data: SellerCenter.Components.Schemas.CompanyProfile[] = (
    request?.filter?.companyIds || []
  ).map((id: string) => {
    return {
      _id: id,
      companyName: '',
      supplierCompanyId: id,
      supplierId: id,
    } as SellerCenter.Components.Schemas.CompanyProfile;
  });
  return {
    status: 200,
    data: data,
  } as any;
});
describe('POST /v3-list-product-backoffice', () => {
  let testProducts: IProductModelV3[] = [];

  beforeEach(async () => {
    await cleanUpV3();
  });

  afterEach(async () => {
    await cleanUpV3();
  });

  it.each([
    [{ size: ' ' }, 400],
    [{ size: -1 }, 400],
    [{ size: 0 }, 400],
    [{ size: 10000000 }, 400],
    [{ size: null }, 400],
    [{ size: undefined }, 200], //default value defined
    [{ size: 'invalid-param' }, 400],
    [
      {
        filter: {
          isReadyToShip: ' ',
        },
      },
      400,
    ],
    [
      {
        filter: {
          isReadyToShip: 'invalid-param',
        },
      },
      400,
    ],
  ])(
    'given %p as input parameter, should return response as code- %p',
    async (params: any, expectedResult) => {
      await supertest(app)
        .post('/v3-list-product-backoffice')
        .send(params)
        .expect(expectedResult)
        .expect('Content-Type', /json/);
    },
  );

  it('should return order list with correct count of products', async () => {
    testProducts = await insertProductData(2);
    const size: number = 2;
    const { body: listProductRes, status } = await supertest(app)
      .post('/v3-list-product-backoffice')
      .send({ size });

    expect(status).toBe(200);
    expect(typeof listProductRes.size).toBe('number');
    expect(typeof listProductRes.totalRecords).toBe('number');
    expect(typeof listProductRes.totalRecords).toBe('number');
    expect(listProductRes.products.length).toEqual(size);
    expect(listProductRes.size).toEqual(size);
    expect(listProductRes.totalRecords).toEqual(2);
  });

  it('should return product list with pagination values for 2 pages ', async () => {
    testProducts = await insertProductData(5);

    const size: number = 2;
    const { body: page1 } = await supertest(app)
      .post('/v3-list-product-backoffice')
      .send({ size, page: 1 });

    expect(page1.products.length).toEqual(size);
    expect(page1.size).toEqual(size);
    expect(page1.currentPage).toEqual(1);

    const { body: page2 } = await supertest(app)
      .post('/v3-list-product-backoffice')
      .send({ size: 2, page: 2 });

    expect(page2.products.length).toEqual(size);
    expect(page2.size).toEqual(size);
    expect(page2.currentPage).toEqual(2);
  });
});
