import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { cleanUpV3, createCategory, createProductHelper } from '../helpers';
import { mockStoreByStoreId } from '@__tests__/api/product/mocks/www-sdk.mock';
import { mockV1InternalListUsers } from '@__tests__/api/product/mocks/account-sdk.mock';
import {
  InternalReviewStatuses,
  ProductStates,
} from '@express/modules/product/types';

type RequestBody = Paths.V3ListProductAction.RequestBody;
describe('POST /v3-list-product', () => {
  let category: Components.Schemas.V1Category;
  beforeAll(async () => {
    await cleanUpV3();
    mockStoreByStoreId();
    mockV1InternalListUsers();
    category = await createCategory();
  });

  beforeEach(async () => {
    await cleanUpV3();
    category = await createCategory();
  });

  afterAll(async () => {
    await cleanUpV3();
  });

  // invalid filters
  const invalidFilters: any[] = [
    { page: -1, filter: {} },
    { size: -1, filter: {} },
    { sort: null, filter: {} },
    { filter: { categoryId: null } },
    { filter: { categoryId: '123123' } },
    { filter: { categoryIds: null } },
    { filter: { categoryIds: ['123', 'some-id'] } },
    { filter: { ids: null } },
    { filter: { ids: ['123', 'some-id'] } },
    { filter: { state: '123' } },
    { filter: { internalReviewStatus: '123' } },
  ];
  it.each(invalidFilters)(
    'should return 400 Bad Request on invalid request parameters: %p',
    async (params) => {
      await callListProductApi(params)
        .expect(400)
        .expect('Content-Type', /json/);
    },
  );

  it(`should return 200 with list of products by ids`, async () => {
    const product: Components.Schemas.V3Product = await createProductHelper(
      category,
    );
    const product2: Components.Schemas.V3Product = await createProductHelper(
      category,
    );
    const payload: RequestBody = {
      page: 1,
      size: 2,
      filter: {
        ids: [product._id.toString(), product2._id.toString()],
      },
    };

    const { body, status } = await callListProductApi(payload);

    expect(status).toBe(200);
    expect(body.currentPage).toBe(1);
    expect(body.totalPages).toBe(1);
    expect(body.totalRecords).toBe(2);
    expect(body.size).toBe(2);
  });

  it(`should return 200 with list of products by ids`, async () => {
    await createProductHelper(category);
    await createProductHelper(category);
    const payload: RequestBody = {
      page: 1,
      size: 2,
      filter: {
        categoryId: category._id.toString(),
      },
    };

    const { body, status } = await callListProductApi(payload);

    expect(status).toBe(200);
    expect(body.currentPage).toBe(1);
    expect(body.totalPages).toBe(1);
    expect(body.totalRecords).toBe(2);
    expect(body.size).toBe(2);
  });

  it(`should return 200 with list of products by Product State`, async () => {
    await createProductHelper(category);
    await createProductHelper(category);
    const payload: RequestBody = {
      page: 1,
      size: 2,
      filter: {
        state: ProductStates.Offline,
      },
    };

    const { body, status } = await callListProductApi(payload);

    expect(status).toBe(200);
    expect(body.currentPage).toBe(1);
    expect(body.totalPages).toBe(1);
    expect(body.totalRecords).toBe(2);
    expect(body.size).toBe(2);
  });

  it(`should return 200 with list of products by InternalReviewStatuses`, async () => {
    await createProductHelper(category);
    await createProductHelper(category);
    const payload: RequestBody = {
      page: 1,
      size: 2,
      filter: {
        internalReviewStatus: InternalReviewStatuses.Pending,
      },
    };

    const { body, status } = await callListProductApi(payload);

    expect(status).toBe(200);
    expect(body.currentPage).toBe(1);
    expect(body.totalPages).toBe(1);
    expect(body.totalRecords).toBe(2);
    expect(body.size).toBe(2);
  });
});

function callListProductApi(payload: RequestBody) {
  return supertest(app)
    .post('/v3-list-product')
    .set('x-store-id', 'tcom-ae')
    .send(payload);
}
