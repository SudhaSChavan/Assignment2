import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { cleanUpV3, insertProductData } from '../helpers';
import { getInternalApiSecret } from '@tradeling/web-js-utils';
import { appConfig } from '@src/config/env';

type RequestBody = Paths.V3InternalGetProductCountAction.RequestBody;

describe('POST /v1-internal-get-product-count', () => {
  beforeAll(() => {
    process.env[`IN_FROM_MODULE_1`] = 'secret';
    process.env[`OUT_TO_MODULE_CATALOG_PIM`] = 'secret';
  });

  beforeEach(async () => {
    await cleanUpV3();
  });

  // invalid filters
  const invalidFilters: RequestBody[] = [{ supplierCompanyIds: null }];
  it.each(invalidFilters)(
    'should return 400 Bad Request on invalid request parameters: %p',
    async (params) => {
      await getProductCountApi(params)
        .expect(400)
        .expect('Content-Type', /json/);
    },
  );

  it(`should return count of products by supplier ID`, async () => {
    const supplierOne: string = '5fbb4a4542480f001bed8600';
    const supplierTwo: string = '5fbb4a4542480f001bed8601';
    await insertProductData(2, (product) => {
      return {
        ...product,
        supplierCompanyId: supplierOne,
        state: 'online',
      };
    });
    await insertProductData(3, (product) => {
      return {
        ...product,
        supplierCompanyId: supplierTwo,
        state: 'offline',
      };
    });
    const payload: RequestBody = {
      supplierCompanyIds: [supplierOne, supplierTwo],
    };
    const { body, status } = await getProductCountApi(payload);
    expect(status).toBe(200);
    expect(body[supplierOne].totalOnlineProducts).toBe(2);
    expect(body[supplierOne].totalOfflineProducts).toBe(0);
    expect(body[supplierOne].totalProducts).toBe(2);

    expect(body[supplierTwo].totalOnlineProducts).toBe(0);
    expect(body[supplierTwo].totalOfflineProducts).toBe(3);
    expect(body[supplierTwo].totalProducts).toBe(3);
  });
});

function getProductCountApi(payload: RequestBody) {
  return supertest(app)
    .post('/v3-internal-get-product-count')
    .set('x-is-internal-request', '1')
    .set(
      'x-t-secret',
      getInternalApiSecret({ to: appConfig.name, from: 'module-1' }),
    )
    .send(payload);
}
