import supertest from 'supertest';
import { app } from '@src/config/server/server';
import {
  cleanUpV3,
  createCategory,
  getProduct,
  getProductParamsV3,
  getSingleProductParamsWithOffer,
  randomString,
  uploadMedia,
  validateProduct,
} from '../helpers';
import { mockStoreByStoreId } from '@__tests__/api/product/mocks/www-sdk.mock';
import map from 'lodash/map';
import { InternalReviewStatuses } from '@express/modules/product/types';
import {
  mockV1GetSupplierCompany,
  mockV1InternalListUsers,
} from '@__tests__/api/product/mocks/account-sdk.mock';

describe('POST /v3-create-product', () => {
  let category: Components.Schemas.V1Category;
  let productParams: Components.RequestBodies.V3CreateProduct;
  let productParamsWithOffer: Partial<Components.RequestBodies.V3CreateProduct>;

  afterEach(async () => {
    await cleanUpV3();
  });

  beforeEach(async () => {
    mockStoreByStoreId();
    category = await createCategory();
    productParams = getProductParamsV3({ categoryId: category._id });
    productParamsWithOffer = getSingleProductParamsWithOffer({
      categoryId: category._id,
    });
  });

  it.each([
    [{ params: { sku: 1 }, invalidParams: ['sku'] }],
    [{ params: { categoryId: 'invalidID' }, invalidParams: ['categoryId'] }],
    [
      {
        params: {
          name: { en: 'product name' },
          description: { en: 'long description' },
          keywords: '',
        },
        invalidParams: ['keywords.en'],
      },
    ],
    [
      {
        params: {
          name: { en: 'product name' },
          description: { en: 'long description' },
          keywords: 'key, word',
        },
        invalidParams: ['keywords.en'],
      },
    ],
    [
      {
        params: {
          keywords: 'key, word',
          categoryId: '5e41ddc4ccab0b5830ed4ba8',
        },
        invalidParams: ['keywords.en', 'categoryId'],
      },
    ],
    [
      {
        params: { keywords: ['keyword'], type: 2, unit: 5 },
        invalidParams: ['unit'],
      },
    ],
    [{ params: { name: undefined }, invalidParams: ['name.en'] }],
    [{ params: { sku: undefined }, invalidParams: ['sku'] }],
    [
      {
        params: { shortDescription: undefined },
        invalidParams: ['shortDescription.en'],
      },
    ],
    [{ params: { categoryId: undefined }, invalidParams: ['categoryId'] }],
  ])(
    'should return 400 Bad Request on invalid request parameters: %p',
    async ({ params, invalidParams }) => {
      const { body } = await supertest(app)
        .post('/v3-create-product')
        .send({ ...productParams, ...params })
        .expect(400)
        .expect('Content-Type', /json/);

      expect(map(body.errors, 'param')).toEqual(
        expect.arrayContaining(invalidParams),
      );
    },
  );

  it('should return 400 Bad Request if SKU already exist', async () => {
    const params: any = {
      ...productParamsWithOffer,
      sku: randomString(),
      storeCode: 'ae',
      storeKeyId: 'tcom-ae',
      websiteCode: 'tcom',
    };

    const { body: product1, status } = await supertest(app)
      .post('/v3-create-product')
      .set('x-store-id', 'tcom-ae')
      .send(params);
    validateProduct(product1);

    await supertest(app)
      .post('/v3-create-product')
      .send(params)
      .expect(400)
      .expect('Content-Type', /json/)
      .expect(/duplicate/i);
  });

  it('should return 200 Request by adding barcode and strategy', async () => {
    const { _id: mediaId } = await uploadMedia();

    const params: any = {
      ...productParamsWithOffer,
      barcode: '123123',
      sku: randomString(),
      media: [
        {
          id: mediaId,
          type: 'image',
          sort: 1,
        },
      ],
      storeCode: 'ae',
      storeKeyId: 'tcom-ae',
      websiteCode: 'tcom',
    };
    const { body: product, status } = await supertest(app)
      .post('/v3-create-product')
      .set('x-store-id', 'tcom-ae')
      .send(params);

    expect(status).toBe(200);
    validateProduct(product);
  });

  it('should create new product without media', async () => {
    const { body: product } = await supertest(app)
      .post('/v3-create-product')
      .set('x-store-id', 'tcom-ae')
      .send(productParamsWithOffer)
      .expect(200)
      .expect('Content-Type', /json/);

    validateProduct(product);
    expect(product.categoryId).toEqual(category._id);
    expect(product.sku).toEqual(productParamsWithOffer.sku.toUpperCase());
    expect(product.name.en).toEqual(productParamsWithOffer.name.en);
    expect(product.shortDescription.en).toEqual(
      productParamsWithOffer.shortDescription.en,
    );
    expect(product.keywords.en).toEqual(productParamsWithOffer.keywords.en);
  });

  it('should create new product with media', async () => {
    const { _id: mediaId } = await uploadMedia();

    const { body: product } = await supertest(app)
      .post('/v3-create-product')
      .set('x-store-id', 'tcom-ae')
      .send({
        ...productParamsWithOffer,
        media: [
          {
            id: mediaId,
            type: 'image',
            sort: 1,
            title: 'New media in object',
          },
        ],
      })
      .expect(200)
      .expect('Content-Type', /json/);

    validateProduct(product);
    expect(product.media).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          id: mediaId,
          sort: 1,
          title: 'New media in object',
          type: 'image',
        }),
      ]),
    );
  });

  it('should strip html from short description and name', async () => {
    const { body: product } = await supertest(app)
      .post('/v3-create-product')
      .set('x-store-id', 'tcom-ae')
      .send({
        ...productParamsWithOffer,
        name: { en: '<h1>Big One</h1>' },
        shortDescription: { en: '<div>Short <p>Description</p></div>' },
        longDescription: { en: '<p>Long <a>Description</a></p>' },
      })
      .expect(200)
      .expect('Content-Type', /json/);

    validateProduct(product);
    expect(product.name.en).toEqual('Big One');
    expect(product.shortDescription.en).toEqual('Short Description');
    expect(product.longDescription.en).toEqual(
      '<p>Long <a>Description</a></p>',
    );
  });

  it('should create new product with valid configuration attributes values', async () => {
    const params: any = {
      ...productParamsWithOffer,
      parentSku: 'test-configuration',
      internalReviewStatus: InternalReviewStatuses.Accepted,
      variantValues: [
        {
          code: 'color',
          value: {
            en: 'red',
            ar: 'ar_red',
          },
        },
        {
          code: 'color',
          value: {
            en: 'blue',
            ar: 'ar_blue',
          },
        },
      ],
    };

    const { body: product } = await supertest(app)
      .post('/v3-create-product')
      .set('x-store-id', 'tcom-ae')
      .send(params)
      .expect(200)
      .expect('Content-Type', /json/);

    mockV1GetSupplierCompany();
    mockV1InternalListUsers();

    const updatedProduct: Components.Schemas.V3Product = await getProduct(
      product._id,
    );

    validateProduct(updatedProduct);

    expect(updatedProduct.configurationAttributes[0]).toEqual(
      expect.objectContaining({
        options: ['red', 'blue'],
        code: 'color',
      }),
    );
  });

  it.each([
    [{}],
    [{ code: 33 }],
    [{ code: 33, label: 'some label', values: [3, 'values'] }],
  ])(
    'should return 400 Bad Request if configuration attributes values are invalid',
    async (configurationAttributes) => {
      const params: any = {
        ...productParamsWithOffer,
        configurationAttributes: [configurationAttributes],
      };

      await supertest(app)
        .post('/v3-create-product')
        .set('x-store-id', 'tcom-ae')
        .send(params)
        .expect(400)
        .expect('Content-Type', /json/);
    },
  );
});
