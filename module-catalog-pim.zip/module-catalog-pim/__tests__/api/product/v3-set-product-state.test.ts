import nock from 'nock';
import supertest from 'supertest';
import { app } from '@src/config/server/server';
import {
  approveProduct,
  changeProductState,
  cleanUpV3,
  createCategory,
  createProductHelper,
  createProductWithMediaHelper,
  getProduct,
  uploadMedia,
} from '../helpers';
import { mockStoreByStoreId } from '@__tests__/api/product/mocks/www-sdk.mock';
import {
  mockV1GetSupplierCompany,
  mockV1InternalListUsers,
} from '@__tests__/api/product/mocks/account-sdk.mock';
import { ProductStates } from '@express/modules/product/types';

describe('POST /v3-set-product-state', () => {
  let category: Components.Schemas.V1Category;

  beforeAll(async () => {
    mockStoreByStoreId();
    mockV1GetSupplierCompany();
    mockV1InternalListUsers();
  });

  afterEach(async () => {
    await cleanUpV3();
  });

  beforeEach(async () => {
    category = await createCategory();
  });

  afterAll((): void => {
    nock.cleanAll();
  });

  it.each([
    [{}],
    [{ ids: 'sorry' }],
    [{ ids: [] }],
    [{ ids: ['sorry'] }],
    [
      {
        ids: [
          '5e2ecb5ad3d66b512d173953',
          '5e2ecb5c7dd83b640eb220d9',
          '5e2ecb75a0dc6fff63a4a96d',
          '5e2ecb7d0884005d0d74baea',
          '5e2ecb84567d16a1d216ed23',
        ],
      },
    ],
    [{ ids: ['5e2ecb5ad3d66b512d173953'] }],
    [{ ids: ['5e2ecb5ad3d66b512d173953'], state: 'sorry' }],
  ])(
    'should return 400 Bad Request on invalid request parameters: %p',
    async (params: any) => {
      await supertest(app)
        .post('/v3-set-product-state')
        .send(params)
        .expect(400)
        .expect('Content-Type', /json/);
    },
  );

  it('should set 1 product state to offline', async () => {
    const product: Components.Schemas.V3Product = await createProductHelper(
      category,
    );
    await approveProduct(product._id);
    await changeProductState(product._id, ProductStates.Online);

    const { body } = await supertest(app)
      .post('/v3-set-product-state')
      .send({ ids: [product._id], state: 'offline' })
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body.isUpdated).toBe(true);

    const updatedProduct: Components.Schemas.V3Product = await getProduct(
      product._id,
    );

    expect(updatedProduct.state).toBe('offline');
  });

  it('should set 2 product state to offline and back to online', async () => {
    const { _id: mediaId } = await uploadMedia();

    const product: Components.Schemas.V3Product = await createProductWithMediaHelper(
      category,
      [
        {
          id: mediaId,
          type: 'image',
          sort: 1,
          title: 'New media in object',
        },
      ],
    );
    await approveProduct(product._id);
    await changeProductState(product._id, ProductStates.Online);

    const product2: Components.Schemas.V3Product = await createProductWithMediaHelper(
      category,
      [
        {
          id: mediaId,
          type: 'image',
          sort: 1,
          title: 'New media in object',
        },
      ],
    );
    await approveProduct(product2._id);
    await changeProductState(product2._id, ProductStates.Online);

    const { body } = await supertest(app)
      .post('/v3-set-product-state')
      .send({ ids: [product._id, product2._id], state: 'offline' })
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body.isUpdated).toBe(true);

    const updatedProduct1: Components.Schemas.V3Product = await getProduct(
      product._id,
    );
    const updatedProduct2: Components.Schemas.V3Product = await getProduct(
      product2._id,
    );
    expect(updatedProduct1.state).toBe('offline');
    expect(updatedProduct2.state).toBe('offline');

    const { body: body2 } = await supertest(app)
      .post('/v3-set-product-state')
      .send({ ids: [product._id, product2._id], state: 'online' })
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body2.isUpdated).toBe(true);
    const updatedProduct3: Components.Schemas.V3Product = await getProduct(
      product._id,
    );
    const updatedProduct4: Components.Schemas.V3Product = await getProduct(
      product2._id,
    );
    expect(updatedProduct3.state).toBe('online');
    expect(updatedProduct4.state).toBe('online');
  });

  it('should only set online the products with media and prices', async () => {
    const { _id: mediaId } = await uploadMedia();

    const product: Components.Schemas.V3Product = await createProductHelper(
      category,
    );
    await approveProduct(product._id);
    await changeProductState(product._id, ProductStates.Online);

    const product2: Components.Schemas.V3Product = await createProductWithMediaHelper(
      category,
      [
        {
          id: mediaId,
          type: 'image',
          sort: 1,
          title: 'New media in object',
        },
      ],
    );
    await approveProduct(product2._id);
    await changeProductState(product2._id, ProductStates.Online);

    const product3: Components.Schemas.V3Product = await createProductWithMediaHelper(
      category,
      [
        {
          id: mediaId,
          type: 'image',
          sort: 1,
          title: 'New media in object',
        },
      ],
    );
    await approveProduct(product3._id);
    await changeProductState(product3._id, ProductStates.Online);

    const { body } = await supertest(app)
      .post('/v3-set-product-state')
      .send({
        ids: [product._id, product2._id, product3._id],
        state: 'offline',
      })
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body.isUpdated).toBe(true);

    const updatedProduct1: Components.Schemas.V3Product = await getProduct(
      product._id,
    );
    const updatedProduct2: Components.Schemas.V3Product = await getProduct(
      product2._id,
    );
    const updatedProduct3: Components.Schemas.V3Product = await getProduct(
      product2._id,
    );
    expect(updatedProduct1.state).toBe('offline');
    expect(updatedProduct2.state).toBe('offline');
    expect(updatedProduct3.state).toBe('offline');

    await supertest(app)
      .post('/v3-set-product-state')
      .send({ ids: [product._id, product2._id, product3._id], state: 'online' })
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body.isUpdated).toBe(true);

    // It should have only updated the product with media to be online
    const secUpdatedProduct1: Components.Schemas.V3Product = await getProduct(
      product._id,
    );
    const secUpdatedProduct2: Components.Schemas.V3Product = await getProduct(
      product2._id,
    );
    const secUpdatedProduct3: Components.Schemas.V3Product = await getProduct(
      product3._id,
    );
    expect(secUpdatedProduct1.state).toBe('offline');
    expect(secUpdatedProduct2.state).toBe('online');
    expect(secUpdatedProduct3.state).toBe('online');
  });

  it('should only set online the approved products only', async () => {
    const { _id: mediaId } = await uploadMedia();

    const product1: Components.Schemas.V3Product = await createProductHelper(
      category,
    );
    await changeProductState(product1._id, ProductStates.Online);

    const product2: Components.Schemas.V3Product = await createProductWithMediaHelper(
      category,
      [
        {
          id: mediaId,
          type: 'image',
          sort: 1,
          title: 'New media in object',
        },
      ],
    );
    await approveProduct(product2._id);
    await changeProductState(product2._id, ProductStates.Online);

    const { body } = await supertest(app)
      .post('/v3-set-product-state')
      .send({ ids: [product1._id, product2._id], state: 'offline' })
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body.isUpdated).toBe(true);

    const updatedProduct1: Components.Schemas.V3Product = await getProduct(
      product1._id,
    );
    const updatedProduct2: Components.Schemas.V3Product = await getProduct(
      product2._id,
    );
    expect(updatedProduct1.state).toBe('offline');
    expect(updatedProduct2.state).toBe('offline');

    await supertest(app)
      .post('/v3-set-product-state')
      .send({ ids: [product1._id, product2._id], state: 'online' })
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body.isUpdated).toBe(true);

    // It should have only updated the product with media to be online
    const secUpdatedProduct1: Components.Schemas.V3Product = await getProduct(
      product1._id,
    );
    const secUpdatedProduct2: Components.Schemas.V3Product = await getProduct(
      product2._id,
    );
    expect(secUpdatedProduct1.state).toBe('offline');
    expect(secUpdatedProduct2.state).toBe('online');
  });
});
