import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { cleanUpV3, insertProductData } from '../helpers';
import { getInternalApiSecret } from '@tradeling/web-js-utils';
import { appConfig } from '@src/config/env';
import { Types } from 'mongoose';
import {
  InternalReviewStatuses,
  ProductStates,
} from '@express/modules/product/types';
import {
  IProductModelV3,
  productModelV3,
} from '@express/modules/product/model-product-v3';

type RequestBody = Paths.V3InternalUpdateProductStateAction.RequestBody;
describe('POST /v1-internal-update-product-state', () => {
  beforeAll(async () => {
    process.env[`IN_FROM_MODULE_1`] = 'secret';
    process.env[`OUT_TO_MODULE_CATALOG_PIM`] = 'secret';
    await cleanUpV3();
  });

  afterEach(async () => {
    await cleanUpV3();
  });

  // invalid filters
  const invalidFilters: RequestBody[] = [{ supplierCompanyId: null } as any];
  it.each(invalidFilters)(
    'should return 400 Bad Request on invalid request parameters: %p',
    async (params) => {
      await callApi(params).expect(400).expect('Content-Type', /json/);
    },
  );

  it(`should update product state when isVerified is false`, async () => {
    const supplierOne: string = new Types.ObjectId().toString();
    const products: IProductModelV3[] = await insertProductData(
      2,
      (product) => {
        return {
          ...product,
          supplierCompanyId: supplierOne,
          internalReviewStatus: InternalReviewStatuses.Accepted,
          state: ProductStates.Online,
        };
      },
    );
    const payload: RequestBody = {
      supplierCompanyId: supplierOne,
      isVerified: false,
    };
    const { status } = await callApi(payload);
    expect(status).toBe(200);
    const updated: IProductModelV3[] = await productModelV3.find({
      _id: { $in: products.map((product) => product._id) },
    });
    expect(updated.map((product) => product.state)).toEqual([
      ProductStates.Offline,
      ProductStates.Offline,
    ]);
  });

  it(`should update product state when isVerified is true`, async () => {
    const supplierOne: string = new Types.ObjectId().toString();
    const products: IProductModelV3[] = await insertProductData(
      2,
      (product) => {
        return {
          ...product,
          supplierCompanyId: supplierOne,
          internalReviewStatus: InternalReviewStatuses.Accepted,
          state: ProductStates.Offline,
          tags: ['verification-rejected'],
        };
      },
    );
    const payload: RequestBody = {
      supplierCompanyId: supplierOne,
      isVerified: true,
    };
    const { status } = await callApi(payload);
    expect(status).toBe(200);
    const updated: IProductModelV3[] = await productModelV3.find({
      _id: { $in: products.map((product) => product._id) },
    });
    expect(updated.map((product) => product.state)).toEqual([
      ProductStates.Online,
      ProductStates.Online,
    ]);
  });
});

function callApi(payload: RequestBody) {
  return supertest(app)
    .post('/v3-internal-update-product-state')
    .set('x-is-internal-request', '1')
    .set(
      'x-t-secret',
      getInternalApiSecret({ to: appConfig.name, from: 'module-1' }),
    )
    .send(payload);
}
