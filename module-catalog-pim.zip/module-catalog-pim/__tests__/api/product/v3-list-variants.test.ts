import {
  cleanUpV3,
  createCategory,
  createProductHelper,
} from '@__tests__/api/helpers';
import { app } from '@src/config/server/server';
import supertest from 'supertest';
import { mockStoreByStoreId } from '@__tests__/api/product/mocks/www-sdk.mock';

describe('POST /v3-list-variants', function () {
  let category: Components.Schemas.V1Category;

  beforeAll(async () => {
    await cleanUpV3();
    mockStoreByStoreId();
  });

  afterEach(async () => {
    category = await createCategory();
  });

  afterAll(async () => {
    await cleanUpV3();
  });

  it.each([
    [{ ids: ' ' }, 400],
    [{ ids: [] }, 400],
  ])(
    'given %p as input parameter, should return response as code- %p',
    async (params: any, expectedResult) => {
      await supertest(app)
        .post('/v3-list-variants')
        .send(params)
        .expect(expectedResult)
        .expect('Content-Type', /json/);
    },
  );

  it('should return 400 on invalid ids', async () => {
    await supertest(app)
      .post('/v3-list-variants')
      .send({ ids: ['5e2ecb5ad3d66b512d173953'] })
      .expect(404)
      .expect('Content-Type', /json/);
  });

  it('should return 200 with product list ', async () => {
    const product: Components.Schemas.V3Product = await createProductHelper(
      category,
    );
    const product2: Components.Schemas.V3Product = await createProductHelper(
      category,
    );
    const product3: Components.Schemas.V3Product = await createProductHelper(
      category,
    );

    const { body: result, status } = await supertest(app)
      .post('/v3-list-variants')
      .send({ ids: [product._id, product2._id, product3._id] });

    expect(status).toBe(200);
    expect(result.length).toEqual(3);
  });
});
