import supertest from 'supertest';
import { app } from '@src/config/server/server';
import {
  cleanUpV3,
  createCategory,
  createProductHelper,
  getProduct,
  getSingleProductParamsWithOffer,
  uploadMedia,
} from '../helpers';
import isArray from 'lodash/isArray';
import isObject from 'lodash/isObject';
import { categoryModel } from '@express/modules/category/model-category';
import { productModelV3 } from '@express/modules/product/model-product-v3';
import { offerModelV3 } from '@express/modules/offer/model-offers-v3';
import { ProductStates } from '@express/modules/product/types';
import { mediaModel } from '@express/modules/media/model-media';
import { mockStoreByStoreId } from '@__tests__/api/product/mocks/www-sdk.mock';
import { mockV1InternalListUsers } from '@__tests__/api/product/mocks/account-sdk.mock';

describe('POST /v3-update-product', () => {
  beforeAll(async () => {
    await cleanUpV3();
    await mediaModel.deleteMany({});
    mockStoreByStoreId();
    mockV1InternalListUsers();
  });

  afterEach(async () => {
    await categoryModel.deleteMany({});
    await productModelV3.deleteMany({});
    await offerModelV3.deleteMany({});
  });

  let category: Components.Schemas.V1Category;
  let product: Components.Schemas.V3Product;
  let productParamsWithOffer: Partial<Components.RequestBodies.V3CreateProduct>;

  beforeEach(async () => {
    category = await createCategory();
    product = await createProductHelper(category);
    productParamsWithOffer = getSingleProductParamsWithOffer({
      categoryId: category._id,
    });
  });

  it.each([
    [{}],
    [{ sku: '1' }],
    [{ categoryId: 'invalidID' }],
    [
      {
        name: { en: 'product name' },
        description: { en: 'long description' },
        keywords: '',
      },
    ],
    [
      {
        name: { en: 'product name' },
        description: { en: 'long description' },
        keywords: 'key, word',
      },
    ],
    [{ keywords: 'key, word', categoryId: '5e41ddc4ccab0b5830ed4ba8' }],
    [{ keywords: ['keyword'], type: 2, unit: 5 }],
    [{ name: undefined }],
    [{ sku: undefined }],
    [{ shortDescription: undefined }],
    [{ categoryId: undefined }],
    [{ type: undefined }],
    [
      {
        media: { id: '5e45923a733c0331b73218fb', title: 'some', type: 'image' },
      },
    ],
  ])(
    'should return 400 Bad Request on invalid request parameters: %p',
    async (params) => {
      await supertest(app)
        .post('/v3-update-product')
        .send({ ...params, id: product._id })
        .expect(400)
        .expect('Content-Type', /json/);
    },
  );

  it('should return 400 Bad Request if product ID is missing', async () => {
    await supertest(app)
      .post('/v3-update-product')
      .send({ ...productParamsWithOffer, keywords: ['some', 'keywords'] })
      .expect(400)
      .expect('Content-Type', /json/);
  });

  it('should return 404 Not Found if product not found', async () => {
    await supertest(app)
      .post('/v3-update-product')
      .send({ ...productParamsWithOffer, id: '5e45923a733c0331b73218fb' })
      .expect(404)
      .expect('Content-Type', /json/);
  });

  it.each([
    [
      {
        sku: 'DXS-123',
        keywords: { en: ['some', 'test'], ar: ['__some', '__test'] },
      },
    ],
    [
      {
        name: { en: 'update baby product name' },
        longDescription: { en: 'long description' },
        keywords: { en: ['some', 'test'], ar: ['__some', '__test'] },
      },
    ],
    [{ sku: 'DXS-123' }],
    [{ type: 'simple' }],
    [{ type: 'configurable' }],
    [{ shortDescription: { en: 'new short description' } }],
    [{ longDescription: { en: 'new long description' } }],
  ])(
    'should return 200 OK on valid request parameters: %p',
    async (params: any) => {
      const { body, status } = await supertest(app)
        .post('/v3-update-product')
        .send({ ...productParamsWithOffer, ...params, id: product._id })
        .expect(200)
        .expect('Content-Type', /json/);

      const fetchedProduct: any = await getProduct(product._id);

      Object.keys(params).forEach((key: string) => {
        if (isArray(params[key])) {
          expect(fetchedProduct[key]).toEqual(
            expect.arrayContaining(params[key]),
          );
        } else if (isObject(params[key])) {
          expect(fetchedProduct[key]).toEqual(
            expect.objectContaining(params[key]),
          );
        } else {
          expect(fetchedProduct[key]).toEqual(params[key]);
        }
      });
    },
  );

  it('should return 200 OK on valid media parameters', async () => {
    const media: Components.Schemas.V1MediaItem = await uploadMedia();
    const mediaParams: any[] = [
      { id: media._id, type: 'image', title: media.originalName, sort: 1 },
    ];

    await supertest(app)
      .post('/v3-update-product')
      .send({ ...productParamsWithOffer, media: mediaParams, id: product._id })
      .expect(200)
      .expect('Content-Type', /json/);

    const fetchedProduct: Components.Schemas.V3Product = await getProduct(
      product._id,
    );

    expect(fetchedProduct.media).toEqual(
      expect.arrayContaining([expect.objectContaining(mediaParams.pop())]),
    );
  });

  it('should set product state to offline if there is no media attached.', async () => {
    await supertest(app)
      .post('/v3-update-product')
      .send({ ...productParamsWithOffer, media: [], id: product._id })
      .expect(200)
      .expect('Content-Type', /json/);

    const fetchedProduct: Components.Schemas.V3Product = await getProduct(
      product._id,
    );

    expect(fetchedProduct.state).toBe(ProductStates.Offline);
    expect(fetchedProduct.media.length).toBe(0);
  });
});
