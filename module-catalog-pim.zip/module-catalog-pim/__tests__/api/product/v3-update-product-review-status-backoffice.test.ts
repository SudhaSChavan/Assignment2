import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { V1InternalListUsersAction } from '@tradeling/tradeling-sdk/account/v1-internal-list-users-action';
import { V1InternalListSupplierCompanyAction } from '@tradeling/tradeling-sdk/account/v1-internal-list-supplier-company-action';
import { insertProductData } from '../helpers';
import { V1InternalUpdateSupplierHasApprovedProductAction } from '@tradeling/tradeling-sdk/account/v1-internal-update-supplier-has-approved-product-action';
import { InternalReviewStatuses } from '@express/modules/product/types';

jest.mock('@tradeling/tradeling-sdk/account/v1-internal-list-users-action');
jest.mock(
  '@tradeling/tradeling-sdk/account/v1-internal-list-supplier-company-action',
);
jest.mock(
  '@tradeling/tradeling-sdk/account/v1-internal-update-supplier-has-approved-product-action',
);

const mockV1InternalListUsersAction: jest.MockedFunction<
  typeof V1InternalListUsersAction
> = <jest.MockedFunction<typeof V1InternalListUsersAction>>(
  (V1InternalListUsersAction as any)
);

mockV1InternalListUsersAction.mockImplementation(() => {
  return {
    status: 200,
    data: {
      data: [],
    },
  } as any;
});

const mockV1InternalListSupplierCompanyAction: jest.MockedFunction<
  typeof V1InternalListSupplierCompanyAction
> = <jest.MockedFunction<typeof V1InternalListSupplierCompanyAction>>(
  (V1InternalListSupplierCompanyAction as any)
);
mockV1InternalListSupplierCompanyAction.mockImplementation(() => {
  return {
    status: 200,
    data: {
      items: [],
    },
  } as any;
});

const mockV1InternalUpdateSupplierHasApprovedProductAction: jest.MockedFunction<
  typeof V1InternalUpdateSupplierHasApprovedProductAction
> = <
  jest.MockedFunction<typeof V1InternalUpdateSupplierHasApprovedProductAction>
>(V1InternalUpdateSupplierHasApprovedProductAction as any);

mockV1InternalUpdateSupplierHasApprovedProductAction.mockImplementation(() => {
  return {
    status: 200,
    data: {
      data: [],
    },
  } as any;
});

describe('POST /v3-update-product-review-status-backoffice', () => {
  afterEach(async () => {});

  it('should return 200', async () => {
    const [product] = await insertProductData(1);
    const params: Paths.V3UpdateProductInternalReviewStatusBackofficeAction.RequestBody = {
      ids: [product._id],
      status: InternalReviewStatuses.Accepted,
    };
    const { body, status } = await supertest(app)
      .post('/v3-update-product-review-status-backoffice')
      .send(params);
    console.log(body);
    expect(status).toBe(200);
  });
});
