import supertest from 'supertest';
import { cleanUpV3, createCategory, createProductHelper } from '../helpers';
import { app } from '@src/config/server/server';

import { Types } from 'mongoose';
import { productModelV3 } from '@express/modules/product/model-product-v3';
import { ProductStates } from '@express/modules/product/types';
import { offerModelV3 } from '@express/modules/offer/model-offers-v3';

describe('POST /v3-seller-products-stats', () => {
  let category: Components.Schemas.V1Category;

  beforeAll(async () => {
    await cleanUpV3();
  });

  beforeEach(async () => {
    category = await createCategory();
  });

  afterEach(async () => {
    await cleanUpV3();
  });

  it('should count live products', async () => {
    const product: Components.Schemas.V3Product = await createProductHelper(
      category,
    );
    await createProductHelper(category);
    await createProductHelper(category);
    await createProductHelper(category);
    await createProductHelper(category);

    await productModelV3.updateMany({}, { state: ProductStates.Online });
    await productModelV3.findOneAndUpdate(
      { _id: product._id },
      { state: ProductStates.Offline, isInStock: false },
    );

    const { body } = await supertest(app)
      .post('/v3-seller-products-stats')
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body).toEqual(
      expect.objectContaining({
        live: 4,
        outOfStock: 1,
      }),
    );
  });

  it('should count outOfStock products', async () => {
    await createProductHelper(category);
    await createProductHelper(category);
    await createProductHelper(category);
    await createProductHelper(category);
    await createProductHelper(category);

    await productModelV3.updateMany({}, { state: ProductStates.Online });
    await productModelV3.updateOne({}, { isInStock: false });

    const { body } = await supertest(app)
      .post('/v3-seller-products-stats')
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body).toEqual(
      expect.objectContaining({
        live: 5,
        outOfStock: 1,
      }),
    );
  });

  it('should not count deleted products', async () => {
    await createProductHelper(category);
    await createProductHelper(category);
    await createProductHelper(category);
    await createProductHelper(category);
    await createProductHelper(category);

    await productModelV3.updateMany({}, { state: ProductStates.Online });
    await productModelV3.updateOne(
      {},
      { $set: { deletedAt: new Date() } as any },
    );

    const { body } = await supertest(app)
      .post('/v3-seller-products-stats')
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body).toEqual(
      expect.objectContaining({
        live: 4,
        outOfStock: 0,
      }),
    );
  });

  it('should not count other sellers products', async () => {
    await createProductHelper(category);
    await createProductHelper(category);
    await createProductHelper(category);
    await createProductHelper(category);
    await createProductHelper(category);

    await productModelV3.updateMany(
      {},
      {
        state: ProductStates.Online,
        supplierCompanyId: new Types.ObjectId().toString(),
      },
    );
    await offerModelV3.updateOne(
      {},
      { $set: { supplierCompanyId: new Types.ObjectId() } as any },
    );

    const { body } = await supertest(app)
      .post('/v3-seller-products-stats')
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body).toEqual(
      expect.objectContaining({
        live: 0,
        outOfStock: 0,
      }),
    );
  });
});
