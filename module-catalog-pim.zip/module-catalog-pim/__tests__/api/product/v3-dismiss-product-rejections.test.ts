import supertest from 'supertest';
import { app } from '@src/config/server/server';
import {
  createCategory,
  createProductHelper,
  cleanUpV3,
  createProductUpdateRequest,
} from '../helpers';
import { mockStoreByStoreId } from '@__tests__/api/product/mocks/www-sdk.mock';
import {
  IProductUpdateRequestModelV3,
  productUpdateRequestModelV3,
} from '@express/modules/product/model-product-update-request-v3';

describe('POST /v3-dismiss-product-rejections', () => {
  let category: Components.Schemas.V1Category;

  beforeAll(async () => {
    await cleanUpV3();
    await productUpdateRequestModelV3.deleteMany({});
    mockStoreByStoreId();
    category = await createCategory();
  });

  afterAll(async () => {
    await cleanUpV3();
    await productUpdateRequestModelV3.deleteMany({});
  });

  it.each([
    [{ id: '' }],
    [{ id: 'sorry' }],
    [{ productId: '' }],
    [{ productId: 'sorry' }],
  ])(
    'should return 400 Bad Request on invalid request parameters: %p',
    async (params: any) => {
      const { body } = await supertest(app)
        .post('/v3-dismiss-product-rejections')
        .send(params)
        .expect(400)
        .expect('Content-Type', /json/);
    },
  );

  it('should dismiss product rejections by product id', async () => {
    const product: Components.Schemas.V3Product = await createProductHelper(
      category,
    );
    await createProductUpdateRequest({
      productId: product._id,
      metadata: { sku: product.sku },
    });
    const { body } = await supertest(app)
      .post('/v3-dismiss-product-rejections')
      .send({ productId: product._id })
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body.isDismissed).toBeTruthy();
  });

  it('should dismiss product rejections by update request id', async () => {
    const product: Components.Schemas.V3Product = await createProductHelper(
      category,
    );
    const ProductUpdateRequest: IProductUpdateRequestModelV3 = await createProductUpdateRequest(
      {
        productId: product._id,
        metadata: { sku: product.sku },
      },
    );
    const { body } = await supertest(app)
      .post('/v3-dismiss-product-rejections')
      .send({ id: ProductUpdateRequest._id })
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body.isDismissed).toBeTruthy();
  });
});
