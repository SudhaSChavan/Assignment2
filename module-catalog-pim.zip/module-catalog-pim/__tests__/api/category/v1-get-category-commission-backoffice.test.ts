import supertest from 'supertest';
import {
  categoryCommissionModel,
  ICategoryCommissionDocument,
  ICategoryCommissionModel,
} from '@express/modules/category/model-category-commission';
import { createCategory } from '../helpers';
import { app } from '@src/config/server/server';
describe('POST /v1-get-category-commission-backoffice', () => {
  afterEach(async () => {
    categoryCommissionModel.deleteMany({});
  });

  it('should return 200', async () => {
    const category: Components.Schemas.V1Category = await createCategory();
    const commissionDoc: ICategoryCommissionDocument = {
      categoryId: category._id,
      commission: 10,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    const commission: ICategoryCommissionModel = await categoryCommissionModel.create(
      commissionDoc,
    );
    const params: Paths.V1GetCategoryCommissionBackofficeAction.RequestBody = {
      id: commission._id,
    };
    const { status } = await supertest(app)
      .post('/v1-get-category-commission-backoffice')
      .send(params);
    expect(status).toBe(200);
  });
});
