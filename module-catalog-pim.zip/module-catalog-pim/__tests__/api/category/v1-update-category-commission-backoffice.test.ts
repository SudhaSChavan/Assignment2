import supertest from 'supertest';
import { app } from '@src/config/server/server';
import {
  categoryCommissionModel,
  ICategoryCommissionDocument,
  ICategoryCommissionModel,
} from '@express/modules/category/model-category-commission';
import { createCategory } from '../helpers';

describe('POST /v1-update-category-commission-backoffice', () => {
  afterEach(async () => {
    categoryCommissionModel.deleteMany({});
  });

  it('should return 200', async () => {
    const category: Components.Schemas.V1Category = await createCategory();
    const commissionDoc: ICategoryCommissionDocument = {
      categoryId: category._id,
      commission: 10,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    const commission: ICategoryCommissionModel = await categoryCommissionModel.create(
      commissionDoc,
    );
    const params: Paths.V1UpdateCategoryCommissionBackofficeAction.RequestBody = {
      id: commission._id,
      commission: 7,
    };
    const { status } = await supertest(app)
      .post('/v1-update-category-commission-backoffice')
      .send(params);
    expect(status).toBe(200);
  });
});
