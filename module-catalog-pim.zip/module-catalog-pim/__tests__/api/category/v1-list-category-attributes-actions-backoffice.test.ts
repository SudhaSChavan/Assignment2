import supertest from 'supertest';
import { app } from '@src/config/server/server';

describe('POST /v1-list-category-attributes-actions-backoffice', () => {
  it('should return 200', async () => {
    const params: Paths.V1ListCategoryAttributesBackofficeAction.RequestBody = {};
    const { body, status } = await supertest(app)
      .post('/v1-list-category-attributes-actions-backoffice')
      .send(params);
    expect(status).toBe(200);
  });
});
