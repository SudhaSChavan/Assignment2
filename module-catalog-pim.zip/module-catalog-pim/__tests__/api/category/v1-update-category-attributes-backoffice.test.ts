import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { categoryModel } from '@express/modules/category/model-category';
import { createCategory } from '../helpers';
import { V1IndexCategoryMetadataAction } from '@tradeling/tradeling-sdk/catalog-search/v1-index-category-metadata-action';
import { StatusCodes } from 'http-status-codes';
import { categoryAttributeModel } from '@express/modules/category/model-category-attribute';

jest.mock(
  '@tradeling/tradeling-sdk/catalog-search/v1-index-category-metadata-action',
);

const mockV1IndexCategoryMetadataAction: jest.MockedFunction<
  typeof V1IndexCategoryMetadataAction
> = <jest.MockedFunction<typeof V1IndexCategoryMetadataAction>>(
  (V1IndexCategoryMetadataAction as any)
);

mockV1IndexCategoryMetadataAction.mockImplementation(() => {
  return {
    status: 200,
    data: {},
  } as any;
});

describe('POST /v1-update-category-attributes-backoffice', () => {
  afterEach(async () => {
    await categoryModel.deleteMany({});
  });

  it('should return 200', async () => {
    const category: Components.Schemas.V1Category = await createCategory();
    const params: Paths.V1UpdateCategoryAttributesBoBackofficeAction.RequestBody = {
      categoryId: category._id,
      attributes: [
        {
          sort: 10,
          allowedValues: [],
          isFilterable: true,
          isLocalized: true,
          showCount: false,
          _id: '629f263410d25b001c0d8213',
          type: 'text',
          label: {
            en: 'Brand',
            ar: 'العلامة التجارية',
          },
          help: {
            en: 'Only the brand name of the product',
          },
          valueHelp: {
            en: 'An alphanumeric string, Max. 60 characters',
          },
          code: 'brand',
          default: null,
          required: true,
          strict: false,
          example: 'HP',
          metadata: null,
          minValue: null,
          maxValue: null,
          isInteger: null,
        },
      ],
    };
    const { body, status } = await supertest(app)
      .post('/v1-update-category-attributes-backoffice')
      .send(params);
    expect(status).toBe(200);
  });

  it('should update category attributes name without spaces', async (): Promise<void> => {
    const { _id: categoryId } = await createCategory();

    const updateCategoryAttributesRequestBody: Components.RequestBodies.V1UpdateCategoryAttribute = {
      categoryId,
      attributes: [
        {
          type: 'text',
          code: 'brand',
          required: true,
          label: { en: 'Brand' },
          help: { en: 'Only the brand name of the product' },
        },
      ],
    };
    const { body, status } = await supertest(app)
      .post('/v1-update-category-attributes-backoffice')
      .send(updateCategoryAttributesRequestBody);
    expect(status).toBe(StatusCodes.OK);
    expect(body.isUpdated).toBeTruthy();

    const { attributes } = await categoryAttributeModel.findOne({
      categoryId,
    });
    expect(attributes[0].label.en).toBe(
      updateCategoryAttributesRequestBody.attributes[0].label.en,
    );
  });
});
