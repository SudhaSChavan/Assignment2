import supertest from 'supertest';
import { app } from '@src/config/server/server';

describe('POST /v1-category-listing-backoffice', () => {
  it('should return 200', async () => {
    const params: Paths.V3CategoryListingBoBackofficeAction.RequestBody = {};
    const { status } = await supertest(app)
      .post('/v3-category-listing-backoffice')
      .send(params);
    expect(status).toBe(200);
  });
});
