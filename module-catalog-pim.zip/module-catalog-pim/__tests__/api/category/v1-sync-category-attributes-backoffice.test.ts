import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { V1IndexCategoryMetadataAction } from '@tradeling/tradeling-sdk/catalog-search/v1-index-category-metadata-action';
import {
  categoryAttributeModel,
  ICategoryAttributeDocument,
} from '@express/modules/category/model-category-attribute';
import { Types } from 'mongoose';

jest.mock(
  '@tradeling/tradeling-sdk/catalog-search/v1-index-category-metadata-action',
);

const mockV1IndexCategoryMetadataAction: jest.MockedFunction<
  typeof V1IndexCategoryMetadataAction
> = <jest.MockedFunction<typeof V1IndexCategoryMetadataAction>>(
  (V1IndexCategoryMetadataAction as any)
);

mockV1IndexCategoryMetadataAction.mockImplementation(() => {
  return {
    status: 200,
    data: {},
  } as any;
});
describe('/v1-sync-category-attribute-backoffice', () => {
  beforeEach(async () => {
    await categoryAttributeModel.deleteMany({});
  });

  afterAll(async () => {
    await categoryAttributeModel.deleteMany({});
  });
  it('should sync supplier', async () => {
    const attribute: ICategoryAttributeDocument = {
      attributes: [],
      // @ts-ignore
      categoryId: new Types.ObjectId().toHexString(),
      categoryTree: [],
    } as any;
    await categoryAttributeModel.create(attribute);
    const { body, status } = await supertest(app)
      .post('/v1-sync-category-attribute-backoffice')
      .set('x-language', 'en')
      .set('x-country', 'ae')
      .send({ batchIndex: 0, batchSize: 1 });
    expect(status).toBe(200);
  });
});
