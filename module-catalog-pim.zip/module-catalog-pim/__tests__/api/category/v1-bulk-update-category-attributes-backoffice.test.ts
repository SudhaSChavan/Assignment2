import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { categoryModel } from '@express/modules/category/model-category';
import { createCategory } from '../helpers';

describe('POST /v1-bulk-update-category-attributes-backoffice', () => {
  afterEach(async () => {
    categoryModel.deleteMany();
  });

  it('should return 200', async () => {
    const category: Components.Schemas.V1Category = await createCategory();
    const params: Paths.V1BulkUpdateCategoryAttributesBackofficeAction.RequestBody = {
      categoryIds: [category._id],
      attribute: {
        code: 'brand',
        label: { en: 'Brand' },
        type: 'text',
      },
    };
    const { status } = await supertest(app)
      .post('/v1-bulk-update-category-attributes-backoffice')
      .send(params);
    expect(status).toBe(200);
  });
});
