import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { categoryModel } from '@express/modules/category/model-category';
import { categoryCommissionModel } from '@express/modules/category/model-category-commission';
import { createCategory } from '../helpers';

describe('POST /v1-create-category-commission-backoffice', () => {
  afterEach(async () => {
    categoryModel.deleteMany();
    categoryCommissionModel.deleteMany();
  });

  it('should return 200', async () => {
    const category: Components.Schemas.V1Category = await createCategory();
    const params: Paths.V1CreateCategoryCommissionBackofficeAction.RequestBody = {
      categoryId: category._id,
      commission: 10,
    };
    const { body, status } = await supertest(app)
      .post('/v1-create-category-commission-backoffice')
      .send(params);
    expect(status).toBe(200);
  });
});
