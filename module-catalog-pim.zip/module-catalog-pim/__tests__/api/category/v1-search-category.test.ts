import supertest from 'supertest';

import { app } from '@src/config/server/server';
import { createCategory, validateCategory } from '../helpers';
import { categoryModel } from '@express/modules/category/model-category';

describe('POST /v1-search-category', () => {
  beforeEach(async () => {
    await categoryModel.deleteMany({});
  });

  it.each([
    [{}],
    [{ term: 1 }],
    //
  ])(
    'should return 400 Bad Request on invalid request parameters: %p',
    async (params: any) => {
      await supertest(app)
        .post('/v1-search-category')
        .send(params)
        .expect(400)
        .expect('Content-Type', /json/);
    },
  );

  it('should return 1 matched leaf category', async () => {
    const categoryParent: Components.Schemas.V1Category = await createCategory({
      name: 'such category',
      description: 'very text',
      level: 0,
    });
    const category1: Components.Schemas.V1Category = await createCategory({
      name: 'wow',
      description: 'much text',
      parentId: categoryParent._id,
      level: 1,
    });
    const category2: Components.Schemas.V1Category = await createCategory({
      name: 'such category',
      description: 'very text',
      parentId: categoryParent._id,
      level: 1,
    });

    const { body } = await supertest(app)
      .post('/v1-search-category')
      .send({ term: 'category' })
      .expect(200)
      .expect('Content-Type', /json/);

    body.forEach(validateCategory);
    expect(body.length).toEqual(1);
    expect(body[0]._id).toEqual(category2._id);
  });
});
