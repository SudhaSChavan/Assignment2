import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { createCategory } from '../helpers';
import { categoryModel } from '@express/modules/category/model-category';

describe('POST /v1-list-category-backoffice', () => {
  afterEach(async () => {
    await categoryModel.deleteMany({});
  });

  it('should return 200', async () => {
    await createCategory();
    await supertest(app)
      .post('/v1-list-category-backoffice')
      .expect(200)
      .expect('Content-Type', /json/);
  });

  it('should return parents including ancestors', async () => {
    const cat1: Components.Schemas.V1Category = await createCategory({
      slug: 'slug-10',
    });
    const cat2: Components.Schemas.V1Category = await createCategory({
      slug: 'slug-11',
      parentId: cat1._id,
    });
    const cat3: Components.Schemas.V1Category = await createCategory({
      slug: 'slug-12',
      parentId: cat2._id,
    });
    const {
      body,
    }: {
      body: Paths.V3CategoryListingBoBackofficeAction.Responses.$200;
    } = await supertest(app)
      .post('/v1-list-category-backoffice')
      .send({ filter: { parentId: cat1._id, includeAncestors: true } })
      .expect(200)
      .expect('Content-Type', /json/);
    expect(body.categories?.length).toBe(2);
    expect(body.categories?.map((c) => c._id).sort()).toStrictEqual(
      [cat2._id.toString(), cat3._id.toString()].sort(),
    );
  });

  it('should filter by slug', async () => {
    const cat1: Components.Schemas.V1Category = await createCategory({
      slug: 'slug-13',
    });
    await createCategory({ slug: 'slug-14' });
    const {
      body,
    }: {
      body: Paths.V3CategoryListingBoBackofficeAction.Responses.$200;
    } = await supertest(app)
      .post('/v1-list-category-backoffice')
      .send({ filter: { slug: 'slug-13' } })
      .expect(200)
      .expect('Content-Type', /json/);
    expect(body.categories?.length).toBe(1);
    expect(body.categories?.map((c) => c._id).sort()).toStrictEqual(
      [cat1._id.toString()].sort(),
    );
  });
});
