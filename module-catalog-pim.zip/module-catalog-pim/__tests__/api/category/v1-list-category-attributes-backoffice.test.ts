import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { createCategory } from '../helpers';

describe('POST /v1-list-category-attributes-backoffice', () => {
  it('should return 200', async () => {
    const category: Components.Schemas.V1Category = await createCategory();
    const params: Paths.V1ListCategoryAttributesBoBackofficeAction.RequestBody = {
      filter: {
        categoryIds: [category._id],
      },
    };
    const { status } = await supertest(app)
      .post('/v1-list-category-attributes-backoffice')
      .send(params);
    expect(status).toBe(200);
  });
});
