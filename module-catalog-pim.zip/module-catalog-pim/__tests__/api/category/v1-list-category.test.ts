import supertest from 'supertest';

import { app } from '@src/config/server/server';
import { createCategory, validateCategory } from '../helpers';
import { categoryModel } from '@express/modules/category/model-category';

describe('POST /v1-list-category', () => {
  afterEach(async () => {
    await categoryModel.deleteMany({});
  });

  it.each([
    [{ page: 'asdsd' }],
    [{ page: -1 }],
    [{ size: 0 }],
    [{ size: 1e6 }],
    [{ filter: { parentId: {} } }],
  ])(
    'should return 400 Bad Request on invalid request parameters: %p',
    async (params: any) => {
      await supertest(app)
        .post('/v1-list-category')
        .send(params)
        .expect(400)
        .expect('Content-Type', /json/);
    },
  );

  it('should return empty categories list for unknown parent id', async () => {
    const { body } = await supertest(app)
      .post('/v1-list-category')
      .send({ filter: { parentId: '22038b404a1113213f365ce4' } })
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body).toEqual({
      currentPage: 1,
      size: 3,
      totalPages: 0,
      totalRecords: 0,
      categories: [],
    });
  });

  it('should return 1 category', async () => {
    const category: Components.Schemas.V1Category = await createCategory();
    const { body } = await supertest(app)
      .post('/v1-list-category')
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body).toEqual({
      currentPage: 1,
      size: 3,
      totalPages: 1,
      totalRecords: 1,
      categories: [category],
    });
    validateCategory(body.categories[0]);
  });

  it(`should return categories list, count=3`, async () => {
    const root: Components.Schemas.V1Category = await createCategory();
    await Promise.all([
      createCategory({ parentId: root._id, level: 1 }),
      createCategory({ parentId: root._id, level: 2 }),
      createCategory({ parentId: root._id, level: 3 }),
    ]);

    const { body } = await supertest(app)
      .post('/v1-list-category')
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body.categories.length).toEqual(3);
    expect(body.size).toEqual(3);
    expect(body.currentPage).toEqual(1);
    expect(body.totalPages).toEqual(2);
    expect(body.totalRecords).toBeGreaterThanOrEqual(4);
    body.categories.forEach(validateCategory);
  });

  it('should return root categories when filter.parentId=null', async () => {
    const roots: any = await Promise.all([
      createCategory({ level: 1 }),
      createCategory({ level: 2 }),
    ]);

    await Promise.all([
      createCategory({ parentId: roots[0]._id, level: 1 }),
      createCategory({ parentId: roots[1]._id, level: 2 }),
    ]);

    const { body } = await supertest(app)
      .post('/v1-list-category')
      .send({ filter: { parentId: null } })
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body.totalRecords).toEqual(2);
    body.categories.forEach((c: any) => expect(c.parentId).toBeNull());
    body.categories.forEach(validateCategory);
  });

  it('should return child categories only', async () => {
    const root0: Components.Schemas.V1Category = await createCategory({
      level: 0,
    });
    const root1: Components.Schemas.V1Category = await createCategory({
      level: 1,
    });

    await createCategory({ parentId: root0._id, level: 2 });
    await createCategory({ parentId: root0._id, level: 3 });

    const { body } = await supertest(app)
      .post('/v1-list-category')
      .send({ filter: { parentId: root0._id } })
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body.totalRecords).toEqual(2);
    body.categories.forEach((c: any) => expect(c.parentId).toEqual(root0._id));
    body.categories.forEach(validateCategory);
  });

  it('should return categories for given level', async () => {
    await createCategory({ level: 0 });
    await createCategory({ level: 1 });
    await createCategory({ level: 2 });
    await createCategory({ level: 2 });
    await createCategory({ level: 2 });
    await createCategory({ level: 3 });

    const { body } = await supertest(app)
      .post('/v1-list-category')
      .send({ filter: { level: 2 } })
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body.totalRecords).toEqual(3);
    body.categories.forEach(validateCategory);

    const { body: body2 } = await supertest(app)
      .post('/v1-list-category')
      .send({ filter: { level: 3 } })
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body2.totalRecords).toEqual(1);
    body2.categories.forEach(validateCategory);
  });

  it('should check pagination and limits', async () => {
    await createCategory({ level: 0 });
    await createCategory({ level: 1 });
    await createCategory({ level: 2 });
    await createCategory({ level: 3 });
    await createCategory({ level: 0 });

    const { body: page1 } = await supertest(app)
      .post('/v1-list-category')
      .send({ size: 2, page: 1 })
      .expect(200)
      .expect('Content-Type', /json/);

    const { body: page2 } = await supertest(app)
      .post('/v1-list-category')
      .send({ size: 2, page: 2 })
      .expect(200)
      .expect('Content-Type', /json/);

    const { body: page3 } = await supertest(app)
      .post('/v1-list-category')
      .send({ size: 2, page: 3 })
      .expect(200)
      .expect('Content-Type', /json/);

    expect(page1.categories.length).toEqual(2);
    expect(page1.size).toEqual(2);
    expect(page1.currentPage).toEqual(1);
    expect(page1.totalPages).toEqual(3);
    expect(page1.totalRecords).toEqual(5);

    expect(page2.categories.length).toEqual(2);
    expect(page2.size).toEqual(2);
    expect(page2.currentPage).toEqual(2);
    expect(page2.totalPages).toEqual(3);
    expect(page2.totalRecords).toEqual(5);

    expect(page3.categories.length).toEqual(1);
    expect(page3.size).toEqual(2);
    expect(page3.currentPage).toEqual(3);
    expect(page3.totalPages).toEqual(3);
    expect(page3.totalRecords).toEqual(5);

    const { body: limit4page1 } = await supertest(app)
      .post('/v1-list-category')
      .send({ size: 4, page: 1 })
      .expect(200)
      .expect('Content-Type', /json/);

    const { body: limit4page2 } = await supertest(app)
      .post('/v1-list-category')
      .send({ size: 4, page: 2 })
      .expect(200)
      .expect('Content-Type', /json/);

    expect(limit4page1.categories.length).toEqual(4);
    expect(limit4page1.size).toEqual(4);
    expect(limit4page1.currentPage).toEqual(1);
    expect(limit4page1.totalPages).toEqual(2);
    expect(limit4page1.totalRecords).toEqual(5);

    expect(limit4page2.categories.length).toEqual(1);
    expect(limit4page2.size).toEqual(4);
    expect(limit4page2.currentPage).toEqual(2);
    expect(limit4page2.totalPages).toEqual(2);
    expect(limit4page2.totalRecords).toEqual(5);
  });
});
