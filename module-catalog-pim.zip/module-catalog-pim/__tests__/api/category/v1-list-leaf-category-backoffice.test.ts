import supertest from 'supertest';
import { app } from '@src/config/server/server';

describe('POST /v1-list-leaf-category-backoffice', () => {
  it('should return 200', async () => {
    const params: Paths.V1ListLeafCategoryBoBackofficeAction.RequestBody = {};
    const { status } = await supertest(app)
      .post('/v1-list-leaf-category-backoffice')
      .send(params);
    expect(status).toBe(200);
  });
});
