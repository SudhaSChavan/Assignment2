import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { createCategory } from '../helpers';
import { V1TempCategoryUploadAction } from '@tradeling/tradeling-sdk/media-storage/v1-temp-category-upload-action';

jest.mock(
  '@tradeling/tradeling-sdk/media-storage/v1-temp-category-upload-action',
);

const mockV1TempCategoryUploadAction: jest.MockedFunction<
  typeof V1TempCategoryUploadAction
> = <jest.MockedFunction<typeof V1TempCategoryUploadAction>>(
  (V1TempCategoryUploadAction as any)
);

mockV1TempCategoryUploadAction.mockImplementation((request) => {
  return {
    status: 200,
    data: {},
  } as any;
});
describe('POST /v1-attachment-category-backoffice', () => {
  it('should return 200', async () => {
    const category: Components.Schemas.V1Category = await createCategory();
    const { status } = await supertest(app)
      .post('/v1-attachment-category-backoffice')
      .field('categoryId', category._id)
      .attach('files[]', Buffer.from(''), {
        filename: 'test.txt',
        contentType: 'text/plain',
      });
    expect(status).toBe(200);
  });
});
