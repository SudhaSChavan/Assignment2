import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { categoryModel } from '@express/modules/category/model-category';

import * as api from '@tradeling/tradeling-sdk/www/v1-get-website-by-code-action';
import { auditFieldsForCreateCategory } from '@express/modules/category/v3/action-create-category-backoffice';
import { auditFields } from '@express/modules/product/send-product-audit-event';

(api as any).V1GetWebsiteByCodeAction = async (data: any): Promise<any> => {
  return {
    data: {
      id: '119f4686-5111-4ae2-8404-a515993399eb',
      websiteCode: 'tcom',
      label: 'Tradeling.com',
      createdAt: '2021-09-02T10:24:46.312Z',
    },
  };
};

describe('POST /v3-create-category-backoffice', () => {
  afterEach(async () => {
    categoryModel.deleteMany({});
  });

  it('should return 200', async () => {
    const params: Paths.V3CreateCategoryBackofficeAction.RequestBody = {
      // get random string
      slug: Math.random().toString(36).substring(7),
      parentId: null,
      name: { en: 'category name', ar: 'arabic' },
      description: { en: 'category name', ar: 'arabic' },
      keywords: { en: ['key', 'word'], ar: ['some', 'more'] },
      active: true,
      level: 0,
      websiteCode: 'tcom',
    };
    const { body, status } = await supertest(app)
      .post('/v3-create-category-backoffice')
      .send(params);
    expect(status).toBe(200);
  });

  it('should return audited fields formated', async () => {
    const params: Paths.V3CreateCategoryBackofficeAction.RequestBody = {
      // get random string
      slug: Math.random().toString(36).substring(7),
      parentId: null,
      name: { en: 'category name', ar: 'arabic' },
      description: { en: 'category name', ar: 'arabic' },
      keywords: { en: ['key', 'word'], ar: ['some', 'more'] },
      active: true,
      level: 0,
      websiteCode: 'tcom',
    };
    const { body, status } = await supertest(app)
      .post('/v3-create-category-backoffice')
      .send(params);
    expect(status).toBe(200);

    const auditedFieldsArray: auditFields[] = auditFieldsForCreateCategory(
      body,
    );

    expect(Array.isArray(auditedFieldsArray)).toBe(true);
    auditedFieldsArray.forEach((auditedFields: auditFields, index, array) => {
      expect(auditedFields && typeof auditedFields === 'object').toBe(true);
      expect(auditedFields.name && typeof auditedFields.name === 'string').toBe(
        true,
      );
      expect(auditedFields.new && typeof auditedFields.new === 'string').toBe(
        true,
      );
      expect(
        auditedFields.old && typeof auditedFields.old === 'string',
      ).toBeNull();
    });
  });
});
