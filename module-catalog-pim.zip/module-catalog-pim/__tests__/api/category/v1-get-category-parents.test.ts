import supertest from 'supertest';

import { app } from '@src/config/server/server';
import { createCategory, validateCategory } from '../helpers';
import { categoryModel } from '@express/modules/category/model-category';
describe('POST /v1-get-category-parents', () => {
  beforeEach(async () => {
    await categoryModel.deleteMany({});
  });
  it.each([
    [{ id: undefined }],
    [{ id: 1 }],
    [{ id: '22038b404a1113213f365ce4' }],
    //
  ])(
    'should return 400 Bad Request on invalid request parameters: %p',
    async (params: any) => {
      await supertest(app)
        .post('/v1-get-category-parents')
        .send(params)
        .expect(400)
        .expect('Content-Type', /json/);
    },
  );

  it('should return self if category does not have parents', async () => {
    const category: Components.Schemas.V1Category = await createCategory();
    const { body } = await supertest(app)
      .post('/v1-get-category-parents')
      .send({ id: category._id })
      .expect(200)
      .expect('Content-Type', /json/);

    validateCategory(body[0]);
    expect(body).toEqual([category]);
  });

  it('should return self if category does not have parents', async () => {
    const category0: Components.Schemas.V1Category = await createCategory({
      level: 0,
    });
    const category1: Components.Schemas.V1Category = await createCategory({
      parentId: category0._id,
      level: 1,
    });
    const category2: Components.Schemas.V1Category = await createCategory({
      parentId: category1._id,
      level: 2,
    });

    const { body } = await supertest(app)
      .post('/v1-get-category-parents')
      .send({ id: category2._id })
      .expect(200)
      .expect('Content-Type', /json/);

    body.forEach(validateCategory);
    expect(body.map((i: any) => i._id)).toEqual([
      category0._id,
      category1._id,
      category2._id,
    ]);
  });
});
