import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { categoryModel } from '@express/modules/category/model-category';
import { createCategory } from '../helpers';

describe('POST /v1-get-category-tree-backoffice', () => {
  afterEach(async () => {
    categoryModel.deleteMany();
  });

  it('should return 200', async () => {
    await createCategory();
    const params: Paths.V1GetCategoryTreeBackofficeAction.RequestBody = {};
    const { body, status } = await supertest(app)
      .post('/v1-get-category-tree-backoffice')
      .send(params);
    expect(status).toBe(200);
  });
});
