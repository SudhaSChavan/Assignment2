import { Types } from 'mongoose';
import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { insertProductData } from '../helpers';
import { productModelV3 } from '@express/modules/product/model-product-v3';

describe('POST /v3-move-products-to-category-backoffice', () => {
  afterEach(async () => {
    await productModelV3.deleteMany({});
  });

  it('should return 200', async () => {
    const sourceCategoryId: Types.ObjectId = new Types.ObjectId();
    const targetCategoryId: Types.ObjectId = new Types.ObjectId();
    const [product] = await insertProductData(1, (product) => ({
      ...product,
      categoryId: sourceCategoryId,
    }));
    const params: Paths.V3MoveProductsToCategoryBackofficeAction.RequestBody = {
      productIds: [product._id],
      moveState: 'full',
      // @ts-ignore
      sourceCategoryId: sourceCategoryId.toHexString(),
      // @ts-ignore
      targetCategoryId: targetCategoryId.toHexString(),
    };
    const { status } = await supertest(app)
      .post('/v3-move-products-to-category-backoffice')
      .set('x-store-id', 'tcom-ae')
      .send(params);
    expect(status).toBe(200);
  });
});
