import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { categoryModel } from '@express/modules/category/model-category';
import {
  AttributeTypes,
  categoryAttributeModel,
  ICategoryAttributeDocument,
} from '@express/modules/category/model-category-attribute';
import { createCategory } from '../helpers';

describe('POST /v1-get-filterable-categories-backoffice', () => {
  afterEach(async () => {
    await categoryModel.deleteMany();
    await categoryAttributeModel.deleteMany();
  });

  it('should return 200', async () => {
    const category: Components.Schemas.V1Category = await createCategory();
    const attr: ICategoryAttributeDocument = {
      attributes: [
        {
          code: 'test',
          label: { en: 'test' },
          help: { en: '' },
          required: true,
          type: AttributeTypes.Text,
        },
      ],
      categoryId: category._id,
    } as any;
    await categoryAttributeModel.create(attr);
    const params: Paths.V1GetFilterableCategoryBackofficeAction.RequestBody = {
      categoryAttributeCode: 'test',
    };
    const { status } = await supertest(app)
      .post('/v1-get-filterable-categories-backoffice')
      .send(params);
    expect(status).toBe(200);
  });
});
