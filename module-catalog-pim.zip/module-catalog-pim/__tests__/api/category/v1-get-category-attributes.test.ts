import supertest from 'supertest';

import { app } from '@src/config/server/server';
import { createCategory } from '../helpers';
import { categoryModel } from '@express/modules/category/model-category';
describe('POST /v1-get-category-attributes', () => {
  afterAll(async () => {
    await categoryModel.deleteMany({});
  });

  it.each([
    [{ id: undefined }],
    [{ id: 1 }],
    [{ id: '22038b404a1113213f365ce4' }],
    //
  ])(
    'should return 400 Bad Request on invalid request parameters: %p',
    async (params: any) => {
      await supertest(app)
        .post('/v1-get-category-attributes')
        .send(params)
        .expect(400)
        .expect('Content-Type', /json/);
    },
  );

  it('should return empty category attributes list', async () => {
    const category: Components.Schemas.V1Category = await createCategory();
    const { body } = await supertest(app)
      .post('/v1-get-category-attributes')
      .send({ id: category._id })
      .expect(200)
      .expect('Content-Type', /json/);

    expect(body).toEqual({});
  });

  it.todo('should return category attributes');
});
