import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { categoryModel } from '@express/modules/category/model-category';
import { createCategory } from '../helpers';

describe('POST /v3-get-products-by-category-backoffice', () => {
  afterEach(async () => {
    categoryModel.deleteMany({});
  });

  it('should return 200', async () => {
    const category: Components.Schemas.V1Category = await createCategory();
    const params: Paths.V3GetProductsByCategoryBackofficeAction.RequestBody = {
      filter: {
        categoryIds: [category._id],
      },
    };
    const { status } = await supertest(app)
      .post('/v3-get-products-by-category-backoffice')
      .send(params);
    expect(status).toBe(200);
  });
});
