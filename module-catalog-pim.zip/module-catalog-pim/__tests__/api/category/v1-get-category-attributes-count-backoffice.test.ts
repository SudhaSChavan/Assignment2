import { Types } from 'mongoose';
import supertest from 'supertest';
import { app } from '@src/config/server/server';
import {
  categoryAttributeModel,
  ICategoryAttributeDocument,
} from '@express/modules/category/model-category-attribute';

describe('/v1-get-category-attributes-count-backoffice', () => {
  beforeEach(async () => {
    await categoryAttributeModel.deleteMany({});
  });
  it('should get company profile count', async () => {
    const attribute: ICategoryAttributeDocument = {
      attributes: [],
      // @ts-ignore
      categoryId: new Types.ObjectId().toHexString(),
      categoryTree: [],
    } as any;
    await categoryAttributeModel.create(attribute);
    const { body } = await supertest(app)
      .post('/v1-get-category-attributes-count-backoffice')
      .set('x-language', 'en')
      .set('x-country', 'ae')
      .send({})
      .expect(200);
    expect(body.count).toBe(1);
  });
});
