import supertest from 'supertest';
import { app } from '@src/config/server/server';

describe('POST /v1-search-category-backoffice', () => {
  it('should return 200', async () => {
    const params: Paths.V1SearchCategoryBackofficeAction.RequestBody = {
      websiteCode: 'tcom',
      term: 'baby',
    };
    const { status } = await supertest(app)
      .post('/v1-search-category-backoffice')
      .send(params);
    expect(status).toBe(200);
  });
});
