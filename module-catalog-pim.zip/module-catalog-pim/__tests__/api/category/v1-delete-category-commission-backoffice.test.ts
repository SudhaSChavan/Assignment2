import { Types } from 'mongoose';
import supertest from 'supertest';
import { app } from '@src/config/server/server';
import {
  categoryCommissionModel,
  ICategoryCommissionDocument,
  ICategoryCommissionModel,
} from '@express/modules/category/model-category-commission';

describe('POST /v1-delete-category-commission-backoffice', () => {
  it('should return 200', async () => {
    const commissionDoc: ICategoryCommissionDocument = {
      // @ts-ignore
      categoryId: new Types.ObjectId().toHexString(),
      commission: 10,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    const commission: ICategoryCommissionModel = await categoryCommissionModel.create(
      commissionDoc,
    );
    const params: Paths.V1DeleteCategoryCommissionBackofficeAction.RequestBody = {
      id: commission._id,
    };
    const { status } = await supertest(app)
      .post('/v1-delete-category-commission-backoffice')
      .send(params);
    expect(status).toBe(200);
  });
});
