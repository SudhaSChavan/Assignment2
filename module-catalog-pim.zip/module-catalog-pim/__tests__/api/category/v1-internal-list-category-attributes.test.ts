import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { createCategory } from '../helpers';
import { getInternalApiSecret } from '@tradeling/web-js-utils';
import { appConfig } from '../../../src/config/env';
import {
  AttributeTypes,
  categoryAttributeModel,
  ICategoryAttributeDocument,
} from '@express/modules/category/model-category-attribute';
import { categoryModel } from '@express/modules/category/model-category';

type RequestBody = Paths.V1InternalListCategoryAttributesAction.RequestBody;
describe('POST /v1-internal-list-category-attributes', () => {
  beforeAll(() => {
    process.env[`IN_FROM_MODULE_1`] = 'secret';
    process.env[`OUT_TO_MODULE_CATALOG_PIM`] = 'secret';
  });

  beforeEach(async () => {
    await categoryAttributeModel.deleteMany({});
    await categoryModel.deleteMany({});
  });

  afterAll(async () => {
    await categoryAttributeModel.deleteMany({});
    await categoryModel.deleteMany({});
  });

  it(`should return list of attributes`, async () => {
    const category: Components.Schemas.V1Category = await createCategory();
    const attr: ICategoryAttributeDocument = {
      attributes: [
        {
          code: 'test',
          label: { en: 'test' },
          help: { en: '' },
          required: true,
          type: AttributeTypes.Text,
        },
      ],
      categoryId: category._id,
    } as any;
    await categoryAttributeModel.create(attr);
    const payload: RequestBody = {
      filter: {
        categoryIds: [category._id],
      },
    };
    const { body, status } = await callListApi(payload);
    expect(status).toBe(200);
    expect(body.length).toBe(1);
  });
});

function callListApi(payload: RequestBody) {
  return supertest(app)
    .post('/v1-internal-list-category-attributes')
    .set('x-is-internal-request', '1')
    .set(
      'x-t-secret',
      getInternalApiSecret({ to: appConfig.name, from: 'module-1' }),
    )
    .send(payload);
}
