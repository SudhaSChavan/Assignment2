import { Types } from 'mongoose';
import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { categoryModel } from '@express/modules/category/model-category';
import { createCategory, insertProductData } from '../helpers';
import { V1InternalListSupplierCompanyAction } from '@tradeling/tradeling-sdk/account/v1-internal-list-supplier-company-action';
import { productModelV3 } from '@express/modules/product/model-product-v3';

jest.mock(
  '@tradeling/tradeling-sdk/account/v1-internal-list-supplier-company-action',
);

const mockV1InternalListSupplierCompanyAction: jest.MockedFunction<
  typeof V1InternalListSupplierCompanyAction
> = <jest.MockedFunction<typeof V1InternalListSupplierCompanyAction>>(
  (V1InternalListSupplierCompanyAction as any)
);
mockV1InternalListSupplierCompanyAction.mockImplementation((request) => {
  return {
    status: 200,
    data: {
      items: request.filter.ids.map((id) => {
        return { _id: id, isVerified: true };
      }),
    },
  } as any;
});

describe('POST /v3-get-category-products-stats-backoffice', () => {
  beforeEach(async () => {
    await categoryModel.deleteMany({});
    await productModelV3.deleteMany({});
  });

  it('should return 200', async () => {
    const category: Components.Schemas.V1Category = await createCategory();
    // @ts-ignore
    await insertProductData(5, (product) => ({
      ...product,
      categoryId: category._id,
      deletedAt: null,
      // @ts-ignore
      createdSupplierCompanyId: new Types.ObjectId().toHexString(),
    }));
    const params: Paths.V3GetCategoryProductsStatsBackofficeAction.RequestBody = {};
    const { body, status } = await supertest(app)
      .post('/v3-get-category-products-stats-backoffice')
      .send(params);
    console.log(body);
    expect(status).toBe(200);
  });
});
