import { Types } from 'mongoose';
import supertest from 'supertest';
import { app } from '@src/config/server/server';

describe('POST /v3-bulk-get-affectable-products-backoffice', () => {
  it('should return 200', async () => {
    const params: Paths.V3BulkGetAffectableProductsBackofficeAction.RequestBody = {
      filter: {
        // @ts-ignore
        newParentId: new Types.ObjectId().toHexString(),
      },
    };
    const { status } = await supertest(app)
      .post('/v3-bulk-get-affectable-products-backoffice')
      .send(params);
    expect(status).toBe(200);
  });
});
