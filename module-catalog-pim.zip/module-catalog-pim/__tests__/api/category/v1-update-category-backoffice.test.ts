import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { categoryModel } from '@express/modules/category/model-category';
import { createCategory } from '../helpers';

describe('POST /v1-update-category-backoffice', () => {
  afterEach(async () => {
    await categoryModel.deleteMany({});
  });

  it('should return 200', async () => {
    const category: Components.Schemas.V1Category = await createCategory();
    const params: Paths.V1UpdateCategoryBackofficeAction.RequestBody = {
      id: category._id,
      name: { en: 'new name', ar: 'ar name' },
      keywords: { en: ['keywords'], ar: ['keywords'] },
      slug: 'slug',
    };
    const { body, status } = await supertest(app)
      .post('/v1-update-category-backoffice')
      .send(params);
    expect(status).toBe(200);
  });
});
