import supertest from 'supertest';
import { app } from '@src/config/server/server';
import { createCategory } from '../helpers';
import { V1IndexCategoryMetadataAction } from '@tradeling/tradeling-sdk/catalog-search/v1-index-category-metadata-action';

jest.mock(
  '@tradeling/tradeling-sdk/catalog-search/v1-index-category-metadata-action',
);

const mockV1IndexCategoryMetadataAction: jest.MockedFunction<
  typeof V1IndexCategoryMetadataAction
> = <jest.MockedFunction<typeof V1IndexCategoryMetadataAction>>(
  (V1IndexCategoryMetadataAction as any)
);

mockV1IndexCategoryMetadataAction.mockImplementation(() => {
  return {
    status: 200,
    data: {},
  } as any;
});

describe('POST /v1-copy-category-attributes-backoffice', () => {
  it('should return 200', async () => {
    const source: Components.Schemas.V1Category = await createCategory();
    const target: Components.Schemas.V1Category = await createCategory();
    const params: Paths.V1CopyCategoryAttributesBackofficeAction.RequestBody = {
      sourceCategoryId: source._id,
      targetCategoryIds: [target._id],
    };
    const { body, status } = await supertest(app)
      .post('/v1-copy-category-attributes-backoffice')
      .send(params);
    expect(status).toBe(200);
  });
});
