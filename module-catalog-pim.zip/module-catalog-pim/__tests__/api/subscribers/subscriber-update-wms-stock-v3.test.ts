import { createCategory, createProductV3, randomString } from '../helpers';
import {
  IOfferModelV3,
  offerModelV3,
} from '@express/modules/offer/model-offers-v3';
import { updateProductStock } from '@express/modules/product/v3/subscribers/subscriber-update-wms-stock-v3';
import {
  IProductModelV3,
  productModelV3,
} from '@express/modules/product/model-product-v3';
import { categoryModel } from '@express/modules/category/model-category';
import V1Category = Components.Schemas.V1Category;

let category: V1Category;
let mainProduct: Components.Schemas.V3Product;
let edukaanProduct: Components.Schemas.V3Product;
let mainOffer: IOfferModelV3;

import * as api from '@tradeling/tradeling-sdk/www/v1-get-store-by-store-id-action';

(api as any).V1GetStoreByStoreIdAction = async (data: any): Promise<any> => {
  return {
    data: {
      id: '8dcb7e52-198e-46b9-9093-1601db946b46',
      websiteCode: 'tcom',
      label: 'Tradeling.com',
      createdAt: '2022-10-26T09:28:46.312Z',
    },
  };
};

describe('subscriber-update-wms-stock-v3.ts', () => {
  beforeAll(async () => {
    category = await createCategory();
    const sku: string = randomString();
    mainProduct = await createProductV3({
      sku,
      categoryId: category._id,
      supplierCompanyId: '5e4e8cfc123ac0e4c0d96f14',
    });

    edukaanProduct = await createProductV3({
      storeKeyId: 'edukaan-ae',
      sku,
      websiteCode: 'edukaan',
      categoryId: category._id,
      supplierCompanyId: '5e4e8cfc123ac0e4c0d96f12',
    });
    mainOffer = await offerModelV3.findOne({ productId: mainProduct._id });
  });

  it('pass stock qty .. stock > MOQ ', async () => {
    // trigger stock update
    await updateProductStock(
      mainProduct.sku,
      12,
      [
        {
          warehouse: {
            guid: '8dcb7e52-198e-46b9-9093-1601db946b46',
            id: 1268,
            name: 'DXB1',
            label: 'AABCCB',
          },
          available: 12,
        },
      ],
      [mainProduct.supplierCompanyId, edukaanProduct.supplierCompanyId],
    );
    // check the mainProduct data ...
    const product: IProductModelV3 = await productModelV3
      .findOne({ _id: mainProduct._id })
      .lean();

    expect(product.tags).toContain('express');
    expect(product.stockQty).toBe(12);
    expect(product.isInStock).toBe(true);

    const productOffer: IOfferModelV3 = await offerModelV3
      .findOne({ productId: mainProduct._id })
      .lean();
    expect(productOffer?.delivery.hasCustomDeliveryDay).toBe(true);

    // edukaan cases ...
    const edukaan: IProductModelV3 = await productModelV3
      .findOne({ _id: edukaanProduct._id })
      .lean();
    expect(edukaan.tags).toEqual([]);
    expect(edukaan.stockQty).toBe(12);
    expect(edukaan.isInStock).toBe(true);
    const edukaanOffer: IOfferModelV3 = await offerModelV3
      .findOne({ productId: edukaan._id })
      .lean();
    expect(edukaanOffer?.delivery.hasCustomDeliveryDay).toBe(true);
  });

  it('pass zero qty .. check the output - should remove express tag / hasCustomDelivery should be false ', async () => {
    // removing stock Qty
    await updateProductStock(
      mainProduct.sku,
      0,
      [
        {
          warehouse: {
            guid: '8dcb7e52-198e-46b9-9093-1601db946b46',
            id: 1268,
            name: 'DXB1',
            label: 'AABCCB',
          },
          available: 0,
        },
      ],
      [mainProduct.supplierCompanyId, edukaanProduct.supplierCompanyId],
    );
    const productDataWithoutStock: IProductModelV3 = await productModelV3
      .findOne({ _id: mainProduct._id })
      .lean();
    expect(productDataWithoutStock.stockQty).toBe(0);
    expect(productDataWithoutStock.isInStock).toBeFalsy();
    const productOfferWithoutStock: IOfferModelV3 = await offerModelV3
      .findOne({ productId: productDataWithoutStock._id })
      .lean();
    expect(productOfferWithoutStock?.delivery.hasCustomDeliveryDay).toBe(false);

    const edukaan: IProductModelV3 = await productModelV3
      .findOne({ _id: edukaanProduct._id })
      .lean();
    expect(edukaan.stockQty).toBe(0);
    expect(edukaan.isInStock).toBeFalsy();
    const edukaanOffer: IOfferModelV3 = await offerModelV3
      .findOne({ productId: edukaan._id })
      .lean();
    expect(edukaanOffer?.delivery.hasCustomDeliveryDay).toBe(false);
  });

  it('pass qty less than MOQ - should update default MOQ - and update MOQ ', async () => {
    const originalMoq: number = mainOffer?.market?.tiers[0]?.minQty;
    await updateProductStock(
      mainProduct.sku,
      9,
      [
        {
          warehouse: {
            guid: '8dcb7e52-198e-46b9-9093-1601db946b46',
            id: 1268,
            name: 'DXB1',
            label: 'AABCCB',
          },
          available: 9,
        },
      ],
      [mainProduct.supplierCompanyId, edukaanProduct.supplierCompanyId],
    );

    const productDataWithStock: IProductModelV3 = await productModelV3
      .findOne({ _id: mainProduct._id })
      .lean();
    expect(productDataWithStock.stockQty).toBe(9);
    expect(productDataWithStock.isInStock).toBeTruthy();
    expect(productDataWithStock.tags).toContain('express');
    const productOfferWithStock: IOfferModelV3 = await offerModelV3
      .findOne({ productId: productDataWithStock._id })
      .lean();
    expect(productOfferWithStock?.delivery.hasCustomDeliveryDay).toBe(true);

    // old MOQ will be stored inside the defaultMOQ
    expect(productOfferWithStock?.market.tiers[0].defaultMoq).toBe(originalMoq);
    expect(productOfferWithStock?.market.tiers[0].minQty).toBe(9);

    const edukaan: IProductModelV3 = await productModelV3
      .findOne({ _id: edukaanProduct._id })
      .lean();
    expect(edukaan.stockQty).toBe(9);
    expect(edukaan.isInStock).toBeTruthy();

    expect(edukaan.tags).toEqual([]);
    const edukaanOffer: IOfferModelV3 = await offerModelV3
      .findOne({ productId: edukaan._id })
      .lean();
    expect(edukaanOffer?.delivery.hasCustomDeliveryDay).toBe(true);

    // old MOQ will be stored inside the defaultMOQ
    expect(productOfferWithStock?.market.tiers[0].defaultMoq).toBe(originalMoq);
    expect(productOfferWithStock?.market.tiers[0].minQty).toBe(9);
  });

  it('when receive new stock greater than the defaultMOQ -- default MOQ should be 0 - MOQ should be reset to original value', async () => {
    const originalMoq: number = mainOffer?.market?.tiers[0]?.minQty;
    await updateProductStock(
      mainProduct.sku,
      20,
      [
        {
          warehouse: {
            guid: '8dcb7e52-198e-46b9-9093-1601db946b46',
            id: 1268,
            name: 'DXB1',
            label: 'AABCCB',
          },
          available: 20,
        },
      ],
      [mainProduct.supplierCompanyId, edukaanProduct.supplierCompanyId],
    );

    const product: IProductModelV3 = await productModelV3
      .findOne({ _id: mainProduct._id })
      .lean();
    expect(product.stockQty).toBe(20);
    expect(product.isInStock).toBe(true);
    expect(product.tags).toContain('express');
    const offer: IOfferModelV3 = await offerModelV3
      .findOne({ productId: product._id })
      .lean();
    expect(offer?.delivery.hasCustomDeliveryDay).toBe(true);

    // old MOQ will be stored inside the defaultMOQ
    expect(offer?.market.tiers[0].defaultMoq).toBe(0);
    expect(offer?.market.tiers[0].minQty).toBe(originalMoq);

    const edukaan: IProductModelV3 = await productModelV3
      .findOne({ _id: edukaanProduct._id })
      .lean();
    expect(edukaan.stockQty).toBe(20);
    expect(edukaan.isInStock).toBe(true);
    expect(edukaan.tags).toEqual([]);
    const edukaanOffer: IOfferModelV3 = await offerModelV3
      .findOne({ productId: edukaan._id })
      .lean();
    expect(edukaanOffer?.delivery.hasCustomDeliveryDay).toBe(true);

    // old MOQ will be stored inside the defaultMOQ
    expect(edukaanOffer?.market.tiers[0].defaultMoq).toBe(0);
    expect(edukaanOffer?.market.tiers[0].minQty).toBe(originalMoq);
  });

  afterAll(async () => {
    await productModelV3.deleteMany({});
    await offerModelV3.deleteMany({});
    await categoryModel.deleteMany({});
  });
});
