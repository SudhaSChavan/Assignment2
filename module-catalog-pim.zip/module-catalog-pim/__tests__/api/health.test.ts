import supertest from 'supertest';
import { app } from '@src/config/server/server';

const secret: string = process.env.BASIC_STATS_SECRET_CONFIG || 'health-secret';

describe('Health endpoints', () => {
  describe('GET /v1-stats', () => {
    it('should return 401 Unauthorized if secret is wrong', async () => {
      await supertest(app)
        .get('/v1-stats')
        .expect(401)
        .expect('Content-Type', /json/);
    });

    it('should return basic stat', async () => {
      const { body } = await supertest(app)
        .get('/v1-stats')
        .query({ secret })
        .expect(200)
        .expect('Content-Type', /json/);

      expect(body.pid).toBeGreaterThanOrEqual(1);
      expect(body.headers).toBeInstanceOf(Object);
      expect(body.freeMem).toBeGreaterThanOrEqual(1);
      expect(body.totalMem).toBeGreaterThanOrEqual(body.freeMem);
    });

    // @todo fix endpoint
    it.skip('should return extended stat if extra health secret provided', async () => {
      const { body } = await supertest(app)
        .get('/v1-stats')
        .query({ secret })
        .expect(200)
        .expect('Content-Type', /json/);

      expect(body.pid).toBeGreaterThanOrEqual(1);
      expect(body.headers).toBeInstanceOf(Object);
      expect(body.freeMem).toBeGreaterThanOrEqual(1);
      expect(body.totalMem).toBeGreaterThanOrEqual(body.freeMem);
      expect(body.config).toBeInstanceOf(Object);
      expect(body.env).toBeInstanceOf(Object);
    });
  });

  // @todo fix endpoint, it does not work
  describe.skip('GET /v1-version', () => {
    it('should return current version', async () => {
      const { body } = await supertest(app)
        .get('/v1-version')
        .expect(200)
        .expect('Content-Type', /json/);

      expect(typeof body.version).toBe('string');
    });
  });

  // @todo fix endpoint, it does not work
  describe.skip('GET /v1-mongodb-health', () => {
    it('should return mongo db health status', async () => {
      const { body } = await supertest(app)
        .get('/v1-mongodb-health')
        .query({ secret })
        .expect(200)
        .expect('Content-Type', /json/);

      expect(body.dbState).toBeGreaterThanOrEqual(0);
    });
  });
});
