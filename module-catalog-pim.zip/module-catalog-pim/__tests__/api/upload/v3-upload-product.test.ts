import supertest from 'supertest';
import Excel, { Workbook, Worksheet } from 'exceljs';
import {
  addAttributesToCategory,
  createCategory,
  createValidProductRow,
  downloadProductTemplate,
  getAttributes,
  listProductUploadRows,
  randomString,
  uploadMedia,
  uploadProducts,
} from '../helpers';
import { app } from '@src/config/server/server';
import { categoryModel } from '@express/modules/category/model-category';
import { CategoryAttributeType } from '@express/modules/category/model-category-attribute';
import {
  IProductUploadRowModelV3,
  productUploadRowModelV3,
} from '@express/modules/upload/model-product-upload-row-v3';

import * as api from '@tradeling/tradeling-sdk/www/v1-get-store-by-store-id-action';

(api as any).V1GetStoreByStoreIdAction = async (data: any): Promise<any> => {
  return {
    status: 200,
    data: {
      storeKeyId: 'tcom-ae',
      storeCode: 'ae',
      name: 'Tradeling Web UAE',
      websiteId: '29cd07c0-6c8e-46ff-b6c9-7e63f440146f',
      website: {
        websiteCode: 'tcom',
        label: 'Tradeling.com',
      },
    },
  };
};

describe('POST /v3-upload-product', () => {
  let category: Components.Schemas.V1Category;
  let workbookBuffer: Buffer;

  beforeAll(async () => {
    category = await createCategory();
    workbookBuffer = await downloadProductTemplate([category._id]);
  });

  afterAll(async () => {
    await categoryModel.deleteMany({});
  });

  it.each([[{ filename: '' }], [{ filename: 'a.b' }]])(
    'should return 400 Bad Request on invalid file name: %p',
    async (params) => {
      await supertest(app)
        .post('/v3-upload-product')
        .attach('files[]', Buffer.from('this is file content'), {
          filename: params.filename,
        })
        .expect(400)
        .expect('Content-Type', /json/);
    },
  );

  it('should return 400 Bad Request when no file provided', async () => {
    await supertest(app)
      .post('/v3-upload-product')
      .set({ 'x-store-id': 'tcom-ae' })
      .expect(400)
      .expect('Content-Type', /json/);
  });

  it('should return 400 Bad Request when xlsx is invalid', async () => {
    await supertest(app)
      .post('/v3-upload-product')
      .set({ 'x-store-id': 'tcom-ae' })
      .attach('files[]', Buffer.from('wrong content'), {
        filename: 'data.xlsx',
      })
      .expect(400)
      .expect('Content-Type', /json/);
  });

  it('should return 400 Bad Request when no sheets on xlsx file', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    wb.removeWorksheet(3);
    wb.removeWorksheet(2);
    wb.removeWorksheet(1);
    const buffer: any = await wb.xlsx.writeBuffer();

    await supertest(app)
      .post('/v3-upload-product')
      .set({ 'x-store-id': 'tcom-ae' })
      .attach('files[]', buffer, { filename: 'data.xlsx' })
      .expect(400)
      .expect('Content-Type', /json/);
  });

  it('should return 400 Bad Request when no data in sheet', async () => {
    await supertest(app)
      .post('/v3-upload-product')
      .set({ 'x-store-id': 'tcom-ae' })
      .attach('files[]', workbookBuffer, { filename: 'data.xlsx' })
      .expect(400)
      .expect('Content-Type', /json/);
  });

  it('should return 400 Bad Request when no meta data sheet in document', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    wb.getWorksheet(1).getRow(2).values = ['1', '2', '3', '4', '5'];
    wb.removeWorksheet(3);
    const buffer: any = await wb.xlsx.writeBuffer();

    await supertest(app)
      .post('/v3-upload-product')
      .set({ 'x-store-id': 'tcom-ae' })
      .attach('files[]', buffer, { filename: 'data.xlsx' })
      .expect(400)
      .expect('Content-Type', /json/);
  });

  it('should return 400 Bad Request when no category slug', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    wb.getWorksheet(4).getCell('A2').value = '';
    const buffer: any = await wb.xlsx.writeBuffer();

    await supertest(app)
      .post('/v3-upload-product')
      .set({ 'x-store-id': 'tcom-ae' })
      .attach('files[]', buffer, { filename: 'data.xlsx' })
      .expect(400)
      .expect('Content-Type', /json/);
  });

  it('should return 400 Bad Request on unknown category slug', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    wb.getWorksheet(4).getCell('A3').value = 'wow-such-category-slug';
    const buffer: any = await wb.xlsx.writeBuffer();

    await supertest(app)
      .post('/v3-upload-product')
      .set({ 'x-store-id': 'tcom-ae' })
      .attach('files[]', buffer, { filename: 'data.xlsx' })
      .expect(400)
      .expect('Content-Type', /json/);
  });

  it('should return upload if there is only one but correct line in sheet', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    const worksheet: Worksheet = wb.getWorksheet(2);
    worksheet
      .addRow(
        await createValidProductRow([category?._id], {
          categoryId: category?.slug,
        }),
        'n',
      )
      .commit();
    const buffer: any = await wb.xlsx.writeBuffer();
    const body: any = await uploadProducts(buffer);
    expect(body.totalCount).toEqual(1);
  });
  it('should validate based on category selection on each line', async () => {
    // create categoryWithRequiredAttribute
    const categoryWithRequiredAttribute: Components.Schemas.V1Category = await createCategory();
    const attributes: CategoryAttributeType[] = getAttributes();
    attributes[0].required = true;
    await addAttributesToCategory(categoryWithRequiredAttribute, attributes);

    // create categoryWithOptionalAttributes
    const categoryWithOptionalAttributes: Components.Schemas.V1Category = await createCategory();
    const newAttributes: CategoryAttributeType[] = getAttributes();
    newAttributes[0].required = false;
    await addAttributesToCategory(
      categoryWithOptionalAttributes,
      newAttributes,
    );

    const multiCategoryWorkbookBuffer: Buffer = await downloadProductTemplate([
      //
      category._id,
      categoryWithRequiredAttribute._id,
      categoryWithOptionalAttributes._id,
    ]);
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(multiCategoryWorkbookBuffer);
    const worksheet: Worksheet = wb.getWorksheet(2);
    worksheet
      .addRow(
        await createValidProductRow(
          [
            //
            category._id,
            categoryWithRequiredAttribute._id,
            categoryWithOptionalAttributes._id,
          ],
          { categoryId: category?.slug, sku: randomString() },
        ),
        'n',
      )
      .commit();
    worksheet
      .addRow(
        await createValidProductRow(
          [
            //
            category._id,
            categoryWithRequiredAttribute._id,
            categoryWithOptionalAttributes._id,
          ],
          {
            categoryId: categoryWithRequiredAttribute?.slug,
            sku: randomString(),
            'attributes.text': '',
          },
        ),
        'n',
      )
      .commit();

    const buffer: Excel.Buffer = await wb.xlsx.writeBuffer();
    const upload: Components.Schemas.V1Upload = await uploadProducts(
      buffer as Buffer,
    );
    const productUploadRows: Components.Schemas.V1ProductUploadRows = await listProductUploadRows(
      upload._id,
    );

    // validate product with category no attributes
    expect(productUploadRows[0].categoryId).toBe(category._id);
    expect(productUploadRows[0].state).toBe('valid');

    // validate product with category required attribute
    expect(productUploadRows[1].categoryId).toBe(
      categoryWithRequiredAttribute._id,
    );
    expect(productUploadRows[1].state).toBe('invalid');

    expect(upload.totalCount).toEqual(2);
  });

  it('should accept localized attribute', async () => {
    // create categoryWithLocalizedAttribute
    const categoryWithLocalizedAttribute: Components.Schemas.V1Category = await createCategory();
    const attributes: CategoryAttributeType[] = getAttributes();
    const localizedAttribute: CategoryAttributeType = attributes[0];
    localizedAttribute.isLocalized = true;
    await addAttributesToCategory(categoryWithLocalizedAttribute, attributes);

    const multiCategoryWorkbookBuffer: Buffer = await downloadProductTemplate([
      categoryWithLocalizedAttribute._id,
    ]);
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(multiCategoryWorkbookBuffer);
    const worksheet: Worksheet = wb.getWorksheet(2);

    worksheet
      .addRow(
        await createValidProductRow([categoryWithLocalizedAttribute._id], {
          categoryId: categoryWithLocalizedAttribute.slug,
        }),
        'n',
      )
      .commit();

    const buffer: Excel.Buffer = await wb.xlsx.writeBuffer();
    const upload: Components.Schemas.V1Upload = await uploadProducts(
      buffer as Buffer,
    );
    const productUploadRows: IProductUploadRowModelV3[] = await productUploadRowModelV3
      .find({ uploadId: upload._id })
      .lean();

    // filled product will have localized attribute
    expect(productUploadRows[0].fields.name).toHaveProperty('en');
    expect(productUploadRows[0].fields.name).toHaveProperty('ar');
    expect(productUploadRows[0].fields.shortDescription.en).toMatch(/@@/);
    expect(productUploadRows[0].fields.shortDescription.ar).toMatch(/@@/);
    expect(productUploadRows[0].fields.longDescription).toHaveProperty('en');
    expect(productUploadRows[0].fields.longDescription).toHaveProperty('ar');
    expect(Array.isArray(productUploadRows[0].fields.keywords.en)).toBeTruthy();
    expect(Array.isArray(productUploadRows[0].fields.keywords.ar)).toBeTruthy();
    expect(productUploadRows[0].fields).toHaveProperty([
      'attributes',
      localizedAttribute.code,
      'en',
    ]);
    expect(productUploadRows[0].fields).toHaveProperty([
      'attributes',
      localizedAttribute.code,
      'ar',
    ]);
    expect(productUploadRows[0].categoryId.toString()).toBe(
      categoryWithLocalizedAttribute._id,
    );
    expect(productUploadRows[0].state).toBe('valid');

    expect(upload.totalCount).toEqual(1);
  });

  it('should upload 2 product upload rows and auto assign media to 1 product upload row', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    const worksheet: Worksheet = wb.getWorksheet(2);
    const imageSku: string = randomString();
    const rowWithImage: any = await createValidProductRow([category?._id], {
      categoryId: category.slug,
      sku: imageSku,
    });
    worksheet.addRow(rowWithImage, 'n').commit();
    worksheet
      .addRow(
        await createValidProductRow([category?._id], {
          sku: randomString(),
          categoryId: category.slug,
        }),
        'n',
      )
      .commit();
    const buffer: any = await wb.xlsx.writeBuffer();

    const media: Components.Schemas.V1MediaItem = await uploadMedia(imageSku); // SKU
    const upload: Paths.V3UploadProductAction.Responses.$200 = await uploadProducts(
      buffer,
    );
    expect(upload.totalCount).toEqual(2);

    const productUploadRows: Components.Schemas.V1ProductUploadRows = await listProductUploadRows(
      upload._id,
    );
    expect(productUploadRows[0].media).toEqual([media._id]);
    expect(productUploadRows[0].state).toEqual('valid');
    expect(productUploadRows[1].media).toEqual([]);
    expect(productUploadRows[1].state).toEqual('valid');
  });

  it('should create a simple product with assigned images', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    const worksheet: Worksheet = wb.getWorksheet(2);
    const imageSku: string = randomString();
    worksheet
      .addRow(
        await createValidProductRow([category._id], {
          categoryId: category?.slug,
          sku: imageSku,
          parentSku: '',
          'variantValues.0.code': '',
          'variantValues.0.value.en': '',
          'variantValues.1.code': '',
          'variantValues.1.value.en': '',
        }),
        'n',
      )
      .commit();

    const buffer: Excel.Buffer = await wb.xlsx.writeBuffer();
    const media: Components.Schemas.V1MediaItem = await uploadMedia(imageSku); // SKU

    const upload: Components.Schemas.V1Upload = await uploadProducts(
      buffer as Buffer,
    );
    const productUploadRows: Components.Schemas.V1ProductUploadRows = await listProductUploadRows(
      upload._id,
    );

    // validate product with category no attributes
    expect(productUploadRows[0].categoryId).toBe(category._id);
    expect(productUploadRows[0].isVariant).toBe(false);
    expect(productUploadRows[0].state).toBe('valid');
    expect(productUploadRows[0].media).toEqual([media._id]);
    expect(upload.totalCount).toEqual(1);
  });

  it('should create a variant product with assigned images', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    const worksheet: Worksheet = wb.getWorksheet(2);
    const imageSku: string = randomString();
    worksheet
      .addRow(
        await createValidProductRow([category._id], {
          categoryId: category?.slug,
          sku: imageSku,
          parentSku: 'test-parent-sku',
          'variantValues.0.code': 'color',
          'variantValues.0.value.en': 'Red',
          'variantValues.1.code': 'size',
          'variantValues.1.value.en': 'M',
        }),
        'n',
      )
      .commit();

    worksheet
      .addRow(
        await createValidProductRow([category._id], {
          categoryId: category?.slug,
          sku: randomString(),
          parentSku: 'test-parent-sku',
          'variantValues.0.code': 'color',
          'variantValues.0.value.en': 'Yellow',
          'variantValues.1.code': 'size',
          'variantValues.1.value.en': 'L',
        }),
        'n',
      )
      .commit();

    const buffer: Excel.Buffer = await wb.xlsx.writeBuffer();
    const media: Components.Schemas.V1MediaItem = await uploadMedia(imageSku); // SKU

    const upload: Components.Schemas.V1Upload = await uploadProducts(
      buffer as Buffer,
    );
    const productUploadRows: IProductUploadRowModelV3[] = await productUploadRowModelV3
      .find({ uploadId: upload._id })
      .lean();

    // validate product with category no attributes
    expect(productUploadRows[0].categoryId.toString()).toBe(category._id);
    expect(productUploadRows[0].isVariant).toBe(true);
    expect(productUploadRows[0].state).toBe('valid');
    expect(productUploadRows[0].fields.postfix?.en).toEqual('Red, M');
    expect(productUploadRows[1].categoryId.toString()).toBe(category._id);
    expect(productUploadRows[1].isVariant).toBe(true);
    expect(productUploadRows[1].state).toBe('valid');
    expect(productUploadRows[1].fields.postfix?.en).toEqual('Yellow, L');
    expect(upload.totalCount).toEqual(2);
  });

  it('should create a product with error if name is not exist', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    const worksheet: Worksheet = wb.getWorksheet(2);
    const imageSku: string = randomString();
    worksheet
      .addRow(
        await createValidProductRow([category._id], {
          categoryId: category?.slug,
          sku: imageSku,
          'name.en': '',
        }),
        'n',
      )
      .commit();

    const buffer: Excel.Buffer = await wb.xlsx.writeBuffer();

    const upload: Components.Schemas.V1Upload = await uploadProducts(
      buffer as Buffer,
    );
    const productUploadRows: Components.Schemas.V1ProductUploadRows = await listProductUploadRows(
      upload._id,
    );
    expect(
      productUploadRows[0].row.find((row) => row.field === 'name.en').error,
    ).not.toBeNull();
    expect(productUploadRows[0].state).toBe('invalid');
    expect(upload.totalCount).toEqual(1);
  });

  it('should create a product with error if name is not less than 15 char', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    const worksheet: Worksheet = wb.getWorksheet(2);
    const imageSku: string = randomString();
    worksheet
      .addRow(
        await createValidProductRow([category._id], {
          categoryId: category?.slug,
          sku: imageSku,
          'name.en': 'test product',
        }),
        'n',
      )
      .commit();

    const buffer: Excel.Buffer = await wb.xlsx.writeBuffer();

    const upload: Components.Schemas.V1Upload = await uploadProducts(
      buffer as Buffer,
    );
    const productUploadRows: Components.Schemas.V1ProductUploadRows = await listProductUploadRows(
      upload._id,
    );
    expect(
      productUploadRows[0].row.find((row) => row.field === 'name.en').error,
    ).not.toBeNull();
    expect(productUploadRows[0].state).toBe('invalid');
    expect(upload.totalCount).toEqual(1);
  });

  it('should create a product with error if keywords.en is not exist', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    const worksheet: Worksheet = wb.getWorksheet(2);
    const imageSku: string = randomString();
    worksheet
      .addRow(
        await createValidProductRow([category._id], {
          categoryId: category?.slug,
          sku: imageSku,
          'keywords.en': '',
        }),
        'n',
      )
      .commit();

    const buffer: Excel.Buffer = await wb.xlsx.writeBuffer();

    const upload: Components.Schemas.V1Upload = await uploadProducts(
      buffer as Buffer,
    );
    const productUploadRows: Components.Schemas.V1ProductUploadRows = await listProductUploadRows(
      upload._id,
    );
    expect(
      productUploadRows[0].row.find((row) => row.field === 'keywords.en').error,
    ).not.toBeNull();
    expect(productUploadRows[0].state).toBe('invalid');
    expect(upload.totalCount).toEqual(1);
  });

  it('should create a product with error if variantValues.0.code is not exist with parent sku', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    const worksheet: Worksheet = wb.getWorksheet(2);
    const imageSku: string = randomString();
    worksheet
      .addRow(
        await createValidProductRow([category._id], {
          categoryId: category?.slug,
          sku: imageSku,
          'variantValues.0.code': '',
          'variantValues.0.value.en': '',
          'variantValues.1.code': '',
          'variantValues.1.value.en': '',
        }),
        'n',
      )
      .commit();

    const buffer: Excel.Buffer = await wb.xlsx.writeBuffer();

    const upload: Components.Schemas.V1Upload = await uploadProducts(
      buffer as Buffer,
    );
    const productUploadRows: Components.Schemas.V1ProductUploadRows = await listProductUploadRows(
      upload._id,
    );
    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'variantValues.0.code',
      ).error,
    ).not.toBeNull();
    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'variantValues.0.value.en',
      ).error,
    ).not.toBeNull();
    expect(productUploadRows[0].state).toBe('invalid');
    expect(upload.totalCount).toEqual(1);
  });

  it('should create a product with error if variantValues.0.code is exist with no parent sku', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    const worksheet: Worksheet = wb.getWorksheet(2);
    const imageSku: string = randomString();
    worksheet
      .addRow(
        await createValidProductRow([category._id], {
          categoryId: category?.slug,
          sku: imageSku,
          parentSku: '',
        }),
        'n',
      )
      .commit();

    const buffer: Excel.Buffer = await wb.xlsx.writeBuffer();

    const upload: Components.Schemas.V1Upload = await uploadProducts(
      buffer as Buffer,
    );
    const productUploadRows: Components.Schemas.V1ProductUploadRows = await listProductUploadRows(
      upload._id,
    );
    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'variantValues.0.code',
      ).error,
    ).not.toBeNull();
    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'variantValues.1.code',
      ).error,
    ).not.toBeNull();
    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'variantValues.0.value.en',
      ).error,
    ).not.toBeNull();
    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'variantValues.1.value.en',
      ).error,
    ).not.toBeNull();
    expect(productUploadRows[0].state).toBe('invalid');
    expect(upload.totalCount).toEqual(1);
  });

  it('should create a product with error if packaging.size or packaging.unit is not exist', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    const worksheet: Worksheet = wb.getWorksheet(2);
    const imageSku: string = randomString();
    worksheet
      .addRow(
        await createValidProductRow([category._id], {
          categoryId: category?.slug,
          sku: imageSku,
          'packaging.size': '',
          'packaging.unit': '',
        }),
        'n',
      )
      .commit();

    const buffer: Excel.Buffer = await wb.xlsx.writeBuffer();

    const upload: Components.Schemas.V1Upload = await uploadProducts(
      buffer as Buffer,
    );
    const productUploadRows: Components.Schemas.V1ProductUploadRows = await listProductUploadRows(
      upload._id,
    );
    expect(
      productUploadRows[0].row.find((row) => row.field === 'packaging.size')
        .error,
    ).not.toBeNull();
    expect(
      productUploadRows[0].row.find((row) => row.field === 'packaging.unit')
        .error,
    ).not.toBeNull();
    expect(productUploadRows[0].state).toBe('invalid');
    expect(upload.totalCount).toEqual(1);
  });

  it('should create a product with error if packaging.unit or packaging.unitsPerCarton is not one of the enum', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    const worksheet: Worksheet = wb.getWorksheet(2);
    const imageSku: string = randomString();
    worksheet
      .addRow(
        await createValidProductRow([category._id], {
          categoryId: category?.slug,
          sku: imageSku,
          'packaging.unit': 'test',
          'packaging.unitsPerCarton': 'test',
        }),
        'n',
      )
      .commit();

    const buffer: Excel.Buffer = await wb.xlsx.writeBuffer();

    const upload: Components.Schemas.V1Upload = await uploadProducts(
      buffer as Buffer,
    );
    const productUploadRows: Components.Schemas.V1ProductUploadRows = await listProductUploadRows(
      upload._id,
    );
    expect(
      productUploadRows[0].row.find((row) => row.field === 'packaging.unit'),
    ).not.toBeNull();
    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'packaging.unitsPerCarton',
      ),
    ).not.toBeNull();
    expect(productUploadRows[0].state).toBe('invalid');
    expect(upload.totalCount).toEqual(1);
  });

  it('should create a product with error if offer.market.currency is not enum', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    const worksheet: Worksheet = wb.getWorksheet(2);
    const imageSku: string = randomString();
    worksheet
      .addRow(
        await createValidProductRow([category._id], {
          categoryId: category?.slug,
          sku: imageSku,
          'offer.market.currency': 'test',
        }),
        'n',
      )
      .commit();

    const buffer: Excel.Buffer = await wb.xlsx.writeBuffer();

    const upload: Components.Schemas.V1Upload = await uploadProducts(
      buffer as Buffer,
    );
    const productUploadRows: Components.Schemas.V1ProductUploadRows = await listProductUploadRows(
      upload._id,
    );
    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'offer.market.currency',
      ),
    ).not.toBeNull();
    expect(productUploadRows[0].state).toBe('invalid');
    expect(upload.totalCount).toEqual(1);
  });

  it('should create a product with error if min qty or price is not exist', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    const worksheet: Worksheet = wb.getWorksheet(2);
    const imageSku: string = randomString();
    worksheet
      .addRow(
        await createValidProductRow([category._id], {
          categoryId: category?.slug,
          sku: imageSku,
          'offer.market.tiers.0.price': '',
          'offer.market.tiers.0.minQty': '',
        }),
        'n',
      )
      .commit();

    const buffer: Excel.Buffer = await wb.xlsx.writeBuffer();

    const upload: Components.Schemas.V1Upload = await uploadProducts(
      buffer as Buffer,
    );
    const productUploadRows: Components.Schemas.V1ProductUploadRows = await listProductUploadRows(
      upload._id,
    );
    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'offer.market.tiers.0.price',
      ),
    ).not.toBeNull();
    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'offer.market.tiers.0.minQty',
      ),
    ).not.toBeNull();
    expect(productUploadRows[0].state).toBe('invalid');
    expect(upload.totalCount).toEqual(1);
  });

  it('should create a product with error if min qty 2 is less than min qty 1', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    const worksheet: Worksheet = wb.getWorksheet(2);
    const imageSku: string = randomString();
    worksheet
      .addRow(
        await createValidProductRow([category._id], {
          categoryId: category?.slug,
          sku: imageSku,
          'offer.market.tiers.1.minQty': '20',
          'offer.market.tiers.0.minQty': '25',
        }),
        'n',
      )
      .commit();

    const buffer: Excel.Buffer = await wb.xlsx.writeBuffer();

    const upload: Components.Schemas.V1Upload = await uploadProducts(
      buffer as Buffer,
    );
    const productUploadRows: Components.Schemas.V1ProductUploadRows = await listProductUploadRows(
      upload._id,
    );
    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'offer.market.tiers.1.minQty',
      ),
    ).not.toBeNull();
    expect(productUploadRows[0].state).toBe('invalid');
    expect(upload.totalCount).toEqual(1);
  });

  it('should create a product with error if min qty 2 is exist and price is not exist', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    const worksheet: Worksheet = wb.getWorksheet(2);
    const imageSku: string = randomString();
    worksheet
      .addRow(
        await createValidProductRow([category._id], {
          categoryId: category?.slug,
          sku: imageSku,
          'offer.market.tiers.1.minQty': '20',
          'offer.market.tiers.1.price': '',
          'offer.market.tiers.2.minQty': '20',
          'offer.market.tiers.2.price': '',
        }),
        'n',
      )
      .commit();

    const buffer: Excel.Buffer = await wb.xlsx.writeBuffer();

    const upload: Components.Schemas.V1Upload = await uploadProducts(
      buffer as Buffer,
    );
    const productUploadRows: Components.Schemas.V1ProductUploadRows = await listProductUploadRows(
      upload._id,
    );
    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'offer.market.tiers.1.price',
      ),
    ).not.toBeNull();
    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'offer.market.tiers.2.price',
      ),
    ).not.toBeNull();
    expect(productUploadRows[0].state).toBe('invalid');
    expect(upload.totalCount).toEqual(1);
  });

  it('should create a product with error if retail price is less than price', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    const worksheet: Worksheet = wb.getWorksheet(2);
    const imageSku: string = randomString();
    worksheet
      .addRow(
        await createValidProductRow([category._id], {
          categoryId: category?.slug,
          sku: imageSku,
          'offer.market.tiers.1.retailPrice': '400',
          'offer.market.tiers.1.price': '500',
          'offer.market.tiers.0.retailPrice': '400',
          'offer.market.tiers.0.price': '500',
          'offer.market.tiers.2.retailPrice': '400',
          'offer.market.tiers.2.price': '500',
        }),
        'n',
      )
      .commit();

    const buffer: Excel.Buffer = await wb.xlsx.writeBuffer();

    const upload: Components.Schemas.V1Upload = await uploadProducts(
      buffer as Buffer,
    );
    const productUploadRows: Components.Schemas.V1ProductUploadRows = await listProductUploadRows(
      upload._id,
    );
    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'offer.market.tiers.1.retailPrice',
      ),
    ).not.toBeNull();
    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'offer.market.tiers.0.retailPrice',
      ),
    ).not.toBeNull();
    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'offer.market.tiers.2.retailPrice',
      ),
    ).not.toBeNull();
    expect(productUploadRows[0].state).toBe('invalid');
    expect(upload.totalCount).toEqual(1);
  });
  it('should create a product with error if unit or transportationMode is not exist', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    const worksheet: Worksheet = wb.getWorksheet(2);
    const imageSku: string = randomString();
    worksheet
      .addRow(
        await createValidProductRow([category._id], {
          categoryId: category?.slug,
          sku: imageSku,
          transportationMode: '',
          unit: '',
        }),
        'n',
      )
      .commit();

    const buffer: Excel.Buffer = await wb.xlsx.writeBuffer();

    const upload: Components.Schemas.V1Upload = await uploadProducts(
      buffer as Buffer,
    );
    const productUploadRows: Components.Schemas.V1ProductUploadRows = await listProductUploadRows(
      upload._id,
    );
    expect(
      productUploadRows[0].row.find((row) => row.field === 'transportationMode')
        .error,
    ).not.toBeNull();
    expect(
      productUploadRows[0].row.find((row) => row.field === 'unit').error,
    ).not.toBeNull();
    expect(productUploadRows[0].state).toBe('invalid');
    expect(upload.totalCount).toEqual(1);
  });

  it('should create a product with error if invalid unit', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    const worksheet: Worksheet = wb.getWorksheet(2);
    const imageSku: string = randomString();
    worksheet
      .addRow(
        await createValidProductRow([category._id], {
          categoryId: category?.slug,
          sku: imageSku,
          unit: 'test',
        }),
        'n',
      )
      .commit();

    const buffer: Excel.Buffer = await wb.xlsx.writeBuffer();

    const upload: Components.Schemas.V1Upload = await uploadProducts(
      buffer as Buffer,
    );
    const productUploadRows: Components.Schemas.V1ProductUploadRows = await listProductUploadRows(
      upload._id,
    );
    expect(
      productUploadRows[0].row.find((row) => row.field === 'unit').error,
    ).not.toBeNull();
    expect(productUploadRows[0].state).toBe('invalid');
    expect(upload.totalCount).toEqual(1);
  });

  it('should create a product with error if leadTimeValue is not exist', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    const worksheet: Worksheet = wb.getWorksheet(2);
    const imageSku: string = randomString();
    worksheet
      .addRow(
        await createValidProductRow([category._id], {
          categoryId: category?.slug,
          sku: imageSku,
          'offer.delivery.leadTimeValue': '',
        }),
        'n',
      )
      .commit();

    const buffer: Excel.Buffer = await wb.xlsx.writeBuffer();

    const upload: Components.Schemas.V1Upload = await uploadProducts(
      buffer as Buffer,
    );
    const productUploadRows: Components.Schemas.V1ProductUploadRows = await listProductUploadRows(
      upload._id,
    );
    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'offer.delivery.leadTimeValue',
      ).error,
    ).not.toBeNull();
    expect(productUploadRows[0].state).toBe('invalid');
    expect(upload.totalCount).toEqual(1);
  });

  it('should create a product with error if availability is not exist', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    const worksheet: Worksheet = wb.getWorksheet(2);
    const imageSku: string = randomString();
    worksheet
      .addRow(
        await createValidProductRow([category._id], {
          categoryId: category?.slug,
          sku: imageSku,
          isReadyToShip: '',
          isBuyNow: '',
          isInStock: '',
        }),
        'n',
      )
      .commit();

    const buffer: Excel.Buffer = await wb.xlsx.writeBuffer();

    const upload: Components.Schemas.V1Upload = await uploadProducts(
      buffer as Buffer,
    );
    const productUploadRows: Components.Schemas.V1ProductUploadRows = await listProductUploadRows(
      upload._id,
    );
    expect(
      productUploadRows[0].row.find((row) => row.field === 'isInStock').error,
    ).not.toBeNull();
    expect(
      productUploadRows[0].row.find((row) => row.field === 'isBuyNow').error,
    ).not.toBeNull();
    expect(
      productUploadRows[0].row.find((row) => row.field === 'isReadyToShip')
        .error,
    ).not.toBeNull();
    expect(productUploadRows[0].state).toBe('invalid');
    expect(upload.totalCount).toEqual(1);
  });

  it('should create a product with error if dimensions is not exist', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    const worksheet: Worksheet = wb.getWorksheet(2);
    const imageSku: string = randomString();
    worksheet
      .addRow(
        await createValidProductRow([category._id], {
          categoryId: category?.slug,
          sku: imageSku,
          'dimensions.length': '',
          'dimensions.lengthUnit': '',
          'dimensions.weight': '',
          'dimensions.width': '',
          'dimensions.widthUnit': '',
          'dimensions.height': '',
          'dimensions.heightUnit': '',
          'dimensions.weightUnit': '',
        }),
        'n',
      )
      .commit();

    const buffer: Excel.Buffer = await wb.xlsx.writeBuffer();

    const upload: Components.Schemas.V1Upload = await uploadProducts(
      buffer as Buffer,
    );
    const productUploadRows: Components.Schemas.V1ProductUploadRows = await listProductUploadRows(
      upload._id,
    );
    expect(
      productUploadRows[0].row.find((row) => row.field === 'dimensions.length')
        .error,
    ).not.toBeNull();

    expect(
      productUploadRows[0].row.find((row) => row.field === 'dimensions.weight')
        .error,
    ).not.toBeNull();

    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'dimensions.lengthUnit',
      ).error,
    ).not.toBeNull();

    expect(
      productUploadRows[0].row.find((row) => row.field === 'dimensions.width')
        .error,
    ).not.toBeNull();

    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'dimensions.widthUnit',
      ).error,
    ).not.toBeNull();

    expect(
      productUploadRows[0].row.find((row) => row.field === 'dimensions.height')
        .error,
    ).not.toBeNull();

    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'dimensions.heightUnit',
      ).error,
    ).not.toBeNull();

    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'dimensions.weightUnit',
      ).error,
    ).not.toBeNull();
    expect(productUploadRows[0].state).toBe('invalid');
    expect(upload.totalCount).toEqual(1);
  });

  it('should create a product with error if dimensions is invalid', async () => {
    const wb: Workbook = new Excel.Workbook();
    await wb.xlsx.load(workbookBuffer);
    const worksheet: Worksheet = wb.getWorksheet(2);
    const imageSku: string = randomString();
    worksheet
      .addRow(
        await createValidProductRow([category._id], {
          categoryId: category?.slug,
          sku: imageSku,
          'dimensions.length': 'test',
          'dimensions.lengthUnit': 'test',
          'dimensions.weight': 'test',
          'dimensions.width': 'test',
          'dimensions.widthUnit': 'test',
          'dimensions.height': 'test',
          'dimensions.heightUnit': 'test',
          'dimensions.weightUnit': 'test',
        }),
        'n',
      )
      .commit();

    const buffer: Excel.Buffer = await wb.xlsx.writeBuffer();

    const upload: Components.Schemas.V1Upload = await uploadProducts(
      buffer as Buffer,
    );
    const productUploadRows: Components.Schemas.V1ProductUploadRows = await listProductUploadRows(
      upload._id,
    );
    expect(
      productUploadRows[0].row.find((row) => row.field === 'dimensions.length')
        .error,
    ).not.toBeNull();

    expect(
      productUploadRows[0].row.find((row) => row.field === 'dimensions.weight')
        .error,
    ).not.toBeNull();

    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'dimensions.lengthUnit',
      ).error,
    ).not.toBeNull();

    expect(
      productUploadRows[0].row.find((row) => row.field === 'dimensions.width')
        .error,
    ).not.toBeNull();

    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'dimensions.widthUnit',
      ).error,
    ).not.toBeNull();

    expect(
      productUploadRows[0].row.find((row) => row.field === 'dimensions.height')
        .error,
    ).not.toBeNull();

    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'dimensions.heightUnit',
      ).error,
    ).not.toBeNull();

    expect(
      productUploadRows[0].row.find(
        (row) => row.field === 'dimensions.weightUnit',
      ).error,
    ).not.toBeNull();
    expect(productUploadRows[0].state).toBe('invalid');
    expect(upload.totalCount).toEqual(1);
  });
});
