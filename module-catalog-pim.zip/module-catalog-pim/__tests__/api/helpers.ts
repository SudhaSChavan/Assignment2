/* istanbul ignore file */

import supertest from 'supertest';
import mongoose from 'mongoose';
import fs from 'fs';
import path from 'path';
import { map } from 'lodash';
import { app } from '@src/config/server/server';
import {
  InternalReviewStatuses,
  DraftCell,
  paymentOptions,
  ProductStates,
} from '@express/modules/product/types';
import {
  categoryModel,
  ICategoryModel,
} from '@express/modules/category/model-category';
import crypto from 'crypto';
import {
  IProductDocumentV3,
  IProductModelV3,
  productModelV3,
} from '@express/modules/product/model-product-v3';
import V3Product = Components.Schemas.V3Product;
import { offerModelV3 } from '@express/modules/offer/model-offers-v3';
import Excel, { Workbook, Worksheet } from 'exceljs';
import { FieldType } from '@express/modules/upload/helpers';
import {
  AttributeTypes,
  CategoryAttributeType,
} from '@express/modules/category/model-category-attribute';
import { getFields } from '@express/modules/upload/v3/fields';
import { getCategoryAttributes } from '@express/modules/upload/v3/helpers';
import { getProductsCategories } from '@express/modules/upload/v3/partial-update/helpers';
import {
  IProductUpdateRequestDocumentV3,
  IProductUpdateRequestModelV3,
  productUpdateRequestModelV3,
} from '@express/modules/product/model-product-update-request-v3';

const availablePaymentOptions: string[] = map(paymentOptions, 'code');

export const pngFile400px: any = getFileBuffer(
  '../fixtures/media/pngFile400x400.png',
);

export async function createCategory(params?: {
  slug?: string;
  parentId?: string;
  level?: number;
  name?: string;
  description?: string;
  moq?: string;
}): Promise<Components.Schemas.V1Category> {
  const requestParams: any = {
    slug: params?.slug || getSlug(),
    parentId: params?.parentId || null,
    name: { en: params?.name || 'category name' },
    description: { en: params?.description ?? 'test desc' },
    keywords: { en: ['key', 'word'], ar: ['some', 'more'] },
    active: true,
    level: params?.level || 0,
    moq: params?.moq || 1,
    websiteCode: 'tcom',
  };

  let parents: string[] = [];
  let parentCategory: ICategoryModel;

  if (requestParams.parentId) {
    parentCategory = await categoryModel.findById(requestParams.parentId);
    parents = [...(parentCategory.parents || []), requestParams.parentId];
  }

  const category: ICategoryModel = new categoryModel();

  category.name = requestParams.name;
  category.slug = requestParams.slug;
  category.parentId = requestParams.parentId;
  category.description = requestParams.description;
  category.keywords = requestParams.keywords;
  category.active = requestParams.active;
  category.level = requestParams.level;
  category.moq = requestParams.moq;
  category.parents = parents;
  category.websiteCode = requestParams.websiteCode;
  category.children = [];

  if (requestParams.parentId) {
    parentCategory.children.push(category._id);
    await parentCategory.save();
  }

  const savedCategory: any = (await category.save()).toJSON();

  const transformedCategory: any = {
    ...savedCategory,
    _id: `${savedCategory._id}`,
    createdAt: savedCategory.createdAt.toISOString(),
    updatedAt: savedCategory.updatedAt.toISOString(),
  };

  validateCategory(transformedCategory);

  return transformedCategory;
}

export function randomString(): string {
  return Math.random().toString(36).substr(2, 6);
}

export function getSlug(): string {
  return `slug${randomString()}`;
}

export function validateCategory(category: Record<string, any>): void {
  if (category.parentId) {
    // @ts-ignore
    expect(mongoose.Types.ObjectId.isValid(category.parentId)).toBe(true);
  }

  if (category.description) {
    expect(Object.keys(category).sort()).toEqual([
      '_id',
      'active',
      'children',
      'createdAt',
      'description',
      'keywords',
      'level',
      'moq',
      'name',
      'parentId',
      'parents',
      'slug',
      'updatedAt',
      'websiteCode',
      'weight',
    ]);
    expect(typeof category.description).toEqual('object');
    expect(typeof category.description.en).toEqual('string');
  } else {
    expect(Object.keys(category).sort()).toEqual([
      '_id',
      'active',
      'children',
      'createdAt',
      'keywords',
      'level',
      'moq',
      'name',
      'parentId',
      'parents',
      'slug',
      'updatedAt',
      'websiteCode',
      'weight',
    ]);
  }

  expect(typeof category.name).toBe('object');
  expect(typeof category._id).toBe('string');
  expect(typeof category.level).toBe('number');
  expect(typeof category.moq).toBe('number');
  expect(typeof category.active).toBe('boolean');
  expect(typeof category.weight).toBe('number');
}

export function validateProduct(product: Record<string, any>): void {
  expect(typeof product.sku).toBe('string');
  expect(typeof product.parentSku).toBe('string');
  expect(product.sku.length).toBeGreaterThanOrEqual(1);
  expect(typeof product.name.en).toBe('string');
  expect(product.name.en.length).toBeGreaterThanOrEqual(1);
  expect(typeof product.shortDescription.en).toBe('string');
  expect(product.shortDescription.en.length).toBeGreaterThanOrEqual(1);
  expect(typeof product.longDescription.en).toBe('string');
  expect(Array.isArray(product.additionalAttributes)).toBe(true);
  expect(typeof product.unit).toBe('string');
  expect(
    product.paymentOptions.every((o: any): boolean =>
      availablePaymentOptions.includes(o),
    ),
  ).toBe(true);
  expect(Object.values(ProductStates).includes(product.state)).toBe(true);
  expect(typeof product.transportationMode).toBe('string');
}

export function validateProductStats(stats: Record<string, any>): any {
  expect(typeof stats.productCount).toBe('number');
  expect(Array.isArray(stats.categories)).toBe(true);
  expect(Array.isArray(stats.products)).toBe(true);
  stats.products.forEach(validateProduct);
  stats.categories.forEach((categoryCount: any): void => {
    expect(typeof categoryCount.id).toBe('string');
    expect(categoryCount.count).toBeGreaterThanOrEqual(0);
  });
}

export async function createProductV3(
  params?: any,
): Promise<Components.Schemas.V3Product> {
  if (!params.categoryId) {
    throw new Error('categoryId is required');
  }

  const product: V3Product = await productModelV3.create(
    getProductParamsV3(params),
  );
  validateProduct(product);

  await offerModelV3.create({ productId: product._id, ...getOffersV3()[0] });
  return product;
}

export async function getProduct(
  id: string,
): Promise<Components.Schemas.V3Product> {
  const { body } = await supertest(app)
    .post('/v3-get-product')
    .send({ id })
    .set('x-store-id', 'tcom-ae')
    .expect('Content-Type', /json/);

  validateProduct(body);
  return body;
}

export async function uploadMedia(
  sku?: string,
): Promise<Components.Schemas.V1MediaItem> {
  const filename: string = `${sku || randomString()}_image.png`;
  const {
    body: [media],
  } = await supertest(app)
    .post('/v1-upload-media')
    .attach('files[]', pngFile400px, { filename })
    .field('skuSeparator', '_')
    .expect(200)
    .expect('Content-Type', /json/);

  validateMedia(media);
  if (sku) {
    expect(media.skuGroup).toEqual(sku.toUpperCase());
  }
  return media;
}

export async function getMedia(
  id: string,
): Promise<Paths.V3GetMediaAction.Responses.$200> {
  const { body } = await supertest(app)
    .post('/v3-get-media')
    .send({ id })
    .expect(200)
    .expect('Content-Type', /json/);

  validateMedia(body.media);
  body.products.forEach(validateProduct);
  return body;
}

export async function deleteMedia(id: string): Promise<void> {
  await supertest(app)
    .post('/v3-delete-media')
    .send({ ids: [id] })
    .expect(200)
    .expect('Content-Type', /json/);
}

export function validateMedia(media: Record<string, any>): void {
  expect(typeof media._id).toBe('string');
  expect(typeof media.name).toBe('string');
  expect(typeof media.originalName).toBe('string');
  expect(typeof media.skuGroup).toBe('string');
  expect(typeof media.group).toBe('string');
  expect(typeof media.provider).toBe('string');
  expect(typeof media.type).toBe('string');
  expect(typeof media.path).toBe('string');
  expect(typeof media.meta).toBe('object');
  expect(typeof media.meta.size).toBe('number');
  expect(typeof media.userId).toBe('string');
  expect(typeof media.supplierId).toBe('string');
  expect(typeof media.supplierCompanyId).toBe('string');
  expect(typeof media.createdAt).toBe('string');
  expect(typeof media.updatedAt).toBe('string');
  expect(typeof media.url).toBe('string');
}

export function getMongoId(): string {
  // @ts-ignore
  return mongoose.Types.ObjectId().toHexString();
}

export function getFileBuffer(filePath: string): Buffer {
  const resolvedPath: string = path.resolve(__dirname, filePath);
  return fs.readFileSync(resolvedPath);
}

export function getRandomId(length: number = 12): string {
  return crypto.randomBytes(length).toString('hex');
}

export async function insertProductData(
  count: number,
  updater?: (product: IProductDocumentV3, index: number) => IProductDocumentV3,
): Promise<IProductModelV3[]> {
  const newProducts: IProductDocumentV3[] = [...Array(count).keys()].map(
    (i) => {
      const product: IProductDocumentV3 = updater
        ? updater(
            {
              ...getProductParamsV3(),
              sku: getRandomId(),
            } as any,
            i,
          )
        : ({ ...getProductParamsV3() } as IProductDocumentV3);
      return product;
    },
  );
  return await productModelV3.create(newProducts);
}

export function getProductParamsV3(
  value?: Partial<Components.RequestBodies.V3CreateProduct>,
): any {
  return {
    packaging: {
      size: '43',
      unit: 'Piece',
      unitsPerCarton: '44',
    },
    categoryId: '5f1f1f1f1f1f1f1f1f1f1f1f',
    variantValues: [
      {
        code: 'color',
        value: {
          en: 'red',
          ar: 'ar_red',
        },
      },
    ],
    storeCode: 'ae',
    storeKeyId: 'tcom-ae',
    websiteCode: 'tcom',
    supplierId: '5f9f1b9b9b9b9b9b9b9b9b9b',
    priceIncotermCondition: 'delivered',
    dimensions: {
      length: 12,
      lengthUnit: 'cm',
      width: 12,
      widthUnit: 'cm',
      height: 12,
      heightUnit: 'cm',
      weight: 12,
      weightUnit: 'mg',
    },
    supplierCompanyId: '5f2b9c3c1c9d4400001e8b1c',
    sku: randomString(),
    parentSku: randomString(),
    name: { en: 'product name should be at least 15 chars' },
    shortDescription: {
      en:
        'short description short description short description short description short description short description',
    },
    longDescription: {
      en: 'long description long description long description long description',
    },
    additionalAttributes: [{ label: 'label', value: 'value' }],
    keywords: {
      en: ['test', 'test-2'],
      ar: ['__test', '__test2'],
    },
    unit: 'piece',
    paymentOptions: ['da', 'dp', 'other'],
    type: 'simple',
    isInStock: true,
    transportationMode: 'food_chilled',
    ...(value ? value : {}),
  };
}

export function getOffersV3(): any {
  return [
    {
      market: {
        currency: 'USD',
        label: 'INT',
        code: 'USD',
        tiers: [
          {
            tierCode: 'TIERS-1',
            minQty: 10,
            price: 100,
            retailPrice: 101,
            maxQty: 12,
          },
        ],
      },
      subSupplierCompanies: [],
      delivery: {
        leadTimeValue: 12,
        leadTimeUnit: 'days',
      },
    },
  ];
}

export function getSingleProductParamsWithOffer(
  value?: Partial<Components.RequestBodies.V3CreateProduct>,
): Partial<Components.RequestBodies.V3CreateProduct> {
  return {
    descriptionMedia: [],
    dimensions: {
      height: 3,
      heightUnit: 'cm',
      length: 3,
      lengthUnit: 'cm',
      weight: 3,
      weightUnit: 'g',
      width: 34,
      widthUnit: 'cm',
    },
    packaging: {
      unitsPerCarton: '23',
      unit: 'gr',
      size: '12',
    },
    unit: 'kg',
    sku: randomString(),
    parentSku: randomString(),
    keywords: {
      en: ['Baby Accessories Product'],
    },
    attributes: {
      brand: {
        en: 'Baby Accessories Product - Baby Accessories Product',
      },
      countryOfProduction: 'AE',
      countryOfShipment: 'AE',
      shelfLifeDays: '12',
      stockLocation: 'AE',
      storageTemperature: 'Chilled',
      technicalSpecificationSheet: 'Available',
    },
    variantValues: [
      {
        code: 'color',
        value: {
          en: 'red',
          ar: 'ar_red',
        },
      },
    ],
    name: {
      en: 'Baby Accessories Product',
    },
    offers: [
      {
        delivery: {
          leadTimeValue: 20,
          leadTimeUnit: 'days',
        },
        subSupplierCompanies: [],
        market: {
          label: 'UAE Market (GULF)',
          code: 'AE',
          currency: 'AED',
          tiers: [
            {
              minQty: 10,
              price: 10,
              retailPrice: 20,
              tierCode: 'TIERS-1',
            },
          ],
        },
      },
    ],
    shortDescription: {
      en: 'test bose audio product desc',
    },
    longDescription: {
      en: '<p>test bose audio product desc</p>',
    },
    transportationMode: 'regular',
    additionalAttributes: [],
    isBuyNow: true,
    isInStock: true,
    isReadyToShip: true,
    tags: [],
    type: 'simple',
    ...(value ? value : {}),
  };
}

export async function createProductHelper(
  category: Components.Schemas.V1Category,
) {
  const params: Partial<Components.RequestBodies.V3CreateProduct> = getSingleProductParamsWithOffer(
    { categoryId: category._id },
  );
  const { body: product } = await supertest(app)
    .post('/v3-create-product')
    .set('x-store-id', 'tcom-ae')
    .send(params)
    .expect(200)
    .expect('Content-Type', /json/);

  return product;
}

export async function createProductWithMediaHelper(
  category: Components.Schemas.V1Category,
  media: Components.Schemas.V1ProductMedia[],
) {
  const params: Partial<Components.RequestBodies.V3CreateProduct> = getSingleProductParamsWithOffer(
    { categoryId: category._id, media },
  );
  const { body: product } = await supertest(app)
    .post('/v3-create-product')
    .set('x-store-id', 'tcom-ae')
    .send(params)
    .expect(200)
    .expect('Content-Type', /json/);
  return product;
}

export async function cleanUpV3(): Promise<void> {
  await categoryModel.deleteMany({});
  await productModelV3.deleteMany({});
  await offerModelV3.deleteMany({});
}

export async function approveProduct(productId: string): Promise<void> {
  await productModelV3.updateOne(
    { _id: productId },
    { $set: { internalReviewStatus: InternalReviewStatuses.Accepted } },
  );
}

export async function changeProductState(
  productId: string,
  state: string,
): Promise<void> {
  await productModelV3.updateOne({ _id: productId }, { $set: { state } });
}

export async function downloadProductTemplate(
  categoryIds: string[],
): Promise<Buffer> {
  const { body } = await supertest(app)
    .post('/v3-get-upload-template')
    .set({ 'x-store-id': 'tcom-ae' })
    .send({ categoryIds })
    .responseType('blob')
    .expect(200)
    .expect('Content-Disposition', /attachment/)
    .expect(
      'Content-Type',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    );

  await validateXlsxTemplate(body);
  return body;
}

export async function validateXlsxTemplate(
  buffer: Buffer,
  categories?: Components.Schemas.V1Category[],
): Promise<Excel.Workbook> {
  const wb: Workbook = new Excel.Workbook();
  await wb.xlsx.load(buffer);
  expect(wb.creator).toEqual('Tradeling');
  expect(wb.lastModifiedBy).toEqual('Tradeling');

  const instructionsSheet: Worksheet = wb.getWorksheet(1);
  expect(instructionsSheet).toBeTruthy();

  const dataSheet: Worksheet = wb.getWorksheet(2);
  expect(dataSheet).toBeTruthy();

  const metaSheet: Worksheet = wb.getWorksheet(4);
  expect(metaSheet).toBeTruthy();

  return wb;
}

export async function addAttributesToCategory(
  category: Components.Schemas.V1Category,
  attributes: CategoryAttributeType | CategoryAttributeType[],
): Promise<any> {
  const attrs: any = new mongoose.models.CategoryAttribute({
    categoryId: category._id,
    categoryTree: [...category.parents, category._id],
    attributes: Array.isArray(attributes) ? attributes : [attributes],
  });
  await attrs.save();
}

type CreateValidProductRowArgsType = {
  categorySlug: string;
  sku?: string;
  attributes?: CategoryAttributeType[];
};

export async function createValidProductRow(
  categoryIds: string[],
  examples: any,
): Promise<any> {
  const categoryAttributes: CategoryAttributeType[] = await getCategoryAttributes(
    categoryIds,
  );
  const categories: Record<
    string,
    ICategoryModel
  > = await getProductsCategories(categoryIds);
  const productFields: FieldType[] = getFields({
    websiteCode: 'tcom',
    categoryAttributes,
    categories,
  }).filter((field) => {
    return !field.shouldExclude;
  });
  return productFields.map((f: FieldType) =>
    ![null, undefined].includes(examples[f.field])
      ? examples[f.field]
      : f.example || '',
  );
}

export async function uploadProducts(
  buffer: Buffer,
): Promise<Paths.V3UploadProductAction.Responses.$200> {
  const { body } = await supertest(app)
    .post('/v3-upload-product')
    .set({ 'x-store-id': 'tcom-ae' })
    .attach('files[]', buffer, { filename: 'data.xlsx' })
    .expect(200)
    .expect('Content-Type', /json/);

  expect(Array.isArray(body.categoryIds)).toBeTruthy();
  validateUpload(body);
  return body;
}

export function validateUpload(upload: Components.Schemas.V1Upload): void {
  expect(typeof upload._id).toEqual('string');
  expect(Array.isArray(upload.categoryIds) || upload.categoryIds === null).toBe(
    true,
  );
  expect(['new', 'imported', 'canceled'].includes(upload.state)).toBe(true);
  expect(['local', 's3'].includes(upload.provider)).toBe(true);
  expect(typeof upload.path).toEqual('string');
  expect(upload.totalCount).toBeGreaterThanOrEqual(0);
  expect(upload.meta.size).toBeGreaterThanOrEqual(5000);
  expect(typeof upload.supplierId).toEqual('string');
  expect(typeof upload.supplierCompanyId).toEqual('string');
  expect(typeof upload.createdAt).toEqual('string');
  expect(typeof upload.updatedAt).toEqual('string');
  expect(typeof upload.url).toBe('string');
}

export function toAttr(
  data: Partial<CategoryAttributeType>,
): CategoryAttributeType {
  return {
    id: getMongoId(),
    code: randomString(),
    type: AttributeTypes.Text,
    required: false,
    label: {
      en: data.code || 'Attribute Label',
    },
    help: {
      en: 'Attribute Help Text',
    },
    ...data,
  };
}

export function getAttributes(): CategoryAttributeType[] {
  return [
    toAttr({ code: 'text', type: AttributeTypes.Text, example: '12345' }),
    toAttr({ code: 'textarea', type: AttributeTypes.Textarea }),
    toAttr({ code: 'checkbox', type: AttributeTypes.Checkbox }),
    toAttr({ code: 'date', type: AttributeTypes.Date }),
    toAttr({
      code: 'multiselect',
      type: AttributeTypes.MultiSelect,
      strict: true,
      allowedValues: ['a', 'b', 'c'],
    }),
    toAttr({
      code: 'multiselect2',
      type: AttributeTypes.MultiSelect,
      strict: false,
      allowedValues: ['a', 'b', 'c'],
    }),
    toAttr({
      code: 'select',
      type: AttributeTypes.Select,
      strict: true,
      allowedValues: ['a', 'b', 'c'],
    }),
    toAttr({
      code: 'select2',
      type: AttributeTypes.Select,
      strict: false,
      allowedValues: ['a', 'b', 'c'],
    }),
    toAttr({
      code: 'number',
      type: AttributeTypes.Number,
      minValue: 0,
      maxValue: 1e9,
      isInteger: true,
    }),
    toAttr({ code: 'url', type: AttributeTypes.Url }),
  ];
}

export async function listProductUploadRows(
  uploadId: string,
): Promise<Components.Schemas.V1ProductUploadRows> {
  const { body } = await supertest(app)
    .post('/v3-list-product-upload-row')
    .send({ filter: { uploadId } })
    .expect(200)
    .expect('Content-Type', /json/);

  expect(Array.isArray(body.data)).toBe(true);
  body.data.forEach(validateProductUploadRowListItem);

  return body.data;
}

export function validateProductUploadRowListItem(
  productUploadRow: Components.Schemas.V1ProductUploadRow,
): void {
  expect(typeof productUploadRow._id).toBe('string');
  expect(typeof productUploadRow.categoryId).toBe('string');
  expect(typeof productUploadRow.uploadId).toBe('string');
  expect(productUploadRow.line).toBeGreaterThanOrEqual(0);
  expect(
    ['draft', 'valid', 'invalid', 'published'].includes(productUploadRow.state),
  ).toBe(true);
  expect(typeof productUploadRow.supplierId).toBe('string');
  expect(typeof productUploadRow.supplierCompanyId).toBe('string');
  expect(typeof productUploadRow.createdAt).toBe('string');
  expect(typeof productUploadRow.updatedAt).toBe('string');
  expect(Array.isArray(productUploadRow.row)).toBe(true);
  productUploadRow.row.forEach((field: DraftCell) => {
    expect(typeof field.field).toBe('string');
    expect(typeof field.label).toBe('string');
    expect(['string', 'undefined'].includes(typeof field.value)).toBeTruthy();
    expect(field.error === null || typeof field.error === 'string').toBe(true);
  });
}

export async function createProductUpdateRequest(
  params: Partial<IProductUpdateRequestDocumentV3>,
): Promise<IProductUpdateRequestModelV3> {
  const data: Partial<IProductUpdateRequestDocumentV3> = {
    supplierId: '5e08ad5c092c1b7d8e9e3034',
    supplierCompanyId: '5e08ad5c092c1b7d8e9e3040',
    diff: {
      longDescription: {
        oldValue: {
          en: '<p>test bose audio product desc</p>',
        },
        newValue: {
          en: "<p>It's not a very strong pokemonn</p>",
        },
      },
      name: {
        oldValue: {
          en: 'Baby Accessories Product',
        },
        newValue: {
          en: 'Tradeling Product',
        },
      },
      attributes: {
        oldValue: {
          brand: {
            en: 'Baby Accessories Product - Baby Accessories Product',
          },
          countryOfProduction: 'AE',
          countryOfShipment: 'AE',
          shelfLifeDays: '1',
          storageTemperature: 'Room Temperature',
          technicalSpecificationSheet: 'Available',
        },
        newValue: {
          brand: {
            en: 'Pokemonn',
          },
          countryOfProduction: 'AE',
          countryOfShipment: 'AE',
          shelfLifeDays: '1',
          storageTemperature: 'Room Temperature',
          technicalSpecificationSheet: 'Available',
          stockLocation: 'AE',
        },
      },
    } as any,
    metadata: {
      name: {
        en: 'Tradeling Product',
      },
      sku: 'KARPKARP',
      media: {},
    },
    rejectionReasons: [
      {
        slug: 'others',
        msg: 'testing flow',
        section: 'general',
      },
    ],
    status: InternalReviewStatuses.Rejected,
    reviewedBy: {
      userId: '6257d9bba0ae66001c2fceb0',
      email: 'arslan.hameed@tradeling.com',
    },
    ...(params ? params : {}),
  };
  return await productUpdateRequestModelV3.create(data);
}
