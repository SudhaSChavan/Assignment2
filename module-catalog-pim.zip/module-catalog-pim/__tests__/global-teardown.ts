const teardown = async () => {
  await (<any>global).__app__.close();
};
export default teardown;
