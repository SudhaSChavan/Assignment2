import { logger } from '@core/util/logger';
import { serverPromise } from '@src/main';

const setup = async () => {
  logger.info('starting the app');
  const app = await serverPromise;
  logger.info('app started successfully');

  logger.info(`┌────────────────────────────────────────────────────────────┐`);
  logger.info(
    `│                APP STARTED SUCCESSFULLY                      │`,
  );
  logger.info(
    `│            Starting: ${new Date().toISOString()}             │`,
  );
  logger.info(`└────────────────────────────────────────────────────────────┘`);

  (<any>global).__app__ = app;
};
export default setup;
