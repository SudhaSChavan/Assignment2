import '@tradeling/nest-js-utils/dist/apm';
import { Server } from 'http';
import { appInstancePromise } from './bootstrap';
import { logger, onListening, onServerClose } from '@tradeling/core';
import { appConfig } from '@src/config/env';

export const serverPromise: Promise<Server> = appInstancePromise
  .then(async (app) => {
    await app.listen(appConfig.port);

    logger.info(`Listening on ${appConfig.port}`);
    onListening();

    const httpServer: Server = app.getHttpServer();
    httpServer.on('close', onServerClose.bind(app));
    return httpServer;
  })
  .catch((err) => {
    console.error(`server failed to start`, err);
    process.exit(1);
  });
