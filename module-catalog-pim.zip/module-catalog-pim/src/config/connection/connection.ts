import mongoose, { ConnectionOptions } from 'mongoose';

import { appConfig } from '../env';
import { logger } from '@core/util/logger';

interface IConnectOptions extends ConnectionOptions {}

const connectOptions: IConnectOptions = {
  bufferCommands: true,
  useCreateIndex: true,
  useNewUrlParser: true,
  useFindAndModify: false,
  useUnifiedTopology: true,
  appname: appConfig.name,
  // poolSize: 7,
};

const mongoURI: string = appConfig.mongodb.uri;

// todo integrate logger with env

(async () => {
  try {
    mongoose.connect(mongoURI, connectOptions, (error: Error): void => {
      if (error) {
        logger.info(JSON.stringify(error));
      }
    });
  } catch (err) {
    console.log('error: ' + err);
  }
})();

// handlers
mongoose.connection.on('connecting', (): void => {
  logger.info('MongoDB :: connecting');
});

mongoose.connection.on('error', (error: string): void => {
  logger.error(`MongoDB :: error ${error}`);
});

mongoose.connection.on('connected', (): void => {
  mongoose.set(
    'debug',
    (
      col: string,
      method: string,
      query: Record<string, unknown>,
      doc: Record<string, unknown>,
    ): void => {
      if (!appConfig.isDevelopment) {
        return;
      }
      logger.info(
        `MongoDB :: ${col}.${method}(${JSON.stringify(query)},${JSON.stringify(
          doc,
        )})`,
      );
    },
  );
  logger.info('MongoDB :: connected');
});

mongoose.connection.on('reconnected', (): void => {
  logger.warn('MongoDB :: reconnected');
});

mongoose.connection.on('reconnectFailed', (): void => {
  logger.error('MongoDB :: reconnectFailed');
});

mongoose.connection.on('disconnected', (): void => {
  logger.warn('MongoDB :: disconnected');
});

mongoose.connection.on('fullsetup', (): void => {
  logger.info('MongoDB :: reconnecting... %d');
});
