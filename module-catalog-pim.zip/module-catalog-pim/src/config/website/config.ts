import get from 'lodash/get';
import { IAppRequest } from '@src/types/app-request';

export enum Websites {
  Tradeling = 'tradeling',
}

export enum Stores {
  TradelingAe = 'tradeling-ae',
  TradelingSa = 'tradeling-sa',
}

export enum Channels {
  Web = 'web',
  Mobile = 'mobile',
}

export const Config: any = {
  '8p4q87qyduj48haw': {
    key: '8p4q87qyduj48haw',
    website: Websites.Tradeling,
    store: Stores.TradelingAe,
    channel: Channels.Web,
  },
  '5wpq8uapkyc64cb9': {
    key: '5wpq8uapkyc64cb9',
    website: Websites.Tradeling,
    store: Stores.TradelingAe,
    channel: Channels.Mobile,
  },
  '6365ets3hm2u4kgx': {
    key: '6365ets3hm2u4kgx',
    website: Websites.Tradeling,
    store: Stores.TradelingSa,
    channel: Channels.Web,
  },
  '2gb8dgq83vp2bkuv': {
    key: '2gb8dgq83vp2bkuv',
    website: Websites.Tradeling,
    store: Stores.TradelingSa,
    channel: Channels.Mobile,
  },
};

export function getApiKey(req: IAppRequest): string {
  return <string>req.headers['x-api-key'] || '';
}

// get the whole config document
export function getApiConfig(req: IAppRequest): any {
  const apiKey: string = getApiKey(req);
  return get(Config, apiKey, '');
}

export function getApiWebsite(req: IAppRequest): string {
  const apiKey: string = getApiKey(req);
  return get(Config, `${apiKey}.website`, '');
}

export function getApiStore(req: IAppRequest): string {
  const apiKey: string = getApiKey(req);
  return get(Config, `${apiKey}.store`, '');
}

export function getApiChannel(req: IAppRequest): string {
  const apiKey: string = getApiKey(req);
  return get(Config, `${apiKey}.channel`, '');
}

// get lookups
export function getWebsites(): any {
  return Object.values(Websites);
}

export function getStores(): any {
  return Object.values(Stores);
}

export function getChannels(): any {
  return Object.values(Channels);
}
