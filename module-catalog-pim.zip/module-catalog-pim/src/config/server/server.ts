import express from 'express';
import { Application } from 'express-serve-static-core';

import '@src/config/connection/connection';
import { appConfig } from '../env';
import {
  configureMiddleware,
  initErrorHandler,
} from '../middleware/middleware';
import { initRouter } from '@express/routes';

/**
 * @constant {Application}
 */
const app: Application = express();

// Serve assets from the disk path
if (appConfig.isDevelopment) {
  app.use(express.static(`/tmp/${appConfig.name}`));
}

/**
 * @constructs Application Middleware
 */
configureMiddleware(app);

/**
 * @constructs Application Routes
 */
initRouter(app);

/**
 * @constructs Application Error Handler
 */
initErrorHandler(app);

/**
 * @exports {Application}
 */
export { app };
