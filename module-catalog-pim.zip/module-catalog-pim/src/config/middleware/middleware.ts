import morgan from 'morgan';
import bodyParser from 'body-parser';
import compression from 'compression';
import cookieParser from 'cookie-parser';
import { Application, NextFunction } from 'express-serve-static-core';
import { v4 as uuidV4 } from 'uuid';
import { V1GetStoreByStoreIdAction } from '@tradeling/tradeling-sdk/www/v1-get-store-by-store-id-action';
import {
  appNameMw,
  currencyMw,
  HttpError,
  ipMw,
  languageMw,
  runtimeHostMw,
  StoreType,
  RedisCacheBase,
  StoreProviderType,
  IBaseAppHeaders,
} from '@tradeling/web-js-utils/dist';

import { appConfig } from '../env';
import { decodeJwtMw } from './decode-jwt-mw';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { sendHttpErrorModule } from '../error/send-http-error';
import { logger, loggerContext } from '@core/util/logger';
import { AxiosError } from 'axios';
import { countryMw } from '@tradeling/web-js-utils';
import { validateStore } from '@tradeling/web-js-utils';
import { redis } from '../redis';

type HttpErrorType = {
  status: number;
  name: string;
  message: string;
  errors: {
    value: string;
    msg: string;
    param: string;
    location: string;
  }[];
};

const storeProvider: StoreProviderType = (
  storeKeyId: string,
  headers: IBaseAppHeaders,
) => {
  return new Promise<StoreType>((resolve, reject) => {
    V1GetStoreByStoreIdAction(
      {},
      { headers: { ...headers } },
      { storeKeyId: storeKeyId },
    )
      .then((data) => {
        if (data.status === 200) {
          resolve(data.data as StoreType);
          return;
        }
        reject(data);
      })
      .catch((error) => {
        reject(error);
      });
  });
};

export function configureMiddleware(app: Application): void {
  // todo sentryClient.Handlers
  // todo lang
  // todo dev_uniqid for mobile devices
  // todo accept-language
  app.disable('x-powered-by');
  // express middleware

  // custom errors
  app.use(sendHttpErrorModule);

  app.use(
    bodyParser.urlencoded({
      extended: false,
    }),
  );
  app.use(bodyParser.json({ limit: process.env.JSON_MAX_LIMIT ?? '100kb' }));
  // http request logger middleware with trace id
  app.use((req: IAppRequest, res: IAppResponse, next) => {
    const store: Map<string, any> = new Map();
    req.headers['x-trace-id'] ||= uuidV4();
    res.setHeader('x-trace-id', req.headers['x-trace-id']);
    store.set('xTraceId', req.headers['x-trace-id']);
    return loggerContext.run(store, next);
  });

  // Do not log http requests if NODE_ENV is testing
  if (!appConfig.isTesting) {
    morgan.token(
      'x-trace-id',
      (req: IAppRequest) => req.headers['x-trace-id'] as string,
    );
    app.use(
      morgan(
        ':date[iso] x-trace-id :x-trace-id :remote-addr - :remote-user ":method :url HTTP/:http-version" :status :res[content-length] ":referrer" ":user-agent"',
      ),
    );
  }
  // parse Cookie header and populate req.cookies with an object keyed by the cookie names.
  app.use(cookieParser());
  // returns the compression middleware
  app.use(compression());
  // add runtime domain and fulldomain to req object
  app.use(runtimeHostMw);
  // Internal API protection
  // app.use(protectInternalApiMw);
  // get user ip and assign it to request
  app.use(ipMw);
  // get user currency and assign it to request
  app.use(currencyMw);
  // decode jwt and assign userJWT to request
  app.use(decodeJwtMw);
  // detect user language and assign to request
  app.use(languageMw);
  // detect user country and assign to request
  app.use(countryMw);
  // get the portal from app name
  app.use(appNameMw);
  // add store config to request
  app.use(
    validateStore({
      cache: new RedisCacheBase(redis, logger as any),
      storeProvider: storeProvider,
      logger: logger as any,
    }),
  );
  // app.use(
  //   cors({
  //     credentials: true,
  //     origin: appConfig.cors.allowedOrigins,
  //     allowedHeaders: appConfig.cors.allowedHeaders,
  //   }),
  // );
}

/**
 * @export
 * @param {Application} app
 */
export function initErrorHandler(app: Application): void {
  app.use(
    (
      error: Error,
      req: IAppRequest,
      res: IAppResponse,
      next: NextFunction,
    ): void => {
      let errorCode: number = typeof error === 'number' ? error : 500;
      let errorMessage: string = error.message;
      let errorsList: HttpErrorType['errors'] = [];
      let errorsListStr: string = '';
      const stack: string = (error?.stack || '').replace(/\s+/g, ' ');

      let internalCallUrl: string = '';
      let internalCallData: string = '';

      // If this is an error on HTTP call from any secondary APIs
      if ((error as AxiosError<HttpErrorType>)?.response?.data?.message) {
        const axiosError: AxiosError<HttpErrorType> = error as AxiosError<HttpErrorType>;
        const httpError: HttpErrorType = axiosError.response.data;

        internalCallData = JSON.stringify(
          axiosError?.config?.data || '',
          null,
          2,
        ).replace(/\s+/g, ' ');
        internalCallUrl = axiosError?.config?.url;
        errorCode = httpError.status;
        errorMessage = httpError.message;
        errorsList = httpError.errors;

        errorsListStr = JSON.stringify(errorsList, null, 2) || '';
        errorsListStr = errorsListStr.replace(/\s+/g, ' ');
      } else if (error instanceof HttpError) {
        errorCode = error.status;
        errorMessage = error.message;
        errorsList = error.errors;
      }

      if (!appConfig.isTesting) {
        if (process.env.ERR_LOG_MSG_ONLY) {
          logger.error(
            `${internalCallUrl} ${errorCode} ${errorMessage} ${errorsListStr} ${internalCallData}`.trim(),
          );
        } else {
          logger.error(
            `${internalCallUrl} ${errorCode} ${errorMessage} ${errorsListStr} ${stack}`,
          );
        }
      }

      // todo fix me
      if (res.headersSent) {
        return;
      }

      res.sendHttpError(new HttpError(errorCode, errorMessage, errorsList));
    },
  );
}
