import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { NextFunction } from 'express-serve-static-core';
import { isBackofficeUserMW } from '@tradeling/web-js-utils';
import { V1GetUserByTokenAction } from '@tradeling/tradeling-sdk/backoffice/v1-get-user-by-token-action';
import { logger } from '@core/util/logger';

export function backOfficeUserMw(
  allowedPermissions: string[],
): (req: IAppRequest, res: IAppResponse, next: NextFunction) => void {
  return isBackofficeUserMW({
    logger: logger,
    GetUserByToken: V1GetUserByTokenAction,
    allowedPermissions: allowedPermissions,
  });
}
