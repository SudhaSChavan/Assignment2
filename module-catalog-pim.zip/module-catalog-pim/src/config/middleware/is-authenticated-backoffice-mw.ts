import { NextFunction } from 'express-serve-static-core';
import { StatusCodes } from 'http-status-codes';
import { HttpError } from '@tradeling/web-js-utils/dist';

import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';

// difference between this mw and jwt decode - this will fail if no user id found jwt, maybe convert to custom validator
export async function isAuthenticatedBackofficeMw(
  req: IAppRequest,
  res: IAppResponse,
  next: NextFunction,
): Promise<void> {
  if (!req.userId || req.platform !== 'backoffice') {
    return next(
      new HttpError(
        StatusCodes.UNAUTHORIZED,
        'Only backoffice users are allowed',
      ),
    );
  }

  return next();
}
