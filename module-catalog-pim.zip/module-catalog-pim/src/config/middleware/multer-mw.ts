import multer from 'multer';
import { omit } from 'lodash';
import { NextFunction, RequestHandler } from 'express-serve-static-core';

import { appConfig } from '../env';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';

export interface IMediaFile extends Express.Multer.File {}

// Upload and save the files at the given path
const upload: RequestHandler = multer({
  dest: `/tmp/${appConfig.name}`,
}).array('files[]');

export function multerHandler(
  req: IAppRequest,
  res: IAppResponse,
  next: NextFunction,
): void {
  upload(req, res, (err?: any): void => {
    if (err instanceof multer.MulterError) {
      // A Multer error occurred when uploading.
      console.log(`Mutler File Upload Error ${err.message}`);
    } else if (err) {
      // An unknown error occurred when uploading.
      console.log(`File Upload Error ${err.message}`);
    }

    const filesList: IMediaFile[] = (req.files as IMediaFile[]) || [];

    req.body.files = filesList;

    // Put the paths separately for validation because validator leaks
    // the upload paths in the errors otherwise
    req.body.validatorFiles = filesList.map((fileItem: IMediaFile): any =>
      omit(fileItem, ['destination', 'path']),
    );

    next();
  });
}
