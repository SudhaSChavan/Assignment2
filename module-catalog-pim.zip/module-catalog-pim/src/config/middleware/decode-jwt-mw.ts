import { NextFunction } from 'express-serve-static-core';
import { IBaseAppUser } from '@tradeling/web-js-utils/dist';

import { appConfig } from '../env';
import { logger } from '@core/util/logger';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { dummyUserJwtDecoded } from '@tradeling/web-js-utils';
import { V1GetSessionByTokenAction } from '@tradeling/tradeling-sdk/account/v1-get-session-by-token-action';

async function decodeJwtTest(
  req: IAppRequest,
  res: IAppResponse,
): Promise<void> {
  // Dev workflow
  try {
    const res: IBaseAppUser =
      dummyUserJwtDecoded[(process.env.USER_JWT_IDX as any) ?? 0];

    req.userJwtDecoded = res;
    if (res && res._id) {
      req.userId = res._id;
      req.buyerId = res._id;
      req.supplierId = res._id;
      req.buyerCompanyId = res.buyerCompanyId;
      req.supplierCompanyId = res.supplierCompanyId;
      req.user = res;
    }
  } catch (error) {
    logger.error(error.message);
  }
}

export async function decodeJwtMw(
  req: IAppRequest,
  res: IAppResponse,
  next: NextFunction,
): Promise<void> {
  const { headers } = req;
  // fallback to cookie if x-jwt-token header is not there
  req.headers['x-jwt-token'] =
    req.headers['x-jwt-token'] || req.cookies?.jwtToken || '';

  // If env is dev or testing and there is no jwt
  // token in header put dummy user inside req
  if (
    (appConfig.isDevelopment || appConfig.isTesting) &&
    !headers['x-jwt-token']
  ) {
    await decodeJwtTest(req, res);

    return next();
  }

  if (!req.headers['x-jwt-token']) {
    return next();
  }

  //
  try {
    const { data: res } = await V1GetSessionByTokenAction(
      {
        token: headers['x-jwt-token'],
      },
      {
        headers: {
          ...(headers || {}),
          'content-type': 'application/json',
        },
      },
    );
    const user: IBaseAppUser = res?.user as IBaseAppUser;

    req.userJwtDecoded = user;
    req.platform = res.platform;
    req.userId = user._id;
    req.user = user;
    if (res && res.platform != 'backoffice') {
      req.buyerId = user._id;
      req.supplierId = user._id;
      req.buyerCompanyId = user.buyerCompanyId;
      req.supplierCompanyId = user.supplierCompanyId;
    }
  } catch (error) {
    logger.error(error);
  }

  return next();
}
