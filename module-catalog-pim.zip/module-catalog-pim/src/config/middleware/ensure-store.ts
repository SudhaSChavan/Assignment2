import { NextFunction, Response } from 'express-serve-static-core';
import { IBaseAppRequest, HttpError } from '@tradeling/web-js-utils';
import { logger } from '@core/util/logger';
import { appConfig } from '../env';

export function ensureStore(
  request: IBaseAppRequest,
  res: Response,
  next: NextFunction,
): void {
  if (appConfig.isTesting) {
    return next();
  }
  if (!request.store) {
    logger.error(
      `No store header sent, referrer ${request.headers['referer']}`,
    );
    return next(
      new HttpError(
        422,
        `Store not found, received x-store-id ${request.headers['x-store-id']}`,
      ),
    );
  }
  return next();
}
