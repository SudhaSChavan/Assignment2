import Emittery from 'emittery';

// tslint:disable-next-line:ext-variable-name
const EE: Emittery = new Emittery();

export { EE };
