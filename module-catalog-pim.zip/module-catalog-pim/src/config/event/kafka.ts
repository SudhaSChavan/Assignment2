import {
  Consumer,
  ConsumerEvents,
  EachMessagePayload,
  Kafka,
  logLevel,
  Producer,
  ProducerEvents,
} from 'kafkajs';
import { appConfig } from '../env';
import { md5 } from '@core/util/crypt';
import { logger } from '@core/util/logger';

export interface IPublisherParams {
  topic: string;
  data: Record<string, any>;
  headers?: Record<string, any>;
}

export interface IConsumerParams extends EachMessagePayload {}

export const clientId: string = md5(
  appConfig.name + Date.now() + Math.random(),
);

export const kafka: Kafka = new Kafka({
  clientId,
  brokers: process.env.KAFKA_QUEUE_URL
    ? process.env.KAFKA_QUEUE_URL.split(',')
    : ['127.0.0.1:9092'],
  logLevel: logLevel.ERROR,
});

export let kafkaProducer: Producer = null;
export const kafkaConsumerList: Record<string, Consumer> = {};

async function connectToConsumer(topic: string) {
  // If there is already a client
  // return it
  if (kafkaConsumerList[topic]) {
    return kafkaConsumerList[topic];
  }

  try {
    kafkaConsumerList[topic] = kafka.consumer({
      groupId: `consumer-${appConfig.name}-topic-${topic}`,
    });
    await kafkaConsumerList[topic].connect();
  } catch (error) {
    logger.error(
      `Kafka :: ${topic} consumer connect error ${JSON.stringify(error)}`,
    );
  }

  const events: ConsumerEvents = kafkaConsumerList[topic].events;

  kafkaConsumerList[topic].on(events.CONNECT, (args: any) => {
    logger.debug(`Kafka :: ${topic} ${events.CONNECT} ${JSON.stringify(args)}`);
  });

  kafkaConsumerList[topic].on(events.DISCONNECT, (args: any) => {
    logger.debug(
      `Kafka :: ${topic} ${events.DISCONNECT} ${JSON.stringify(args)}`,
    );
  });

  kafkaConsumerList[topic].on(events.STOP, (args: any) => {
    logger.debug(`Kafka :: ${topic} ${events.STOP} ${JSON.stringify(args)}`);
  });

  kafkaConsumerList[topic].on(events.CRASH, (args: any) => {
    logger.error(`Kafka :: ${events.CRASH} ${JSON.stringify(args)}`);
  });

  kafkaConsumerList[topic].on(events.REQUEST_TIMEOUT, (args: any) => {
    logger.debug(
      `Kafka :: ${topic} ${events.REQUEST_TIMEOUT} ${JSON.stringify(args)}`,
    );
  });
}

async function connectToPublisher() {
  // If there is already a client
  // return it
  if (kafkaProducer) {
    return kafkaProducer;
  }

  try {
    kafkaProducer = kafka.producer();
    await kafkaProducer.connect();
  } catch (error) {
    logger.error(`Kafka :: producer connect error ${JSON.stringify(error)}`);
  }

  const events: ProducerEvents = kafkaProducer.events;

  kafkaProducer.on(events.CONNECT, (args: any) => {
    logger.info(`Kafka :: connected`);
  });

  kafkaProducer.on(events.DISCONNECT, (args: any) => {
    logger.warn(`Kafka :: connection closed ${JSON.stringify(args)}`);
  });

  kafkaProducer.on(events.REQUEST_TIMEOUT, (args: any) => {
    logger.error(`Kafka :: ${events.REQUEST_TIMEOUT} ${JSON.stringify(args)}`);
  });
}

export async function publishToQueue(params: IPublisherParams): Promise<void> {
  try {
    await connectToPublisher();
    await kafkaProducer.send({
      topic: params.topic,
      messages: [
        {
          value: JSON.stringify(params.data),
          headers: params?.headers,
        },
      ],
    });
  } catch (error) {
    throw new Error(error);
  }
}

export async function consumeFromQueue(
  topic: string,
  callback: (params: IConsumerParams) => Promise<void>,
): Promise<any> {
  try {
    await connectToConsumer(topic);
    await kafkaConsumerList[topic].subscribe({ topic, fromBeginning: false });
    await kafkaConsumerList[topic].run({ eachMessage: callback });
  } catch (error) {
    throw new Error(error);
  }
}
