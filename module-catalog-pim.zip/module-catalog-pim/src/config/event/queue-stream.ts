import { connect, Stan } from 'node-nats-streaming';

import { IStanOptions } from './types';
import { logger } from '@core/util/logger';

type ConnectToQueueStreamParamsType = {
  clientId: string;
  clusterId: string;
  options?: IStanOptions;
};

type RejectType = (error: Error) => void;
type ResolveType = (client: Stan) => void;

let clientBackup: Stan;
let clientInProgress: boolean = false;

export async function connectToQueueStream(
  params: ConnectToQueueStreamParamsType,
): Promise<Stan> {
  return new Promise((resolve: ResolveType, reject: RejectType): void => {
    const { clientId, clusterId, options = {} } = params;

    // If there is already a client
    // return it
    if (clientBackup) {
      return resolve(clientBackup);
    }

    if (clientInProgress) {
      setTimeout((): void => {
        if (clientBackup) {
          resolve(clientBackup);
        } else {
          reject(new Error('no connection'));
        }
      }, 3000);
      return;
    }

    clientInProgress = true;
    logger.info('NatsStream :: connecting');

    let client: Stan;
    try {
      client = connect(clusterId, clientId, options);
    } catch (error) {
      // example connection refused is not handled by events
      logger.error(
        `NatsStream :: client connect error ${JSON.stringify(error)}`,
      );
    }

    if (!client) {
      logger.error(`NatsStream :: no client `);
      return reject(Error('NatsStream :: no client'));
    }

    client.on('connect', (client: Stan): void => {
      logger.info('NatsStream :: connected');
      clientBackup = client;
      clientInProgress = false;
      return resolve(client);
    });

    client.on('reconnect', (client: Stan): void => {
      clientInProgress = false;
      clientBackup = client;
      logger.info('NatsStream :: reconnected');
      return resolve(client);
    });

    client.on('error', (error: Error): void => {
      clientBackup = undefined;
      logger.error(`NatsStream :: client error ${JSON.stringify(error)}`);
      return reject(error);
    });

    client.on('permission_error', (error: Error): void => {
      clientBackup = undefined;
      logger.error(`NatsStream :: permission error ${JSON.stringify(error)}`);
      return reject(error);
    });

    client.on('client_lost', (error: Error): void => {
      clientBackup = undefined;
      logger.warn(`NatsStream :: client lost ${JSON.stringify(error)}`);
      return reject(error);
    });

    client.on('close', (error: Error): void => {
      clientBackup = undefined;
      logger.warn(`NatsStream :: client closed ${JSON.stringify(error)}`);
      return reject(error);
    });

    client.on('reconnecting', (): void => {
      clientInProgress = true;
      clientBackup = undefined;
      logger.info('NatsStream :: reconnecting');
    });

    client.on('disconnect', (): void => {
      clientBackup = undefined;
      logger.warn('NatsStream :: disconnected');
    });
  });
}
