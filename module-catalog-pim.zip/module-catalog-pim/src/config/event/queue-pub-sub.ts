import { Client, connect, NatsConnectionOptions } from 'ts-nats';

import { logger } from '@core/util/logger';

/**
 * @doc https://nats.io/blog/ts-nats/#events
 */

type ConnectToQueuePubSubParamsType = {
  options?: NatsConnectionOptions;
};

type RejectType = (error: Error) => void;
type ResolveType = (client: Client) => void;

let clientBackup: Client;
let clientInProgress: boolean = false;

export async function connectToQueuePubSub(
  params: ConnectToQueuePubSubParamsType = {},
): Promise<Client> {
  return new Promise(
    async (resolve: ResolveType, reject: RejectType): Promise<void> => {
      const { options } = params;

      if (clientBackup) {
        return resolve(clientBackup);
      }

      if (clientInProgress) {
        setTimeout((): void => {
          if (clientBackup) {
            resolve(clientBackup);
          } else {
            reject(new Error('no connection'));
          }
        }, 3000);
        return;
      }

      clientInProgress = true;
      logger.info('NatsPubSub :: connecting');

      let client: Client;
      try {
        client = await connect(options);
      } catch (error) {
        // example connection refused is not handled by events
        logger.error(
          `NatsPubSub :: client connect error ${JSON.stringify(error)}`,
        );
      }

      if (!client) {
        logger.error(`NatsPubSub :: no client `);
        return reject(Error('NatsPubSub :: no client'));
      }

      client.on('connect', (client: Client): void => {
        clientBackup = client;
        clientInProgress = false;
        logger.info('NatsPubSub :: connected');
        return resolve(client);
      });

      client.on('reconnect', (client: Client): void => {
        clientBackup = client;
        clientInProgress = false;
        logger.info('NatsPubSub :: reconnected');
        return resolve(client);
      });

      client.on('error', (error: Error): void => {
        clientBackup = undefined;
        logger.error(`NatsPubSub :: client error ${JSON.stringify(error)}`);
        return reject(error);
      });

      client.on('permissionError', (error: Error): void => {
        clientBackup = undefined;
        logger.error(`NatsPubSub :: permission error ${JSON.stringify(error)}`);
        return reject(error);
      });

      client.on('close', (error: Error): void => {
        clientBackup = undefined;
        logger.warn(`NatsPubSub :: client closed ${JSON.stringify(error)}`);
        return reject(error);
      });

      client.on('reconnecting', (): void => {
        clientInProgress = true;
        clientBackup = undefined;
        logger.info('NatsPubSub :: reconnecting');
      });

      client.on('disconnect', (): void => {
        clientBackup = undefined;
        logger.warn('NatsPubSub :: disconnected');
      });
    },
  );
}
