import {
  Stan,
  StartPosition,
  Subscription as StreamSubscription,
} from 'node-nats-streaming';
import {
  Client,
  NatsConnectionOptions,
  Subscription as SubscriptionPubSub,
} from 'ts-nats';
import { appConfig } from '../env';
import { connectToQueueStream } from './queue-stream';
import { connectToQueuePubSub } from './queue-pub-sub';
import { md5 } from '@core/util/crypt';
import { logger } from '@core/util/logger';
import { EE } from './emitter';
import {
  IAppQueuePubSubMessage,
  IAppQueueStreamMessage,
  IDoSubscribeToPubSubParams,
  IDoSubscribeToQueueGroupParams,
  IPublishToPubSubParams,
  IPublishToQueueStream,
  IQueueStreamSubscriptionOptions,
  IRequestReplyViaPubSub,
  IStanOptions,
  ISubscribeToPubSubParams,
  ISubscribeToQueueGroupParams,
  SubscribersListEntryType,
  SubscribersType,
} from './types';

const subscribers: SubscribersType = {};

// hack because its not exported from the driver
// todo refactor in new release
export function getQueueStreamSubscriptionOptions(): IQueueStreamSubscriptionOptions {
  return {
    durableName: '',
    maxInFlight: 16384,
    ackWait: 30 * 1000,
    startPosition: StartPosition.NEW_ONLY,
    startSequence: undefined,
    startTime: undefined,
    manualAcks: false,

    setStartWithLastReceived(): IQueueStreamSubscriptionOptions {
      this.startPosition = StartPosition.LAST_RECEIVED;
      return this;
    },
    setAckWait(millis: number): IQueueStreamSubscriptionOptions {
      this.ackWait = millis;
      return this;
    },
    setDeliverAllAvailable(): IQueueStreamSubscriptionOptions {
      this.startPosition = StartPosition.FIRST;
      return this;
    },
    setDurableName(durableName: string): IQueueStreamSubscriptionOptions {
      this.durableName = durableName;
      return this;
    },
    setManualAckMode(tf: boolean): IQueueStreamSubscriptionOptions {
      this.manualAcks = tf;
      return this;
    },
    setMaxInFlight(n: number): IQueueStreamSubscriptionOptions {
      this.maxInFlight = n;
      return this;
    },
    setStartAt(startPosition: StartPosition): IQueueStreamSubscriptionOptions {
      this.startPosition = startPosition;
      return this;
    },
    setStartAtSequence(sequence: number): IQueueStreamSubscriptionOptions {
      this.startPosition = StartPosition.SEQUENCE_START;
      this.startSequence = sequence;
      return this;
    },
    setStartAtTimeDelta(millis: number): IQueueStreamSubscriptionOptions {
      this.startPosition = StartPosition.TIME_DELTA_START;
      // noinspection JSUnresolvedFunction
      // server expects values in ns
      this.startTime = millis * 1000000;
      return this;
    },
    setStartTime(date: Date): IQueueStreamSubscriptionOptions {
      this.startPosition = StartPosition.TIME_DELTA_START;
      // server expects values in ns
      this.startTime = (Date.now() - date.valueOf()) * 1000000;
      return this;
    },
  };
}

export const clusterId: string =
  process.env.NATS_QUEUE_CLUSTERNAME || 'test-cluster';
export const clientId: string = md5(
  appConfig.name + Date.now() + Math.random(),
);
const clientName: string =
  appConfig.name + md5(Date.now() + Math.random().toString());

const natsConnectionOptions: NatsConnectionOptions = {
  waitOnFirstConnect: false,
  reconnect: true,
  name: clientName,
  maxReconnectAttempts: 1000,
  servers: process.env.NATS_QUEUE_URL
    ? process.env.NATS_QUEUE_URL.split(',')
    : ['nats://0.0.0.0:4222'],
  pass: process.env.NATS_QUEUE_PASS || undefined,
  user: process.env.NATS_QUEUE_USER || undefined,
};

const streamConnectionOptions: IStanOptions = {
  waitOnFirstConnect: false,
  reconnect: true,
  name: clientName,
  maxReconnectAttempts: 1000,
  servers: process.env.NATS_QUEUE_URL
    ? process.env.NATS_QUEUE_URL.split(',')
    : ['nats://0.0.0.0:4222'],
  pass: process.env.NATS_QUEUE_PASS || undefined,
  user: process.env.NATS_QUEUE_USER || undefined,
};

function decodeQueueMessage(data: Buffer): Record<string | number, any> {
  return JSON.parse(data.toString());
}

// stream
export async function publishToQueueStream(
  params: IPublishToQueueStream,
): Promise<string> {
  try {
    const { data, subject, callback } = params;
    const dataAsString: string = JSON.stringify(data);
    const client: Stan = await connectToQueueStream({
      clusterId: clusterId,
      clientId: clientId,
      options: streamConnectionOptions,
    });
    return client.publish(subject, dataAsString, callback);
  } catch (error) {
    throw new Error(error);
  }
}

export async function subscribeToQueueGroup(
  params: ISubscribeToQueueGroupParams,
): Promise<string> {
  // Generate unique identifier for subscriber
  const subscriberKey: string = `subscribeToQueueGroup-${params.subject}-${md5(
    `${params.subject}subscribeToQueueGroup${Math.random()}${Math.random()}`,
  )}`;

  // Put new subscriber into array
  subscribers[subscriberKey] = params;

  return subscriberKey;
}

async function doSubscribeToQueueGroup(
  params: IDoSubscribeToQueueGroupParams,
): Promise<void> {
  try {
    const { subject, processMessage, options } = params;
    const subscriptionOptions: IQueueStreamSubscriptionOptions = getQueueStreamSubscriptionOptions();
    subscriptionOptions.setDurableName(`${appConfig.name}-${subject}`);

    const client: Stan = await connectToQueueStream({
      clusterId: clusterId,
      clientId: clientId,
      options: streamConnectionOptions,
    });

    const subscription: StreamSubscription = client.subscribe(
      subject,
      `${appConfig.name}-${subject}`,
      { ...subscriptionOptions, ...options },
    );
    subscription.on('message', (message: IAppQueueStreamMessage): void => {
      processMessage({
        message,
        data: decodeQueueMessage(message.getRawData()),
        meta: {},
      });
    });
  } catch (error) {
    logger.error(
      `Error happened while subscribing in queue${JSON.stringify(error)}`,
    );
  }
}

// pub sub
export async function requestReplyViaPubSub(
  params: IRequestReplyViaPubSub,
): Promise<void> {
  try {
    const { subject, request, timeout = 10000, processReply } = params;
    const client: Client = await connectToQueuePubSub();

    client
      .request(subject, timeout, JSON.stringify(request))
      .then((replyMessage: IAppQueuePubSubMessage): void => {
        processReply({
          request,
          meta: {},
          replyMessage,
          data: decodeQueueMessage(replyMessage.data),
        });
      });
  } catch (error) {
    logger.error(
      `Error happened while subscribing in queue ${JSON.stringify(error)}`,
    );
  }
}

// pub sub // todo fix
export async function subscribeToPubSub(
  params: ISubscribeToPubSubParams,
): Promise<string> {
  // Generate unique identifier for subscriber
  const subscriberKey: string = `subscribeToPubSub-${params.subject}-${md5(
    `${params.subject}subscribeToPubSub${Math.random()}${Math.random()}`,
  )}`;

  // Put new subscriber into array
  subscribers[subscriberKey] = params;

  return subscriberKey;
}

async function doSubscribeToPubSub(
  params: IDoSubscribeToPubSubParams,
): Promise<SubscriptionPubSub> {
  const { subject, processMessage, subscriptionOptions = {} } = params;

  try {
    const client: Client = await connectToQueuePubSub();

    return client.subscribe(subject, processMessage, subscriptionOptions);
  } catch (error) {
    logger.error(
      `Error happened while subscribing in queue${JSON.stringify(error)}`,
    );
  }
}

// pub sub
export async function publishToPubSub(
  params: IPublishToPubSubParams,
): Promise<void> {
  const { data, subject, reply = '' } = params;
  try {
    const dataAsString: string = JSON.stringify(data);
    const client: Client = await connectToQueuePubSub();

    client.publish(subject, dataAsString, reply);
  } catch (error) {
    logger.error(
      `Error happened while subscribing in queue${JSON.stringify(error)}`,
    );
  }
}

let natsClient: Client;
let natsStreamingClient: Stan;

async function iniConnectionAndSubscribers(): Promise<void> {
  // If there is nothing to subscribe
  // on return
  if (!subscribers) {
    return;
  }

  try {
    // Only if there subscribers
    natsClient = await connectToQueuePubSub({ options: natsConnectionOptions });
  } catch (e) {
    logger.error(e);
    process.exit();
  }

  try {
    // Only if there subscribers
    natsStreamingClient = await connectToQueueStream({
      clientId,
      clusterId,
      options: streamConnectionOptions,
    });
  } catch (e) {
    logger.error(e);
    process.exit();
  }

  Object.entries(subscribers).forEach(
    ([subscriberKey, subscriberParams]: SubscribersListEntryType): void => {
      const subscriberType: string = subscriberKey.split('-')[0];
      switch (subscriberType) {
        case 'subscribeToQueueGroup':
          logger.info(`NatsStream :: subscribing to ${subscriberKey}`);
          doSubscribeToQueueGroup(
            subscriberParams as IDoSubscribeToQueueGroupParams,
          ).then();
          break;
        case 'subscribeToPubSub':
          logger.info(`NatsPubSub :: subscribing to ${subscriberKey}`);
          doSubscribeToPubSub(
            subscriberParams as IDoSubscribeToPubSubParams,
          ).then();
          break;
        default:
          logger.error(`unknown subscription type ${subscriberKey}`);
      }
    },
  );
}

EE.on('server.listening', (): void => {
  logger.info(`server.listening event listener`);
  // setTimeout((): void => {
  //   iniConnectionAndSubscribers().then();
  // }, Number(process.env.QUEUE_SUBSCRIBE_DELAY || 2000));
});

export function closeNatsConnections(): void {
  natsStreamingClient && natsStreamingClient.close();
  natsClient && natsClient.close();
}

process.on('exit', () => {
  logger.info('process.exit.closeNatsConnections');
  closeNatsConnections();
});

process.on('SIGINT', () => {
  logger.info('process.SIGINT.closeNatsConnections');

  closeNatsConnections();
});

process.on('SIGTERM', () => {
  logger.info('process.SIGTERM.closeNatsConnections');
  closeNatsConnections();
});

process.on('SIGILL', () => {
  logger.info('process.SIGILL.closeNatsConnections');
  closeNatsConnections();
});
