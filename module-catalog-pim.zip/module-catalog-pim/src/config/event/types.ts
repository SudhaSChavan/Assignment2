import { NatsError } from 'ts-nats/lib/error';
import {
  Msg as PubSubMessage,
  SubscriptionOptions as PubSubSubscriptionOptions,
} from 'ts-nats';
import {
  AckHandlerCallback,
  Message as StreamMessage,
  StanOptions,
  SubscriptionOptions as StreamSubscriptionOptions,
} from 'node-nats-streaming';

export interface IAppQueueStreamMessage extends StreamMessage {}

export interface IAppQueuePubSubMessage extends PubSubMessage {}

export interface IQueueStreamSubscriptionOptions
  extends StreamSubscriptionOptions {}

export interface IQueuePubSubSubscriptionOptions
  extends PubSubSubscriptionOptions {}

export interface IQueuePubSubMessageCallback {
  (err: NatsError | null, message: IAppQueuePubSubMessage): void;
}

export interface IStanOptions extends StanOptions {}

export interface IPublishToQueueStream {
  subject: string;
  callback?: AckHandlerCallback;
  data: Record<string | number, any>;
}

export interface ISubscribeToPubSubParams {
  subject: string;
  processMessage: IQueuePubSubMessageCallback;
  subscriptionOptions?: IQueuePubSubSubscriptionOptions;
}

export interface IDoSubscribeToPubSubParams extends ISubscribeToPubSubParams {}

export interface IPublishToPubSubParams {
  reply?: string;
  subject: string;
  data: Record<string | number, any>;
}

export interface IProcessReplayParams {
  request: Record<any, any>;
  meta?: Record<string, string>;
  data: Record<string | number, any>;
  replyMessage: IAppQueuePubSubMessage;
}

export interface IRequestReplyViaPubSub {
  subject: string;
  timeout?: number;
  request: Record<any, any>;
  processReply: (params: IProcessReplayParams) => void;
}

export interface IProcessMessageParams {
  meta?: Record<string, string>;
  message: IAppQueueStreamMessage;
  data: Record<string | number, any>;
}

export interface ISubscribeToQueueGroupParams {
  subject: string;
  options?: IQueueStreamSubscriptionOptions;
  processMessage: (params: IProcessMessageParams) => void;
}

export interface IDoSubscribeToQueueGroupParams
  extends ISubscribeToQueueGroupParams {}

export type SubscribersType = {
  [key: string]: ISubscribeToQueueGroupParams | ISubscribeToPubSubParams;
};

export type SubscribersListEntryType = [
  string,
  ISubscribeToQueueGroupParams | ISubscribeToPubSubParams,
];
