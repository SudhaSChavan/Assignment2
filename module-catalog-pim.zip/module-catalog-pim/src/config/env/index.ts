import 'dotenv/config';
import { version as appVersion } from '../../../package.json';
import { port } from '@tradeling/config';

export type ConfigMapType = {
  [name: string]: () => IConfig;
};

// server runtime environment, configurable on development server as dev and production environment as prod
// use case example:
// when user register on development environment, we don't have access to sms or email
// or in automation environment we need to get the verification code in registration
// so we use this flag to send the sms in the response so we can access it without needing email or phone
export const isAuditEnabled: boolean =
  (process.env.ENABLE_AUDIT || '0') === '1';
export const isUpdatingSkuEnabled: boolean =
  (process.env.ENABLE_SKU_UPDATE || '0') === '1';
// by default it's enabled
export const isMarginGuardrailsEnabled: boolean =
  (process.env.ENABLE_MARGINGUARD_RAILS || '1') === '1';

export interface IConfig {
  swaggerTitle: string;
  swaggerVersion: string;
  EmailsCanOverrideGuardRails: string[];
  EmailsCanUpdateRebate: string[];
  swaggerDescription: string;
  name: string;
  port: number;
  maxNumberOfImageUploadCsv: number;
  maxChunkImageUploadSize: number;
  tradelingExpressIds?: string[];
  isAuditEnabled: boolean;
  isUpdatingSkuEnabled?: boolean;
  providers?: Record<string, any>;
  secret: string;
  jwtSecret: string;
  backofficeJwtSecret: string;
  isLocal?: boolean;
  httpTimeout: number;
  blinkMinCommissionValue: number;
  isTesting?: boolean;
  jwtExpInDays: string;
  encryptionKey: string;
  isProduction?: boolean;
  isDevelopment?: boolean;
  routePathPrefix: string;
  categoryTTLSecs: number;
  mongodb: {
    uri: string;
    poolSize: number;
  };
  redis: {
    uri: string;
    prefix: string;
    timeout: number;
    maxRetires: number;
  };
  category: {
    listDefaultLimit: number;
    listMaxLimit: number;
    keywordsLimit: number;
  };
  product: {
    maxMediaLimit: number;
    maxKeywordsLimit: number;
    listDefaultLimit: number;
    listMaxLimit: number;
    allowedUploadExtensions: string[];
    maxFileSizeBytes: number;
    maxIndexingBatchSize: number;
  };
  media: {
    listDefaultLimit: number;
    listMaxLimit: number;
    allowedImageUploadExtensions: string[];
    allowedUploadExtensions: string[];
    maxFileSizeBytes: number;
    minWidth: number;
    minHeight: number;
    minAspectRatio: number;
    maxAspectRatio: number;
    maxResolution: number;
  };
  storage: {
    tempMulterPath: string;
    diskPath: string;
    disk: string;
    tempMediaPath: string;
  };
  s3: {
    bucket: string;
    region: string;
    accessKeyId: string;
    secretAccessKey: string;
  };
  mediaBaseUrl: string;
  tempMediaBaseUrl: string;
  storeCacheTTL: number;
  cors: {
    allowedOrigins: string[];
    allowedHeaders: string[];
  };
}

const appName: string = process.env.APP_NAME ?? 'module-catalog-pim';
const nodeEnv: string = process.env.NODE_ENV ?? 'development';
export const localAppUrl: string = `http://localhost:${port}`;

// Path where files will be temporarily stored before moving to relevant place
const tempMulterPath: string =
  process.env.TEMP_MULTER_PATH || `/tmp/${appName}`;
const tempMediaPath: string = process.env.TEMP_MEDIA_PATH || `/tmp/${appName}`;
const diskStoragePath: string =
  process.env.DISK_STORAGE_PATH || `/tmp/${appName}`;
const storageDisk: string = process.env.DISK || 'local';
const mediaBaseUrl: string =
  process.env.MEDIA_BASE_URL ||
  (nodeEnv === 'development' ? 'http://module-catalog-pim.b2b.localhost' : '');
const tempMediaBaseUrl: string =
  process.env.TEMP_MEDIA_BASE_URL ||
  (nodeEnv === 'development' ? 'http://module-catalog-pim.b2b.localhost' : '');

// Set max image size to 10MB.
const maxFileSizeBytes: number = 10 * 1024 * 1024;

export const allowedImageExtensions: string[] = [
  'png',
  'bmp',
  'jpg',
  'jpe',
  'jpeg',
  'gif',
  'bmp',
  'webp',
];

export const allowedVideoExtensions: string[] = [
  'mov',
  'gifv',
  'mp4',
  'm3u',
  'mpeg',
  'mpg',
  'avi',
];

export const allowedDocExtensions: string[] = [
  'rtf',
  'text',
  'md',
  'xlt',
  'pdf',
  'txt',
  'xls',
  'xlsx',
  'doc',
  'docx',
  'ppt',
  'pptx',
  'csv',
];

const allowedUploadExtensions: string[] = [
  ...allowedImageExtensions,
  ...allowedVideoExtensions,
  ...allowedDocExtensions,
];

const allowedProductUploadExtensions: string[] = ['xlsx'];

// We allow images between 1/5 5/1
const minAspectRatio: number =
  parseFloat(process.env.MEDIA_MIN_ASPECT_RATIO) || 1 / 5;
const maxAspectRatio: number =
  parseFloat(process.env.MEDIA_MAX_ASPECT_RATIO) || 5;
const minMediaWidth: number = parseInt(process.env.MEDIA_MIN_WIDTH) || 500;
const minMediaHeight: number = parseInt(process.env.MEDIA_MIN_HEIGHT) || 500;
const maxResolution: number =
  parseInt(process.env.MEDIA_MAX_RESOLUTION) || 65 * 1024 * 1024;

const development: any = (): IConfig => {
  return {
    EmailsCanOverrideGuardRails: (
      process.env.EMAILS_CAN_OVERRIDE_GUARDRAILS || ''
    ).split(','),
    EmailsCanUpdateRebate: (process.env.EMAILS_CAN_UPDATE_REBATE || '').split(
      ',',
    ),
    swaggerTitle: appName ?? 'Tradeling',
    swaggerVersion: appVersion,
    swaggerDescription: 'Module Backoffice APIS',
    isAuditEnabled,
    isUpdatingSkuEnabled,
    tradelingExpressIds: (process.env.TRADELING_EXPRESS_IDS || '').split(','),
    isLocal: false,
    isTesting: false,
    isDevelopment: nodeEnv === 'development',
    isProduction: nodeEnv === 'production',
    name: appName,
    jwtExpInDays: process.env.JWT_EXP_IN_DAYS ?? '365',
    jwtSecret: process.env.JWT_SECRET,
    backofficeJwtSecret: 'module-backoffice',
    routePathPrefix:
      process.env.ROUTE_PATH_PREFIX ?? '/api/module-catalog-pim/',
    categoryTTLSecs: parseInt(process.env.CATEGORY_TTL_SECS || '900'),
    maxNumberOfImageUploadCsv: parseInt(
      process.env.MAX_NUMBER_OF_IMAGE_UPLOAD_CSV || '150000',
    ),
    maxChunkImageUploadSize: parseInt(
      process.env.MAX_CHUNK_IMAGE_UPLOAD_SIZE || '100',
    ),
    port: parseInt(process.env.PORT || '0') ?? 0,
    blinkMinCommissionValue: parseFloat(
      process.env.BLINK_MINCOMMISSION_VALUE || '2.5',
    ),
    mongodb: {
      poolSize: parseInt(process.env.MONGODB_DB_POOL_SIZE) || 10,
      uri:
        process.env.MONGODB_URI ?? 'mongodb://0.0.0.0:27017/module-catalog-pim',
    },
    secret: process.env.SECRET ?? '@QEGTUI',
    encryptionKey:
      process.env.ENCRYPTION_KEY ?? 'ZWH5RwuA0YhMyKWwXPJPZgKHHEDRtGXP',
    redis: {
      uri: process.env.REDIS_URI ?? 'redis://0.0.0.0:6379',
      prefix: process.env.REDIS_PREFIX ?? 'module-catalog-pim_',
      timeout: parseInt(process.env.REDIS_TIMEOUT) ?? 10000, // 10 seconds
      maxRetires: parseInt(process.env.REDIS_TIMEOUT) ?? 10,
    },
    httpTimeout: parseInt(process.env.HTTP_CLIENT_TIMEOUT) ?? 10000,
    category: {
      listDefaultLimit: parseInt(process.env.CATEGORY_LIST_DEFAULT_LIMIT) || 50,
      listMaxLimit: parseInt(process.env.CATEGORY_LIST_MAX_LIMIT) || 1000,
      keywordsLimit: parseInt(process.env.CATEGORY_KEYWORDS_LIMIT) || 50,
    },
    product: {
      maxMediaLimit: parseInt(process.env.PRODUCT_MAX_MEDIA_LIMIT) || 16,
      maxKeywordsLimit: parseInt(process.env.PRODUCT_MAX_KEYWORDS_LIMIT) || 50,
      listDefaultLimit: parseInt(process.env.PRODUCT_LIST_DEFAULT_LIMIT) || 20,
      listMaxLimit: parseInt(process.env.PRODUCT_LIST_MAX_LIMIT) || 1000,
      allowedUploadExtensions: allowedProductUploadExtensions,
      maxFileSizeBytes: 10_000_000,
      maxIndexingBatchSize:
        parseInt(process.env.PRODUCT_MAX_INDEXING_BATCH_SIZE) || 100,
    },
    media: {
      listDefaultLimit: parseInt(process.env.MEDIA_LIST_DEFAULT_LIMIT) || 50,
      listMaxLimit: parseInt(process.env.MEDIA_LIST_MAX_LIMIT) || 1000,
      allowedImageUploadExtensions: allowedImageExtensions,
      allowedUploadExtensions,
      maxFileSizeBytes,
      minHeight: minMediaHeight,
      minWidth: minMediaWidth,
      minAspectRatio: minAspectRatio,
      maxAspectRatio: maxAspectRatio,
      maxResolution: maxResolution,
    },
    storage: {
      tempMulterPath: tempMulterPath,
      diskPath: diskStoragePath,
      disk: storageDisk,
      tempMediaPath,
    },
    s3: {
      bucket: process.env.S3_BUCKET,
      region: process.env.S3_REGION,
      accessKeyId: process.env.S3_ACCESS_KEY_ID,
      secretAccessKey: process.env.S3_SECRET_ACCESS_KEY,
    },
    mediaBaseUrl,
    tempMediaBaseUrl,
    storeCacheTTL: parseInt(process.env.USER_INFO_CACHE_EXPIRY ?? '300'),
    cors: {
      allowedOrigins: process.env.CORS_ALLOWED_ORIGINS
        ? process.env.CORS_ALLOWED_ORIGINS.split(',')
        : ['*'],
      allowedHeaders: process.env.CORS_ALLOWED_HEADERS
        ? process.env.CORS_ALLOWED_HEADERS.split(',')
        : [],
    },
  };
};

const production: any = (): IConfig => {
  return {
    EmailsCanOverrideGuardRails: (
      process.env.EMAILS_CAN_OVERRIDE_GUARDRAILS || ''
    ).split(','),
    EmailsCanUpdateRebate: (process.env.EMAILS_CAN_UPDATE_REBATE || '').split(
      ',',
    ),
    swaggerTitle: appName ?? 'Tradeling',
    swaggerVersion: appVersion,
    swaggerDescription: 'Module Backoffice APIS',
    isAuditEnabled,
    isUpdatingSkuEnabled,
    blinkMinCommissionValue: parseFloat(
      process.env.BLINK_MINCOMMISSION_VALUE || '2.5',
    ),
    tradelingExpressIds: (process.env.TRADELING_EXPRESS_IDS || '').split(','),
    isTesting: false,
    isLocal: false,
    isDevelopment: nodeEnv === 'development',
    isProduction: nodeEnv === 'production',
    name: appName,
    jwtExpInDays: process.env.JWT_EXP_IN_DAYS ?? '365',
    jwtSecret: process.env.JWT_SECRET,
    backofficeJwtSecret: 'module-backoffice',
    routePathPrefix:
      process.env.ROUTE_PATH_PREFIX ?? '/api/module-catalog-pim/',
    categoryTTLSecs: parseInt(process.env.CATEGORY_TTL_SECS || '900'),
    maxNumberOfImageUploadCsv: parseInt(
      process.env.MAX_NUMBER_OF_IMAGE_UPLOAD_CSV || '150000',
    ),
    maxChunkImageUploadSize: parseInt(
      process.env.MAX_CHUNK_IMAGE_UPLOAD_SIZE || '100',
    ),
    port: parseInt(process.env.PORT || '0') ?? 0,
    mongodb: {
      poolSize: parseInt(process.env.MONGODB_DB_POOL_SIZE) || 10,
      uri:
        process.env.MONGODB_URI ?? 'mongodb://0.0.0.0:27017/module-catalog-pim',
    },
    secret: process.env.SECRET ?? '@QEGTUI',
    encryptionKey:
      process.env.ENCRYPTION_KEY ?? 'ZWH5RwuA0YhMyKWwXPJPZgKHHEDRtGXP',
    redis: {
      uri: process.env.REDIS_URI ?? 'redis://0.0.0.0:6379',
      prefix: process.env.REDIS_PREFIX ?? 'module-catalog-pim_',
      timeout: parseInt(process.env.REDIS_TIMEOUT) ?? 10000, // 10 seconds
      maxRetires: parseInt(process.env.REDIS_TIMEOUT) ?? 10,
    },
    httpTimeout: parseInt(process.env.HTTP_CLIENT_TIMEOUT) ?? 10000,
    category: {
      listDefaultLimit: parseInt(process.env.CATEGORY_LIST_DEFAULT_LIMIT) || 50,
      listMaxLimit: parseInt(process.env.CATEGORY_LIST_MAX_LIMIT) || 1000,
      keywordsLimit: parseInt(process.env.CATEGORY_KEYWORDS_LIMIT) || 50,
    },
    product: {
      maxMediaLimit: parseInt(process.env.PRODUCT_MAX_MEDIA_LIMIT) || 16,
      maxKeywordsLimit: parseInt(process.env.PRODUCT_MAX_KEYWORDS_LIMIT) || 50,
      listDefaultLimit: parseInt(process.env.PRODUCT_LIST_DEFAULT_LIMIT) || 50,
      listMaxLimit: parseInt(process.env.PRODUCT_LIST_MAX_LIMIT) || 1000,
      allowedUploadExtensions: allowedProductUploadExtensions,
      maxFileSizeBytes: 10_000_000,
      maxIndexingBatchSize:
        parseInt(process.env.PRODUCT_MAX_INDEXING_BATCH_SIZE) || 100,
    },
    media: {
      listDefaultLimit: parseInt(process.env.MEDIA_LIST_DEFAULT_LIMIT) || 20,
      listMaxLimit: parseInt(process.env.MEDIA_LIST_MAX_LIMIT) || 1000,
      allowedImageUploadExtensions: allowedImageExtensions,
      allowedUploadExtensions,
      maxFileSizeBytes,
      minHeight: minMediaHeight,
      minWidth: minMediaWidth,
      minAspectRatio: minAspectRatio,
      maxAspectRatio: maxAspectRatio,
      maxResolution: maxResolution,
    },
    storage: {
      tempMulterPath: tempMulterPath,
      diskPath: diskStoragePath,
      disk: storageDisk,
      tempMediaPath,
    },
    s3: {
      bucket: process.env.S3_BUCKET,
      region: process.env.S3_REGION,
      accessKeyId: process.env.S3_ACCESS_KEY_ID,
      secretAccessKey: process.env.S3_SECRET_ACCESS_KEY,
    },
    mediaBaseUrl,
    tempMediaBaseUrl,
    storeCacheTTL: parseInt(process.env.USER_INFO_CACHE_EXPIRY ?? '300'),
    cors: {
      allowedOrigins: process.env.CORS_ALLOWED_ORIGINS
        ? process.env.CORS_ALLOWED_ORIGINS.split(',')
        : ['*'],
      allowedHeaders: process.env.CORS_ALLOWED_HEADERS
        ? process.env.CORS_ALLOWED_HEADERS.split(',')
        : [],
    },
  };
};

const test: any = (): IConfig => {
  return {
    EmailsCanOverrideGuardRails: (
      process.env.EMAILS_CAN_OVERRIDE_GUARDRAILS || ''
    ).split(','),
    EmailsCanUpdateRebate: (process.env.EMAILS_CAN_UPDATE_REBATE || '').split(
      ',',
    ),
    swaggerTitle: appName ?? 'Tradeling',
    swaggerVersion: appVersion,
    swaggerDescription: 'Module Backoffice APIS',
    isAuditEnabled,
    isUpdatingSkuEnabled,
    blinkMinCommissionValue: parseFloat(
      process.env.BLINK_MINCOMMISSION_VALUE || '2.5',
    ),
    tradelingExpressIds: (process.env.TRADELING_EXPRESS_IDS || '').split(','),
    isTesting: true,
    isLocal: false,
    isDevelopment: nodeEnv === 'development',
    isProduction: nodeEnv === 'production',
    name: appName,
    jwtExpInDays: process.env.JWT_EXP_IN_DAYS ?? '365',
    jwtSecret: process.env.JWT_SECRET ?? 'module-catalog-pim',
    backofficeJwtSecret: 'module-backoffice',
    routePathPrefix:
      process.env.ROUTE_PATH_PREFIX ?? '/api/module-catalog-pim/',
    categoryTTLSecs: parseInt(process.env.CATEGORY_TTL_SECS || '900'),
    maxNumberOfImageUploadCsv: parseInt(
      process.env.MAX_NUMBER_OF_IMAGE_UPLOAD_CSV || '150000',
    ),
    maxChunkImageUploadSize: parseInt(
      process.env.MAX_CHUNK_IMAGE_UPLOAD_SIZE || '100',
    ),
    port: parseInt(process.env.PORT || '0') ?? 0,
    mongodb: {
      poolSize: parseInt(process.env.MONGODB_DB_POOL_SIZE) || 10,
      uri:
        process.env.TESTING_MONGODB_URI ??
        process.env.MONGODB_URI ??
        'mongodb://0.0.0.0:27017/module-catalog-pim-test',
    },
    secret: process.env.SECRET ?? '@QEGTUI',
    encryptionKey:
      process.env.ENCRYPTION_KEY ?? 'ZWH5RwuA0YhMyKWwXPJPZgKHHEDRtGXP',
    redis: {
      uri: process.env.REDIS_URI ?? 'redis://0.0.0.0:6379',
      prefix: process.env.REDIS_PREFIX ?? 'module-catalog-pim_',
      timeout: parseInt(process.env.REDIS_TIMEOUT) ?? 10000, // 10 seconds
      maxRetires: parseInt(process.env.REDIS_TIMEOUT) ?? 10,
    },
    httpTimeout: parseInt(process.env.HTTP_CLIENT_TIMEOUT) ?? 10000,
    category: {
      listDefaultLimit: parseInt(process.env.CATEGORY_LIST_DEFAULT_LIMIT) || 3,
      listMaxLimit: parseInt(process.env.CATEGORY_LIST_MAX_LIMIT) || 4,
      keywordsLimit: parseInt(process.env.CATEGORY_KEYWORDS_LIMIT) || 2,
    },
    product: {
      maxMediaLimit: parseInt(process.env.PRODUCT_MAX_MEDIA_LIMIT) || 16,
      maxKeywordsLimit: parseInt(process.env.PRODUCT_MAX_KEYWORDS_LIMIT) || 2,
      listDefaultLimit: parseInt(process.env.PRODUCT_LIST_DEFAULT_LIMIT) || 3,
      listMaxLimit: parseInt(process.env.PRODUCT_LIST_MAX_LIMIT) || 4,
      allowedUploadExtensions: allowedProductUploadExtensions,
      maxFileSizeBytes: 10_000_000,
      maxIndexingBatchSize:
        parseInt(process.env.PRODUCT_MAX_INDEXING_BATCH_SIZE) || 100,
    },
    media: {
      listDefaultLimit: parseInt(process.env.MEDIA_LIST_DEFAULT_LIMIT) || 3,
      listMaxLimit: parseInt(process.env.MEDIA_LIST_MAX_LIMIT) || 4,
      allowedImageUploadExtensions: allowedImageExtensions,
      allowedUploadExtensions,
      maxFileSizeBytes,
      minHeight: parseInt(process.env.MEDIA_MIN_HEIGHT) || 400,
      minWidth: parseInt(process.env.MEDIA_MIN_WIDTH) || 400,
      minAspectRatio: minAspectRatio,
      maxAspectRatio: maxAspectRatio,
      maxResolution: maxResolution,
    },
    storage: {
      tempMulterPath: tempMulterPath,
      diskPath: diskStoragePath,
      disk: storageDisk,
      tempMediaPath,
    },
    s3: {
      bucket: process.env.S3_BUCKET,
      region: process.env.S3_REGION,
      accessKeyId: process.env.S3_ACCESS_KEY_ID,
      secretAccessKey: process.env.S3_SECRET_ACCESS_KEY,
    },
    mediaBaseUrl,
    tempMediaBaseUrl,
    storeCacheTTL: parseInt(process.env.USER_INFO_CACHE_EXPIRY ?? '300'),
    cors: {
      allowedOrigins: process.env.CORS_ALLOWED_ORIGINS
        ? process.env.CORS_ALLOWED_ORIGINS.split(',')
        : ['*'],
      allowedHeaders: process.env.CORS_ALLOWED_HEADERS
        ? process.env.CORS_ALLOWED_HEADERS.split(',')
        : [],
    },
  };
};

const configMap: ConfigMapType = {
  test,
  development,
  production,
};

export const appConfig: IConfig = configMap[nodeEnv]();

const appNamePortSum: any = (): number => {
  return (
    Math.ceil(
      [...appConfig.name, ...appConfig.name.split('-').pop()].reduce(
        (sum: any, char: any): number => sum + char.charCodeAt(0),
        0,
      ) / 30,
    ) + 3000
  );
};

// tslint:disable-next-line:no-typeof-undefined
appConfig.port =
  typeof process.env.PORT == 'undefined' ? appNamePortSum() : appConfig.port;
