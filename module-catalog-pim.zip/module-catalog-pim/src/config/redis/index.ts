import Redis, { RedisOptions } from 'ioredis';

import { appConfig } from '../env';
import { logger } from '@core/util/logger';

interface IRedisOptions extends RedisOptions {}

const options: IRedisOptions = {
  keyPrefix: appConfig.redis.prefix,
  connectTimeout: appConfig.redis.timeout,
  maxRetriesPerRequest: appConfig.redis.maxRetires,
};

const redisURI: string = appConfig.redis.uri;
const redis: Redis.Redis = new Redis(redisURI, options);

redis.on('error', (error: Error): void => {
  logger.error(`Redis :: connection ${JSON.stringify(error)}`);
});

redis.on('connect', (): void => {
  logger.info('Redis :: connected');
});

redis.on('reconnecting', (): void => {
  logger.warn('Redis :: reconnecting');
});

redis.on('end', (): void => {
  logger.warn('Redis :: disconnected');
});

export { redis };
