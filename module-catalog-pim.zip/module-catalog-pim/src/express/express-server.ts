import express from 'express';
import { Application } from 'express-serve-static-core';

import '@src/config/connection/connection';
import { appConfig } from '@src/config/env';
import { initRouter } from '@express/routes';
import { configureMiddleware } from '@src/config/middleware/middleware';

/**
 * @constant {Application}
 */
const expressApp: Application = express();

// Serve assets from the disk path
if (appConfig.isDevelopment) {
  expressApp.use(express.static(`/tmp/${appConfig.name}`));
}

/**
 * @constructs Application Middleware
 */
configureMiddleware(expressApp);

/**
 * @constructs Application Routes
 */
initRouter(expressApp);

/**
 * @exports {Application}
 */
export { expressApp };
