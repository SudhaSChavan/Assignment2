import { Router } from 'express';
import { Router as IRouter } from 'express-serve-static-core';

import { isAuthenticatedMw } from '@tradeling/web-js-utils';
import { catchAsyncErrors } from '@core/util/router';
import {
  listCollectionAction,
  validateListCollection,
} from './action-list-collection';
import { authenticateInternalMw } from '@tradeling/web-js-utils';
import {
  validateCreateCollectionBackoffice,
  createCollectionBackofficeAction,
} from './action-create-collection-backoffice';
import {
  validateGetCollectionBackoffice,
  getCollectionBackofficeAction,
} from './action-get-collection-backoffice';
import {
  validateListCollectionBackoffice,
  listCollectionBackofficeAction,
} from './action-list-collection-backoffice';
import {
  validateUpdateCollectionBackoffice,
  updateCollectionBackofficeAction,
} from './action-update-collection-backoffice';
import { backOfficeUserMw } from '@src/config/middleware/is-backoffice-user';
import {
  deleteCollectionBackofficeActionV3,
  validateDeleteCollectionBackofficeV3,
} from './v3/action-delete-collection-backoffice';

const router: IRouter = Router();

router.post(
  '/v1-list-collection',
  isAuthenticatedMw(),
  validateListCollection,
  catchAsyncErrors(listCollectionAction),
);
router.post(
  '/v1-internal-list-collection',
  authenticateInternalMw,
  validateListCollection,
  catchAsyncErrors(listCollectionAction),
);
router.post(
  '/v1-create-collection-backoffice',
  backOfficeUserMw([]),
  validateCreateCollectionBackoffice,
  catchAsyncErrors(createCollectionBackofficeAction),
);
router.post(
  '/v1-get-collection-backoffice',
  backOfficeUserMw([]),
  validateGetCollectionBackoffice,
  catchAsyncErrors(getCollectionBackofficeAction),
);
router.post(
  '/v1-list-collection-backoffice',
  backOfficeUserMw([]),
  validateListCollectionBackoffice,
  catchAsyncErrors(listCollectionBackofficeAction),
);
router.post(
  '/v1-update-collection-backoffice',
  backOfficeUserMw([]),
  validateUpdateCollectionBackoffice,
  catchAsyncErrors(updateCollectionBackofficeAction),
);

router.post(
  '/v3-delete-collection-backoffice',
  backOfficeUserMw([]),
  validateDeleteCollectionBackofficeV3,
  catchAsyncErrors(deleteCollectionBackofficeActionV3),
);

export { router as collectionRoutes };
