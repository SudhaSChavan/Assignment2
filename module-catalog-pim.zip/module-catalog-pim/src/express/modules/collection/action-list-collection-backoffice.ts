import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils';
import { body } from 'express-validator';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { ERRORS } from '@src/types/errors';
import { collectionModel, ICollectionModel } from './model-collection';

interface IReq extends IAppRequest {
  body: Paths.V1ListCollectionBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1ListCollectionBackofficeAction.Responses.$200) => this;
}

export const validateListCollectionBackoffice: BaseValidationType = [
  body('page').optional().isInt({ gt: 0 }).withMessage(ERRORS.INVALID),
  body('limit').optional().isInt({ gt: 0 }).withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function listCollectionBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { page = 1, limit = 60 } = req.body;

  const totalRecords: number = await collectionModel.countDocuments();
  const data: ICollectionModel[] = await collectionModel
    .find(
      {},
      {
        _id: 1,
        slug: 1,
        name: 1,
        createdAt: 1,
        updatedAt: 1,
      },
      {
        limit,
        sort: { createdAt: -1 },
        skip: (page - 1) * limit,
      },
    )
    .lean();

  res.json({
    limit,
    data,
    currentPage: page,
    total: totalRecords,
    lastPage: Math.ceil(totalRecords / limit),
  });
}
