import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils';

import { ERRORS } from '@src/types/errors';
import { collectionModel } from '../model-collection';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { productModelV3 } from '../../product/model-product-v3';

interface IReq extends IAppRequest {
  body: Paths.V3DeleteCollectionBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3DeleteCollectionBackofficeAction.Responses.$200) => this;
}

export const validateDeleteCollectionBackofficeV3: BaseValidationType = [
  body('id').optional().isMongoId().withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function deleteCollectionBackofficeActionV3(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { id } = req.body;

  await collectionModel.findByIdAndDelete(id);

  await productModelV3.updateMany(
    { collectionIds: id },
    { syncedAt: new Date() },
  );

  res.json({
    isDeleted: true,
  });
}
