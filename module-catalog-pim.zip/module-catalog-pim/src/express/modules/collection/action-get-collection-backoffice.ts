import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils';

import { ERRORS } from '@src/types/errors';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { collectionModel, ICollectionDocument } from './model-collection';

interface IReq extends IAppRequest {
  body: Paths.V1GetCollectionBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1GetCollectionBackofficeAction.Responses.$200) => this;
}

export const validateGetCollectionBackoffice: BaseValidationType = [
  body('id').optional().isMongoId().withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function getCollectionBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { id } = req.body;

  const collection: ICollectionDocument = await collectionModel.findById(id);

  res.json(collection);
}
