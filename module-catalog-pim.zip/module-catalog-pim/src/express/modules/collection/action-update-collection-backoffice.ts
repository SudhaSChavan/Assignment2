import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils';
import { body } from 'express-validator';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { ERRORS } from '@src/types/errors';
import { collectionModel, ICollectionModel } from './model-collection';

interface IReq extends IAppRequest {
  body: Paths.V1UpdateCollectionBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1UpdateCollectionBackofficeAction.Responses.$200) => this;
}

export const validateUpdateCollectionBackoffice: BaseValidationType = [
  body('id').isMongoId().withMessage(ERRORS.INVALID),
  body('name').optional().isString().withMessage(ERRORS.INVALID).trim(),
  reqValidationResult,
];

export async function updateCollectionBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { id, name } = req.body;

  const collectionFromDB: ICollectionModel = await collectionModel.findOne({
    _id: id,
  });

  collectionFromDB.name = name ?? collectionFromDB.name;

  await collectionFromDB.save();

  res.json({
    isUpdated: true,
  });
}
