import {
  BaseValidationType,
  HttpError,
  reqValidationResult,
} from '@tradeling/web-js-utils';
import { body } from 'express-validator';
import { StatusCodes } from 'http-status-codes';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { ERRORS } from '@src/types/errors';
import { collectionModel, ICollectionDocument } from './model-collection';

interface IReq extends IAppRequest {
  body: Paths.V1CreateCollectionBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1CreateCollectionBackofficeAction.Responses.$200) => this;
}

export const validateCreateCollectionBackoffice: BaseValidationType = [
  body('name')
    .isString()
    .withMessage(ERRORS.INVALID)
    .trim()
    .custom(
      async (name: string): Promise<void> => {
        const transformedName: string = name.replace(/\s+/g, ' ');

        const isCollectionExists: boolean = await collectionModel.exists({
          name: {
            $regex: new RegExp(transformedName, 'i'),
          },
        });
        if (isCollectionExists) {
          throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.DUPLICATE);
        }
      },
    ),
  reqValidationResult,
];

export async function createCollectionBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { name } = req.body;

  collectionModel.create<Partial<ICollectionDocument>>({
    name: name.replace(/\s+/g, ' '),
  });

  res.json({
    isCreated: true,
  });
}
