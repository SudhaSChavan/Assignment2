import mongoose, { Schema } from 'mongoose';

export type ICollectionDocument = {
  name: string;
  slug: string;
  createdAt: string;
  updatedAt: string;
};

export interface ICollectionModel
  extends ICollectionDocument,
    mongoose.Document {
  _id: string;
}

const collectionSchema: Schema = new mongoose.Schema(
  {
    name: {
      trim: true,
      unique: true,
      type: String,
      required: true,
    },
    slug: {
      unique: true,
      type: String,
    },
  },
  {
    timestamps: true,
    versionKey: false,
    collection: 'collection',
  },
);

collectionSchema.index({ slug: 1 });

collectionSchema.pre<ICollectionModel>('save', function (next): void {
  this.slug = this.name.toLowerCase().replace(/\s+/g, ' ').split(' ').join('-');
  next();
});

export const collectionModel: mongoose.Model<ICollectionModel> = mongoose.model<ICollectionModel>(
  'Collection',
  collectionSchema,
);
