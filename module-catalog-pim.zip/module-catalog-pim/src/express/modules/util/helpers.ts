import { appConfig } from '@src/config/env';

export function generateSkip(limit: number, page: number): number {
  let skip: number = 0;
  if (page) {
    skip = (page - 1) * limit;
  }
  return skip;
}

export function getCommissionValue(
  costPrice: number,
  rebate: number = 0,
): number {
  let newCostPrice = costPrice;

  if (rebate !== 0) {
    newCostPrice = costPrice - (costPrice * rebate) / 100;
  }
  const commissionValue = 1 - appConfig.blinkMinCommissionValue / 100;
  return parseFloat((newCostPrice / commissionValue).toFixed(2));
}
