import mongoose, { Document, Model, Schema } from 'mongoose';
import { Channels, Stores, Websites } from '@src/config/website/config';

type SiteConfiguration = {
  stores: Stores[];
  channels: Channels[];
  websites: Websites[];
};

export interface IOfferDocumentV3 {
  productId: string;
  isActive: boolean;
  version?: number;
  isDefault: boolean;
  isManualDefault: boolean;
  userId: string;
  supplierCompanyId: string;
  supplierId: string;
  market: {
    currency: string;
    label: string;
    code: string;
    tiers: {
      tierCode: string;
      minQty: number;
      maxQty: number;
      price: number;
      defaultMoq?: number;
      retailPrice: number;
    }[];
  };
  delivery: {
    leadTimeUnit?: 'days';
    leadTimeValue?: number;
    hasCustomDeliveryDay?: boolean;
  };
  subSupplierCompanies?: ISubSupplierCompany[];
  siteConfiguration?: SiteConfiguration;
}

export interface Market {
  marketCurrency: string;
  marketLabel: string;
  marketCode: string;
  tiers: {
    tierCode: string;
    minQty: number;
    defaultMoq?: number;
    maxQty: number;
    price: number;
    retailPrice: number;
  }[];
}

export interface ISubSupplierCompany {
  subSupplierCompanyId?: string;
  vendorSku?: string;
  costPrice?: number;
  rebate?: number;
}

export interface IOfferModelV3 extends IOfferDocumentV3, Document {
  _id: string;
}

const offerSchema: mongoose.Schema<IOfferModelV3> = new Schema(
  {
    productId: {
      type: String,
      required: true,
    },
    market: {
      type: {
        code: {
          type: String,
          required: true,
        }, // country or region code
        label: {
          type: String,
          required: true,
        },
        currency: {
          type: String,
          required: true,
        },
        tiers: {
          type: [
            {
              tierCode: {
                type: String,
                required: true,
              },
              minQty: {
                type: Number,
                required: true,
              },
              maxQty: Number,
              price: {
                type: Number,
                required: true,
              },
              defaultMoq: {
                type: Number,
                default: 0,
              },
              retailPrice: Number,
            },
          ],
        },
      },
      required: true,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    isDefault: {
      type: Boolean,
      default: true,
    },
    isManualDefault: {
      type: Boolean,
      default: false,
    },
    delivery: {
      leadTimeUnit: {
        type: String,
        default: 'days',
      },
      leadTimeValue: {
        type: Number,
        //required: true,
      },
      hasCustomDeliveryDay: {
        type: Boolean,
        default: false,
      },
    },
    subSupplierCompanies: {
      type: [
        {
          subSupplierCompanyId: String,
          vendorSku: String,
          costPrice: Number,
          rebate: Number,
        },
      ],
      default: [],
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      // required: true,
    },
    supplierId: {
      type: mongoose.Schema.Types.ObjectId,
      // required: true,
    },
    supplierCompanyId: {
      type: mongoose.Schema.Types.ObjectId,
      // required: true,
    },
    siteConfiguration: {
      channels: {
        type: [String],
        default: [Channels.Web, Channels.Mobile],
      },
      websites: {
        type: [String],
        default: [Websites.Tradeling],
      },
      stores: {
        type: [String],
        default: [Stores.TradelingAe],
      },
    },
    version: {
      type: Number,
      default: 2,
    },
  },
  {
    versionKey: false,
    timestamps: true,
    collection: 'offerV3',
  },
);

offerSchema.index({ supplierId: -1 });
offerSchema.index({ supplierCompanyId: -1 });
offerSchema.index({ productId: -1 });

export const offerModelV3: Model<IOfferModelV3> = mongoose.model<IOfferModelV3>(
  'offerV3',
  offerSchema,
);
