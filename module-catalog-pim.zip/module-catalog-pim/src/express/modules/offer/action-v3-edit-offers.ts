import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { StatusCodes } from 'http-status-codes';
import { HttpError } from '@tradeling/web-js-utils/dist';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils';
import { mongo } from 'mongoose';
import { IProductModelV3, productModelV3 } from '../product/model-product-v3';
import { IOfferModelV3, offerModelV3 } from './model-offers-v3';
import { updateV3OfferValidators } from '@core/util/validatorsV3';
import {
  auditFields,
  logAuditEventForV3Products,
} from '@express/modules/product/send-product-audit-event';
import { getAuditForOffers } from '@express/modules/upload/helpers';
import { EE } from '@src/config/event/emitter';
import {
  ProductSyncEvent,
  ProductSyncEventType,
} from '@express/modules/product/sync-hlper';
import { logger } from '@core/util/logger';

interface IReq extends IAppRequest {
  body: Paths.V3EditOfferAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3EditOfferAction.Responses.$200) => this;
}

export const validateV3EditOffer: BaseValidationType = [
  ...updateV3OfferValidators,
  reqValidationResult,
];

export async function editV3OfferAction(req: IReq, res: IRes): Promise<IRes> {
  const { body } = req;
  const { _id: id, productId } = body;

  // check if product exists
  const isAvailable: IProductModelV3 = await productModelV3
    .findOne({ _id: new mongo.ObjectID(productId) as any })
    .lean();
  if (!isAvailable) {
    throw new HttpError(StatusCodes.NOT_FOUND, 'product variant not found');
  }

  const condition = {
    _id: id,
    deletedAt: null,
  };
  const defaultOffer = await offerModelV3.findOne(condition).lean();
  const fields: auditFields[] = getAuditForOffers(defaultOffer, body);
  await logAuditEventForV3Products(
    { _id: defaultOffer.productId },
    req,
    fields,
  );

  await offerModelV3.findOneAndUpdate(condition, {
    ...body,
  } as IOfferModelV3);

  // emit event for sync model
  EE.emit(ProductSyncEvent.Updated, {
    req,
    productIds: [defaultOffer.productId],
    priority: 'highest',
  } as ProductSyncEventType).catch((error: Error): void => {
    logger.error(`Event ${ProductSyncEvent.Updated} failed: ${error.stack}`);
  });

  return res.json({
    isUpdated: true,
  });
}
