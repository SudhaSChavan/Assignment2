import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { FilterQuery } from 'mongoose';
import { IOfferModelV3, offerModelV3 } from './model-offers-v3';

interface IReq extends IAppRequest {
  body: Paths.V3InternalListOfferAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3InternalListOfferAction.Responses.$200) => this;
}

export const validateV3InternalListOffers: BaseValidationType = [
  body('filter.ids').optional().isArray(),
  body('filter.ids.*').isMongoId(),
  body('filter.productIds').optional().isArray(),
  body('filter.productIds.*').isMongoId(),
  body('limit').optional().isInt({ max: 1000 }),
  body('page').optional().isInt({ gt: 0 }),
  reqValidationResult,
];

export async function internalV3ListOffersAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { limit = 1000, page = 1 } = req.body;
  const { ids = [], productIds = [] } = req.body?.filter ?? {};
  const query: FilterQuery<IOfferModelV3> = {
    deletedAt: null,
  };

  if (ids.length > 0) {
    query._id = {
      $in: ids,
    };
  }

  if (productIds.length > 0) {
    query.productId = {
      $in: productIds,
    };
  }

  const offers: Partial<IOfferModelV3[]> = await offerModelV3
    .find(query)
    .limit(limit)
    .skip((page - 1) * limit)
    .lean();

  res.json(offers);
}
