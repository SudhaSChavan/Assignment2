import { Router as IRouter } from 'express-serve-static-core';
import { Router } from 'express';
import { isAuthenticatedBackofficeMw } from '@src/config/middleware/is-authenticated-backoffice-mw';
import { catchAsyncErrors } from '@core/util/router';
import { authenticateInternalMw } from '@tradeling/web-js-utils';
import {
  internalV3ListOffersAction,
  validateV3InternalListOffers,
} from './action-v3-internal-list-offer';
import {
  editV3OfferAction,
  validateV3EditOffer,
} from './action-v3-edit-offers';

const router: IRouter = Router();

router.post(
  '/v3-internal-list-offer',
  authenticateInternalMw,
  validateV3InternalListOffers,
  catchAsyncErrors(internalV3ListOffersAction),
);
router.post(
  '/v3-edit-offer',
  isAuthenticatedBackofficeMw,
  validateV3EditOffer,
  catchAsyncErrors(editV3OfferAction),
);

export { router as offerRoutes };
