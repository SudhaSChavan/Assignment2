import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { Types } from 'mongoose';
import { keyBy, map } from 'lodash';
import { categoryModel } from '../../category/model-category';
import { productModelV3 } from '../../product/model-product-v3';

interface IReq extends IAppRequest {}

interface IRes extends IAppResponse {
  json: (body: Paths.V3GetSupplierStatsAction.Responses.$200) => this;
}

interface ICategoryCountArrayItem {
  _id: string;
  count: number;
}

interface ICategoryResItem {
  id: string;
  count: number;
  title: string;
}

interface ICategoryMetaItem {
  _id: Types.ObjectId;
  name: { en: string };
}

export const validateGetSupplierStatsV3: BaseValidationType = [
  reqValidationResult,
];

export async function getSupplierStatsActionV3(
  req: IReq,
  res: IRes,
): Promise<IRes> {
  const { supplierCompanyId } = req;

  const productCount: number = await productModelV3.countDocuments({
    supplierCompanyId,
  });
  const categoryCountArray: ICategoryCountArrayItem[] = await productModelV3.aggregate(
    [
      { $match: { supplierCompanyId, categoryId: { $ne: null } } },
      { $group: { _id: '$categoryId', count: { $sum: 1 } } }, //
    ],
  );
  const categoryMeta: ICategoryMetaItem[] = await categoryModel
    .find({ _id: { $in: map(categoryCountArray, '_id') } }, { 'name.en': 1 })
    .lean();
  const categoryMetaMap: Record<string, ICategoryMetaItem> = keyBy(
    categoryMeta,
    '_id',
  );

  const topProducts: any = await productModelV3
    .find({ supplierCompanyId }, {}, { sort: { createdAt: -1 }, limit: 10 })
    .lean();
  const categoryCounts: any[] = categoryCountArray.map(
    (obj: ICategoryCountArrayItem): ICategoryResItem => {
      const matchedCatObj: ICategoryMetaItem =
        categoryMetaMap[obj._id.toString()];

      return {
        title: matchedCatObj && matchedCatObj.name.en,
        id: obj._id.toString(),
        count: obj.count,
      };
    },
  );

  return res.json({
    productCount,
    categories: categoryCounts,
    products: topProducts,
  });
}
