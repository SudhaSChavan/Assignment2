import { Router } from 'express';
import { Router as IRouter } from 'express-serve-static-core';

import './listeners';
import { isAuthenticatedMw } from '@tradeling/web-js-utils';
import { catchAsyncErrors } from '@core/util/router';
import {
  getSupplierStatsActionV3,
  validateGetSupplierStatsV3,
} from './v3/action-get-supplier-stats';

const router: IRouter = Router();

router.post(
  '/v3-get-supplier-stats',
  isAuthenticatedMw(),
  validateGetSupplierStatsV3,
  catchAsyncErrors(getSupplierStatsActionV3),
);

export { router as supplierRoutes };
