import Excel, { CellValue, Row } from 'exceljs';
import { StatusCodes } from 'http-status-codes';
import striptags from 'striptags';

import { IMediaFile } from '../media/types';
import { UserIdentifier } from '@src/types/command';
import { HttpError } from '@tradeling/web-js-utils';
import {
  CategoryAttributeType,
  ICategoryAttributeModel,
} from '../category/model-category-attribute';
import { isEmpty, isEqual, pick, round, sortBy, uniq } from 'lodash';
import { countries, CountryType } from '@core/util/countries';
import { ICategoryModel } from '../category/model-category';
import {
  ConfigurationAttributeType,
  Project,
  Template,
} from '../product/types';
import { Types } from 'mongoose';
import { Channels, Stores, Websites } from '@src/config/website/config';
import { ICollectionModel } from '../collection/model-collection';
import Collator = Intl.Collator;
import { KeyValAny } from '@src/types/common';
import { auditFields } from '../product/send-product-audit-event';
import { IProductModelV3, productModelV3 } from '../product/model-product-v3';
import { ISubSupplierCompany } from '@express/modules/offer/model-offers-v3';

type StoreUploadType = {
  file: IMediaFile;
  uid: UserIdentifier;
  template: TemplateType;
  categoryIds?: Types.ObjectId[];
};

export type UnitType = {
  code: string;
  label: string;
};

export const maxRowCount: number = 500;

export enum Units {
  kg = 'KG',
  gr = 'GR',
  lb = 'LB',
  lt = 'LT',
  cl = 'CL',
  ml = 'ML',
  gal = 'Gal',
  floz = 'fl_oz',
  piece = 'Piece',
  carton = 'Carton',
  packet = 'Packet',
  pack = 'Pack',
  box = 'Box',
  roll = 'Roll',
}

export enum formattedUnits {
  kg = 'kg',
  gr = 'gr',
  lb = 'lb',
  lt = 'lt',
  cl = 'cl',
  ml = 'ml',
  gal = 'gal',
  floz = 'fl_oz',
  piece = 'piece',
  carton = 'carton',
  packet = 'packet',
  pack = 'pack',
  box = 'box',
  roll = 'roll',
}

export const packagingUnits: string[] = [
  Units.kg,
  Units.gr,
  Units.lb,
  Units.lt,
  Units.cl,
  Units.ml,
  Units.gal,
  Units.floz,
  Units.piece,
  Units.carton,
  Units.packet,
  Units.pack,
  Units.box,
  Units.roll,
];

type PackagingUnitType = {
  single: {
    en: string;
    ar: string;
  };
  plural: {
    en: string;
    ar: string;
  };
};

export const packUnitsOfMeasureMap: Record<string, PackagingUnitType> = {
  [formattedUnits.kg]: {
    single: { en: 'kg', ar: 'كيلوجرام' },
    plural: { en: 'kg', ar: 'كيلوجرام' },
  },
  [formattedUnits.gr]: {
    single: { en: 'g', ar: 'جرام' },
    plural: { en: 'g', ar: 'جرام' },
  },
  [formattedUnits.lb]: {
    single: { en: 'lb', ar: 'رطل' },
    plural: { en: 'lb', ar: 'رطل' },
  },
  [formattedUnits.lt]: {
    single: { en: 'ltr', ar: 'لتر' },
    plural: { en: 'ltr', ar: 'لتر' },
  },
  [formattedUnits.cl]: {
    single: { en: 'cl', ar: 'سنتيلتر' },
    plural: { en: 'cl', ar: 'سنتيلتر' },
  },
  [formattedUnits.ml]: {
    single: { en: 'ml', ar: 'مليلتر' },
    plural: { en: 'ml', ar: 'مليلتر' },
  },
  [formattedUnits.gal]: {
    single: { en: 'gal', ar: 'جاليون' },
    plural: { en: 'gal', ar: 'جاليون' },
  },
  [formattedUnits.floz]: {
    single: { en: 'oz', ar: 'أونصة سائلة' },
    plural: { en: 'oz', ar: 'أونصة سائلة' },
  },
  [formattedUnits.piece]: {
    single: { en: 'pc', ar: 'قطعة' },
    plural: { en: 'pcs', ar: 'قطع' },
  },
  [formattedUnits.packet]: {
    single: { en: 'pack', ar: 'رزمة' },
    plural: { en: 'packs', ar: 'رزمة' },
  },
  [formattedUnits.pack]: {
    single: { en: 'pack', ar: 'رزمة' },
    plural: { en: 'packs', ar: 'رزمة' },
  },
  [formattedUnits.carton]: {
    single: { en: 'carton', ar: 'كرتونة' },
    plural: { en: 'cartons', ar: 'كرتونات' },
  },
  [formattedUnits.box]: {
    single: { en: 'box', ar: 'صندوق' },
    plural: { en: 'boxes', ar: 'صَنَادِيقُ' },
  },
  [formattedUnits.roll]: {
    single: { en: 'roll', ar: 'رول' },
    plural: { en: 'roll', ar: 'رول' },
  },
};

const pricingUnits: string[] = [...packagingUnits];

export const weightUnits: UnitType[] = [
  { code: 'mg', label: 'Milligrams' },
  { code: 'g', label: 'Grams' },
  { code: 'kg', label: 'Kilograms' },
  { code: 'lbs', label: 'Pounds' },
];

export const sizeUnits: UnitType[] = [
  { code: 'cm', label: 'Centimeters' },
  { code: 'm', label: 'Meters' },
  { code: 'in', label: 'Inches' },
];

export const sizeUnitLabels: string[] = sizeUnits.map(
  (sizeUnit: UnitType) => sizeUnit.label,
);
export const weightUnitLabels: string[] = weightUnits.map(
  (weightUnit: UnitType) => weightUnit.label,
);

export function getRawData(worksheet: Excel.Worksheet): string[][] {
  const rows: any[] = worksheet.getSheetValues();
  const result: string[][] = [];

  // first row is undefined and second for headers, so skip them
  for (let i: number = 2; i < rows.length; i++) {
    const row: any[] = rows[i];

    if (row && row.length) {
      // each row looks like:
      // [undefined, cell1, cell2, cell3, ...]
      // so we need to remove first undefined and cast everything else to strings
      const allExceptFirst: Excel.CellValue[] = row.slice(1);

      result.push(
        allExceptFirst.map((value: CellValue): string => {
          if (String(value) !== '[object Object]') {
            return String(value);
          } else if ((value as Excel.CellRichTextValue)?.richText) {
            return String(
              (value as Excel.CellRichTextValue)?.richText
                .map((textItem: Excel.RichText) => textItem.text)
                .join(''),
            );
          } else if ((value as Excel.CellHyperlinkValue)?.text) {
            return String((value as Excel.CellHyperlinkValue)?.text);
          } else if ((value as Excel.CellFormulaValue).result) {
            return String((value as Excel.CellFormulaValue)?.result);
          } else if ((value as Excel.CellSharedFormulaValue).result) {
            return String((value as Excel.CellSharedFormulaValue)?.result);
          } else if ((value as Excel.CellErrorValue).error) {
            return String((value as Excel.CellErrorValue)?.error);
          }

          return String(value);
        }),
      );
    }
  }

  return result;
}

export async function getWorkbook(filePath: string): Promise<Excel.Workbook> {
  const workbook: Excel.Workbook = new Excel.Workbook();

  await workbook.xlsx.readFile(filePath).catch((): void => {
    throw new HttpError(StatusCodes.BAD_REQUEST, 'invalid xlsx file'); // map parsing error to 400 Bad Request
  });

  const worksheet: Excel.Worksheet = workbook.getWorksheet(1);

  if (!worksheet) {
    throw new HttpError(StatusCodes.BAD_REQUEST, 'no worksheets found');
  }

  if (worksheet.rowCount <= 1) {
    throw new HttpError(StatusCodes.BAD_REQUEST, 'no data found');
  }

  const metaSheet: Excel.Worksheet = workbook.getWorksheet(4);

  if (!metaSheet) {
    throw new HttpError(StatusCodes.BAD_REQUEST, 'no metadata sheet found');
  }

  return workbook;
}

export const simplePriceProductTemplate: string = 'simple-price-product';
export const configurablePriceProductTemplate: string =
  'configurable-price-product';
export const simpleProductTemplate: string = 'simple-product';
export const configurableProductTemplate: string = 'configurable-product';
// @fixme make it `simple-price` and `configurable-price`
export const simplePriceListTemplate: string = 'simple-price-list';
export const v3ProductTemplate: string = 'product-template';
export const productPartialUpdateTemplate: string = 'partial-product-update';
export const offerTemplate: string = Template.OfferTemplate;
export const configurablePriceListTemplate: string = 'configurable-price-list';
export const edukaanProductTemplate: string = 'edukaan-product';
export const productTemplate: string = Template.ProductTemplate;

export function isEdukaanTemplate(template: TemplateType): boolean {
  return [edukaanProductTemplate].includes(template);
}

export const TransportationModeLabelMapping: Record<
  Components.Schemas.V1TransportationMode,
  string
> = {
  regular: 'Regular',
  food_ambient: 'Food Ambient',
  food_chilled: 'Food Chilled',
  food_frozen: 'Food Frozen',
  na: 'N/A',
};

export const TransportationModeLabels: string[] = Object.values(
  TransportationModeLabelMapping,
);
export const TransportationModeValues: Components.Schemas.V1TransportationMode[] = Object.keys(
  TransportationModeLabelMapping,
) as Components.Schemas.V1TransportationMode[];

export type TemplateType =
  | typeof simpleProductTemplate
  | typeof configurableProductTemplate
  | typeof edukaanProductTemplate
  | typeof simplePriceListTemplate
  | typeof configurablePriceListTemplate;
type FieldSanitizer = (value: any) => any;
type FieldValidator = (value: any) => boolean;
type FieldDependValidator = (
  value: any,
  raw: any,
  offer?: any,
) => Promise<boolean> | boolean;
type FieldValueGenerator = (value: any) => any;
export type FieldType = {
  field: string;
  label: string;
  required: boolean;
  enum?: any[];
  width?: number;
  example?: any;
  valueHelp?: string;
  instruction?: string;
  sanitizers: FieldSanitizer[];
  sheetSanitizers?: FieldSanitizer[];
  dependSanitizers?: FieldSanitizer[];
  dependSheetSanitizers?: FieldSanitizer[];
  validators: FieldValidator[];
  dependValidators?: FieldDependValidator[];
  invalidValueMessage?: string;
  shouldRemove?: boolean;
  shouldRemoveFromSheet?: boolean;
  dataFormatter?: (value: any) => any;
  defaultValue?: any;
  template?: TemplateType[];
  exclude?: TemplateType[];
  shouldExclude?: boolean;
  categoriesSlugs?: string[];
  categoryIds?: string[];
  cellValidation?: {
    type: 'list' | 'textLength' | 'date' | 'whole' | 'decimal' | 'custom';
    allowBlank: boolean;
    formulae: string[];
    valuesList: string[];
  };
  mustGenerate?: boolean;
  generateValue?: FieldValueGenerator[];
};

// no one understand please leave it alone, but its working, generate all possible values of multiple arrays
// reference https://stackoverflow.com/questions/15298912/javascript-generating-combinations-from-n-arrays-with-m-elements
export function* cartesian(head?: any[], ...tail: any[]): any {
  const remainder: any = tail.length ? cartesian(...tail) : [[]];
  for (const r of remainder) {
    for (const h of head) {
      yield [h, ...r];
    }
  }
}

type MarketType = {
  value: string;
  label: string;
  currency: string;
};

type GenerateMarketPricingForMarketPropsType = {
  market: MarketType;
  configurationAttributes: ConfigurationAttributeType[];
  tierCount: number;
  price: number;
  retailPrice: number;
  minQty: number;
};

export const availableMarkets: MarketType[] = [
  {
    value: 'AE',
    label: 'UAE Market (GULF)',
    currency: 'AED',
  },
  {
    value: 'INTL',
    label: 'All Markets',
    currency: 'USD',
  },
];

function getCategoryIdFromSlug(categories: ICategoryModel[]) {
  const categoryMap: Record<string, string> = categories.reduce(
    (agg, cat) => Object.assign(agg, { [cat.slug]: cat._id }),
    {},
  );
  return (categorySlug: string): string | undefined =>
    categoryMap[categorySlug];
}

export function getCategorySelectionField(
  categories: ICategoryModel[],
): FieldType {
  return {
    field: 'categoryId',
    label: 'Category',
    instruction: 'Refer from the Tradeling uploaded products',
    example: 'baby-cereal',
    valueHelp: 'Categorized the product based on provided product information',
    required: true,
    width: 10,
    sanitizers: [trim, getCategoryIdFromSlug(categories)],
    validators: [isEnum(categories.map((cat) => cat._id))],
    invalidValueMessage: 'select valid category',
    cellValidation: {
      type: 'list',
      allowBlank: false,
      formulae: [`"${categories.map((category) => category.slug).join(',')}"`],
      valuesList: categories.map((category) => category.slug),
    },
  };
}

function getCollectionIdFromSlug(collections: ICollectionModel[]) {
  const collectionsMap: Record<string, string> = (collections || []).reduce(
    (agg, collection) =>
      Object.assign(agg, { [collection.slug]: collection._id }),
    {},
  );
  return (collectionSlugs: string[]): string[] =>
    collectionSlugs.map((collectionSlug) => collectionsMap[collectionSlug]);
}

function isAllArray(collections: ICollectionModel[]) {
  const collectionsMap: Record<string, string> = (collections || []).reduce(
    (agg, collection) =>
      Object.assign(agg, { [collection.slug]: collection._id }),
    {},
  );
  return (collectionSlugs: string[]): string[] =>
    collectionSlugs.map((collectionSlug) => collectionsMap[collectionSlug]);
}

export function getCollectionSelectionFields(
  collections: ICollectionModel[],
  template: TemplateType,
): FieldType[] {
  const fields: FieldType[] = [
    {
      field: 'collectionIds',
      label: 'Collections',
      instruction: 'Comma separated with allowed slugs',
      example: 'baby-cereal',
      valueHelp: 'Comma separated with allowed slugs',
      required: true,
      width: 10,
      sanitizers: [commaSeparated, getCollectionIdFromSlug(collections)],
      validators: [
        isArrayEnum(collections?.map((collection) => collection._id)),
      ],
      invalidValueMessage: 'select valid Collection',
      template: [edukaanProductTemplate],
      cellValidation: {
        type: 'list',
        allowBlank: false,
        formulae: [],
        valuesList: collections?.map((collection) => collection.slug),
      },
    },
  ];
  return fields.filter((item: FieldType): boolean => {
    return (
      (!item.template || item.template.includes(template)) &&
      !item.exclude?.includes(template)
    );
  });
}

export function getProductUploadFields(
  template: TemplateType = simpleProductTemplate,
  isInternationalSeller: boolean,
): FieldType[] {
  const fields: FieldType[] = [
    {
      field: 'sku',
      label: template == Template.ProductTemplate ? 'Master SKU' : 'SKU ID',
      instruction: 'Unique value across all your company products',
      example: '12345',
      valueHelp: 'An alphanumeric string',
      required: !isEdukaanTemplate(template),
      width: 10,
      sanitizers: [trim, upperCase],
      validators: [minLength(1), maxLength(60)],
      invalidValueMessage: 'SKU must be between 1 and 60 characters',
      mustGenerate: isEdukaanTemplate(template),
      generateValue: isEdukaanTemplate(template) ? [uniqueGeneratedSku] : [],
    },
    {
      field: 'variantSku',
      label: 'Variant Sku',
      instruction: 'Unique value across all your variants',
      example: '12345',
      valueHelp: 'An alphanumeric string',
      required: true,
      width: 10,
      template: [productTemplate],
      sanitizers: [trim, upperCase],
      validators: [minLength(1), maxLength(60)],
      invalidValueMessage: 'SKU must be between 1 and 60 characters',
    },
    {
      field: 'barcode',
      label: 'Variant Barcode',
      instruction: 'additional value across your variant',
      example: 'bar-code-12345',
      valueHelp: 'An alphanumeric string',
      required: false,
      width: 10,
      sanitizers: [trim, upperCase],
      validators: [minLength(1), maxLength(60)],
      invalidValueMessage:
        'variant barcode must be between 1 and 60 characters',
    },
    {
      field: 'name.en',
      label: 'Product name (en)',
      required: true,
      width: 20,
      sanitizers: [trim, stripHtml],
      validators: [minLength(15), maxLength(200)],
      invalidValueMessage: 'Name must be between 15 and 200 characters',
      example: 'Paper, Multipurpose Ultra White',
      instruction: 'Create as per Tradeling guidelines',
      valueHelp: 'It must be an alphanumeric string, Max. 200 characters',
    },
    {
      field: 'name.ar',
      label: 'Product name (ar)',
      required: false,
      width: 20,
      sanitizers: [trim, stripHtml],
      validators: [minLength(15), maxLength(200)],
      invalidValueMessage: 'Name must be between 15 and 200 characters',
      example: 'Paper, Multipurpose Ultra White',
      instruction: 'Create as per Tradeling guidelines',
      valueHelp: 'It must be an alphanumeric string, Max. 200 characters',
      exclude: [edukaanProductTemplate],
    },
    {
      field: 'keyFeature1.en',
      label: 'Key product feature 1 "short description" (en)',
      example:
        'Everyday office paper, superior , and dependability for printing at home',
      instruction: "Used to highlight the product's most important qualities",
      valueHelp: 'It must be an alphanumeric string, Max. 250 characters',
      required: !isEdukaanTemplate(template),
      width: 30,
      sanitizers: [trim, stripHtml],
      validators: [minLength(3), maxLength(250)],
      invalidValueMessage: 'Description must be between 3 and 250 characters',
    },
    {
      field: 'keyFeature1.ar',
      label: 'Key product feature 1 "short description" (ar)',
      example:
        'Everyday office paper, superior , and dependability for printing at home',
      instruction: "Used to highlight the product's most important qualities",
      valueHelp: 'It must be an alphanumeric string, Max. 250 characters',
      required: false,
      width: 30,
      sanitizers: [trim, stripHtml],
      validators: [minLength(3), maxLength(250)],
      invalidValueMessage: 'Description must be between 3 and 250 characters',
      exclude: [edukaanProductTemplate],
    },
    {
      field: 'keyFeature2.en',
      label: 'Key product feature 2 (en)',
      example:
        'Everyday office paper, superior , and dependability for printing at home',
      instruction: "Used to highlight the product's most important qualities",
      valueHelp: 'It must be an alphanumeric string, Max. 250 characters',
      required: !isEdukaanTemplate(template),
      width: 30,
      sanitizers: [trim, stripHtml],
      validators: [minLength(3), maxLength(250)],
      invalidValueMessage: 'Description must be between 3 and 250 characters',
    },
    {
      field: 'keyFeature2.ar',
      label: 'Key product feature 2 (ar)',
      example:
        'Everyday office paper, superior , and dependability for printing at home',
      instruction: "Used to highlight the product's most important qualities",
      valueHelp: 'It must be an alphanumeric string, Max. 250 characters',
      required: false,
      width: 30,
      sanitizers: [trim, stripHtml],
      validators: [minLength(3), maxLength(250)],
      invalidValueMessage: 'Description must be between 3 and 250 characters',
      exclude: [edukaanProductTemplate],
    },
    {
      field: 'keyFeature3.en',
      label: 'Key product feature 3 (en)',
      example:
        'Everyday office paper, superior , and dependability for printing at home',
      instruction: "Used to highlight the product's most important qualities",
      valueHelp: 'It must be an alphanumeric string, Max. 250 characters',
      required: false,
      width: 30,
      sanitizers: [trim, stripHtml],
      validators: [minLength(3), maxLength(250)],
      invalidValueMessage: 'Description must be between 3 and 250 characters',
    },
    {
      field: 'keyFeature3.ar',
      label: 'Key product feature 3 (ar)',
      example:
        'Everyday office paper, superior , and dependability for printing at home',
      instruction: "Used to highlight the product's most important qualities",
      valueHelp: 'It must be an alphanumeric string, Max. 250 characters',
      required: false,
      width: 30,
      sanitizers: [trim, stripHtml],
      validators: [minLength(3), maxLength(250)],
      invalidValueMessage: 'Description must be between 3 and 250 characters',
      exclude: [edukaanProductTemplate],
    },
    {
      field: 'keyFeature4.en',
      label: 'Key product feature 4 (en)',
      example:
        'Everyday office paper, superior , and dependability for printing at home',
      instruction: "Used to highlight the product's most important qualities",
      valueHelp: 'It must be an alphanumeric string, Max. 250 characters',
      required: false,
      width: 30,
      sanitizers: [trim, stripHtml],
      validators: [minLength(3), maxLength(250)],
      invalidValueMessage: 'Description must be between 3 and 250 characters',
    },
    {
      field: 'keyFeature4.ar',
      label: 'Key product feature 4 (ar)',
      example:
        'Everyday office paper, superior , and dependability for printing at home',
      instruction: "Used to highlight the product's most important qualities",
      valueHelp: 'It must be an alphanumeric string, Max. 250 characters',
      required: false,
      width: 30,
      sanitizers: [trim, stripHtml],
      validators: [minLength(3), maxLength(250)],
      invalidValueMessage: 'Description must be between 3 and 250 characters',
      exclude: [edukaanProductTemplate],
    },
    {
      field: 'keyFeature5.en',
      label: 'Key product feature 5 (en)',
      example:
        'Everyday office paper, superior , and dependability for printing at home',
      instruction: "Used to highlight the product's most important qualities",
      valueHelp: 'It must be an alphanumeric string, Max. 250 characters',
      required: false,
      width: 30,
      sanitizers: [trim, stripHtml],
      validators: [minLength(3), maxLength(250)],
      invalidValueMessage: 'Description must be between 3 and 250 characters',
    },
    {
      field: 'keyFeature5.ar',
      label: 'Key product feature 5 (ar)',
      example:
        'Everyday office paper, superior , and dependability for printing at home',
      instruction: "Used to highlight the product's most important qualities",
      valueHelp: 'It must be an alphanumeric string, Max. 250 characters',
      required: false,
      width: 30,
      sanitizers: [trim, stripHtml],
      validators: [minLength(3), maxLength(250)],
      invalidValueMessage: 'Description must be between 3 and 250 characters',
      exclude: [edukaanProductTemplate],
    },
    {
      field: 'keyFeature6.en',
      label: 'Key product feature 6 (en)',
      example:
        'Everyday office paper, superior , and dependability for printing at home',
      instruction: "Used to highlight the product's most important qualities",
      valueHelp: 'It must be an alphanumeric string, Max. 250 characters',
      required: false,
      width: 30,
      sanitizers: [trim, stripHtml],
      validators: [minLength(3), maxLength(250)],
      invalidValueMessage: 'Description must be between 3 and 250 characters',
    },
    {
      field: 'keyFeature6.ar',
      label: 'Key product feature 6 (ar)',
      example:
        'Everyday office paper, superior , and dependability for printing at home',
      instruction: "Used to highlight the product's most important qualities",
      valueHelp: 'It must be an alphanumeric string, Max. 250 characters',
      required: false,
      width: 30,
      sanitizers: [trim, stripHtml],
      validators: [minLength(3), maxLength(250)],
      invalidValueMessage: 'Description must be between 3 and 250 characters',
      exclude: [edukaanProductTemplate],
    },
    {
      field: 'packaging.size',
      label: 'Product pack size',
      example: '400',
      instruction:
        'Use it to provide the product pack size "for single unit", this can be weight or number of units',
      valueHelp: 'Positive integer',
      required: true,
      width: 30,
      sanitizers: [trim],
      validators: [isNumber, greaterThanOrEqual(1)],
      invalidValueMessage: 'Size must be a positive number and greater than 0',
    },
    {
      field: 'packaging.unit',
      label: 'Pack unit of measure',
      example: 'GR',
      instruction:
        'Select the unit of measure associated with the product pack',
      valueHelp: `Select
                  from valid values "${packagingUnits.join(',')}"`,
      required: true,
      width: 30,
      sanitizers: [trim, lowerCase],
      validators: [
        isEnum(
          packagingUnits.map((unit: string): string => unit.toLowerCase()),
        ),
      ],
      invalidValueMessage: `Unit can only be one of "${packagingUnits.join(
        ', ',
      )}"`,
      cellValidation: {
        type: 'list',
        allowBlank: true,
        formulae: [`"${packagingUnits.join(',')}"`],
        valuesList: packagingUnits,
      },
    },
    {
      field: 'packaging.unitsPerCarton',
      label: 'Number of packs/Units per carton',
      example: '12',
      instruction: 'Use to provide the number of item per carton',
      valueHelp: 'Numeric value',
      required: true,
      width: 30,
      sanitizers: [trim],
      validators: [isInteger, greaterThanOrEqual(1)],
      invalidValueMessage:
        'Units per carton must be a positive integer and greater than 0',
    },
    {
      field: 'offer.marketCurrency',
      label: 'Market Currency',
      instruction: 'Select the 3 letter currency code i.e. "AED" or "USD"',
      valueHelp: 'Select from valid values "AED, USD"',
      example: 'AED',
      required: true,
      width: 15,
      sanitizers: [trim, upperCase],
      validators: [minLength(2), isEnum(['AED', 'USD'])],
      invalidValueMessage: 'Market currency can only be on of "AED, USD"',
      template: [
        simplePriceProductTemplate,
        configurablePriceProductTemplate,
        edukaanProductTemplate,
      ],
      cellValidation: {
        type: 'list',
        allowBlank: true,
        formulae: ['"AED,USD"'],
        valuesList: ['AED', 'USD'],
      },
    },
    {
      field: 'offer.tiers.0.price',
      label: 'Price',
      instruction:
        'It must be the measuring unit for a given market, in a given currency, it will be rounded to 2 decimals',
      valueHelp: 'Numeric value',
      required: true,
      width: 12,
      sanitizers: [trim, toDecimal(2)],
      validators: [isNumber, greaterThan(0)],
      invalidValueMessage: 'Price should be greater than 0',
      example: '54',
      template: [
        simplePriceProductTemplate,
        configurablePriceProductTemplate,
        edukaanProductTemplate,
      ],
    },
    {
      field: 'offer.tiers.0.retailPrice',
      label: 'Retail Price',
      instruction:
        'It must be the measuring unit for a given market, in a given currency, it will be rounded to 2 decimals',
      valueHelp: 'Numeric value',
      required: false,
      width: 12,
      sanitizers: [trim, toDecimal(2)],
      validators: [isNumber, greaterThan(0)],
      invalidValueMessage: 'Retail price should be greater than 0',
      example: '55',
      template: [
        simplePriceProductTemplate,
        configurablePriceProductTemplate,
        edukaanProductTemplate,
      ],
    },
    {
      field: 'unit',
      label: 'Price unit of measure',
      instruction:
        'Select the unit of measure associated with the product pack',
      valueHelp: `Select
                  from valid values "${packagingUnits.join(',')}"`,
      required: true,
      width: 15,
      sanitizers: [trim, lowerCase],
      validators: [
        isEnum(
          packagingUnits.map((unit: string): string => unit.toLowerCase()),
        ),
      ],
      invalidValueMessage: `Unit must be one of "${packagingUnits.join(', ')}"`,
      example: 'KG',
      defaultValue: 'piece',
      cellValidation: {
        type: 'list',
        allowBlank: true,
        formulae: [`"${packagingUnits.join(',')}"`],
        valuesList: packagingUnits,
      },
    },
    {
      field: 'offer.subSupplierCompanyIds',
      label: `Vendor ID`,
      instruction:
        'IDs of sub-supplier which product was purchased by BLINK Technolgy',
      valueHelp: 'Semi colon Separated',
      example: '5fbfd632582550d0aac48e68;5fbfd632582550d0aac48e69',
      required: false,
      width: 35,
      sanitizers: [semiColonSeparated],
      validators: [],
      invalidValueMessage: '',
      template: [edukaanProductTemplate],
    },
    {
      field: 'offer.vendorSku',
      label: `Vendor SKU`,
      instruction: `SKU's of sub-suppliers`,
      valueHelp: 'Semi colon Separated',
      example: 'AX123;AB123',
      required: false,
      width: 35,
      sanitizers: [semiColonSeparated],
      validators: [],
      invalidValueMessage: '',
      template: [edukaanProductTemplate],
    },
    {
      field: 'offer.costPrices',
      label: 'Cost Price',
      instruction: 'Prices purchase bought by sub-supplier ',
      valueHelp: 'Semi colon Separated',
      example: '450;300.5',
      required: false,
      width: 35,
      sanitizers: [semiColonSeparated, parseIntArray],
      validators: [],
      invalidValueMessage: 'Cost price must be a positive number',
      template: [edukaanProductTemplate],
    },
    {
      field: 'transportationMode',
      label: 'Transportation mode',
      instruction: 'Select a transportation mode',
      valueHelp: `Select
                  from valid values "${TransportationModeLabels.join(',')}"`,
      required: !isEdukaanTemplate(template),
      width: 15,
      sanitizers: [trim, lowerCase, transportationLabelToValue],
      validators: [isEnum(TransportationModeValues)],
      invalidValueMessage: `Transportation must be one of "${TransportationModeLabels.join(
        ', ',
      )}"`,
      example: 'regular',
      defaultValue: 'regular',
      cellValidation: {
        type: 'list',
        allowBlank: false,
        formulae: [`"${TransportationModeLabels.join(',')}"`],
        valuesList: TransportationModeLabels,
      },
    },
    {
      field: 'offer.delivery.leadTimeValue',
      label:
        'Lead time is the amount of days it takes to prepare an item between when an order is placed and when it is ready to be shipped.',
      instruction:
        'Use it to provide the Avg. number of day for order delivery',
      valueHelp: 'Numeric value',
      required: true,
      width: 15,
      sanitizers: [trim, toNumber],
      validators: [isNumber, greaterThan(0)],
      invalidValueMessage: 'Lead time value must be a positive number',
      template: [
        simplePriceProductTemplate,
        configurablePriceProductTemplate,
        simpleProductTemplate,
        edukaanProductTemplate,
      ],
      example: '54',
    },
    {
      field: 'offer.tiers.0.minQty',
      label: 'Minimum order quantity ',
      instruction: 'Use it to provide the lowest set amount of stock to sell',
      valueHelp: 'Numeric value (Enter "1" if no MOQ)',
      required: true,
      width: 12,
      sanitizers: [trim, toNumber],
      validators: [isInteger, greaterThan(0), shouldNotDecimal],
      dependValidators: isEdukaanTemplate(template)
        ? [validateMinOrderAndStockQty]
        : [],
      invalidValueMessage:
        "Min quantity must be a positive integer, shouldn't be decimal and must be greater than available stock quantity",
      example: '32',
      template: [
        simplePriceProductTemplate,
        configurablePriceProductTemplate,
        edukaanProductTemplate,
      ],
    },
    {
      field: 'keywords.en',
      label: 'Keywords (en)',
      instruction:
        'Use keywords which describe your product, use Comma to separate your keywords. At least one keyword is required',
      valueHelp: 'An alphanumeric string',
      required: true,
      width: 20,
      sanitizers: [sanitizeKeywords],
      validators: [minLength(1), each(minLength(2))],
      invalidValueMessage:
        'Keywords must be 1 at least and 2 or more characters',
      example: 'Green apple,Granny smith,Apple',
    },
    {
      field: 'keywords.ar',
      label: 'Keywords (ar)',
      instruction:
        'Use keywords which describe your product, use Comma to separate your keywords. At least one keyword is required',
      valueHelp: 'An alphanumeric string',
      required: false,
      width: 20,
      sanitizers: [sanitizeKeywords],
      validators: [minLength(1), each(minLength(2))],
      invalidValueMessage:
        'Keywords must be 1 at least and 2 or more characters',
      example: 'Green apple,Granny smith,Apple',
      exclude: [edukaanProductTemplate],
    },
    {
      field: 'isReadyToShip',
      label: 'Is Ready to Ship?',
      instruction:
        'Is the product ready to ship or needs manufacturing or production.',
      valueHelp: 'Can only be one of yes, no',
      required: true,
      width: 20,
      sanitizers: [trim, lowerCase, toBoolean],
      validators: [isBoolean],
      invalidValueMessage: 'Ready to ship must be either yes or no',
      example: 'yes',
      cellValidation: {
        type: 'list',
        allowBlank: true,
        formulae: ['"Yes,No"'],
        valuesList: ['Yes', 'No'],
      },
    },
    {
      field: 'isBuyNow',
      label: 'Is Ready to Buy?',
      instruction: 'Can this product be bought using checkout?',
      valueHelp: 'Can only be one of yes, no',
      required: true,
      width: 20,
      sanitizers: [trim, lowerCase, toBoolean],
      validators: [isBoolean],
      invalidValueMessage: 'Ready to buy must be either yes or no',
      example: 'yes',
      cellValidation: {
        type: 'list',
        allowBlank: true,
        formulae: ['"Yes,No"'],
        valuesList: ['Yes', 'No'],
      },
    },
    {
      field: 'isInStock',
      label: 'Is In Stock?',
      instruction: 'Is this product is in stock or out of stock?',
      valueHelp: 'Can only be one of yes, no',
      required: true,
      width: 20,
      sanitizers: [trim, lowerCase, toBoolean],
      validators: [isBoolean],
      invalidValueMessage: 'Is in stock must be either yes or no',
      example: 'yes',
      cellValidation: {
        type: 'list',
        allowBlank: false,
        formulae: ['"Yes,No"'],
        valuesList: ['Yes', 'No'],
      },
    },
    {
      field: 'dimensions.length',
      label: 'Carton Length',
      example: '20',
      instruction: 'Use it to provide the carton length',
      valueHelp: 'Positive number',
      required: true,
      width: 30,
      sanitizers: [trim, toNumber],
      validators: [isNumber, greaterThan(0)],
      invalidValueMessage: 'Carton length must be a positive number',
    },
    {
      field: 'dimensions.lengthUnit',
      label: 'Carton Length Unit',
      instruction: 'What is the unit of the given length?',
      valueHelp: 'Can only be one of the units listed',
      required: true,
      width: 20,
      sanitizers: [sizeUnitLabelToValue],
      validators: [isSizeUnit],
      invalidValueMessage: 'Can only be one of the units listed',
      example: sizeUnitLabels[0],
      cellValidation: {
        type: 'list',
        allowBlank: true,
        formulae: [`"${sizeUnitLabels.join(',')}"`],
        valuesList: sizeUnitLabels,
      },
    },
    {
      field: 'dimensions.width',
      label: 'Carton Width',
      example: '20',
      instruction: 'Use it to provide the carton width',
      valueHelp: 'Positive number',
      required: true,
      width: 30,
      sanitizers: [trim, toNumber],
      validators: [isNumber, greaterThan(0)],
      invalidValueMessage: 'Carton width must be a positive number',
    },
    {
      field: 'dimensions.widthUnit',
      label: 'Carton Width Unit',
      instruction: 'What is the unit of given width?',
      valueHelp: 'Can only be one of the units listed',
      required: true,
      width: 20,
      sanitizers: [sizeUnitLabelToValue],
      validators: [isSizeUnit],
      invalidValueMessage: 'Can only be one of the units listed',
      example: sizeUnitLabels[0],
      cellValidation: {
        type: 'list',
        allowBlank: true,
        formulae: [`"${sizeUnitLabels.join(',')}"`],
        valuesList: sizeUnitLabels,
      },
    },
    {
      field: 'dimensions.height',
      label: 'Carton Height',
      example: '20',
      instruction: 'Use it to provide the carton height',
      valueHelp: 'Positive number',
      required: true,
      width: 30,
      sanitizers: [trim, toNumber],
      validators: [isNumber, greaterThan(0)],
      invalidValueMessage: 'Carton height must be a positive number',
    },
    {
      field: 'dimensions.heightUnit',
      label: 'Carton Height Unit',
      instruction: 'What is the unit of given height?',
      valueHelp: 'Can only be one of the units listed',
      required: true,
      width: 20,
      sanitizers: [sizeUnitLabelToValue],
      validators: [isSizeUnit],
      invalidValueMessage: 'Can only be one of the units listed',
      example: sizeUnitLabels[0],
      cellValidation: {
        type: 'list',
        allowBlank: true,
        formulae: [`"${sizeUnitLabels.join(',')}"`],
        valuesList: sizeUnitLabels,
      },
    },
    {
      field: 'dimensions.weight',
      label: 'Carton Weight',
      example: '20',
      instruction: 'Use it to provide the carton weight',
      valueHelp: 'Positive number',
      required: true,
      width: 30,
      sanitizers: [trim, toNumber],
      validators: [isNumber, greaterThan(0)],
      invalidValueMessage: 'Carton weight must be a positive number',
    },
    {
      field: 'dimensions.weightUnit',
      label: 'Carton Weight Unit',
      instruction: 'What is the unit of given weight?',
      valueHelp: 'Can only be one of the units listed',
      required: true,
      width: 20,
      sanitizers: [weightUnitLabelToValue],
      validators: [isWeightUnit],
      invalidValueMessage: 'Can only be one of the units listed',
      example: weightUnitLabels[0],
      cellValidation: {
        type: 'list',
        allowBlank: true,
        formulae: [`"${weightUnitLabels.join(',')}"`],
        valuesList: weightUnitLabels,
      },
    },
    {
      field: 'longDescription.en',
      label: 'Long Description (en)',
      instruction:
        'Use to provide full description related to the product with as many details as possible',
      valueHelp: 'An alphanumeric string',
      required: false,
      width: 30,
      sanitizers: [trim],
      validators: [],
      example:
        'HP Papers is sourced from renewable forest resources and has achieved production with 0% deforestation in North America. See images. OPTIMIZED FOR HP TECHNOLOGY - All HP Papers provide premium performance on HP equipment, as well as on all other printer and copier equipment.',
    },
    {
      field: 'longDescription.ar',
      label: 'Long Description (ar)',
      instruction:
        'Use to provide full description related to the product with as many details as possible',
      valueHelp: 'An alphanumeric string',
      required: false,
      width: 30,
      sanitizers: [trim],
      validators: [],
      exclude: [edukaanProductTemplate],
      example:
        'HP Papers is sourced from renewable forest resources and has achieved production with 0% deforestation in North America. See images. OPTIMIZED FOR HP TECHNOLOGY - All HP Papers provide premium performance on HP equipment, as well as on all other printer and copier equipment.',
    },
    {
      field: 'variantValue[0].code',
      label: 'Variant Attribute 1',
      instruction:
        'Use to provide the type of variant with values e.g. Color:red,blue,green or Size:large,small,medium,x-large',
      valueHelp: 'An alphanumeric string',
      required: false,
      width: 20,
      sanitizers: [trim],
      validators: [],
      example: 'color',
      template: [Template.ProductTemplate],
    },
    {
      field: 'variantValue[0].value',
      label: 'Variant value 1',
      instruction:
        'Use to provide the type of variant with value e.g. Blue, Blue-L, Red-S',
      valueHelp: 'An alphanumeric string',
      required: false,
      width: 20,
      sanitizers: [trim],
      validators: [validateVariantValue],
      example: 'Red',
      template: [Template.ProductTemplate],
    },
    {
      field: 'variantValue[1].code',
      label: 'Variant Attribute 2',
      instruction:
        'Use to provide the type of variant with values e.g. Color:red,blue,green or Size:large,small,medium,x-large',
      valueHelp: 'An alphanumeric string',
      required: false,
      width: 20,
      sanitizers: [trim],
      validators: [],
      example: 'capacity',
      template: [Template.ProductTemplate],
    },
    {
      field: 'variantValue[1].value',
      label: 'Variant value 2',
      instruction:
        'Use to provide the type of variant with value e.g. Blue, Blue-L, Red-S',
      valueHelp: 'An alphanumeric string',
      required: false,
      width: 20,
      sanitizers: [trim],
      validators: [validateVariantValue],
      example: 'Red',
      template: [Template.ProductTemplate],
    },
    {
      field: 'variantValue[2].code',
      label: 'Variant Attribute 3',
      instruction:
        'Use to provide the type of variant with values e.g. Color:red,blue,green or Size:large,small,medium,x-large',
      valueHelp: 'An alphanumeric string',
      required: false,
      width: 20,
      sanitizers: [trim],
      validators: [],
      example: 'size',
      template: [Template.ProductTemplate],
    },
    {
      field: 'variantValue[2].value',
      label: 'Variant value 3',
      instruction:
        'Use to provide the type of variant with value e.g. Blue, Blue-L, Red-S',
      valueHelp: 'An alphanumeric string',
      required: false,
      width: 20,
      sanitizers: [trim],
      validators: [validateVariantValue],
      example: 'Red',
      template: [Template.ProductTemplate],
    },
    {
      field: 'variantValue[3].code',
      label: 'Variant Attribute 4',
      instruction:
        'Use to provide the type of variant with values e.g. Color:red,blue,green or Size:large,small,medium,x-large',
      valueHelp: 'An alphanumeric string',
      required: false,
      width: 20,
      sanitizers: [trim],
      validators: [],
      example: 'material',
      template: [Template.ProductTemplate],
    },
    {
      field: 'variantValue[3].value',
      label: 'Variant value 4',
      instruction:
        'Use to provide the type of variant with value e.g. Blue, Blue-L, Red-S',
      valueHelp: 'An alphanumeric string',
      required: false,
      width: 20,
      sanitizers: [trim],
      validators: [validateVariantValue],
      example: 'Red',
      template: [Template.ProductTemplate],
    },
    {
      field: 'offerPrivateLabelOption',
      label: 'Offer private label option',
      instruction:
        'Offering your product as Private Label allows buyers to be able to sell this product under their brand',
      valueHelp: 'Can only be one of yes, no',
      required: false,
      exclude: [edukaanProductTemplate],
      width: 20,
      sanitizers: [trim, lowerCase, toBoolean],
      validators: [isBoolean],
      invalidValueMessage:
        'Offer praivate label option must be either yes or no',
      example: 'yes',
      cellValidation: {
        type: 'list',
        allowBlank: true,
        formulae: ['"Yes,No"'],
        valuesList: ['Yes', 'No'],
      },
    },
  ];

  return fields.filter((item: FieldType): boolean => {
    return (
      (!item.template || item.template.includes(template)) &&
      !item.exclude?.includes(template)
    );
  });
}

export function getCommonOfferFields(): FieldType[] {
  return [
    {
      field: 'marketCode',
      label: 'Market Code',
      instruction:
        'Select the Market code, it could be either AE (for Gulf) or INTL (for international pricing)',
      valueHelp: 'Select from valid values "AE, INTL"',
      example: 'AE',
      required: true,
      width: 20,
      sanitizers: [trim, upperCase],
      validators: [isEnum(['AE', 'INTL'])],
      invalidValueMessage: `Market Code must be one of "AE, INTL"`,
      cellValidation: {
        type: 'list',
        allowBlank: true,
        formulae: ['"AE,INTL"'],
        valuesList: ['AE', 'INTL'],
      },
    },
    {
      field: 'marketCurrency',
      label: 'Market Currency',
      instruction: '3 letter currency code',
      valueHelp: 'Select from valid values "AED, USD"',
      example: 'AED',
      required: true,
      width: 20,
      sanitizers: [trim, upperCase],
      validators: [minLength(2), isEnum(['AED', 'USD'])],
      invalidValueMessage: 'Market Currency must be one of "AED, USD"',
      cellValidation: {
        type: 'list',
        allowBlank: true,
        formulae: ['"AED,USD"'],
        valuesList: ['AED', 'USD'],
      },
    },
    {
      field: 'tiers.0.price',
      label: 'Price per unit of measure',
      instruction:
        'Price per measure unit for given market, in given currency, for given tier.',
      valueHelp: 'Numeric value',
      example: '450',
      required: true,
      width: 35,
      sanitizers: [trim, toNumber],
      validators: [isNumber, greaterThan(0)],
      invalidValueMessage: 'Price should be greater than 0',
    },
    {
      field: 'tiers.0.retailPrice',
      label: 'Retail price per unit of measure',
      instruction:
        'Retail price per measure unit for given market, in given currency, for given tier.',
      valueHelp: 'Numeric value',
      example: '500',
      required: false,
      width: 35,
      sanitizers: [trim, toNumber],
      validators: [isNumber, greaterThan(0)],
      invalidValueMessage: 'Retail price should be greater than 0',
    },
    {
      field: 'marketLabel',
      label: 'Market Label',
      instruction:
        'Select the Market code, it could be either AE (for Gulf) or INTL (for international pricing)',
      valueHelp: 'Word',
      example: 'AE',
      required: true,
      width: 20,
      sanitizers: [trim, upperCase],
      validators: [],
      invalidValueMessage: `Market Labek must be one of "AE, INTL"`,
    },
    {
      field: 'tiers.0.minQty',
      label: 'Min order quantity ',
      instruction:
        'Use it to provide the lowest set amount of stock to sell for the given tier',
      valueHelp: 'Positive integer',
      example: '20',
      required: true,
      width: 35,
      sanitizers: [trim, toNumber],
      validators: [isInteger, greaterThan(0), shouldNotDecimal],
      dependValidators: [validateMinOrderAndStockQty],
      invalidValueMessage:
        "Min quantity must be a positive integer, shouldn't be decimal and must be greater than available stock quantity",
    },

    {
      field: 'tiers.0.maxQty',
      label: 'Max order quantity',
      instruction:
        'Use it to provide the maximum set amount of stock to sell for the given tier',
      valueHelp: 'Numeric value',
      required: false,
      width: 15,
      sanitizers: [trim, toNumber],
      validators: [isNumber, greaterThan(0)],
      invalidValueMessage: 'Lead time value must be a positive number',
      example: '54',
    },
    {
      field: 'subSupplierCompanyIds',
      label: `Vendor ID`,
      instruction:
        'IDs of sub-supplier which product was purchased by BLINK Technolgy',
      valueHelp: 'Semi colon Separated',
      example: '5fbfd632582550d0aac48e68;5fbfd632582550d0aac48e69',
      required: false,
      width: 35,
      sanitizers: [semiColonSeparated],
      validators: [],
      invalidValueMessage: '',
    },
    {
      field: 'vendorSku',
      label: `Vendor SKU`,
      instruction: `SKU's of sub-suppliers`,
      valueHelp: 'Semi colon Separated',
      example: 'AX123;AB123',
      required: false,
      width: 35,
      sanitizers: [semiColonSeparated],
      validators: [],
      invalidValueMessage: '',
    },
    {
      field: 'costPrices',
      label: 'Cost Price',
      instruction: 'Prices purchase bought by sub-supplier ',
      valueHelp: 'Semi colon Separated',
      example: '450;300.5',
      required: false,
      width: 35,
      sanitizers: [semiColonSeparated, parseIntArray],
      validators: [],
      invalidValueMessage: 'Cost price must be a positive number',
    },
    {
      field: 'delivery.leadTimeValue',
      label: 'Avg. lead time (Days)',
      instruction:
        'Use it to provide the Avg. number of day for order delivery',
      valueHelp: 'Numeric value',
      required: true,
      width: 15,
      sanitizers: [trim, toNumber],
      validators: [isNumber, greaterThan(0)],
      invalidValueMessage: 'Lead time value must be a positive number',
      example: '54',
    },
    {
      field: 'siteConfiguration.channels',
      label: 'Channels',
      instruction: 'Select channels for this offer',
      valueHelp: 'web,mobile',
      required: false,
      width: 15,
      sanitizers: [commaSeparated],
      validators: [validateCommaSeparatedIn([Channels.Mobile, Channels.Web])],
      invalidValueMessage: 'channels must be comma separated in web and mobile',
      example: 'web,mobile',
    },
    {
      field: 'siteConfiguration.stores',
      label: 'Stores',
      instruction: 'Select stores for this offer',
      valueHelp: 'tradeling-ae,tradeling-sa',
      required: false,
      width: 15,
      sanitizers: [commaSeparated],
      validators: [
        validateCommaSeparatedIn([Stores.TradelingAe, Stores.TradelingSa]),
      ],
      invalidValueMessage: 'channels must be in tradeling-ae and tradeling-sa',
      example: 'tradeling-ae,tradeling-sa',
    },
    {
      field: 'siteConfiguration.websites',
      label: 'Websites',
      instruction: 'Select websites for this offer',
      valueHelp: 'tradeling',
      required: false,
      width: 15,
      sanitizers: [commaSeparated],
      validators: [validateCommaSeparatedIn([Websites.Tradeling])],
      invalidValueMessage: 'websites must be tradeling',
      example: 'tradeling',
    },
    {
      field: 'inStock',
      label: 'In Stock?',
      instruction: 'Is the product is in stock?',
      valueHelp: 'Can only be one of yes, no',
      required: false,
      width: 20,
      sanitizers: [trim, lowerCase, tryToBoolean],
      validators: [isBoolean],
      invalidValueMessage: 'In stock must be either yes or no',
      example: 'yes',
      cellValidation: {
        type: 'list',
        allowBlank: false,
        formulae: ['"Yes,No"'],
        valuesList: ['Yes', 'No'],
      },
    },
    {
      field: 'online',
      label: 'Online',
      instruction: 'Is the product online?',
      valueHelp: 'Can only be one of yes, no',
      required: false,
      width: 20,
      sanitizers: [trim, lowerCase, tryToBoolean],
      validators: [isBoolean],
      invalidValueMessage: 'Online must be either yes or no',
      example: 'yes',
      cellValidation: {
        type: 'list',
        allowBlank: false,
        formulae: ['"Yes,No"'],
        valuesList: ['Yes', 'No'],
      },
    },
  ];
}

export function getOffersFields(
  template: string = simplePriceListTemplate,
): FieldType[] {
  const fields: FieldType[] = [
    {
      field: 'sku',
      label: 'variant SKU',
      instruction:
        'a unique identifier for each product/ variant listed and is defined by the seller',
      example: '62b170ef110be8001c93f41b',
      valueHelp: 'An alphanumeric string',
      required: true,
      width: 10,
      sanitizers: [trim, upperCase],
      validators: [minLength(1), maxLength(60)],
      invalidValueMessage: 'SKU must be between 1 to 60 characters',
    },
    ...getCommonOfferFields(),
  ];

  return fields.filter((item: FieldType): boolean => {
    return !item.template || item.template.includes(template);
  });
}

export function getAttributeCellValidation(
  attribute: AttributeWithCategoriesType,
): any {
  const isSelectField: boolean = ['country', 'select', 'multi_select'].includes(
    attribute.type,
  );

  if (!isSelectField) {
    return null;
  }

  if (attribute.type === 'multi_select') {
    return {
      // I couldn't find native support in excel for multi select
      valuesList: attribute.allowedValues,
    };
  }

  // For country type attributes, dropdown
  if (attribute.type === 'country') {
    const countryList: string[] = countries.map(
      (country: CountryType): string => country.label,
    );

    return {
      type: 'textLength',
      operator: 'lessThan',
      showErrorMessage: true,
      allowBlank: true,
      formulae: [150],
      valuesList: countryList,
    };
  }

  if (!attribute?.allowedValues?.length) {
    return null;
  }

  return {
    type: 'list',
    allowBlank: true,
    formulae: [`"${attribute.allowedValues.join(',')}"`],
    valuesList: attribute.allowedValues,
  };
}

function getCategoriesConditionalFormattingRules(
  categoriesSlugs: string[],
): Excel.ConditionalFormattingRule[] {
  return [
    {
      type: 'expression',
      // if the selected category (first cell in row) is not from the categoriesSlugs
      // !(categoriesSlugs.join().includes(selectedCategory))
      formulae: [
        `NOT( ISNUMBER( SEARCH(INDIRECT(ADDRESS(ROW(), 1)), "${categoriesSlugs.join()}")))`,
      ],
      style: {
        fill: {
          type: 'pattern',
          pattern: 'solid',
          bgColor: { argb: 'FF444242' },
          fgColor: { argb: 'FFFF0000' },
        },
      },
      priority: 1,
    },
  ];
}

function duplicateLocalizedAttributes(
  attributes: AttributeWithCategoriesType[],
  template: TemplateType,
): AttributeWithCategoriesType[] {
  return attributes.flatMap(
    (attribute: AttributeWithCategoriesType): AttributeWithCategoriesType[] =>
      !attribute.isLocalized || isEdukaanTemplate(template)
        ? [attribute]
        : [
            {
              ...attribute,
              code: `${attribute.code}.en`,
              label: { en: `${attribute.label.en} (en)` },
            },
            {
              ...attribute,
              code: `${attribute.code}.ar`,
              label: { en: `${attribute.label.en} (ar)` },
              required: false,
            },
          ],
  );
}

export function getAttributeFields(
  attributes: AttributeWithCategoriesType[] = [],
  template: TemplateType,
): FieldType[] {
  // Sort the attributes in the required order
  const sortedAttributes: AttributeWithCategoriesType[] =
    sortBy(attributes, 'sort') || [];
  const allAttributesWithLocalization: AttributeWithCategoriesType[] = duplicateLocalizedAttributes(
    sortedAttributes,
    template,
  );
  return allAttributesWithLocalization.map(
    (attribute: AttributeWithCategoriesType): FieldType => {
      return {
        field: `attributes.${attribute.code}`,
        label: attribute?.label?.en,
        valueHelp: attribute?.valueHelp?.en,
        required: attribute.required,
        width: 20,
        sanitizers: getCategoryAttributeSanitizers(attribute),
        validators: getCategoryAttributeValidators(attribute),
        invalidValueMessage: getCategoryAttributeInvalidValueMessage(attribute),
        example: attribute?.example ?? '',
        instruction: attribute.help?.en,
        cellValidation: getAttributeCellValidation(attribute),
        categoriesSlugs: attribute.categories?.map((category) => category.slug),
      };
    },
  );
}

export function getCategoryAttributeSheetSanitizers(
  attribute: CategoryAttributeType,
): FieldSanitizer[] {
  switch (attribute.type) {
    case 'country':
      return [fromCountryCode];
    case 'multi_select':
      return [joinBy(',')];
  }

  return [trim];
}

export function getCategoryAttributeSanitizers(
  attribute: CategoryAttributeType,
): FieldSanitizer[] {
  switch (attribute.type) {
    case 'country':
      return [trim, upperCase, toCountryCode];
    case 'checkbox':
      return [trim, lowerCase, toBoolean];
    case 'multi_select':
      return [splitBy(',')];
    case 'number':
      return [toNumber];
    case 'date':
      return [toDate];
  }

  return [trim];
}

export function getCategoryAttributeValidators(
  attribute: CategoryAttributeType,
): FieldValidator[] {
  switch (attribute.type) {
    case 'checkbox':
      return [isBoolean];
    case 'country':
      return [isCountryCode];
    case 'multi_select':
      return attribute.strict ? [each(isEnum(attribute.allowedValues))] : [];
    case 'select':
      return attribute.strict ? [isEnum(attribute.allowedValues)] : [];
    case 'number': {
      const validators: FieldValidator[] = [isNumber];

      if (attribute.isInteger === true) {
        validators.push(isInteger);
      }
      if (attribute.minValue) {
        validators.push(greaterThanOrEqual(attribute.minValue));
      }
      if (attribute.maxValue) {
        validators.push(lessThanOrEqual(attribute.maxValue));
      }

      return validators;
    }
    case 'date':
      return [isDate];
    case 'url':
      return [isUrl];
  }

  return [];
}

export function getCategoryAttributeInvalidValueMessage(
  attribute: CategoryAttributeType,
): string {
  switch (attribute.type) {
    case 'country':
      return `${attribute?.label?.en} must be a country code. e.g. US`;
    case 'multi_select':
      return `${attribute?.label?.en} must be one of allowed values`;
    case 'select':
      return `${attribute?.label?.en} must be one of allowed values"`;
    case 'number': {
      let str: string = `${attribute?.label?.en} must be a number`;

      if (attribute.minValue && attribute.maxValue) {
        str += ` between ${attribute.minValue} and ${attribute.maxValue}`;
      }

      if (attribute.minValue && !attribute.maxValue) {
        str += ` and minimum value limit ${attribute.minValue}`;
      }

      if (!attribute.minValue && attribute.maxValue) {
        str += ` and maximum value limit ${attribute.minValue}`;
      }

      return str;
    }
    case 'date':
      return `${attribute?.label?.en} must be a valid date`;
    case 'url':
      return `${attribute?.label?.en} must be a valid url`;
  }

  return null;
}

export function sanitizeField(
  value: string,
  sanitizers: FieldSanitizer[],
): { value: any; error?: Error } {
  try {
    return {
      value: sanitizers.reduce(
        (newValue: any, sanitizer: FieldSanitizer): any => sanitizer(newValue),
        value,
      ),
    };
  } catch (error) {
    return {
      value: undefined,
      error,
    };
  }
}

export function validateField(
  value: any,
  validators: FieldValidator[],
): boolean {
  try {
    return validators.every((validator: FieldValidator): boolean =>
      validator(value),
    );
  } catch (error) {
    return false;
  }
}

export async function validateFieldDependent(
  value: any,
  row: any,
  validators: FieldDependValidator[],
): Promise<boolean> {
  try {
    for (const validator of validators) {
      if (!(await validator(value, row))) {
        return false;
      }
    }
    return true;
  } catch (err) {
    return false;
  }
}

// Sanitizers

const truthyValues: string[] = ['1', 'yes', 'true'];
const falsyValues: string[] = ['0', 'no', 'false'];

export function toBoolean(value: string): boolean {
  return truthyValues.includes(value);
}

export function tryToBoolean(value: string): boolean | string {
  return truthyValues.includes(value)
    ? true
    : falsyValues.includes(value)
    ? false
    : value;
}

export function toCountryCode(value: string): string {
  const normalizedValue: string = value.toUpperCase();
  const foundCountry: CountryType = countries.find(
    (country: CountryType): boolean => {
      return (
        country.label.toUpperCase() === normalizedValue ||
        country.value.toUpperCase() === normalizedValue
      );
    },
  );

  return foundCountry?.value || '';
}

export function fromCountryCode(value: string): string {
  const normalizedValue: string = value.toUpperCase();
  const foundCountry: CountryType = countries.find(
    (country: CountryType): boolean => {
      return (
        country.label.toUpperCase() === normalizedValue ||
        country.value.toUpperCase() === normalizedValue
      );
    },
  );

  return foundCountry?.label || '';
}

export function trim(value: any): string {
  return String(value).trim();
}

export function upperCase(value: any): string {
  return String(value).toUpperCase();
}

export function commaSeparated(value: any): string[] {
  return String(value).split(',');
}

export function semiColonSeparated(value: any): string[] {
  return String(value)
    .split(';')
    .filter((item) => item !== '');
}

export function parseIntArray(value: string[]): number[] {
  return value.map((item) => parseFloat(item.replace(/,/g, '')));
}

export function lowerCase(value: any): string {
  return String(value).toLowerCase();
}

export function sizeUnitLabelToValue(value: any): string {
  const givenValue: string = String(value).toLowerCase().trim();

  const found: UnitType = sizeUnits.find(
    (sizeUnit: UnitType): boolean =>
      sizeUnit.label.toLowerCase() === givenValue,
  );

  return found?.code || null;
}

export function toSizeUnit(value: any): string {
  const givenValue: string = String(value).toLowerCase().trim();

  const found: UnitType = sizeUnits.find(
    (sizeUnit: UnitType): boolean => sizeUnit.code === givenValue,
  );

  return found?.label || null;
}

export function weightUnitLabelToValue(value: any): string {
  const givenValue: string = String(value).toLowerCase().trim();

  const found: UnitType = weightUnits.find(
    (sizeUnit: UnitType): boolean =>
      sizeUnit.label.toLowerCase() === givenValue,
  );

  return found?.code || null;
}

export function transportationLabelToValue(value: any): string {
  const givenValue: string = String(value).toLowerCase().trim();

  const foundValue: string = Object.keys(TransportationModeLabelMapping).find(
    (key: string) => {
      const keyValue: string =
        TransportationModeLabelMapping[
          key as Components.Schemas.V1TransportationMode
        ];

      return keyValue.toLowerCase().trim() === givenValue;
    },
  );

  return foundValue || null;
}

export function toTransportationLabel(value: any): string {
  return TransportationModeLabelMapping[value] || null;
}

export function splitBy(delimiter: string): (value: any) => string[] {
  return (value: any): string[] =>
    String(value)
      .split(delimiter)
      .map((s: string): string => s.trim())
      .filter(Boolean);
}

export function joinBy(delimiter: string): (value: any) => string {
  return (value: any[]): string => {
    return Array.isArray(value) ? value?.join(delimiter) : '';
  };
}

export function toNumber(value: string): number {
  return Number(value);
}

export function toDecimal(precision: number): (value: string) => number {
  return (value: string) => round(Number(value), precision);
}

export function toDate(value: string): Date {
  return new Date(value);
}

export function sanitizeConfigurationAttribute(variants: any): any {
  const configurationAttributesObj: any = {};
  const configurationAttributes: any[] = [];
  for (const variant of variants) {
    if (variant.variantValues) {
      for (const variantValue of variant.variantValues) {
        configurationAttributesObj[variantValue.code] = [
          ...(configurationAttributesObj[variantValue.code] || []),
          variantValue.value,
        ];
      }
    }
  }
  for (const code of Object.keys(configurationAttributesObj)) {
    configurationAttributes.push({
      code,
      options: uniq(configurationAttributesObj[code]),
    });
  }
  return configurationAttributes;
}

export function sanitizeKeywords(value: string): any {
  return value
    .split(',')
    .map((keyword: string): string => keyword.trim().toLowerCase())
    .filter((keyword: string): boolean => keyword !== '');
}

export function stripHtml(value: string): string {
  return striptags(String(value));
}

// Validators

export function minLength(min: any = 1): (value: any) => boolean {
  return (value: any): boolean =>
    (typeof value === 'string' || Array.isArray(value)) && value.length >= min;
}

export function maxLength(max: any = 1): (value: any) => boolean {
  return (value: any): boolean =>
    (typeof value === 'string' || Array.isArray(value)) && value.length <= max;
}

export function greaterThan(minimum: number): (value: any) => boolean {
  return (value: any): boolean => parseFloat(value) > minimum;
}

export function greaterThanOrEqual(minimum: number): (value: any) => boolean {
  return (value: any): boolean => parseFloat(value) >= minimum;
}

export function lessThan(maximum: number): (value: any) => boolean {
  return (value: any): boolean => parseInt(value, 10) < maximum;
}

export function lessThanOrEqual(maximum: number): (value: any) => boolean {
  return (value: any): boolean => parseInt(value, 10) <= maximum;
}

export function each(
  validator: (value: any) => boolean,
): (value: any) => boolean {
  return (values: any): boolean => {
    return Array.isArray(values)
      ? values.every((value: any): boolean => validator(value))
      : false;
  };
}

export function validateCommaSeparatedIn(
  values: string[],
): (value: any) => boolean {
  return (value: any): boolean =>
    String(value)
      .split(',')
      .every((val) => values.includes(val));
}

export function isEnum(enumValues: any[]): (value: any) => boolean {
  return (value: any): boolean => enumValues.includes(value);
}

export function isArrayEnum(enumValues: any[]): (value: any) => boolean {
  return (array: any[]): boolean =>
    array.every((value) => enumValues.includes(value));
}

export function isBoolean(value: any): boolean {
  return typeof value === 'boolean';
}

export function isSizeUnit(value: any): boolean {
  return !!sizeUnits.find((sizeUnit) => sizeUnit.code == value?.toLowerCase());
}

export function isWeightUnit(value: any): boolean {
  return !!weightUnits.find(
    (weightUnit) => weightUnit.code == value?.toLowerCase(),
  );
}

export function isCountryCode(value: any): boolean {
  return !!countries.find(
    (country: CountryType): boolean => country.value === value,
  );
}

export function isNumber(value: any): boolean {
  return typeof parseInt(value) === 'number' && !isNaN(value);
}

export function isArrayOfNumbers(value: string): boolean {
  return (
    value
      .split(';')
      .filter(
        (item) => typeof parseInt(item) === 'number' && !isNaN(parseInt(item)),
      ).length > 0
  );
}

export function lessThanArray(maximum: number): (value: any) => boolean {
  return (value: any): boolean =>
    value.split(';').every((item) => parseFloat(item) < maximum);
}

export function isInteger(value: any): boolean {
  return Number.isSafeInteger(parseInt(value));
}

export function shouldNotDecimal(value: any): boolean {
  return Number.isInteger(value);
}

export function isDate(value: any): boolean {
  return value instanceof Date && !isNaN(value.getTime());
}

const urlRe: RegExp = /^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/;

export function isUrl(value: any): boolean {
  return typeof value === 'string' && urlRe.test(value);
}

export function isMongoId(value: any): boolean {
  // @ts-ignore
  return Types.ObjectId.isValid(value);
}

export function validateVariantValue(value: string): boolean {
  // todo get  allow configurable value base on the variant e.g color should red,  blue .... etc
  return typeof value === 'string';
}

export async function validateMinOrderAndStockQty(
  minQty: number,
  fields: any,
): Promise<boolean> {
  /**
   * if empty SKU ID consider it new product and by pass it
   * Collection exists only for edukaan
   */
  if (isEmpty(fields['SKU ID']) || isEmpty(fields.Collections)) {
    return true;
  }
  const variant: IProductModelV3 = await productModelV3.findOne({
    sku: fields['SKU ID'],
  });
  const stockQty: number = variant?.stockQty || 0;
  return !(stockQty != 0 && minQty > stockQty);
}

export function isValidTemplateType(value: any): boolean {
  return [
    simplePriceProductTemplate,
    simplePriceListTemplate,
    simpleProductTemplate,
    edukaanProductTemplate,
    configurablePriceListTemplate,
    configurableProductTemplate,
    offerTemplate,
    productTemplate,
  ].includes(value);
}

export function isProductTemplate(value: any): boolean {
  return [
    simplePriceProductTemplate,
    configurablePriceProductTemplate,
    edukaanProductTemplate,
    simpleProductTemplate,
    configurableProductTemplate,
    productTemplate,
    productPartialUpdateTemplate,
  ].includes(value);
}

export function isProductCreateTemplate(value: any): boolean {
  return [
    simplePriceProductTemplate,
    configurablePriceProductTemplate,
    edukaanProductTemplate,
    simpleProductTemplate,
    configurableProductTemplate,
    productTemplate,
  ].includes(value);
}

export function isPriceListTemplate(value: any): boolean {
  return [
    simplePriceListTemplate,
    configurablePriceListTemplate,
    offerTemplate,
  ].includes(value);
}

export function isPartialUpdateTemplate(value: any): boolean {
  return [productPartialUpdateTemplate].includes(value);
}

export type CategoryMetaType = {
  category: ICategoryModel;
  attributes: CategoryAttributeType[];
  fields?: FieldType[];
};

type CreateWorkbookArgs = {
  categoryMetas: CategoryMetaType[];
  collections?: ICollectionModel[];
  template?: TemplateType;
  isInternationalSeller?: boolean;
};

type AttributeWithCategoriesType = CategoryAttributeType & {
  categories?: ICategoryModel[];
};

const attributeIdentifiers: string[] = ['code', 'allowedValues'];

function isSameAttribute(
  attr1: CategoryAttributeType,
  attr2: CategoryAttributeType,
): boolean {
  return isEqual(
    pick(attr1, attributeIdentifiers),
    pick(attr2, attributeIdentifiers),
  );
}

export function getCategoriesUniqueAttributes(
  categoryMetas: CategoryMetaType[],
): AttributeWithCategoriesType[] {
  return categoryMetas.reduce((agg, catMeta) => {
    catMeta.attributes.forEach((attr) => {
      const duplicateFound: AttributeWithCategoriesType = agg.find((a) =>
        isSameAttribute(a, attr),
      );
      if (duplicateFound) {
        duplicateFound.categories.push(catMeta.category);
      } else {
        agg.push({ ...attr, categories: [catMeta.category] });
      }
    });
    return agg;
  }, []);
}

export function getMultiCategoryProductUploadFields(
  categories: ICategoryModel[],
  template: TemplateType,
  isInternationalSeller: boolean,
  collections: ICollectionModel[],
): FieldType[] {
  return [
    getCategorySelectionField(categories),
    ...getCollectionSelectionFields(collections, template),
    ...getProductUploadFields(template, isInternationalSeller),
  ];
}

function getMultiCategoryWorkbookFields({
  categoryMetas,
  template,
  isInternationalSeller,
  collections,
}: CreateWorkbookArgs): FieldType[] {
  const uniqAttributes: AttributeWithCategoriesType[] = getCategoriesUniqueAttributes(
    categoryMetas,
  );
  const categories: ICategoryModel[] = categoryMetas.map(
    (catMeta) => catMeta.category,
  );
  const allFields: FieldType[] = [
    ...getMultiCategoryProductUploadFields(
      categories,
      template,
      isInternationalSeller,
      collections,
    ),
    ...getAttributeFields(uniqAttributes, template),
    ...(template == Template.ProductTemplate ? getCommonOfferFields() : []),
  ];
  return allFields;
}

export function getProductFieldsWithoutCategory({
  categoryMetas,
  template,
  isInternationalSeller,
}: CreateWorkbookArgs): FieldType[] {
  const uniqAttributes: AttributeWithCategoriesType[] = getCategoriesUniqueAttributes(
    categoryMetas,
  );
  return [
    ...getProductUploadFields(template, isInternationalSeller),
    ...getAttributeFields(uniqAttributes, template),
    ...getCommonOfferFields(),
  ];
}

export function getWorkbookFields({
  categoryMetas,
  template,
  isInternationalSeller,
  collections,
}: Partial<CreateWorkbookArgs>): FieldType[] {
  if (!categoryMetas?.length) {
    return [
      ...getProductUploadFields(template, isInternationalSeller),
      ...(template == Template.ProductTemplate ? getCommonOfferFields() : []),
    ];
  } else {
    return getMultiCategoryWorkbookFields({
      categoryMetas,
      template,
      isInternationalSeller,
      collections,
    });
  }
}

function createMOQWorkSheet(
  workbook: Excel.Workbook,
  categories: CategoryMetaType[],
): void {
  const moqWorksheet: Excel.Worksheet = workbook.addWorksheet('MOQ');

  moqWorksheet.getRow(1).font = { bold: true };
  moqWorksheet.getRow(1).border = { bottom: { style: 'thin' } };

  moqWorksheet.columns = [
    { header: 'Category', width: 50 },
    { header: 'Category slug', width: 50 },
    { header: 'MOQ', width: 30 },
  ] as Excel.Column[];

  categories.forEach((category, index) => {
    moqWorksheet.getCell(`A${index + 2}`).value = category?.category?.name?.en;
    moqWorksheet.getCell(`B${index + 2}`).value = category?.category?.slug;
    moqWorksheet.getCell(`C${index + 2}`).value = category?.category?.moq;
  });
}

export function getCategoryMetas(
  categories: ICategoryModel[],
  categoriesAttributes: ICategoryAttributeModel[],
): CategoryMetaType[] {
  return categories.map((category) => {
    const attributesDocument: ICategoryAttributeModel = categoriesAttributes.find(
      (attributesDocument) =>
        attributesDocument.categoryId.toString() === category._id.toString(),
    );
    return { category, attributes: attributesDocument?.attributes ?? [] };
  });
}

function addAllowedValuesSheetToWorkbook(
  wb: Excel.Workbook,
  fields: FieldType[],
): void {
  const valueSheet: Excel.Worksheet = wb.addWorksheet('Valid Values');
  const titleRow: Row = valueSheet.addRow(
    ['Please use these valid values'],
    'n',
  );

  titleRow.font = { bold: true, size: 12 };
  titleRow.height = 35;
  titleRow.border = { bottom: { style: 'thin' } };

  const selectFields: FieldType[] = fields.filter(
    (field: FieldType): boolean => !!field?.cellValidation?.valuesList?.length,
  );

  // Add the columns list
  const columnsList: string[] = selectFields.map(
    (field: FieldType): string => field.label,
  );
  const columnsRow: Row = valueSheet.addRow(columnsList, 'n');

  columnsRow.border = { bottom: { style: 'thin' } };
  columnsRow.font = {
    bold: true,
    size: 12,
    color: {
      argb: 'FFFF3344',
    },
  };

  // Dump the values for the select fields
  selectFields.map((selectField: FieldType, fieldCounter: number): void => {
    const colNumber: number = fieldCounter + 1;
    const colName: string = getExcelColumnName(colNumber);

    valueSheet.getColumn(colNumber).width = 30;

    // Remove double quotes from start and end and split by , to get allowed values
    const allowedValues: string[] =
      selectField?.cellValidation?.valuesList ?? [];

    // For each of the values, put that in excel
    allowedValues.forEach(
      (allowedValue: string, valueCounter: number): void => {
        valueSheet.getCell(
          `${colName}${valueCounter + 3}`,
        ).value = allowedValue;
      },
    );
  });
}

export function getEmptyWorkbook(fields: FieldType[]): Excel.Workbook {
  const workbook: Excel.Workbook = new Excel.Workbook();

  workbook.creator = Project.Name;
  workbook.lastModifiedBy = Project.Name;

  /////////////////////////////////////////////////////////////////
  // Add instructions sheet
  /////////////////////////////////////////////////////////////////
  const instructionsWorksheet: Excel.Worksheet = workbook.addWorksheet(
    'Instructions',
  );

  instructionsWorksheet.columns = [
    { header: 'Field', width: 30 },
    { header: 'Example', width: 50 },
    { header: 'Definition', width: 80 },
    { header: 'Accepted Values', width: 50 },
    { header: 'Required', width: 10 },
  ] as Excel.Column[];

  instructionsWorksheet.getRow(1).font = { bold: true };
  instructionsWorksheet.getRow(1).border = { bottom: { style: 'thin' } };

  fields.forEach((f: FieldType, rowCounter: number): void => {
    // prettier-ignore
    const currRow: Row = instructionsWorksheet.addRow([
      f.label,                              // A
      f.example || "",                      // B
      f.instruction || "",                  // C
      f.valueHelp || "",                    // D
      f.required ? "Required" : "Optional" // E
    ], "n");

    currRow.font = {
      size: 10,
    };

    instructionsWorksheet.getCell(`B${rowCounter + 2}`).alignment = {
      wrapText: true,
    };

    instructionsWorksheet.getCell(`E${rowCounter + 2}`).style = {
      font: {
        color: f.required ? { argb: 'FFFF3344' } : undefined,
      },
      alignment: {
        horizontal: 'center',
      },
    };
  });

  /////////////////////////////////////////////////////////////////
  // Add data sheet
  /////////////////////////////////////////////////////////////////
  const dataWorksheet: Excel.Worksheet = workbook.addWorksheet(`Data`, {
    properties: { tabColor: { argb: 'FFFFFF99' } },
  });
  const headersRow: Excel.Row = dataWorksheet.getRow(1);
  headersRow.height = 65;

  dataWorksheet.views = [{ xSplit: 10, ySplit: 1, activeCell: 'A2' }];
  dataWorksheet.columns = fields.map((field: FieldType): any => ({
    header: field.label,
    width: field.width,
  }));
  fields.forEach((field: FieldType, i: number): void => {
    const columnName: string = getExcelColumnName(i + 1);
    dataWorksheet.getCell(`${columnName}1`).style = {
      border: { bottom: { style: 'thin' } },
      font: {
        size: 10,
        family: 2,
        color: field.required ? { argb: 'FFFF3344' } : undefined,
        bold: true,
      },
    };
    dataWorksheet.getCell(`${columnName}1`).note = {
      texts: [
        {
          text: field.required ? 'Required' : 'Optional',
          ...(field.required && {
            font: { color: { argb: 'FFFF0000' }, scheme: 'minor' },
          }),
        },
        {
          text: '\n\n',
        },
        {
          text: field.instruction || ' ',
        },
        {
          text: '\n\n',
        },
        {
          text: field.valueHelp ? `Accepted Value: ${field.valueHelp}` : '',
        },
      ],
      editAs: 'twoCells',
    };

    if (field.cellValidation) {
      for (let j: number = 2; j < maxRowCount; j++) {
        dataWorksheet.getCell(`${columnName}${j}`).dataValidation =
          field.cellValidation;
      }
    }

    if (field.categoriesSlugs) {
      dataWorksheet.addConditionalFormatting({
        ref: `${columnName}2:${columnName}${maxRowCount}`,
        rules: getCategoriesConditionalFormattingRules(field.categoriesSlugs),
      });
    }
  });

  //////////////////////////////////////////////////////////////////
  // Add allowed values sheet
  //////////////////////////////////////////////////////////////////
  addAllowedValuesSheetToWorkbook(workbook, fields);

  /////////////////////////////////////////////////////////////////
  // Add metadata sheet
  /////////////////////////////////////////////////////////////////
  const metaWorksheet: Excel.Worksheet = workbook.addWorksheet('do NOT change');

  metaWorksheet.state = 'hidden';

  return workbook;
}

export function getExcelColumnName(number: number): string {
  let dividend: number = number;
  let columnName: string = '';
  let modulo: number;

  while (dividend > 0) {
    modulo = (dividend - 1) % 26;
    columnName = String.fromCharCode(65 + modulo) + columnName;
    dividend = Math.floor((dividend - modulo) / 26);
  }

  return columnName;
}

export function formatPackagingInfo(
  unit: string,
  packaging: KeyValAny,
): string {
  if (!unit || !packaging) {
    return undefined;
  }
  const { size, unitsPerCarton, unit: packagingUnit } = packaging;
  if (unit === packagingUnit) {
    if (size > 1) {
      return `${size} ${packUnitsOfMeasureMap[unit.toLowerCase()].plural.en}`;
    }
    if (unitsPerCarton > 1) {
      return `${unitsPerCarton} ${
        packUnitsOfMeasureMap[unit.toLowerCase()].plural.en
      }`;
    }
    return `${unitsPerCarton} ${
      packUnitsOfMeasureMap[unit.toLowerCase()].single.en
    }`;
  }
  let packsFormat: string;
  if (unit !== formattedUnits.piece) {
    packsFormat = `${capitalize(
      packUnitsOfMeasureMap[unit.toLowerCase()].single.en,
    )}: ${unitsPerCarton}`;
  } else {
    packsFormat =
      unitsPerCarton > 1
        ? `${unitsPerCarton} ${
            packUnitsOfMeasureMap[unit.toLowerCase()].plural.en
          }`
        : `${unitsPerCarton} ${
            packUnitsOfMeasureMap[unit.toLowerCase()].single.en
          }`;
  }

  const sizeFormat: string =
    size > 1
      ? `${size} ${
          packUnitsOfMeasureMap[packagingUnit.toLowerCase()].plural.en
        }`
      : `${size} ${
          packUnitsOfMeasureMap[packagingUnit.toLowerCase()].single.en
        }`;
  return `${packsFormat} x ${sizeFormat}`;
}

function capitalize(str: string): string {
  return str && str[0].toUpperCase() + str.slice(1);
}

/**
 * Generate random 13 digit sku and return as string as current pattern follow string for sku
 */
export function generateRandomSku(): string {
  return String(Math.floor(1e12 + Math.random() * 9e12));
}

/**
 * function to ensure the system generated sku is unique
 * Recursion approach
 */
async function uniqueGeneratedSku(): Promise<string> {
  try {
    const sku: string = generateRandomSku();
    const skuExists: boolean = await productModelV3.exists({ sku: sku });

    if (skuExists) {
      return await uniqueGeneratedSku();
    }
    return sku;
  } catch (error) {
    return error;
  }
}

/**
 * Generate the value for field as per FieldType setup
 * @param value
 * @param generators
 */
export async function generateFieldValue(
  value: string,
  generators: FieldValueGenerator[],
): Promise<{ value: any; error?: Error }> {
  try {
    return {
      value: await generators.reduce(
        (newValue: any, generators: FieldValueGenerator): any =>
          generators(newValue),
        value,
      ),
    };
  } catch (error) {
    return {
      value: undefined,
      error,
    };
  }
}

export type updateVariant = {
  updateOne: {
    filter: { supplierCompanyId: string; productId: string; sku: string };
    upsert: boolean;
    update: Record<string, any>;
  };
};
export type updateMasterVariant = {
  updateOne: {
    filter: { _id: string; sku: string };
    upsert: boolean;
    update: {
      uploadCount: number;
      lastUploadDate: Date;
      internalReviewStatus: number;
      packagingFormat: string;
    };
  };
};
export type updatedRequestVariant = {
  updateOne: {
    filter: {
      supplierCompanyId: string;
      productId: string;
      variantId: string;
      type: string;
      status: { $ne: number };
    };
    upsert: boolean;
    update: {
      metadata: {
        name: { en: string; ar?: string };
        media: Record<string, any>;
      };
      diff: any;
      websiteCode: string;
      status: number;
    };
  };
};

export function getAuditForOffers(
  defaultOffer: any,
  variantOffer: any,
): auditFields[] {
  let fields: auditFields[] = [];
  const subSupplierCount: number = Math.max(
    variantOffer?.subSupplierCompanies?.length,
    defaultOffer?.subSupplierCompanies?.length,
  );

  for (let index = 0; index <= subSupplierCount; index++) {
    const oldSubSupplierCompany: ISubSupplierCompany =
      defaultOffer?.subSupplierCompanies[index] || {};
    const newSubSupplierCompany: ISubSupplierCompany =
      variantOffer?.subSupplierCompanies[index] || {};
    const isCostPriceChange: boolean =
      newSubSupplierCompany?.costPrice !== oldSubSupplierCompany?.costPrice;
    if (isCostPriceChange) {
      fields = [
        ...fields,
        {
          name: `cost-price-${index}`,
          old: oldSubSupplierCompany?.costPrice,
          new: newSubSupplierCompany?.costPrice,
        },
      ];
    }
  }

  defaultOffer?.market?.tiers?.forEach((tier: any, index: number) => {
    const variantTier: any = variantOffer?.market?.tiers[index] || {};
    const isPRiceChange: boolean =
      tier?.price !== variantTier?.price ||
      tier?.retailPrice !== variantTier?.retailPrice;
    if (variantTier && isPRiceChange) {
      fields = [
        ...fields,
        {
          name: `price-${index}`,
          old: tier?.price,
          new: variantTier?.price,
        },
        {
          name: `minQty-${index}`,
          old: tier?.minQty,
          new: variantTier?.minQty,
        },
        {
          name: `retailPrice-${index}`,
          old: tier?.retailPrice || '',
          new: variantTier?.retailPrice || '',
        },
      ];
    }
  });

  return fields;
}

export function getAuditForCostPrice(
  defaultOffer: any,
  variantOffer: any,
): auditFields[] {
  let fields: auditFields[] = [];
  const subSupplierCount: number = Math.max(
    variantOffer?.subSupplierCompanies?.length,
    defaultOffer?.subSupplierCompanies?.length,
  );

  for (let index = 0; index <= subSupplierCount; index++) {
    const oldSubSupplierCompany: ISubSupplierCompany =
      defaultOffer?.subSupplierCompanies[index] || {};
    const newSubSupplierCompany: ISubSupplierCompany =
      variantOffer?.subSupplierCompanies[index] || {};
    const isCostPriceChange: boolean =
      newSubSupplierCompany?.costPrice !== oldSubSupplierCompany?.costPrice;
    const isRebateChanged =
      newSubSupplierCompany?.rebate !== oldSubSupplierCompany?.rebate;
    if (isCostPriceChange) {
      fields = [
        ...fields,
        {
          name: `cost-price-${index}`,
          old: oldSubSupplierCompany?.costPrice,
          new: newSubSupplierCompany?.costPrice,
        },
      ];
    }
    if (isRebateChanged) {
      fields = [
        ...fields,
        {
          name: `rebate-${index}`,
          old: oldSubSupplierCompany?.rebate,
          new: newSubSupplierCompany?.rebate,
        },
      ];
    }
  }
  return fields;
}

export function isBackoffice(platform: string): boolean {
  return platform === 'backoffice';
}
