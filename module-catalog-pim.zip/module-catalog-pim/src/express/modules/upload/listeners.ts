import { EE } from '@src/config/event/emitter';
import { listenerProductPendingReviewEmail } from '../product/listener-product-pending-review-email';
import { setSupplierHasProducts } from '../product/helpers';
import { CommitUploadEvent, CommitUploadEventType } from '../product/types';

EE.on(
  CommitUploadEvent.Success,
  async (data: CommitUploadEventType): Promise<void> => {
    await Promise.all([
      listenerProductPendingReviewEmail({
        req: data.req,
        productIds: data.productIds,
      }),
      setSupplierHasProducts(data.req.headers),
    ]);
  },
);
