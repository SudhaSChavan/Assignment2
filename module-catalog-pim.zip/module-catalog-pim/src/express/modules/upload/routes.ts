import { Router } from 'express';
import { Router as IRouter } from 'express-serve-static-core';

import './listeners';
import { isAuthenticatedMw } from '@tradeling/web-js-utils';
import { catchAsyncErrors } from '@core/util/router';
import { multerHandler } from '@src/config/middleware/multer-mw';
import {
  getUploadTemplateV3,
  validateGetUploadTemplateV3,
} from './v3/action-get-upload-template';
import {
  uploadProductV3,
  validateUploadProductV3,
} from './v3/action-upload-product';
import {
  commitUploadActionV3,
  validateCommitUploadV3,
} from './v3/action-commit-upload';
import { ensureStore } from '@src/config/middleware/ensure-store';
import {
  listProductUploadRowV3Action,
  validateListProductUploadV3,
} from './v3/action-list-product-upload-row-v3';
import {
  getPartialUpdateTemplateActionV3,
  validateGetPartialUpdateTemplateV3,
} from './v3/action-get-partial-update-template';
import {
  getPartialUpdateFieldsV3,
  validateGetPartialUpdateFieldsV3,
} from './v3/action-get-partial-fields';
import {
  uploadPartialProductsActionV3,
  validateUploadPartialProductsV3,
} from './v3/action-upload-partial-product';
import {
  listUploadActionV3,
  validateListUploadV3,
} from './v3/action-list-upload';
import { getUploadActionV3, validateGetUploadV3 } from './v3/action-get-upload';
import {
  cancelUploadActionV3,
  validateCancelUploadV3,
} from './v3/action-cancel-upload';
import {
  reassignUploadMediaActionV3,
  validateReassignUploadMediaV3,
} from './v3/action-reassign-upload-media';
import {
  unassignProductUploadRowMediaActionV3,
  validateUnassignProductUploadRowMediaV3,
} from './v3/action-unassign-product-upload-row-media';
import {
  getInvalidRowTemplateActionV3,
  validateGetInvalidRowsTemplateV3,
} from '@express/modules/upload/v3/action-get-invalid-rows-template';

const router: IRouter = Router();

router.post(
  '/v3-get-upload-template',
  ensureStore,
  isAuthenticatedMw(),
  validateGetUploadTemplateV3,
  catchAsyncErrors(getUploadTemplateV3),
);
router.post(
  '/v3-get-partial-update-template',
  isAuthenticatedMw(),
  validateGetPartialUpdateTemplateV3,
  catchAsyncErrors(getPartialUpdateTemplateActionV3),
);
router.post(
  '/v3-list-product-upload-row',
  isAuthenticatedMw(),
  validateListProductUploadV3,
  catchAsyncErrors(listProductUploadRowV3Action),
);
router.post(
  '/v3-upload-product',
  ensureStore,
  isAuthenticatedMw(),
  multerHandler,
  validateUploadProductV3,
  catchAsyncErrors(uploadProductV3),
);
router.post(
  '/v3-commit-upload',
  ensureStore,
  isAuthenticatedMw(),
  validateCommitUploadV3,
  catchAsyncErrors(commitUploadActionV3),
);
router.post(
  '/v3-get-partial-product-fields',
  isAuthenticatedMw(),
  multerHandler,
  validateGetPartialUpdateFieldsV3,
  catchAsyncErrors(getPartialUpdateFieldsV3),
);
router.post(
  '/v3-upload-partial-product',
  isAuthenticatedMw(),
  multerHandler,
  validateUploadPartialProductsV3,
  catchAsyncErrors(uploadPartialProductsActionV3),
);
router.post(
  '/v3-list-upload',
  isAuthenticatedMw(),
  validateListUploadV3,
  catchAsyncErrors(listUploadActionV3),
);
router.post(
  '/v3-get-upload',
  isAuthenticatedMw(),
  validateGetUploadV3,
  catchAsyncErrors(getUploadActionV3),
);
router.post(
  '/v3-cancel-upload',
  isAuthenticatedMw(),
  validateCancelUploadV3,
  catchAsyncErrors(cancelUploadActionV3),
);
router.post(
  '/v3-reassign-upload-media',
  isAuthenticatedMw(),
  validateReassignUploadMediaV3,
  catchAsyncErrors(reassignUploadMediaActionV3),
);
router.post(
  '/v3-unassign-product-upload-row-media',
  isAuthenticatedMw(),
  validateUnassignProductUploadRowMediaV3,
  catchAsyncErrors(unassignProductUploadRowMediaActionV3),
);
router.post(
  '/v3-get-invalid-rows-template',
  isAuthenticatedMw(),
  validateGetInvalidRowsTemplateV3,
  catchAsyncErrors(getInvalidRowTemplateActionV3),
);

export { router as uploadRoutes };
