import mongoose from 'mongoose';
import { logger } from '@core/util/logger';
import {
  TemplateType,
  v3MediaTemplate,
  v3PartialTemplate,
  v3ProductTemplate,
} from './v3/helpers';
import { UploadType } from '@express/modules/product/types';

export interface IUploadDocumentV3 {
  categoryIds?: string[];
  collectionIds?: string[];
  fields?: string[];
  originalName: string;
  provider: string;
  path: string;
  type?: string;
  state: UPLOAD_STATE.NEW | UPLOAD_STATE.IMPORTED | UPLOAD_STATE.CANCELED;
  totalCount: number;
  validCount?: number;
  invalidCount?: number;
  uploadedCount?: number;
  draftCount?: number;
  publishedCount?: number;
  meta: Record<string, any>;
  uploadType: TemplateType;
  userId: string;
  supplierId: string;
  supplierCompanyId: string;
  byBackoffice: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface IUploadModelV3 extends IUploadDocumentV3, mongoose.Document {
  _id: string;
}

export enum UPLOAD_STATE {
  NEW = 'new',
  IMPORTED = 'imported',
  CANCELED = 'canceled',
}

const uploadSchemaV3: mongoose.Schema = new mongoose.Schema(
  {
    categoryIds: {
      type: [
        {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'Category',
        },
      ],
      default: null,
    },
    collectionIds: {
      type: [String],
    },
    fields: {
      type: [String],
    },
    type: {
      type: String,
      enum: Object.values(UploadType),
      default: UploadType.Product,
    },
    originalName: {
      type: String,
      required: true,
    },
    provider: {
      type: String,
      required: true,
    },
    // Relative path where the file was stored
    path: {
      type: String,
      required: true,
    },
    state: {
      type: String,
      enum: Object.values(UPLOAD_STATE),
      required: true,
      default: UPLOAD_STATE.NEW,
    },
    totalCount: {
      type: Number,
    },
    invalidCount: {
      type: Number,
    },
    uploadedCount: {
      type: Number,
    },
    meta: {
      type: Object,
      default: {},
    },
    byBackoffice: {
      type: Boolean,
      default: false,
    },
    uploadType: {
      type: String,
      enum: [v3ProductTemplate, v3PartialTemplate, v3MediaTemplate],
      default: v3ProductTemplate,
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      required: false,
    },
    supplierId: {
      type: mongoose.Schema.Types.ObjectId,
      required: false,
    },
    supplierCompanyId: {
      type: mongoose.Schema.Types.ObjectId,
      required: false,
    },
  },
  {
    versionKey: false,
    timestamps: true,
    collection: 'uploadV3',
  },
);

uploadSchemaV3.index({ categoryIds: 1 });
uploadSchemaV3.index({ createdAt: -1 });
uploadSchemaV3.index({ supplierCompanyId: 1, type: 1 });
uploadSchemaV3.index({ byBackOffice: 1, type: 1 });

export const uploadModelV3: mongoose.Model<IUploadModelV3> = mongoose.model<IUploadModelV3>(
  'UploadV3',
  uploadSchemaV3,
);

uploadModelV3.on('index', (err) => {
  if (err) {
    logger.error(err);
  }
});
