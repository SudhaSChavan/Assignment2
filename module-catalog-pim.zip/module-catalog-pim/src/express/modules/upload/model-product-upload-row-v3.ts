import mongoose from 'mongoose';
import {
  DraftCell,
  DraftState,
  DraftStateType,
  UploadRowType,
} from '../product/types';
import { uniq } from 'lodash';
import { logger } from '@core/util/logger';
import { IProductContentV3 } from '../product/model-product-v3';

export interface IProductUploadRowDocumentV3 {
  uploadId: string;
  categoryId: string;
  userId: string;
  supplierId: string;
  supplierCompanyId: string;
  isVariant?: boolean;
  variants?: any[];
  fields: Partial<IProductContentV3>;
  line: number;
  row: DraftCell[];
  media?: string[];
  attributes: Record<string, any>;
  state:
    | DraftState.Draft
    | DraftState.Valid
    | DraftState.Invalid
    | DraftState.Published;
  rowType?: UploadRowType.New | UploadRowType.Existing;
  createdAt?: string;
  updatedAt?: string;
}

export interface IProductUploadRowModelV3
  extends IProductUploadRowDocumentV3,
    mongoose.Document {}

const productUploadRowSchemaV3: mongoose.Schema = new mongoose.Schema(
  {
    uploadId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'ProductUpload',
      required: true,
    },
    categoryId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Category',
      default: null,
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
    },
    supplierId: {
      type: mongoose.Schema.Types.ObjectId,
      required: false,
    },
    supplierCompanyId: {
      type: mongoose.Schema.Types.ObjectId,
      required: false,
    },
    media: {
      type: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Media' }],
      set: (item: string[]): string[] => uniq(item),
      default: [],
    },
    fields: {
      type: Object,
      required: true,
      default: {},
    },
    attributes: {
      // attributes inherited from parent category
      type: Object,
      required: true,
      default: {},
    },
    variants: {
      // attributes inherited from parent category
      type: Object,
      required: true,
      default: [],
    },
    state: {
      type: String,
      enum: Object.values(DraftState),
      default: DraftState.Draft,
    },
    line: {
      type: Number,
      required: true,
    },
    rowType: {
      type: String,
      enum: Object.values(UploadRowType),
    },
    isVariant: {
      type: Boolean,
      default: false,
    },
    row: [
      {
        field: {
          type: String,
          required: true,
        },
        error: String,
        label: {
          type: String,
          required: true,
        },
        value: String,
      },
    ],
  },
  {
    versionKey: false,
    timestamps: true,
    collection: 'productUploadRowV3',
  },
);

// support for listing query and sort
productUploadRowSchemaV3.index({ uploadId: 1 });
productUploadRowSchemaV3.index({ sku: 1 });

export const productUploadRowModelV3: mongoose.Model<IProductUploadRowModelV3> = mongoose.model<IProductUploadRowModelV3>(
  'ProductUploadRowV3',
  productUploadRowSchemaV3,
);

productUploadRowModelV3.on('index', (err) => {
  if (err) {
    logger.error(err);
  }
});

/**
 * Gets the count of the products with given state for the given upload id
 */
export async function getUploadRowCount(
  uploadId: string,
  state: DraftStateType,
): Promise<number> {
  return productUploadRowModelV3.countDocuments({
    uploadId,
    state,
  });
}
