import { body } from 'express-validator';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { appConfig } from '@src/config/env';
import { ERRORS } from '@src/types/errors';
import {
  BaseValidationType,
  HttpError,
  reqValidationResult,
} from '@tradeling/web-js-utils';
import {
  configurablePriceListTemplate,
  configurablePriceProductTemplate,
  configurableProductTemplate,
  offerTemplate,
  productPartialUpdateTemplate,
  productTemplate,
  simplePriceListTemplate,
  simplePriceProductTemplate,
  simpleProductTemplate,
} from '../helpers';
import { joinUrl } from '@core/util/url';
import { V1ListUserAction } from '@tradeling/tradeling-sdk/account/v1-list-user-action';
import { StatusCodes } from 'http-status-codes';
import { AxiosResponse } from 'axios';
import { logger } from '@core/util/logger';
import { keyBy, uniq } from 'lodash';
import { IUploadModelV3, uploadModelV3 } from '../model-upload-v3';
import { UploadType } from '@express/modules/product/types';

interface IReq extends IAppRequest {
  body: Paths.V3ListUploadAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3ListUploadAction.Responses.$200) => this;
}

export const validateListUploadV3: BaseValidationType = [
  body('page').optional().isInt({ gt: 0 }).withMessage(ERRORS.INVALID),
  body('size')
    .optional()
    .isInt({ lt: appConfig.product.listMaxLimit, gt: 0 })
    .withMessage(ERRORS.INVALID),
  body('filter.categoryId').optional().isMongoId().withMessage(ERRORS.INVALID),
  body('filter.state').optional().isString().withMessage(ERRORS.INVALID),
  body('filter.uploadType').optional().isArray().withMessage(ERRORS.INVALID),
  body('filter.uploadType.*')
    .optional()
    .isIn([
      simplePriceProductTemplate,
      productPartialUpdateTemplate,
      configurablePriceProductTemplate,
      simpleProductTemplate,
      configurableProductTemplate,
      simplePriceListTemplate,
      configurablePriceListTemplate,
      offerTemplate,
      productTemplate,
    ])
    .withMessage(ERRORS.INVALID),
  body('filter.dateFrom').optional().isISO8601().withMessage(ERRORS.INVALID),
  body('filter.dateTo').optional().isISO8601().withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function listUploadActionV3(req: IReq, res: IRes): Promise<void> {
  const {
    supplierCompanyId,
    platform,
    body: {
      page = 1,
      size = appConfig.product.listDefaultLimit,
      filter: {
        categoryId = null,
        state = '',
        type = UploadType.Product,
        uploadType = [],
        dateFrom,
        dateTo,
      } = {},
    },
  } = req;

  const recordsToSkip: number = (page - 1) * size;
  const byBackOffice: boolean = platform == 'backoffice';

  const query: any = {
    ...(categoryId ? { categoryIds: categoryId } : {}),
    ...(state ? { state } : {}),
    ...(type === UploadType.Product
      ? { type: { $nin: [UploadType.Media] } }
      : { type: { $in: [UploadType.Media] } }),
    ...(uploadType?.length ? { uploadType: { $in: uploadType } } : {}),
    ...(byBackOffice ? { byBackoffice: true } : { supplierCompanyId }),
  };

  if (dateFrom || dateTo) {
    query.createdAt = {
      ...(dateFrom ? { $gte: dateFrom } : {}),
      ...(dateTo ? { $lte: dateTo } : {}),
    };
  }

  const totalRecords: number = await uploadModelV3.countDocuments(query);
  const uploads: IUploadModelV3[] = await uploadModelV3
    .find(
      query,
      {
        _id: 1,
        categoryIds: 1,
        originalName: 1,
        provider: 1,
        path: 1,
        state: 1,
        totalCount: 1,
        validCount: 1,
        invalidCount: 1,
        draftCount: 1,
        publishedCount: 1,
        meta: 1,
        uploadType: 1,
        userId: 1,
        supplierId: 1,
        supplierCompanyId: 1,
        createdAt: 1,
        updatedAt: 1,
      },
      {
        sort: {
          createdAt: -1,
        },
        skip: recordsToSkip,
        limit: size,
      },
    )
    .lean();

  const supplierCompanyIds: string[] = uploads.map(
    (upload) => upload.supplierCompanyId,
  );
  const supplierDetails: SupplierDetails = await fetchSupplierDetails(
    supplierCompanyIds,
  );
  res.json({
    currentPage: page,
    totalPages: Math.ceil(totalRecords / size),
    totalRecords,
    size,
    data: mapUploadsToResponse(uploads, supplierDetails),
  });
}

function mapUploadsToResponse(
  uploads: IUploadModelV3[],
  supplierDetails: SupplierDetails,
) {
  return uploads.map((upload) => ({
    ...upload,
    url: joinUrl(appConfig.mediaBaseUrl, upload.path),
    supplierName:
      supplierDetails[upload.supplierCompanyId]?.companyName || 'N/A',
  }));
}

type SupplierDetails = {
  [id: string]: Account.Components.Schemas.V1ListUserResponse[0];
};

async function fetchSupplierDetails(
  supplierCompanyIds: string[],
): Promise<SupplierDetails> {
  const uniqueSupplierCompanyIds: string[] = uniq(supplierCompanyIds).filter(
    Boolean,
  );
  if (uniqueSupplierCompanyIds.length === 0) return {};
  try {
    const res: AxiosResponse<Account.Components.Schemas.V1ListUserResponse> = await V1ListUserAction(
      {
        filter: {
          supplierCompanyId: uniqueSupplierCompanyIds,
        },
      },
      {
        headers: {
          'x-country': 'ae',
          'x-language': 'en',
        },
      },
    );
    return keyBy(res.data, 'supplierCompanyId');
  } catch (err) {
    if (err?.response?.status === 404) {
      return {};
    }
    logger.error(
      `error fetching supplier details: ${
        err.response?.data?.message || err.message
      }`,
    );
    throw new HttpError(
      StatusCodes.INTERNAL_SERVER_ERROR,
      `Internal error: Failed to fetch supplier details`,
    );
  }
}
