import { DraftState, InternalReviewStatuses } from '../../../product/types';
import { HttpError } from '@tradeling/web-js-utils';
import { StatusCodes } from 'http-status-codes';
import { ERRORS } from '@src/types/errors';
import { V3CommitUpload } from '../action-commit-upload';
import {
  get,
  keyBy,
  map,
  union,
  groupBy,
  isEmpty,
  isEqual,
  xor,
  isBoolean,
} from 'lodash';
import { IAppRequest } from '@src/types/app-request';
import {
  IProductUploadRowDocumentV3,
  IProductUploadRowModelV3,
  productUploadRowModelV3,
} from '../../model-product-upload-row-v3';
import {
  IProductModelV3,
  productModelV3,
} from '../../../product/model-product-v3';
import { IOfferModelV3, offerModelV3 } from '../../../offer/model-offers-v3';
import { productUpdateRequestModelV3 } from '../../../product/model-product-update-request-v3';
import { logAuditEventForV3Products } from '../../../product/send-product-audit-event';
import { refreshBulkConfigurationAttributes } from '../helpers';
import {
  getAuditForCostPrice,
  getAuditForOffers,
} from '@express/modules/upload/helpers';

export async function commitPartialUpdate(
  uploadId: string,
  req: IAppRequest,
): Promise<V3CommitUpload> {
  const validProductUploadRows: IProductUploadRowModelV3[] = await getProductUploadRows(
    uploadId,
  );

  const skippedCount: number = await productUploadRowModelV3.countDocuments({
    uploadId,
    state: DraftState.Invalid,
  });
  const successfulCount: number = validProductUploadRows.length;

  const productIds: string[] = await updateProducts(
    validProductUploadRows,
    req,
  );

  await productUploadRowModelV3.updateMany(
    {
      uploadId,
      state: DraftState.Valid,
    },
    {
      state: DraftState.Published,
    },
  );

  return {
    uploadId,
    successfulCount,
    skippedCount,
    productIds,
  };
}

async function getProductUploadRows(
  uploadId: string,
): Promise<IProductUploadRowModelV3[]> {
  const validProductUploadRows: IProductUploadRowModelV3[] = await productUploadRowModelV3
    .find({ uploadId, state: { $in: [DraftState.Valid, DraftState.Draft] } })
    .lean();

  if (!validProductUploadRows || validProductUploadRows.length === 0) {
    throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.NOT_ALLOWED);
  }
  return validProductUploadRows;
}

async function updateProducts(
  validProductUploadRows: IProductUploadRowModelV3[],
  req: IAppRequest,
) {
  const rowsGroupedBySupplier: Record<
    string,
    IProductUploadRowModelV3[]
  > = groupBy(validProductUploadRows, 'supplierCompanyId');
  let existingProductIds: string[] = [];
  for (const supplierCompanyId in rowsGroupedBySupplier) {
    const updatedSkus: string[] = rowsGroupedBySupplier[
      supplierCompanyId || ''
    ].map((uploadRow: any): string =>
      get(uploadRow, 'fields.sku').toUpperCase(),
    );
    const existingProducts: IProductModelV3[] = await productModelV3
      .find({ sku: { $in: updatedSkus }, supplierCompanyId: supplierCompanyId })
      .lean();
    const productIds: string[] = map(existingProducts, '_id');
    existingProductIds = existingProductIds.concat(productIds);
    const products: Record<string, IProductModelV3> = keyBy(
      existingProducts,
      'sku',
    );
    const offers: IOfferModelV3[] = await offerModelV3
      .find({ productId: { $in: productIds } })
      .lean();
    const offerObj: Record<string, IOfferModelV3> = keyBy(offers, 'productId');
    const bulkOperations: any = getBulkOperations(
      validProductUploadRows,
      products,
      offerObj,
    );
    await Promise.all([
      productModelV3.bulkWrite(
        map(bulkOperations, 'updateMasterProduct').filter(
          (request) => !!request,
        ) || [],
      ),
      productUpdateRequestModelV3.bulkWrite(
        map(bulkOperations, 'updateRequestVariant').filter(
          (request) => !isEmpty(request),
        ) || [],
      ),
      offerModelV3.bulkWrite(
        map(bulkOperations, 'updateOffers')
          .flat(1)
          .filter((offer) => !!offer),
      ),
    ]);
    await refreshBulkConfigurationAttributes(
      map(products, 'parentSku'),
      supplierCompanyId,
    );
    await logAuditChanges(
      map(bulkOperations, 'auditData'),
      map(bulkOperations, 'auditPrices'),
      map(bulkOperations, 'auditCostPrices'),
      req,
    );
  }

  return union(existingProductIds);
}

function getBulkOperations(
  validExistingProductUploadRows: IProductUploadRowDocumentV3[],
  products: Record<string, IProductModelV3>,
  offers: Record<string, IOfferModelV3>,
) {
  return validExistingProductUploadRows.map((productRow) => {
    const product: IProductModelV3 =
      products[productRow.fields?.sku?.toUpperCase()];
    if (!product) {
      return {};
    }

    const isApprovedProduct: boolean =
      product.internalReviewStatus == InternalReviewStatuses.Accepted;
    const pendingDiffs: any = getPendingDiffs(productRow.fields, product);
    const approvedDiffs: any = getApprovedFieldsDiffs(
      productRow.fields,
      product,
    );
    const diff: any = { ...pendingDiffs, ...approvedDiffs };

    const updateMasterProduct: any = getMasterProductOperation(
      product,
      isApprovedProduct ? approvedDiffs : diff,
    );
    const updatedRequestVariant: any =
      !isApprovedProduct || isEmpty(pendingDiffs)
        ? null
        : getUpdateRequestOperation(product, pendingDiffs);
    let auditPrices: any;
    let auditCostPrices: any;
    const updateOffers: any =
      productRow?.fields?.offers?.map((offer: Components.Schemas.V3Offer) => {
        auditPrices = getAuditForOffers(offers[product?._id], offer);
        auditCostPrices = getAuditForCostPrice(offers[product?._id], offer);
        return getOfferOperation(product, offer, offers[product?._id]);
      }) || [];

    return {
      updateRequestVariant: updatedRequestVariant,
      updateMasterProduct: updateMasterProduct,
      updateOffers: updateOffers,
      auditData: { id: product._id, diff: approvedDiffs },
      auditPrices: { id: product._id, diff: auditPrices },
      auditCostPrices: { id: product._id, diff: auditCostPrices },
    };
  });
}

function getPendingDiffs(body: any, product: IProductModelV3): any {
  const fieldsToCompare: string[] = [
    'categoryId',
    'longDescription',
    'name',
    'shortDescription',
    'unit',
    'attributes',
    'keywords',
    'dimensions',
    'packaging',
    'transportationMode',
  ];
  return compareChanges(fieldsToCompare, body, product);
}

function getApprovedFieldsDiffs(body: any, product: IProductModelV3): any {
  const fieldsToCompare: string[] = [
    'isInStock',
    'isReadyToShip',
    'barcode',
    'isBuyNow',
    'state',
    'isOverSell',
    'new_sku',
    'variantValues',
    'postfix',
    'parentSku',
    'hasVariants',
  ];

  return compareChanges(fieldsToCompare, body, product);
}

function compareChanges(
  fieldsToCompare: string[],
  body: any,
  product: IProductModelV3,
): any {
  const diff: Record<string, any> = {};

  for (const key of fieldsToCompare) {
    if (
      isSame(product, body, key) ||
      [null, undefined].includes(get(body, key))
    ) {
      continue;
    }

    const bodyValue: any = get(body, key);
    const oldValue: any = get(product, key);

    diff[key] = {
      oldValue,
      newValue:
        typeof bodyValue === 'object' && !Array.isArray(bodyValue)
          ? {
              ...oldValue,
              ...bodyValue,
            }
          : skipEmptyValuesForArrays(bodyValue),
    };
  }

  return diff;
}

function skipEmptyValuesForArrays(value) {
  return Array.isArray(value)
    ? value?.filter((item) => {
        return getObjectValues(item).filter(Boolean).length > 0;
      })
    : value;
}

function getObjectValues(obj): string[] {
  return obj && typeof obj === 'object'
    ? Object.values(obj).map(getObjectValues).flat()
    : [obj];
}

function isSame(product: any, body: any, field: string): boolean {
  // For indexed arrays match the field value without sorting except for media
  if (field.includes('.*.')) {
    const [lField, rField] = field.split('.*.');
    const newValue: any = map(get(body, lField), rField);
    const oldValue: any = map(get(product, lField), rField);
    if (lField === 'media') {
      return isEqual(newValue, oldValue);
    }
    return xor(newValue, oldValue).length === 0;
  }

  const bodyValue: any = get(body, field);

  const oldValue: any = get(product, field);

  const newValue: any =
    typeof bodyValue === 'object'
      ? {
          ...oldValue,
          ...bodyValue,
        }
      : bodyValue;

  // If either old or new value is bool, we don't check the emptiness because _.isEmpty returns true for both
  if (!isBoolean(oldValue) && (isEmpty(oldValue) || isEmpty(newValue))) {
    return isEmpty(oldValue) === isEmpty(newValue);
  }

  // normal equality checks
  return isEqual(oldValue, newValue);
}

function getMasterProductOperation(product: IProductModelV3, diff: any) {
  const fields: string[] = Object.keys(diff).filter(
    (field) => !['new_sku'].includes(field),
  );
  const new_sku: string = diff?.new_sku?.newValue;
  return {
    updateOne: {
      filter: {
        _id: product?._id,
      },
      update: {
        ...(product?.internalReviewStatus !== InternalReviewStatuses.Accepted
          ? { internalReviewStatus: InternalReviewStatuses.Pending }
          : {}),
        ...fields.reduce((obj: any, field: string) => {
          obj[field] = (diff as any)[field].newValue;
          return obj;
        }, {}),
        lastUploadDate: new Date(),
        ...(new_sku ? { sku: new_sku } : {}),
        uploadCount: (product?.uploadCount || 0) + 1,
        ...(new_sku
          ? {
              metadata: {
                ...product?.metadata,
                old_sku: product?.sku,
              },
            }
          : {}),
      },
      upsert: false,
    },
  };
}

function getUpdateRequestOperation(product: IProductModelV3, diff: any) {
  return {
    updateOne: {
      filter: {
        productId: product?._id,
        status: { $ne: InternalReviewStatuses.Accepted },
        supplierCompanyId: product?.supplierCompanyId,
        type: 'variant',
      },
      update: {
        diff,
        status: InternalReviewStatuses.Pending,
        websiteCode: product?.websiteCode,
        metadata: {
          name: product.name,
          sku: product.sku,
        },
      },
      upsert: true,
    },
  };
}

function getOfferOperation(
  product: IProductModelV3,
  offer: Components.Schemas.V3Offer,
  existingOffer: IOfferModelV3,
) {
  return {
    updateOne: {
      filter: {
        productId: product?._id,
        supplierCompanyId: product?.supplierCompanyId,
      },
      update: {
        ...offer,
        ...(offer?.market?.tiers && {
          tiers: offer?.market?.tiers?.map((tier: any, index: number) => {
            return {
              tierCode: `Tier ${index}`,
              ...tier,
            };
          }),
        }),
        ...(offer?.subSupplierCompanies && {
          subSupplierCompanies: offer?.subSupplierCompanies.map(
            (subSupplierCompany: any, index) => {
              return {
                ...(existingOffer.subSupplierCompanies[index] || {}),
                ...subSupplierCompany,
              };
            },
          ),
        }),
        delivery: {
          ...existingOffer.delivery,
          ...offer.delivery,
        },
      },
      upsert: false,
    },
  };
}

async function logPricesChanges(auditData: any[], req: IAppRequest) {
  for (const audit of auditData) {
    if (audit?.diff?.length > 0) {
      await logAuditEventForV3Products(
        { _id: audit?.id },
        req,
        audit?.diff,
        'partial-update',
      );
    }
  }
}

async function logCostPricesChanges(auditData: any[], req: IAppRequest) {
  for (const audit of auditData) {
    if (audit?.diff?.length > 0) {
      await logAuditEventForV3Products(
        { _id: audit?.id },
        req,
        audit?.diff,
        'partial-update',
      );
    }
  }
}

async function logAuditChanges(
  auditData: any[],
  auditPrices: any,
  auditCostPrices: any,
  req: IAppRequest,
) {
  await logInStockChanges(auditData, req);
  await logState(auditData, req);
  await logPricesChanges(auditPrices, req);
  await logCostPricesChanges(auditCostPrices, req);
}

async function logInStockChanges(auditData: any[], req: IAppRequest) {
  const inStockProductIds: string[] = [];
  const outOfStockProductIds: string[] = [];
  auditData.forEach((audit: any) => {
    if (audit?.diff?.isInStock?.newValue === true)
      inStockProductIds.push(audit?.id);
    else if (audit?.diff?.isInStock?.newValue === false)
      outOfStockProductIds.push(audit?.id);
  });

  if (!isEmpty(inStockProductIds)) {
    await logAuditEventForV3Products(
      { _id: { $in: inStockProductIds } },
      req,
      { name: 'isInStock', old: false, new: true },
      'partial-update',
    );
  }
  if (!isEmpty(outOfStockProductIds)) {
    await logAuditEventForV3Products(
      { _id: { $in: outOfStockProductIds } },
      req,
      { name: 'isInStock', old: true, new: false },
      'partial-update',
    );
  }
}

async function logState(auditData: any[], req: IAppRequest) {
  const onlineProductIds: string[] = [];
  const offlineProductIds: string[] = [];
  auditData.forEach((audit: any) => {
    if (audit?.diff?.state?.newValue === 'online')
      onlineProductIds.push(audit?.id);
    else if (audit?.diff?.state?.newValue === 'offline')
      offlineProductIds.push(audit?.id);
  });
  if (!isEmpty(onlineProductIds)) {
    await logAuditEventForV3Products(
      { _id: { $in: onlineProductIds } },
      req,
      { name: 'state', old: 'offline', new: 'online' },
      'partial-update',
    );
  }
  if (!isEmpty(offlineProductIds)) {
    await logAuditEventForV3Products(
      { _id: { $in: offlineProductIds } },
      req,
      { name: 'state', old: 'online', new: 'offline' },
      'partial-update',
    );
  }
}
