import { FilterQuery, mongo, Types } from 'mongoose';
import { groupBy, keyBy, map, isEmpty } from 'lodash';
import { IProductContent, IProductFilterQuery } from './types';
import {
  categoryModel,
  ICategoryModel,
} from '../../../category/model-category';
import {
  collectionModel,
  ICollectionModel,
} from '../../../collection/model-collection';
import { DraftState, ProductStates } from '../../../product/types';
import {
  categoryAttributeModel,
  CategoryAttributeType,
} from '../../../category/model-category-attribute';
import {
  IProductModelV3,
  productModelV3,
} from '../../../product/model-product-v3';
import { IOfferModelV3, offerModelV3 } from '../../../offer/model-offers-v3';
import {
  IProductUploadRowDocumentV3,
  productUploadRowModelV3,
} from '../../model-product-upload-row-v3';
import { IUploadModelV3 } from '../../model-upload-v3';

export function getProductFilterQuery(
  filters: IProductFilterQuery,
): FilterQuery<IProductModelV3> {
  const {
    supplierCompanyIds,
    categoryIds,
    internalReviewStatus,
    isInStock,
    state,
    websiteCode,
  } = filters;

  const filterQuery: FilterQuery<IProductModelV3> = {
    $and: [],
  };

  if (supplierCompanyIds.length > 0) {
    filterQuery.$and.push({
      supplierCompanyId: {
        $in: supplierCompanyIds,
      },
    });
  }

  if (state) {
    filterQuery.$and.push({
      state: state as ProductStates,
    });
  }

  if (websiteCode) {
    filterQuery.$and.push({
      websiteCode: websiteCode,
    });
  }

  if (!isEmpty(isInStock)) {
    filterQuery.$and.push({
      isInStock: isInStock,
    });
  }

  if (internalReviewStatus.length > 0) {
    filterQuery.$and.push({
      internalReviewStatus: {
        $in: internalReviewStatus,
      },
    });
  }

  if (categoryIds.length > 0) {
    filterQuery.$and.push({ categoryId: { $in: categoryIds } });
  }

  return filterQuery;
}

export async function getProductContent(
  filterQuery: FilterQuery<IProductModelV3>,
): Promise<IProductContent[]> {
  const products: IProductModelV3[] = await productModelV3
    .find(filterQuery)
    .lean();
  const productIds: string[] = map(products, '_id');
  const offers: IOfferModelV3[] = await getOffers(productIds);
  const offersObj: Record<string, IOfferModelV3[]> = groupBy(
    offers,
    'productId',
  );
  return products.map((product) => {
    return {
      ...product,
      offers: offersObj[product._id],
    };
  });
}

export async function getChildrenCategories(
  categoryIds: string[],
): Promise<string[]> {
  const categories: ICategoryModel[] = await categoryModel
    .find(
      {
        _id: { $in: categoryIds },
      },
      {
        children: 1,
      },
    )
    .lean();
  return map(categories, 'children').flat(1).concat(categoryIds);
}

export async function getProductsCategories(
  categoryIds: string[],
  key = '_id',
): Promise<Record<string, ICategoryModel>> {
  const categories: ICategoryModel[] = await categoryModel
    .find(
      {
        // @ts-ignore
        _id: { $in: categoryIds.filter((id) => Types.ObjectId.isValid(id)) },
      },
      {
        slug: 1,
      },
    )
    .lean();
  return keyBy(categories, key);
}

export async function getProductsCollections(
  collectionIds: string[],
  key: string = '_id',
): Promise<Record<string, ICollectionModel>> {
  const collections: ICollectionModel[] = await collectionModel
    .find(
      {
        _id: { $in: collectionIds },
      },
      {
        slug: 1,
      },
    )
    .lean();
  return keyBy(collections, key);
}

async function getOffers(productIds: string[]): Promise<IOfferModelV3[]> {
  return offerModelV3
    .find({
      deletedAt: null,
      productId: { $in: productIds },
    })
    .lean();
}

export async function getCategoryAttributes(
  categoryIds: string[],
): Promise<CategoryAttributeType[]> {
  return categoryAttributeModel.aggregate([
    {
      $match: {
        categoryId: {
          $in: categoryIds
            // @ts-ignore
            .filter((id) => Types.ObjectId.isValid(id))
            .map((id) => new mongo.ObjectID(id)),
        },
      },
    },
    { $unwind: '$attributes' },
    {
      $group: {
        _id: '$attributes.code',
        type: { $first: '$attributes.type' },
        label: { $first: '$attributes.label' },
        help: { $first: '$attributes.help' },
        valueHelp: { $first: '$attributes.valueHelp' },
        isFilterable: { $first: '$attributes.isFilterable' },
        sort: { $first: '$attributes.sort' },
        code: { $first: '$attributes.code' },
        default: { $first: '$attributes.default' },
        allowedValues: { $first: '$attributes.allowedValues' },
        required: { $first: '$attributes.required' },
        strict: { $first: '$attributes.strict' },
        example: { $first: '$attributes.example' },
        isLocalized: { $first: '$attributes.isLocalized' },
        showCount: { $first: '$attributes.showCount' },
        metadata: { $first: '$attributes.metadata' },
        minValue: { $first: '$attributes.minValue' },
        maxValue: { $first: '$attributes.maxValue' },
        isInteger: { $first: '$attributes.isInteger' },
        categoryIds: { $addToSet: '$categoryId' },
      },
    },
    {
      $sort: {
        sort: 1,
        code: 1,
      },
    },
  ]);
}

export async function saveProductUploadRows(
  productUploadRows: IProductUploadRowDocumentV3[],
  productUpload: IUploadModelV3,
): Promise<IUploadModelV3> {
  await productUploadRowModelV3.insertMany(productUploadRows);
  productUpload.set('totalCount', productUploadRows.length);
  productUpload.set(
    'invalidCount',
    productUploadRows.filter((productUploadRow) => {
      return productUploadRow.state == DraftState.Invalid;
    }).length,
  );

  await productUpload.save();
  return productUpload;
}
