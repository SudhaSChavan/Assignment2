import {
  FieldType,
  getEmptyWorkbook,
  getExcelColumnName,
  getWorkbook,
} from '../../helpers';
import Excel from 'exceljs';
import { IGetTemplateParams, IProductContent } from './types';
import lodash, { get, groupBy, isEmpty, map } from 'lodash';
import { FIELD_MAP, getFields } from './fields';
import { ICategoryModel } from '../../../category/model-category';
import { CategoryAttributeType } from '../../../category/model-category-attribute';
import {
  getCategoryAttributes,
  getProductsCategories,
  getProductsCollections,
} from './helpers';
import { KeyValAny } from '@src/types/common';
import { DraftCell, DraftState } from '../../../product/types';
import { ICollectionModel } from '../../../collection/model-collection';
import { IUploadModelV3 } from '../../model-upload-v3';
import { IProductUploadRowDocumentV3 } from '../../model-product-upload-row-v3';
import { appConfig } from '@src/config/env';
import { IOfferModelV3 } from '@express/modules/offer/model-offers-v3';

export function getInvalidRowsPartialTemplate(
  params: IGetTemplateParams,
): Excel.Workbook {
  const { invalidRows } = params;
  const selectedFields: FieldType[] = getSelectedFields(params).filter(
    (field) => {
      return !field.shouldRemoveFromSheet && !field.shouldExclude;
    },
  );
  const workbook: Excel.Workbook = getEmptyWorkbook(selectedFields);
  fillSheetWithInvalidRows(workbook, invalidRows);
  addMetaDataSheet(workbook, params);
  return workbook;
}

export function getPartialProductTemplate(
  params: IGetTemplateParams,
): Excel.Workbook {
  const { products } = params;
  const selectedFields: FieldType[] = getSelectedFields(params).filter(
    (field) => {
      return !field.shouldRemoveFromSheet && !field.shouldExclude;
    },
  );
  const workbook: Excel.Workbook = getEmptyWorkbook(selectedFields);
  fillSheetWithProducts(selectedFields, workbook, products);
  addMetaDataSheet(workbook, params);
  return workbook;
}

export function getSelectedFields(params: IGetTemplateParams): FieldType[] {
  const { fields } = params;
  const allFields: Record<string, FieldType[]> = getFields(params);
  let selectedFields: FieldType[] = allFields.mandatory;
  const availabilityFields: Record<string, FieldType[]> = groupBy(
    allFields.availability,
    'field',
  );
  const restFields: Record<string, FieldType[]> = groupBy(
    allFields.content,
    'field',
  );
  const groupedFields: Record<string, FieldType[]> = {
    ...allFields,
    ...restFields,
    ...availabilityFields,
  };

  for (const field of fields) {
    if (['content', 'availability'].includes(field)) {
      selectedFields = [...selectedFields, ...allFields[field]];
      continue;
    }
    selectedFields = [...selectedFields, ...groupedFields[field]];
  }
  return selectedFields;
}

function fillSheetWithProducts(
  fields: FieldType[],
  workbook: Excel.Workbook,
  products: IProductContent[],
) {
  const productRows: string[][] = getProductRows(fields, products);
  const datasheet: Excel.Worksheet = workbook.getWorksheet('Data');
  productRows.forEach((row, rowIndex) => {
    row.forEach((column, i) => {
      const columnName: string = getExcelColumnName(i + 1);
      datasheet.getCell(`${columnName}${rowIndex + 2}`).value = column;
    });
  });
}

function fillSheetWithInvalidRows(
  workbook: Excel.Workbook,
  productUploadRows: IProductUploadRowDocumentV3[],
) {
  const invalidRows: string[][] = getInvalidRows(productUploadRows);
  const datasheet: Excel.Worksheet = workbook.getWorksheet('Data');
  invalidRows.forEach((row, rowIndex) => {
    row.forEach((column, i) => {
      const columnName: string = getExcelColumnName(i + 1);
      datasheet.getCell(`${columnName}${rowIndex + 2}`).value = column;
    });
  });
}

function getInvalidRows(
  productUploadRows: IProductUploadRowDocumentV3[],
): string[][] {
  return productUploadRows.map((row) => {
    return map(row.row, 'value');
  });
}

function getProductRows(
  fields: FieldType[],
  products: IProductContent[],
): string[][] {
  return products.reduce(
    (productsRows: string[][], product: IProductContent): string[][] => {
      const paths: string[][] = fields.map((field) => {
        return getPossiblePaths(product, field.field);
      });
      const maximumRepeatedFields: string[] = paths.reduce(
        (previous, current): string[] => {
          return current.length > previous.length ||
            current[0]?.split('.').length > previous[0]?.split('.').length
            ? current
            : previous;
        },
        [],
      );

      return productsRows.concat(
        maximumRepeatedFields.map((repeatedFieldName): string[] => {
          const repeatedFieldBaseName: string = repeatedFieldName
            .split('.')
            .slice(0, repeatedFieldName.split('.').length - 1)
            .join('.');

          return paths.map((fieldPaths): string => {
            const rightPath: string = fieldPaths.find((path) => {
              const pathBaseName: string = repeatedFieldName
                .split('.')
                .slice(0, repeatedFieldName.split('.').length - 1)
                .join('.');
              return (
                !pathBaseName || repeatedFieldBaseName.includes(pathBaseName)
              );
            });

            const field: FieldType = getFieldByPath(rightPath, fields);
            let value: any =
              get(product, FIELD_MAP[rightPath] || rightPath) || '';
            field?.sheetSanitizers?.forEach((fn) => {
              value = fn(value);
            });

            field?.dependSheetSanitizers?.forEach((fn) => {
              value = fn(product);
            });

            return value;
          });
        }),
      );
    },
    [],
  );
}

function getPossiblePaths(product: IProductContent, path: string): string[] {
  const finalPaths: string[] = [];
  const parts: string[] = path.split('.');

  findPath(product, [], 0, parts, finalPaths);
  return finalPaths.length ? finalPaths : [path];
}

function getFieldByPath(path: string, fields: FieldType[]): FieldType {
  return fields.find((field) => {
    return field.field == path?.replace(/\.\d/g, '.*');
  });
}

function findPath(
  obj: any,
  iterParts: string[],
  partIndex: number,
  parts: string[],
  finalPaths: string[],
) {
  if (partIndex === parts.length) {
    finalPaths.push(iterParts.join('.'));
    return;
  }
  if (!obj || typeof obj !== 'object') {
    return;
  }
  if (parts[partIndex] === '*') {
    Object.keys(obj).forEach(function (starIndex) {
      findPath(
        obj[starIndex],
        iterParts.concat(starIndex),
        partIndex,
        parts,
        finalPaths,
      );
      findPath(
        obj[starIndex],
        iterParts.concat(starIndex),
        partIndex + 1,
        parts,
        finalPaths,
      );
    });
    return;
  }
  if (parts[partIndex] in obj) {
    findPath(
      obj[parts[partIndex]],
      iterParts.concat(parts[partIndex]),
      partIndex + 1,
      parts,
      finalPaths,
    );
  }
}

function addMetaDataSheet(
  workbook: Excel.Workbook,
  params: IGetTemplateParams,
) {
  const metaWorksheet: Excel.Worksheet = workbook.getWorksheet(4);
  const { fields, categories, collections, isBackoffice } = params;

  metaWorksheet.getCell('A1').value = 'DO NOT CHANGE VALUES BELOW';
  metaWorksheet.getCell('A2').value = fields.join('@@');
  metaWorksheet.getCell('A3').value = Object.keys(categories).join('@@');
  metaWorksheet.getCell('A4').value = Object.keys(collections).join('@@');
  metaWorksheet.getCell('A5').value = isBackoffice;
}

export async function getSheetByIndex(
  file: any,
  index: number,
): Promise<Excel.Worksheet> {
  const workbook: Excel.Workbook = await getWorkbook(file.path);
  return workbook.getWorksheet(index);
}

export async function getFieldsFromSheet(
  metadataSheet: Excel.Worksheet,
  categoryIds: string[],
  supplierCompanyId: string,
  email: string = '',
): Promise<FieldType[]> {
  const fields: string[] = metadataSheet
    .getCell('A2')
    .value.toString()
    .split('@@');
  const collectionIds: string[] = metadataSheet
    .getCell('A4')
    ?.value?.toString()
    ?.split('@@')
    ?.filter(Boolean);
  const isBackoffice: string = metadataSheet.getCell('A5').value.toString();
  const categoryAttributes: CategoryAttributeType[] = await getCategoryAttributes(
    categoryIds,
  );
  const collections: Record<
    string,
    ICollectionModel
  > = await getProductsCollections(collectionIds, 'slug');
  const categories: Record<
    string,
    ICategoryModel
  > = await getProductsCategories(categoryIds, 'slug');
  return getSelectedFields({
    fields,
    categoryAttributes,
    categories,
    collections,
    isBackoffice: isBackoffice === 'true',
    email,
    isTradeling: isTheUSerHasPermissionToSkipGuardrails(email)
      ? false
      : isTradelingCompany([supplierCompanyId]),
  }).filter((field) => {
    return !field.shouldRemoveFromSheet && !field.shouldExclude;
  });
}

export function mapRowDataToFields(
  rowData: string[][],
  fields: FieldType[],
): KeyValAny[] {
  return rowData.map(
    (row): KeyValAny => {
      return fields.reduce(
        (obj: KeyValAny, field: FieldType, index: number): KeyValAny => {
          return {
            ...obj,
            [fields[index].field]: row[index] || '',
          };
        },
        {},
      );
    },
  );
}

export function getProductUploadRows(
  rows: KeyValAny[],
  fields: FieldType[],
  upload: IUploadModelV3,
  offers: Record<string, IOfferModelV3>,
): IProductUploadRowDocumentV3[] {
  const productUploadRowsMap: Record<string, IProductUploadRowDocumentV3> = {};

  rows.forEach((row, index) => {
    let isValid: boolean = true;
    const productUploadRowCells: DraftCell[] = [];
    const offer: IOfferModelV3 = offers[row?.sku];
    const productUploadRowFields: KeyValAny = fields.reduce(
      (productUploadRowFields: KeyValAny, field: FieldType): KeyValAny => {
        const fieldName: string = field?.field;
        let value: any = row[fieldName];
        let error: string = null;

        if (value === '""') {
          value = '';
        }

        field.sanitizers.forEach((sanitize) => {
          value = sanitize(value);
        });

        if (!isEmpty(row[fieldName])) {
          field.validators.forEach((validator) => {
            if (!validator(value)) {
              isValid = false;
              error = field.invalidValueMessage;
            }
          });
        }

        field.dependValidators?.forEach((validator) => {
          if (!validator(value, row, offer)) {
            isValid = false;
            error = field.invalidValueMessage;
          }
        });

        field.dependSanitizers?.forEach((sanitize) => {
          value = sanitize(row);
        });

        if (['', null, undefined].includes(value) && field.required && !error) {
          isValid = false;
          error = 'Field is required';
        }

        productUploadRowCells.push({
          field: field.field,
          label: field.label,
          value: row[fieldName],
          error,
        });

        if (field.field.includes('*')) {
          field.field = field.field.replace(
            '*',
            productUploadRowsMap[row.sku] ? '1' : '0',
          );
        }

        if (!field.shouldRemove && row[fieldName] !== '') {
          lodash.set(
            productUploadRowFields,
            FIELD_MAP[field.field] || field.field,
            value,
          );
        }
        return productUploadRowFields;
      },
      productUploadRowsMap[row.sku]?.fields || {},
    );
    productUploadRowsMap[row.sku] = {
      supplierCompanyId:
        productUploadRowFields?.supplierCompanyId || upload?.supplierCompanyId,
      supplierId:
        upload?.supplierId || productUploadRowFields?.supplierCompanyId || null,
      userId:
        upload?.supplierId || productUploadRowFields?.supplierCompanyId || null,
      uploadId: upload?._id,
      categoryId: productUploadRowFields?.categoryId,
      line: index + 1,
      fields: productUploadRowFields,
      state: isValid ? DraftState.Valid : DraftState.Invalid,
      attributes: {},
      row: productUploadRowCells,
    };
  });
  return Object.values(productUploadRowsMap);
}

export function shouldMergeVendorWithOffer(
  supplierCompanyIds: string[],
  fields: string[],
): boolean {
  return (
    isTradelingCompany(supplierCompanyIds) &&
    fields.some((field) => ['vendor', 'offer'].includes(field))
  );
}

export function isTradelingCompany(supplierCompanyIds: string[]): boolean {
  return supplierCompanyIds.some((id) =>
    appConfig.tradelingExpressIds.includes(id),
  );
}

export function isTheUSerHasPermissionToSkipGuardrails(email: string): boolean {
  return appConfig.EmailsCanOverrideGuardRails.includes(email);
}

export function isTheUSerHasPermissionToUpdateRebate(email: string): boolean {
  return appConfig.EmailsCanUpdateRebate.includes(email);
}
