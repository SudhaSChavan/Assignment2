import { map, isEmpty, last } from 'lodash';
import { ICategoryModel } from '../../../category/model-category';
import { ICollectionModel } from '../../../collection/model-collection';
import { sizeUnits, UnitType, weightUnits } from '../../helpers';
import { ISubSupplierCompany } from '../../../offer/model-offers-v3';
import {
  isTheUSerHasPermissionToSkipGuardrails,
  isTradelingCompany,
} from '@express/modules/upload/v3/partial-update/template-utils';
import { getCommissionValue } from '@express/modules/util/helpers';
import { formatPrice } from '@tradeling/web-js-utils';

export function fromBoolean(value: boolean): string {
  return value ? 'Yes' : 'No';
}

export function toKeyFeatures(index: number): (value: string) => string {
  return (value): string => {
    return value.split('@@')[index] || '';
  };
}

export function sanitizeSubSupplierCompany(
  keyName: string,
): (value: ISubSupplierCompany[]) => string {
  return (value = []): string => {
    return map(value, keyName).join(';');
  };
}

export function sanitizeParentSku(row: any): string {
  return row?.hasVariants ? row?.parentSku : '';
}

export function toKeywords(value: string[] = []): any {
  return Array.isArray(value) ? value?.join(',') : value;
}

export function toCategorySlug(
  categories: Record<string, ICategoryModel>,
): (value: string) => string {
  return (value): string => {
    return categories[value]?.slug;
  };
}

export function toCategoryId(
  categories: Record<string, ICategoryModel>,
): (value: string) => string {
  return (value): string => {
    return categories[value]?._id.toString();
  };
}

export function toCollectionSlugs(
  collections: Record<string, ICollectionModel>,
): (value: string[]) => string {
  return (collectionIds): string => {
    return Array.isArray(collectionIds)
      ? collectionIds
          ?.map((collectionId) => {
            return collections[collectionId]?.slug;
          })
          .join(',')
      : '';
  };
}

export function toCollectionIds(
  collections: Record<string, ICollectionModel>,
): (value: string) => string[] {
  return (collectionSlugs): string[] => {
    return collectionSlugs.split(',').map((collectionSlug) => {
      return collections[collectionSlug]?._id;
    });
  };
}

export function toWeightUnitLabel(value: any): string {
  const givenValue: string = String(value).toLowerCase().trim();

  const found: UnitType = weightUnits.find(
    (sizeUnit: UnitType): boolean => sizeUnit.code.toLowerCase() === givenValue,
  );

  return found?.label || null;
}

export function toSizeUnitLabel(value: any): string {
  const givenValue: string = String(value).toLowerCase().trim();

  const found: UnitType = sizeUnits.find(
    (sizeUnit: UnitType): boolean => sizeUnit.code.toLowerCase() === givenValue,
  );

  return found?.label || null;
}

export function toUnit(value: any): string {
  const givenValue: string = String(value).toLowerCase().trim();

  const found: UnitType = unitsOfMeasure.find(
    (sizeUnit: UnitType): boolean => sizeUnit.code.toLowerCase() === givenValue,
  );

  return found?.label || null;
}

export function toShortDescription(lang: string): (value: any) => string {
  return (row): string => {
    return [
      row[`keyFeature1.${lang}`],
      row[`keyFeature2.${lang}`],
      row[`keyFeature3.${lang}`],
      row[`keyFeature4.${lang}`],
      row[`keyFeature5.${lang}`],
      row[`keyFeature6.${lang}`],
    ]
      .filter(Boolean)
      .join('@@');
  };
}

export function toNumber(value: string): number {
  return value ? Number(value) : null;
}

export function toPrice(value: string): number {
  return value ? formatPrice(Number(value)) : null;
}

export function toSubSupplierCompany(row: any): ISubSupplierCompany[] {
  const subSupplierCompanies: ISubSupplierCompany[] = [];
  const subSupplierCompanyIds: string[] = row.subSupplierCompanyIds?.split(';');
  const vendorSku: string[] = row.vendorSku?.split(';');
  const costPrices: string[] = row.costPrices?.split(';');
  const rebates: string[] = row.rebate?.split(';');
  for (let i: number = 0; i < subSupplierCompanyIds.length; i++) {
    if (!subSupplierCompanyIds[i] || !costPrices[i]) continue;

    subSupplierCompanies.push({
      subSupplierCompanyId: subSupplierCompanyIds[i],
      vendorSku: vendorSku[i],
      costPrice: parseFloat(costPrices[i]),
      ...(rebates ? { rebate: parseFloat(rebates[i] || '0') } : {}),
    });
  }
  return subSupplierCompanies;
}

export function validateSalePrice(
  isTradelingSheet: boolean,
  email?: string,
): (value: any, row: any, offer: any) => boolean {
  return (value: any, row: any, offer: any): boolean => {
    if (email && isTheUSerHasPermissionToSkipGuardrails(email)) {
      return true;
    }
    const isTradelingRow: boolean = row.supplierCompanyId
      ? isTradelingCompany([row.supplierCompanyId])
      : isTradelingSheet;
    const latestCostPrice: number = parseFloat(
      row.costPrices?.split(';').pop(),
    );
    const lastSupplierObj: any = last(offer?.subSupplierCompanies);
    const rebate =
      parseFloat(row.rebate?.split(';').pop()) ||
      parseFloat(lastSupplierObj?.rebate);
    return (
      !isTradelingRow ||
      !value ||
      !latestCostPrice ||
      parseFloat(value) >= getCommissionValue(latestCostPrice, rebate || 0)
    );
  };
}

export function requiredIfFieldsHaveValue(
  fields: string[],
): (value: any, row: any) => boolean {
  return (value, row): boolean => {
    let isOneFieldHaveValue: boolean = false;
    fields.forEach((field) => {
      if (!isEmpty(row[field]?.toString()) && row[field]?.toString() !== '""') {
        isOneFieldHaveValue = true;
      }
    });
    return !(isEmpty(value?.toString()) && isOneFieldHaveValue);
  };
}

export function greaterThanCategoryMinQty(
  categories: Record<string, ICategoryModel>,
): (value: any, row: any) => boolean {
  return (value, row): boolean => {
    const category: ICategoryModel = categories[row?.categoryId];
    console.log(category);
    return category?.moq <= value;
  };
}

export function requiredInCaseOfTradeling(value: any, row: any): boolean {
  return !(isEmpty(value) && isTradelingCompany([row.supplierCompanyId]));
}

export function greaterThanField(
  field: string,
): (value: any, row: any) => boolean {
  return (value: any, row: any): boolean =>
    !value || parseFloat(value) > row[field];
}

export function nextNumberAfterField(
  field: string,
): (value: any, row: any) => boolean {
  return (value: any, row: any): boolean => {
    return !value || parseFloat(value) == parseFloat(row[field]) + 1;
  };
}

export const unitsOfMeasure: UnitType[] = [
  { code: 'kg', label: 'KG' },
  { code: 'gr', label: 'GR' },
  { code: 'lb', label: 'LB' },
  { code: 'lt', label: 'LT' },
  { code: 'cl', label: 'CL' },
  { code: 'ml', label: 'ML' },
  { code: 'gal', label: 'Gal' },
  { code: 'floz', label: 'fl_oz' },
  { code: 'piece', label: 'Piece' },
  { code: 'carton', label: 'Carton' },
  { code: 'packet', label: 'Packet' },
  { code: 'pack', label: 'Pack' },
  { code: 'box', label: 'Box' },
  { code: 'roll', label: 'Roll' },
];
