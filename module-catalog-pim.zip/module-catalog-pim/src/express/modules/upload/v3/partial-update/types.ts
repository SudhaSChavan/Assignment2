import { ICategoryModel } from '../../../category/model-category';
import { ICollectionModel } from '../../../collection/model-collection';
import { InternalReviewStatusType } from '../../../product/types';
import { CategoryAttributeType } from '../../../category/model-category-attribute';
import { IProductDocumentV3 } from '../../../product/model-product-v3';
import { IProductUploadRowModelV3 } from '@express/modules/upload/model-product-upload-row-v3';

type V3Offer = Components.Schemas.V3Offer;

export interface IProductFilterQuery {
  categoryIds?: string[];
  supplierCompanyIds?: string[];
  state?: string;
  isInStock?: boolean;
  internalReviewStatus?: InternalReviewStatusType[];
  websiteCode?: string;
}

export interface IProductContent extends IProductDocumentV3 {
  _id: string;
  offers: V3Offer[];
}

export interface IGetTemplateParams {
  fields?: string[];
  products?: IProductContent[];
  categories?: Record<string, ICategoryModel>;
  collections?: Record<string, ICollectionModel>;
  categoryAttributes?: CategoryAttributeType[];
  isBackoffice?: boolean;
  invalidRows?: IProductUploadRowModelV3[];
  isTradeling?: boolean;
  email?: string;
}
