import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { appConfig } from '@src/config/env';
import { validateFileUpload } from '@core/util/validators';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { IMediaFile } from '../../media/types';
import Excel from 'exceljs';
import { FieldType, getRawData, isBackoffice } from '../helpers';
import { storeUploadFile } from './helpers';
import {
  getFieldsFromSheet,
  getProductUploadRows,
  getSheetByIndex,
  mapRowDataToFields,
} from './partial-update/template-utils';
import { KeyValAny } from '@src/types/common';
import { mongo, Types } from 'mongoose';
import { saveProductUploadRows } from './partial-update/helpers';
import { joinUrl } from '@core/util/url';
import { IUploadModelV3 } from '../model-upload-v3';
import { IProductUploadRowDocumentV3 } from '../model-product-upload-row-v3';
import { map, keyBy } from 'lodash';
import { UploadType } from '@express/modules/product/types';
import { IBaseAppUser } from '@tradeling/web-js-utils';
import {
  IProductModelV3,
  productModelV3,
} from '@express/modules/product/model-product-v3';
import {
  IOfferModelV3,
  offerModelV3,
} from '@express/modules/offer/model-offers-v3';

interface IReq extends IAppRequest {
  body: Paths.V3UploadPartialProductAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3UploadPartialProductAction.Responses.$200) => this;
}

export const validateUploadPartialProductsV3: BaseValidationType = [
  validateFileUpload({
    maxFileSize: appConfig.product.maxFileSizeBytes,
    extensions: ['xlsx'],
    maxFiles: 1,
  }),
  reqValidationResult,
];

export async function uploadPartialProductsActionV3(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    userId,
    supplierId,
    supplierCompanyId,
    platform,
    userJwtDecoded,
  } = req;

  const { files }: { files: IMediaFile[] } = req.body as any;
  const dataSheet: Excel.Worksheet = await getSheetByIndex(files[0], 2);
  const rawData: string[][] = getRawData(dataSheet);

  const metadataSheet: Excel.Worksheet = await getSheetByIndex(files[0], 4);
  const categoryIds: string[] = metadataSheet
    .getCell('A3')
    .value.toString()
    .split('@@');
  const fields: FieldType[] = await getFieldsFromSheet(
    metadataSheet,
    categoryIds,
    supplierCompanyId,
    (userJwtDecoded as IBaseAppUser)?.email,
  );

  const fieldNames: string[] = metadataSheet
    .getCell('A2')
    .value.toString()
    .split('@@');
  const collectionIds: string[] = metadataSheet
    .getCell('A4')
    ?.value?.toString()
    ?.split('@@')
    ?.filter(Boolean);

  const mappedRows: KeyValAny[] = mapRowDataToFields(
    rawData,
    Object.values(fields).filter((field) => {
      return !field.shouldRemoveFromSheet;
    }),
  );

  let productUpload: IUploadModelV3 = await storeUploadFile(
    {
      file: files[0],
      uid: {
        userId,
        supplierCompanyId:
          mappedRows[0]['supplierCompanyId'] || supplierCompanyId,
        supplierId,
      },
      template: 'partial-product-update',
      categoryIds: categoryIds
        // @ts-ignore
        .filter((id) => Types.ObjectId.isValid(id))
        .map((id) => new mongo.ObjectID(id)),
      collectionIds,
      fields: fieldNames,
      type: UploadType.Product,
    },
    isBackoffice(platform),
  );
  const skus: string[] = map(mappedRows, 'sku');
  const products: IProductModelV3[] = await productModelV3.find({
    sku: { $in: skus },
    supplierCompanyId: { $in: appConfig.tradelingExpressIds },
  });
  const productsObj: Record<string, IProductModelV3> = keyBy(products, '_id');
  const offers: IOfferModelV3[] = await offerModelV3.find({
    productId: { $in: map(products, '_id') },
    'subSupplierCompanies.0': { $exists: true },
  });
  const offersObj: Record<string, IOfferModelV3> = {};
  offers.forEach((offer) => {
    const product: IProductModelV3 = productsObj[offer?.productId];
    offersObj[product?.sku] = offer;
  });
  const productUploadRows: IProductUploadRowDocumentV3[] = getProductUploadRows(
    mappedRows,
    Object.values(fields),
    productUpload,
    offersObj,
  );
  productUpload = await saveProductUploadRows(productUploadRows, productUpload);

  res.json({
    ...productUpload.toJSON(),
    url: joinUrl(appConfig.mediaBaseUrl, productUpload.path),
  });
}
