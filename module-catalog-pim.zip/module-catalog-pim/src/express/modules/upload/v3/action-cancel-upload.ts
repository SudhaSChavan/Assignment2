import { body } from 'express-validator';
import { StatusCodes } from 'http-status-codes';
import {
  BaseValidationType,
  HttpError,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { ERRORS } from '@src/types/errors';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { EE } from '@src/config/event/emitter';
import { logger } from '@core/util/logger';
import {
  IUploadModelV3,
  UPLOAD_STATE,
  uploadModelV3,
} from '../model-upload-v3';

export enum CancelUploadEvent {
  Success = 'product.cancelUpload.success',
}

interface IReq extends IAppRequest {
  body: Paths.V3CancelUploadAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3CancelUploadAction.Responses.$200) => this;
}

export const validateCancelUploadV3: BaseValidationType = [
  body('uploadId').not().isEmpty().isMongoId().withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function cancelUploadActionV3(
  req: IReq,
  res: IRes,
): Promise<IRes> {
  const {
    supplierCompanyId,
    body: { uploadId },
  } = req;

  const productUpload: IUploadModelV3 = await uploadModelV3.findOne({
    _id: uploadId,
    ...(!!req.cookies.backofficeJwtToken ? {} : { supplierCompanyId }),
  });

  if (!productUpload) {
    throw new HttpError(StatusCodes.NOT_FOUND, ERRORS.NOT_FOUND);
  }

  if (productUpload.get('state') !== UPLOAD_STATE.NEW) {
    throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.NOT_ALLOWED);
  }

  const updateResult: any = await uploadModelV3.updateOne(
    {
      _id: uploadId,
    },
    {
      $set: {
        state: UPLOAD_STATE.CANCELED,
      },
    },
  );

  EE.emit(CancelUploadEvent.Success, uploadId).catch((error: Error): void => {
    logger.error(`Event ${CancelUploadEvent.Success} failed: ${error.stack}`);
  });

  return res.json({
    isUpdated: updateResult && updateResult.nModified === 1,
  });
}
