import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import {
  categoryAttributeModel,
  ICategoryAttributeModel,
} from '../../category/model-category-attribute';
import { filter, uniq } from 'lodash';
import { getFields } from './partial-update/fields';

interface IReq extends IAppRequest {
  body: Paths.V3GetPartialUploadFieldsAction.RequestBody;
}

interface IRes extends IAppResponse {
  body: (body: Paths.V3GetPartialUploadFieldsAction.Responses.$400) => this;
}

export const validateGetPartialUpdateFieldsV3: BaseValidationType = [
  // prettier-ignore
  body('categoryIds')
    .optional()
    .isArray()
    .isMongoId(),
  reqValidationResult,
];

export async function getPartialUpdateFieldsV3(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { categoryIds } = req.body;
  let categoryFields: string[] = [];
  const catAttributes: ICategoryAttributeModel[] = await categoryAttributeModel
    .find({
      categoryId: { $in: categoryIds },
    })
    .lean();

  const allFields: Record<any, any> = getFields({
    categoryAttributes: [],
    fields: [],
  });

  const combinedFields: any = [
    ...allFields?.availability,
    ...allFields?.content,
  ];
  const rest: any = combinedFields.map((field: any) => {
    return {
      code: field.field,
      name: field.label,
    };
  });

  categoryFields = filter(uniq(getCategoryAttributesFields(catAttributes)));

  res.json([...rest, ...categoryFields]);
}

export function getCategoryAttributesFields(
  attributes: ICategoryAttributeModel[],
): string[] {
  return attributes.flatMap((attribute: any): any => {
    return attribute.attributes.flatMap((attr: any): any => {
      return [{ code: `attributes.${attr?.code}`, name: attr?.label?.en }];
    });
  });
}
