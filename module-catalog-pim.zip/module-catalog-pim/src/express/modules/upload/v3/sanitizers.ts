import { isEmpty } from 'lodash';
import { ICategoryModel } from '../../category/model-category';
import { generateRandomSku } from '../helpers';
import { ISubSupplierCompany } from '../../offer/model-offers-v3';

export function toCategoryId(
  categories: Record<string, ICategoryModel>,
): (value: string) => string {
  return (value): string => {
    return categories[value]?._id;
  };
}

export function toShortDescription(lang: string): (value: any) => string {
  return (row): string => {
    return [
      row[`keyFeature1.${lang}`],
      row[`keyFeature2.${lang}`],
      row[`keyFeature3.${lang}`],
      row[`keyFeature4.${lang}`],
      row[`keyFeature5.${lang}`],
      row[`keyFeature6.${lang}`],
    ]
      .filter(Boolean)
      .join('@@');
  };
}

export function toNumber(value: string): number {
  return value ? Number(value) : null;
}

export function toParentSku(row: any): number {
  return row.parentSku && row.parentSku !== '""' ? row.parentSku : row.sku;
}

export function toSubSupplierCompany(row: any): ISubSupplierCompany[] {
  const subSupplierCompanies: ISubSupplierCompany[] = [];
  const subSupplierCompanyIds: string[] = row.subSupplierCompanyIds?.split(';');
  const vendorSku: string[] = row.vendorSku?.split(';');
  const costPrices: string[] = row.costPrices?.split(';');
  for (let i: number = 0; i < subSupplierCompanyIds.length; i++) {
    if (!subSupplierCompanyIds[i] || !costPrices[i]) continue;

    subSupplierCompanies.push({
      subSupplierCompanyId: subSupplierCompanyIds[i],
      vendorSku: vendorSku[i],
      costPrice: parseFloat(costPrices[i]),
    });
  }
  return subSupplierCompanies;
}

export function toPostfix(row: any): string {
  return `${
    row['variantValues.0.value.en'] && row['variantValues.0.value.en'] !== '""'
      ? row['variantValues.0.value.en']
      : ''
  }${
    row['variantValues.1.value.en'] && row['variantValues.1.value.en'] !== '""'
      ? `, ${row['variantValues.1.value.en']}`
      : ''
  }`;
}

export function generateInCaseOf(
  shouldGenerate: boolean,
): (value: any) => string {
  return (value: any): string =>
    shouldGenerate && !value ? generateRandomSku() : value;
}

export function hasVariant(row: any): boolean {
  return !isEmpty(row.parentSku?.trim()) && row.parentSku?.trim() !== '""';
}

export function requiredIfFieldsHaveValue(
  fields: string[],
): (value: any, row: any) => boolean {
  return (value, row): boolean => {
    let isOneFieldHaveValue: boolean = false;
    fields.forEach((field) => {
      if (!isEmpty(row[field]?.toString().trim())) {
        isOneFieldHaveValue = true;
      }
    });
    return !(isEmpty(value?.toString()) && isOneFieldHaveValue);
  };
}

export function notRequiredIfFieldsDontHaveValue(
  fields: string[],
): (value: any, row: any) => boolean {
  return (value, row): boolean => {
    let isAllFieldDoesntHaveValue: boolean = true;
    fields.forEach((field) => {
      if (!isEmpty(row[field]?.toString().trim())) {
        isAllFieldDoesntHaveValue = false;
      }
    });
    return isEmpty(value?.toString()) || !isAllFieldDoesntHaveValue;
  };
}

export function parseIntArray(value: string[]): number[] {
  return value.map((item) => parseFloat(item.replace(/,/g, '')));
}
