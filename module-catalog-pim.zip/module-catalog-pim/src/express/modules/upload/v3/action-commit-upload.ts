import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { ERRORS } from '@src/types/errors';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { HttpError, StoreType } from '@tradeling/web-js-utils';
import { StatusCodes } from 'http-status-codes';
import {
  CommitUploadEvent,
  CommitUploadEventType,
  DraftState,
  InternalReviewStatuses,
  ProductMediaType,
  ProductStates,
} from '../../product/types';
import { get, keyBy, map, omit } from 'lodash';
import {
  IProductDocumentV3,
  IProductModelV3,
  productModelV3,
} from '../../product/model-product-v3';
import { formatPackagingInfo, isPartialUpdateTemplate } from '../helpers';
import { offerModelV3 } from '../../offer/model-offers-v3';
import { logger } from '@core/util/logger';
import { EE } from '@src/config/event/emitter';
import {
  getMarketCode,
  getMarketLabel,
  refreshBulkConfigurationAttributes,
} from './helpers';
import {
  IProductUploadRowDocumentV3,
  IProductUploadRowModelV3,
  productUploadRowModelV3,
} from '../model-product-upload-row-v3';
import {
  IUploadModelV3,
  UPLOAD_STATE,
  uploadModelV3,
} from '../model-upload-v3';
import { commitPartialUpdate } from './partial-update/commit-upload';
import {
  ProductSyncEvent,
  ProductSyncEventType,
} from '../../product/sync-hlper';

export type V3CommitUpload = {
  productIds: string[];
  uploadId: string;
  successfulCount: number;
  skippedCount: number;
};

export enum CommitUploadEventV3 {
  Success = 'product.commitUpload.success',
}

export type CommitUploadEventTypeV3 = {
  req: IAppRequest;
  uploadId: string;
  uploadType: string;
  productIds: string[];
};

interface IReq extends IAppRequest {
  body: Paths.V3CommitUploadAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3CommitUploadAction.Responses.$200) => this;
}

export const validateCommitUploadV3: BaseValidationType = [
  body('uploadId').notEmpty().isMongoId().withMessage(ERRORS.INVALID), //
  reqValidationResult,
];

export async function commitUploadActionV3(
  req: IReq,
  res: IRes,
): Promise<IRes> {
  const {
    supplierId,
    body: { uploadId },
    store,
  } = req;

  const byBackOffice: boolean = !req.supplierId;

  const upload: IUploadModelV3 = await getAndValidateUpload(
    uploadId,
    supplierId,
    byBackOffice,
  );

  let commitRes: V3CommitUpload;
  let eventType: string;

  if (isPartialUpdateTemplate(upload.uploadType)) {
    commitRes = await commitPartialUpdate(uploadId, req);
    eventType = ProductSyncEvent.PartialUpdated;
  } else {
    commitRes = await getCommitUploadProducts(
      uploadId,
      upload.supplierCompanyId,
      store,
      upload?.supplierId,
    );
    eventType = ProductSyncEvent.BulkUpload;
  }
  // emit event -- update uploads and upload Row
  EE.emit(CommitUploadEvent.Success, {
    req,
    uploadId,
    uploadType: upload.uploadType,
    productIds: commitRes.productIds,
  } as CommitUploadEventType).catch((error: Error): void => {
    logger.error(`Event ${CommitUploadEvent.Success} failed: ${error.stack}`);
  });

  // emit event for sync model
  EE.emit(eventType, {
    req,
    productIds: commitRes.productIds,
    priority: 'normal',
  } as ProductSyncEventType).catch((error: Error): void => {
    logger.error(`Event ${ProductSyncEvent.Updated} failed: ${error.stack}`);
  });

  return res.json(commitRes);
}

async function getCommitUploadProducts(
  uploadId: string,
  supplierCompanyId: string,
  store: StoreType,
  supplierId: string,
) {
  const validProductUploadRows: IProductUploadRowModelV3[] = await getProductUploadRows(
    uploadId,
  );
  const skippedCount: number = await productUploadRowModelV3.countDocuments({
    uploadId,
    state: DraftState.Invalid,
  });
  const successfulCount: number = validProductUploadRows.length;

  // const productIds: string[] = await updateProducts(validProductUploadRows, supplierCompanyId);
  const productIds: any = await updateProducts(
    validProductUploadRows,
    supplierCompanyId,
    store,
    supplierId,
    uploadId,
  );
  await markDataAsCompleted(uploadId);

  return {
    uploadId,
    successfulCount,
    skippedCount,
    productIds: map(productIds, '_id'),
  };
}

async function markDataAsCompleted(uploadId: string): Promise<void> {
  await uploadModelV3.findByIdAndUpdate(uploadId, {
    state: UPLOAD_STATE.IMPORTED,
  });
  await productUploadRowModelV3.updateMany(
    {
      uploadId,
      state: DraftState.Valid,
    },
    {
      state: DraftState.Published,
    },
  );
}

async function getProductUploadRows(
  uploadId: string,
): Promise<IProductUploadRowModelV3[]> {
  const validProductUploadRows: IProductUploadRowModelV3[] = await productUploadRowModelV3
    .find({ uploadId, state: { $in: [DraftState.Valid, DraftState.Draft] } })
    .lean();

  if (!validProductUploadRows || validProductUploadRows.length === 0) {
    throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.NOT_ALLOWED);
  }
  return validProductUploadRows;
}

async function getAndValidateUpload(
  uploadId: string,
  supplierId: string,
  byBackoffice: boolean,
): Promise<IUploadModelV3> {
  const upload: IUploadModelV3 = await uploadModelV3.findOne({
    _id: uploadId,
    ...(byBackoffice ? {} : { supplierId }),
  });

  if (!upload) {
    throw new HttpError(StatusCodes.NOT_FOUND, ERRORS.NOT_FOUND);
  }

  if (upload.get('state') !== UPLOAD_STATE.NEW) {
    throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.NOT_ALLOWED);
  }
  return upload;
}

/**
 *
 * @param validProductUploadRows
 * @param supplierCompanyId
 */
async function updateProducts(
  validProductUploadRows: IProductUploadRowModelV3[],
  supplierCompanyId: string,
  store: StoreType,
  supplierId: string,
  uploadId: string,
) {
  const updatedSkus: string[] = validProductUploadRows.map(
    (uploadRow: any): string => get(uploadRow, 'fields.sku').toUpperCase(),
  );
  const parentSkus: string[] = validProductUploadRows.map(
    (uploadRow: any): string =>
      get(uploadRow, 'fields.parentSku')?.toUpperCase(),
  );
  const newSku: string[] = [];

  // top match the new structure -- variants should has new condition ... not this one
  const existingProducts: IProductDocumentV3[] = await productModelV3
    .find({ sku: { $in: updatedSkus }, supplierCompanyId })
    .lean();
  const variants: Record<string, IProductDocumentV3> = keyBy(
    existingProducts,
    'sku',
  );

  //validate new products
  const validNewProductUploadRows: IProductUploadRowDocumentV3[] = validProductUploadRows.filter(
    (productUploadRow) => {
      const sku: string = productUploadRow?.fields?.sku?.toUpperCase();
      const isNewProduct: boolean = !variants[sku];
      isNewProduct ? newSku.push(sku) : false;
      return isNewProduct;
    },
  );

  // insert new products
  const bulkOperations: any = getBulkNewProducts(
    validNewProductUploadRows,
    supplierCompanyId,
    store,
  );
  await productModelV3.bulkWrite(bulkOperations);
  const uploadedOffers: any[] = getOffersFromProductUploadRow(
    validNewProductUploadRows,
  );
  await createOffersWithVariants(uploadedOffers, supplierId, supplierCompanyId);
  await refreshBulkConfigurationAttributes(parentSkus, supplierCompanyId);

  return productModelV3
    .find({ sku: { $in: newSku }, supplierCompanyId }, '_id')
    .lean();
}

async function createOffersWithVariants(
  offers: any,
  supplierId: string,
  supplierCompanyId: string,
) {
  const variantSkus: string[] = map(offers, 'variantSku');
  const variants: IProductModelV3[] = await productModelV3
    .find({ sku: { $in: variantSkus }, supplierCompanyId })
    .lean();
  const variantsBySkus: Record<string, IProductModelV3> = keyBy(
    variants,
    'sku',
  );
  const newOffers: any[] = offers.map((offerRow: any) => {
    const { delivery, ...offer } = offerRow;
    const currency: string = offer?.market?.currency;
    return {
      updateOne: {
        filter: {
          productId: variantsBySkus[offer.variantSku]?._id,
          supplierId,
          supplierCompanyId,
        },
        update: {
          ...offer,
          market: {
            currency: currency,
            label: getMarketLabel(currency),
            code: getMarketCode(currency),
            tiers: offer.market.tiers.map((tier: any, index: number) => ({
              ...tier,
              maxQty: offer.market.tiers[index + 1]
                ? offer.market.tiers[index + 1].minQty
                : 1000000,
              tierCode: `TIERS-${index}`,
            })),
          },

          productId: variantsBySkus[offer.variantSku]?._id,
          'delivery.leadTimeValue': delivery.leadTimeValue,
          supplierId,
          supplierCompanyId,
          isDefault: true,
          isActive: true,
        },
        upsert: true,
        setDefaultsOnInsert: true,
      },
    };
  });
  await offerModelV3.bulkWrite(newOffers);
}

/**
 *
 * @param validNewProductUploadRows
 * @param supplierCompanyId
 * @param store
 */
function getBulkNewProducts(
  validNewProductUploadRows: IProductUploadRowDocumentV3[],
  supplierCompanyId: string,
  store: StoreType,
): any {
  return validNewProductUploadRows.map(
    (productUploadRow: IProductUploadRowModelV3): any => {
      let sortCounter: number = 0;
      const productMedia: ProductMediaType[] = (
        productUploadRow.media || []
      ).map(
        (mediaId: string): ProductMediaType => {
          sortCounter++;
          return {
            id: mediaId,
            type: 'image',
            sort: sortCounter,
          };
        },
      );

      const defaults: any = omit(
        new productModelV3().toJSON({ minimize: false }),
        ['_id'],
      );

      return {
        updateOne: {
          filter: {
            sku: productUploadRow.fields.sku.toUpperCase(),
            supplierCompanyId,
          },
          update: {
            $set: {
              ...defaults,
              ...productUploadRow.fields,
              hasVariants: productUploadRow?.fields?.hasVariants,
              internalReviewStatus: InternalReviewStatuses.Pending,
              categoryId: productUploadRow.categoryId,
              packagingFormat: formatPackagingInfo(
                productUploadRow.fields.unit,
                productUploadRow.fields.packaging,
              ),
              media: productMedia,
              supplierCompanyId,
              state: ProductStates.Offline,
              lastUploadDate: new Date(),
              uploadCount: 1,
              deletedAt: null,
              storeKeyId: store?.storeKeyId,
              websiteCode: store?.website?.websiteCode,
              storeCode: store?.storeCode,
            },
          },
          upsert: true,
        },
      };
    },
  );
}

/**
 *
 * @param validProductUploadRows
 */
function getOffersFromProductUploadRow(validProductUploadRows: any[]) {
  const offers: any[] = [];
  validProductUploadRows.map((productUploadRow) => {
    const offer: any = productUploadRow?.fields?.offer;
    if (offer?.market?.tiers) {
      offers.push({
        ...productUploadRow.fields.offer,
        market: {
          ...productUploadRow.fields.offer.market,
          tiers: productUploadRow.fields.offer.market.tiers
            .filter((tier: any) => !!tier?.price)
            .map((tier: any, index: number) => ({
              ...tier,
              tierCode: `TIERS-${index}`,
            })),
        },
        variantSku: productUploadRow.fields.sku,
      });
    }
  });
  return offers;
}
