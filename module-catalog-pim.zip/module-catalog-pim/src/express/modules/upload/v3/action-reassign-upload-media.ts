import { body } from 'express-validator';
import { get, groupBy, map, uniq } from 'lodash';
import { StatusCodes } from 'http-status-codes';
import { HttpError } from '@tradeling/web-js-utils';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { ERRORS } from '@src/types/errors';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { mediaModel } from '../../media/model-media';
import { DraftState, LeanMediaType } from '../../product/types';
import { IUploadModelV3, uploadModelV3 } from '../model-upload-v3';
import {
  IProductUploadRowModelV3,
  productUploadRowModelV3,
} from '../model-product-upload-row-v3';

interface IReq extends IAppRequest {
  body: Paths.V3ReassignUploadMediaAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3ReassignUploadMediaAction.Responses.$200) => this;
}

export const validateReassignUploadMediaV3: BaseValidationType = [
  body('id').notEmpty().isMongoId(),
  reqValidationResult,
];

export async function reassignUploadMediaActionV3(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    supplierCompanyId,
    body: { id },
  } = req;

  const byBackOffice: boolean = !req.supplierId;

  const upload: IUploadModelV3 = await uploadModelV3
    .findOne({ _id: id, ...(byBackOffice ? {} : { supplierCompanyId }) })
    .lean();

  if (!upload) {
    throw new HttpError(StatusCodes.NOT_FOUND, ERRORS.NOT_FOUND);
  }

  // Get the SKUs for all the products under this upload
  const productUploadRows: IProductUploadRowModelV3[] = await productUploadRowModelV3
    .find({
      uploadId: upload._id,
      ...(byBackOffice ? {} : { supplierCompanyId }),
    })
    .lean();

  const skuList: string[] = productUploadRows.map((uploadRow: any): string =>
    get(uploadRow, 'fields.sku', '').toUpperCase(),
  );

  // @todo do it in chunks of 200. This won't scale - what if a supplier has 100,000 images
  const skuMediaList: LeanMediaType[] = await mediaModel
    .find(
      {
        skuGroup: {
          $in: skuList,
        },
        ...(byBackOffice ? {} : { supplierCompanyId }),
        deletedAt: null,
      },
      '_id skuGroup',
    )
    .lean();

  // Create a hashmap using media SKU groups
  const skuGroupedMedia: Record<string, LeanMediaType[]> = groupBy(
    skuMediaList,
    'skuGroup',
  );

  // Update the product upload rows with the newly found and old images
  const updatedProductUploadRows: IProductUploadRowModelV3[] = productUploadRows.map(
    (productUploadRow: IProductUploadRowModelV3): IProductUploadRowModelV3 => {
      const sku: string = productUploadRow?.fields?.sku?.toUpperCase();

      if (!skuGroupedMedia[sku]) {
        return productUploadRow;
      }

      // Gets all the existing IDs and casts them to string
      const existingMediaIds: string[] = map(
        skuGroupedMedia[sku],
        (mediaGroup: LeanMediaType): string => mediaGroup._id.toString(),
      );
      const foundMediaIds: string[] = (
        productUploadRow.media || []
      ).map((mediaId: any): string => mediaId.toString());

      productUploadRow.media = uniq([...existingMediaIds, ...foundMediaIds]);

      // Change the state to valid if the images were found and assigned
      if (productUploadRow.state === DraftState.Draft) {
        productUploadRow.state = DraftState.Valid;
      }

      return productUploadRow;
    },
  );

  await productUploadRowModelV3.bulkWrite(
    updatedProductUploadRows.map(
      (productUploadRow: IProductUploadRowModelV3): any => ({
        updateOne: {
          filter: {
            _id: productUploadRow._id,
            ...(byBackOffice ? {} : { supplierCompanyId }),
          },
          update: {
            media: productUploadRow.media,
            state: productUploadRow.state,
          },
          upsert: false,
        },
      }),
    ),
  );

  res.json({
    updatedProductUploadRows: updatedProductUploadRows.length,
  });
}
