import { StatusCodes } from 'http-status-codes';
import {
  BaseValidationType,
  HttpError,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { body } from 'express-validator';
import { ERRORS } from '@src/types/errors';
import { DraftState } from '../../product/types';
import {
  IProductUploadRowModelV3,
  productUploadRowModelV3,
} from '../model-product-upload-row-v3';

interface IReq extends IAppRequest {
  body: Paths.V3UnassignProductUploadRowMediaAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body: Paths.V3UnassignProductUploadRowMediaAction.Responses.$200,
  ) => this;
}

export const validateUnassignProductUploadRowMediaV3: BaseValidationType = [
  body('productUploadRowId').notEmpty().isMongoId(),
  body('mediaId').optional().isMongoId(),
  reqValidationResult,
];

export async function unassignProductUploadRowMediaActionV3(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    supplierCompanyId,
    body: { mediaId, productUploadRowId },
  } = req;

  const byBackOffice: boolean = !req.supplierId;

  const list: IProductUploadRowModelV3 = await productUploadRowModelV3.findOne({
    _id: productUploadRowId,
    ...(byBackOffice ? {} : { supplierCompanyId }),
  });

  if (!list) {
    throw new HttpError(StatusCodes.NOT_FOUND, ERRORS.NOT_FOUND);
  }

  list.media = mediaId
    ? list.media.filter((id: string): boolean => String(id) !== mediaId)
    : [];

  if (!list.media.length && list.state === DraftState.Valid) {
    list.state = DraftState.Draft;
  }

  await list.save();

  res.json({ isUpdated: true });
}
