import {
  BaseValidationType,
  HttpError,
  reqValidationResult,
  WebsiteCode,
} from '@tradeling/web-js-utils/dist';

import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { body } from 'express-validator';
import {
  getProductsCategories,
  getProductsCollections,
} from './partial-update/helpers';
import { getInvalidRowsPartialTemplate } from './partial-update/template-utils';
import Excel from 'exceljs';
import { ICategoryModel } from '../../category/model-category';
import { ICollectionModel } from '../../collection/model-collection';
import { CategoryAttributeType } from '../../category/model-category-attribute';
import { IUploadModelV3 } from '../model-upload-v3';
import {
  getAndValidateUploadNotExist,
  getProductsCategoriesWithoutKeys,
  v3PartialTemplate,
  getCategoryAttributes,
} from './helpers';
import {
  IProductUploadRowModelV3,
  productUploadRowModelV3,
} from '../model-product-upload-row-v3';
import { DraftState } from '../../product/types';
import { StatusCodes } from 'http-status-codes';
import { ERRORS } from '@src/types/errors';
import { getInvalidProductTemplate } from './template-utils';

interface IReq extends IAppRequest {
  body: Paths.V3GetInvalidRowsTemplateAction.RequestBody;
}

interface IRes extends IAppResponse {
  body: (body: Paths.V3GetInvalidRowsTemplateAction.Responses.$400) => this;
}

export const validateGetInvalidRowsTemplateV3: BaseValidationType = [
  body('uploadId').notEmpty().isMongoId(),
  reqValidationResult,
];

export async function getInvalidRowTemplateActionV3(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    platform,
    body,
    supplierId,
    store: {
      website: { websiteCode = WebsiteCode.tcom },
    },
  } = req;
  const { uploadId } = body;

  const byBackOffice: boolean = platform == 'backoffice';
  const upload: IUploadModelV3 = await getAndValidateUploadNotExist(
    uploadId,
    supplierId,
    byBackOffice,
  );
  const { categoryIds, collectionIds, fields } = upload;

  const categories: Record<
    string,
    ICategoryModel
  > = await getProductsCategories(categoryIds);
  const collections: Record<
    string,
    ICollectionModel
  > = await getProductsCollections(collectionIds);
  const categoryAttributes: CategoryAttributeType[] = await getCategoryAttributes(
    categoryIds,
  );

  const inValidProductUploadRows: IProductUploadRowModelV3[] = await getInvalidProductUploadRows(
    uploadId,
  );

  let workbook: Excel.Workbook;

  if (upload?.uploadType == v3PartialTemplate) {
    workbook = getInvalidRowsPartialTemplate({
      fields,
      invalidRows: inValidProductUploadRows,
      categories,
      collections,
      categoryAttributes,
      isBackoffice: platform == 'backoffice',
    });
    res.setHeader(
      'Content-disposition',
      `attachment; filename=${'product-partial-update'}.xlsx`,
    );
  } else {
    const categoriesWithoutGroup: Record<
      string,
      ICategoryModel
    > = await getProductsCategoriesWithoutKeys(categoryIds);
    workbook = getInvalidProductTemplate({
      categories,
      categoriesWithoutGroup,
      categoryAttributes,
      websiteCode,
      collections,
      invalidRows: inValidProductUploadRows,
    });
    res.setHeader(
      'Content-disposition',
      `attachment; filename=${'product-template'}.xlsx`,
    );
  }
  res.setHeader(
    'content-type',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  );

  await workbook.xlsx.write(res);

  res.end();
}

async function getInvalidProductUploadRows(
  uploadId: string,
): Promise<IProductUploadRowModelV3[]> {
  const inValidProductUploadRows: IProductUploadRowModelV3[] = await productUploadRowModelV3
    .find({ uploadId, state: { $in: [DraftState.Invalid] } })
    .lean();

  if (!inValidProductUploadRows || inValidProductUploadRows.length === 0) {
    throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.NOT_ALLOWED);
  }
  return inValidProductUploadRows;
}
