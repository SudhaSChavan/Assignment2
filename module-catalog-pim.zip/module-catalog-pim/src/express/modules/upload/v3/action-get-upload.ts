import { body } from 'express-validator';
import { StatusCodes } from 'http-status-codes';
import {
  BaseValidationType,
  HttpError,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { ERRORS } from '@src/types/errors';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { getUploadRowCount } from '../model-product-upload-row-v3';
import { DraftState } from '../../product/types';
import { joinUrl } from '@core/util/url';
import { appConfig } from '@src/config/env';
import { IUploadModelV3, uploadModelV3 } from '../model-upload-v3';

interface IReq extends IAppRequest {
  body: Paths.V3GetUploadAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3GetUploadAction.Responses.$200) => this;
}

export const validateGetUploadV3: BaseValidationType = [
  body('id').exists().isMongoId().withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function getUploadActionV3(req: IReq, res: IRes): Promise<void> {
  const {
    supplierCompanyId,
    body: { id },
  } = req;

  const byBackOffice: boolean = !req.supplierId;

  const productUpload: IUploadModelV3 = await uploadModelV3
    .findOne(
      {
        _id: id,
        ...(byBackOffice ? {} : { supplierCompanyId }),
      },
      {
        // @todo add projection
      },
    )
    .lean();

  if (!productUpload) {
    throw new HttpError(StatusCodes.NOT_FOUND, ERRORS.NOT_FOUND);
  }

  res.json({
    ...(productUpload as any),
    url: joinUrl(appConfig.mediaBaseUrl, productUpload.path),
    draftCount: await getUploadRowCount(productUpload._id, DraftState.Draft),
    validCount: await getUploadRowCount(productUpload._id, DraftState.Valid),
    invalidCount: await getUploadRowCount(
      productUpload._id,
      DraftState.Invalid,
    ),
    publishedCount: await getUploadRowCount(
      productUpload._id,
      DraftState.Published,
    ),
  });
}
