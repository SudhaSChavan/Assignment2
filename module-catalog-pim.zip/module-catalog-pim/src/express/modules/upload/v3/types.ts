import { ICategoryModel } from '../../category/model-category';
import { CategoryAttributeType } from '../../category/model-category-attribute';
import { Units } from '../helpers';
import { ICollectionModel } from '../../collection/model-collection';
import { IProductUploadRowModelV3 } from '@express/modules/upload/model-product-upload-row-v3';

export interface IGetTemplateParams {
  categories?: Record<string, ICategoryModel>;
  categoriesWithoutGroup?: Record<string, ICategoryModel>;
  categoryAttributes?: CategoryAttributeType[];
  fields?: string[];
  isTradeling?: boolean;
  websiteCode: string;
  collections?: Record<string, ICollectionModel>;
  invalidRows?: IProductUploadRowModelV3[];
}

export const packagingUnits: string[] = [
  Units.kg,
  Units.gr,
  Units.lb,
  Units.lt,
  Units.cl,
  Units.ml,
  Units.gal,
  Units.floz,
  Units.piece,
  Units.carton,
  Units.packet,
  Units.pack,
  Units.box,
  Units.roll,
];

export const TransportationModeLabelMapping: Record<
  Components.Schemas.V1TransportationMode,
  string
> = {
  regular: 'Regular',
  food_ambient: 'Food Ambient',
  food_chilled: 'Food Chilled',
  food_frozen: 'Food Frozen',
  na: 'N/A',
};

export const TransportationModeLabels: string[] = Object.values(
  TransportationModeLabelMapping,
);
export const TransportationModeValues: Components.Schemas.V1TransportationMode[] = Object.keys(
  TransportationModeLabelMapping,
) as Components.Schemas.V1TransportationMode[];
