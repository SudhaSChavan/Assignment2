import {
  FieldType,
  getEmptyWorkbook,
  getExcelColumnName,
  getWorkbook,
  TransportationModeLabelMapping,
} from '../helpers';
import Excel from 'exceljs';
import { IGetTemplateParams } from './types';
import { getFields } from './fields';
import { CategoryAttributeType } from '../../category/model-category-attribute';
import { KeyValAny } from '@src/types/common';
import {
  DraftCell,
  DraftState,
  LeanMediaType,
  ProductMediaType,
  UploadRowType,
} from '../../product/types';
import lodash, { groupBy, isEmpty, keyBy, map, uniq } from 'lodash';
import { FIELD_MAP } from './fields';
import { getCategoryAttributes, getProductsCollections } from './helpers';
import { ICategoryModel } from '../../category/model-category';
import { mediaModel } from '../../media/model-media';
import {
  IProductDocumentV3,
  productModelV3,
} from '../../product/model-product-v3';
import { ICollectionModel } from '../../collection/model-collection';
import { IProductUploadRowDocumentV3 } from '../model-product-upload-row-v3';
import { IUploadModelV3 } from '../model-upload-v3';

export function getUploadProductTemplate(
  params: IGetTemplateParams,
): Excel.Workbook {
  const fields: FieldType[] = getFields(params).filter((field) => {
    return !field.shouldRemoveFromSheet && !field.shouldExclude;
  });
  const workbook: Excel.Workbook = getEmptyWorkbook(fields);
  addMetaDataSheet(workbook, params);
  return workbook;
}

export function getInvalidProductTemplate(
  params: IGetTemplateParams,
): Excel.Workbook {
  const { invalidRows } = params;
  const fields: FieldType[] = getFields(params).filter((field) => {
    return !field.shouldRemoveFromSheet && !field.shouldExclude;
  });
  const workbook: Excel.Workbook = getEmptyWorkbook(fields);
  addMetaDataSheet(workbook, params);
  fillSheetWithInvalidRows(workbook, invalidRows);
  return workbook;
}

function fillSheetWithInvalidRows(
  workbook: Excel.Workbook,
  productUploadRows: IProductUploadRowDocumentV3[],
) {
  const invalidRows: string[][] = getInvalidRows(productUploadRows);
  const datasheet: Excel.Worksheet = workbook.getWorksheet('Data');
  invalidRows.forEach((row, rowIndex) => {
    row.forEach((column, i) => {
      const columnName: string = getExcelColumnName(i + 1);
      datasheet.getCell(`${columnName}${rowIndex + 2}`).value = column;
    });
  });
}

function getInvalidRows(
  productUploadRows: IProductUploadRowDocumentV3[],
): string[][] {
  return productUploadRows.map((row) => {
    return map(row.row, 'value');
  });
}

export function transportationLabelToValue(value: any): string {
  const givenValue: string = String(value).toLowerCase().trim();

  const foundValue: string = Object.keys(TransportationModeLabelMapping).find(
    (key: string) => {
      const keyValue: string =
        TransportationModeLabelMapping[
          key as Components.Schemas.V1TransportationMode
        ];

      return keyValue.toLowerCase().trim() === givenValue;
    },
  );

  return foundValue || null;
}

function addMetaDataSheet(
  workbook: Excel.Workbook,
  params: IGetTemplateParams,
) {
  const metaWorksheet: Excel.Worksheet = workbook.getWorksheet(4);
  const { categories } = params;

  metaWorksheet.getCell('A1').value = 'DO NOT CHANGE VALUES BELOW';
  metaWorksheet.getCell('A2').value = Object.keys(categories).join('@@');
}

export function mapRowDataToFields(
  rowData: string[][],
  fields: FieldType[],
): KeyValAny[] {
  return rowData.map(
    (row): KeyValAny => {
      return fields.reduce(
        (obj: KeyValAny, field: FieldType, index: number): KeyValAny => {
          return {
            ...obj,
            [fields[index].field]: row[index] || '',
          };
        },
        {},
      );
    },
  );
}

export async function getSheetByIndex(
  file: any,
  index: number,
): Promise<Excel.Worksheet> {
  const workbook: Excel.Workbook = await getWorkbook(file.path);
  return workbook.getWorksheet(index);
}

export async function getFieldsFromSheet(
  metadataSheet: Excel.Worksheet,
  categoriesWithoutGroup: Record<string, ICategoryModel>,
  websiteCode: string,
  isTradeling?: boolean,
): Promise<Record<string, FieldType>> {
  const categoryAttributes: CategoryAttributeType[] = await getCategoryAttributes(
    map(categoriesWithoutGroup, '_id'),
  );
  const categories: Record<string, ICategoryModel> = keyBy(
    categoriesWithoutGroup,
    'slug',
  );

  const collections: Record<
    string,
    ICollectionModel
  > = await getProductsCollections();

  return keyBy(
    getFields({
      categories,
      categoriesWithoutGroup,
      categoryAttributes,
      websiteCode,
      collections,
      isTradeling,
    }).filter((field) => {
      return !field.shouldExclude;
    }),
    'field',
  );
}

export async function assignMediaToProductUploadRow(
  productUploadRowsMap: Record<string, IProductUploadRowDocumentV3>,
  supplierCompanyId: string,
): Promise<IProductUploadRowDocumentV3[]> {
  const skuList: string[] = Object.keys(productUploadRowsMap);
  const productUploadRows: IProductUploadRowDocumentV3[] = Object.values(
    productUploadRowsMap,
  );
  const autoAssignedMediaList: LeanMediaType[] = await mediaModel
    .find(
      {
        skuGroup: { $in: skuList },
        deletedAt: null,
        supplierCompanyId,
      },
      '_id skuGroup',
    )
    .sort({ originalName: 1 })
    .lean();

  const existingProducts: any[] = await productModelV3
    .find({ sku: { $in: skuList } }, '_id sku media')
    .lean();

  const groupedMedia: Record<string, LeanMediaType[]> = groupBy(
    autoAssignedMediaList,
    'skuGroup',
  );
  const existingProductGroup: Record<string, IProductDocumentV3> = keyBy(
    existingProducts,
    'sku',
  );

  return productUploadRows.map(
    (
      productUploadRow: IProductUploadRowDocumentV3,
    ): IProductUploadRowDocumentV3 => {
      const sku: string = productUploadRow?.fields?.sku?.toUpperCase();
      const existingProduct: any = existingProductGroup[sku];

      productUploadRow.rowType = existingProduct
        ? UploadRowType.Existing
        : UploadRowType.New;

      const existingMedia: ProductMediaType[] = existingProduct?.media ?? [];
      const existingMediaIds: string[] = map(existingMedia, 'id') || [];

      productUploadRow.media = uniq([
        ...map(groupedMedia[sku], '_id').map(String),
        ...existingMediaIds.map(String),
      ]);

      if (
        productUploadRow.media?.length &&
        productUploadRow.state === DraftState.Draft
      ) {
        productUploadRow.state = DraftState.Valid;
      }
      return productUploadRow;
    },
  );
}

export function getProductUploadRows(
  rows: KeyValAny[],
  fields: Record<string, FieldType>,
  upload: IUploadModelV3,
): Record<string, IProductUploadRowDocumentV3> {
  const productUploadRowsMap: Record<string, IProductUploadRowDocumentV3> = {};

  rows.forEach((row, index) => {
    let isValid: boolean = true;
    const productUploadRowCells: DraftCell[] = [];
    const productUploadRowFields: KeyValAny = Object.keys(row).reduce(
      (productUploadRowFields: KeyValAny, fieldName: string): KeyValAny => {
        const field: FieldType = fields[fieldName];
        let value: any = row[fieldName];
        let error: string = null;

        field.sanitizers.forEach((sanitize) => {
          value = sanitize(value);
        });

        if (!isEmpty(row[fieldName])) {
          field.validators.forEach((validator) => {
            if (!validator(value)) {
              isValid = false;
              error = field.invalidValueMessage;
            }
          });
        }

        field.dependSanitizers?.forEach((sanitize) => {
          value = sanitize(row);
        });

        field.dependValidators?.forEach((validator) => {
          if (!validator(value, row)) {
            isValid = false;
            error = field.invalidValueMessage;
          }
        });

        if (
          ['', null, undefined].includes(row[fieldName]) ||
          (Array.isArray(value) && value.length == 0)
        ) {
          if (
            field.required &&
            !error &&
            (!field.categoryIds ||
              field.categoryIds?.includes(
                productUploadRowFields.categoryId?.toString(),
              ))
          ) {
            isValid = false;
            error = 'Field is required';
          }
        }

        if (!field.shouldRemoveFromSheet && !field.shouldExclude) {
          productUploadRowCells.push({
            field: field.field,
            label: field.label,
            value: ![null, undefined].includes(row[fieldName])
              ? row[fieldName]
              : '',
            error,
          });
        }

        if (!field.shouldRemove && ![null, undefined, ''].includes(value)) {
          lodash.set(
            productUploadRowFields,
            FIELD_MAP[field.field] || field.field,
            value,
          );
        }
        return productUploadRowFields;
      },
      {},
    );

    productUploadRowsMap[productUploadRowFields.sku] = {
      isVariant: productUploadRowFields?.hasVariants,
      supplierCompanyId: upload?.supplierCompanyId,
      supplierId: upload?.supplierId,
      userId: upload?.supplierId,
      uploadId: upload?._id,
      categoryId: productUploadRowFields?.categoryId,
      line: index + 1,
      fields: productUploadRowFields,
      state: isValid ? DraftState.Valid : DraftState.Invalid,
      attributes: {},
      row: productUploadRowCells,
    };
  });
  return productUploadRowsMap;
}

export function duplicateLocalizedAttributes(
  attributes: CategoryAttributeType[],
): CategoryAttributeType[] {
  return attributes.flatMap(
    (attribute: CategoryAttributeType): CategoryAttributeType[] =>
      !attribute.isLocalized
        ? [attribute]
        : [
            {
              ...attribute,
              code: `${attribute.code}.en`,
              label: { en: `${attribute.label.en} (en)` },
            },
            {
              ...attribute,
              code: `${attribute.code}.ar`,
              label: { en: `${attribute.label.en} (ar)` },
              required: false,
            },
          ],
  );
}

export function getCategorySlugsForAttributes(
  categories: Record<string, ICategoryModel>,
  attribute: CategoryAttributeType & { categoryIds?: string[] },
): string[] {
  return attribute.categoryIds.map((id) => {
    return categories[id]?.slug;
  });
}
