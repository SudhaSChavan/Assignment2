import {
  BaseValidationType,
  IBaseAppUser,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { body } from 'express-validator';
import { FilterQuery } from 'mongoose';
import {
  getCategoryAttributes,
  getChildrenCategories,
  getProductContent,
  getProductFilterQuery,
  getProductsCategories,
  getProductsCollections,
} from './partial-update/helpers';
import {
  getPartialProductTemplate,
  isTheUSerHasPermissionToSkipGuardrails,
  isTradelingCompany,
  shouldMergeVendorWithOffer,
} from './partial-update/template-utils';
import { IProductContent } from './partial-update/types';
import Excel from 'exceljs';
import { ICategoryModel } from '../../category/model-category';
import { ICollectionModel } from '../../collection/model-collection';
import { map, uniq } from 'lodash';
import { CategoryAttributeType } from '../../category/model-category-attribute';
import { ERRORS } from '@src/types/errors';
import { InternalReviewStatuses } from '../../product/types';
import { IProductModelV3 } from '../../product/model-product-v3';
import { isBackoffice } from '@express/modules/upload/helpers';

interface IReq extends IAppRequest {
  body: Paths.V3GetPartialUpdateTemplateAction.RequestBody;
}

interface IRes extends IAppResponse {
  body: (body: Paths.V3GetPartialUpdateTemplateAction.Responses.$400) => this;
}

export const validateGetPartialUpdateTemplateV3: BaseValidationType = [
  body('fields').notEmpty().isArray({ min: 1 }),
  body('filters.categoryIds.*').notEmpty().isMongoId(),
  body('supplierCompanyIds.*').notEmpty().isMongoId(),
  body('filters.state')
    .optional()
    .isString()
    .isIn(['online', 'offline'])
    .withMessage(ERRORS.INVALID),
  body('filters.isInStock')
    .optional()
    .isBoolean()
    .isIn([true, false])
    .withMessage(ERRORS.INVALID),
  body('filters.websiteCode').optional().isString(),
  body('filters.internalReviewStatus')
    .optional()
    .isNumeric()
    .isIn(Object.values(InternalReviewStatuses))
    .withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function getPartialUpdateTemplateActionV3(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { supplierCompanyId, platform, userJwtDecoded } = req;
  const {
    exportEmptySheet,
    filters: {
      categoryIds = [],
      internalReviewStatus = [],
      websiteCode,
      supplierCompanyIds,
      state,
      isInStock,
    },
  } = req.body;
  let { fields } = req.body;
  const email = (userJwtDecoded as IBaseAppUser)?.email;
  let childrenCategoryIds: string[] = await getChildrenCategories(categoryIds);

  let products: IProductContent[] = [];

  const filteredSupplierCompanyIds: string[] = isBackoffice(platform)
    ? supplierCompanyIds
    : [supplierCompanyId];

  if (!exportEmptySheet) {
    const filterQuery: FilterQuery<IProductModelV3> = await getProductFilterQuery(
      {
        categoryIds: childrenCategoryIds,
        supplierCompanyIds: filteredSupplierCompanyIds,
        websiteCode,
        internalReviewStatus,
        state,
        isInStock,
      },
    );
    products = await getProductContent(filterQuery);
  }

  if (shouldMergeVendorWithOffer(filteredSupplierCompanyIds, fields)) {
    fields = uniq(fields.concat(['vendor', 'offer']));
  }

  childrenCategoryIds =
    categoryIds.length > 0 ? categoryIds : map(products, 'categoryId');
  const categories: Record<
    string,
    ICategoryModel
  > = await getProductsCategories(childrenCategoryIds);

  const collectionIds: string[] = map(products, 'collectionIds').flat(1);
  const collections: Record<
    string,
    ICollectionModel
  > = await getProductsCollections(collectionIds);
  const categoryAttributes: CategoryAttributeType[] = await getCategoryAttributes(
    childrenCategoryIds,
  );

  const workbook: Excel.Workbook = getPartialProductTemplate({
    fields,
    products,
    categories,
    collections,
    categoryAttributes,
    isBackoffice: isBackoffice(platform),
    email,
    isTradeling: isTheUSerHasPermissionToSkipGuardrails(email)
      ? false
      : isTradelingCompany(filteredSupplierCompanyIds),
  });

  res.setHeader(
    'Content-disposition',
    `attachment; filename=${'product-partial-update'}.xlsx`,
  );
  res.setHeader(
    'content-type',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  );

  await workbook.xlsx.write(res);

  res.end();
}
