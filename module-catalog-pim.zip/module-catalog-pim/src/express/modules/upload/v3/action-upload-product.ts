import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { validateFileUpload } from '@core/util/validators';
import { appConfig } from '@src/config/env';
import { IMediaFile } from '../../media/types';
import Excel from 'exceljs';
import { FieldType, getRawData } from '../helpers';
import { mongo } from 'mongoose';
import { KeyValAny } from '@src/types/common';
import {
  assignMediaToProductUploadRow,
  getFieldsFromSheet,
  getProductUploadRows,
  getSheetByIndex,
  mapRowDataToFields,
} from './template-utils';
import {
  getProductsCategoriesWithoutKeys,
  saveProductUploadRows,
  storeUploadFile,
  v3ProductTemplate,
} from './helpers';
import { joinUrl } from '@core/util/url';
import { IProductUploadRowDocumentV3 } from '../model-product-upload-row-v3';
import { IUploadModelV3 } from '../model-upload-v3';
import { HttpError, WebsiteCode } from '@tradeling/web-js-utils';
import { StatusCodes } from 'http-status-codes';
import { ICategoryModel } from '@express/modules/category/model-category';
import { UploadType } from '@express/modules/product/types';
import { isTradelingCompany } from '@express/modules/upload/v3/partial-update/template-utils';

interface IReq extends IAppRequest {
  body: Paths.V3UploadProductAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3UploadProductAction.Responses.$200) => this;
}

export const validateUploadProductV3: BaseValidationType = [
  validateFileUpload({
    maxFileSize: appConfig.product.maxFileSizeBytes,
    extensions: ['xlsx'],
    maxFiles: 1,
  }),
  reqValidationResult,
];

export async function uploadProductV3(req: IReq, res: IRes): Promise<void> {
  const {
    platform,
    store: {
      website: { websiteCode = WebsiteCode.tcom },
    },
    body,
  } = req;
  const { files }: { files: IMediaFile[] } = req.body as any;
  const byBackoffice: boolean = platform == 'backoffice';
  const supplierCompanyId: string = byBackoffice
    ? body?.supplierCompanyId
    : req?.supplierCompanyId;
  const supplierId: string = byBackoffice ? body?.supplierId : req?.supplierId;
  const userId: string = byBackoffice ? body?.userId : req?.userId;
  const dataSheet: Excel.Worksheet = await getSheetByIndex(files[0], 2);
  const metadataSheet: Excel.Worksheet = await getSheetByIndex(files[0], 4);

  const categoryIds: string[] =
    metadataSheet.getCell('A2').value?.toString().split('@@').filter(Boolean) ||
    [];

  const categoriesWithoutGroup: Record<
    string,
    ICategoryModel
  > = await getProductsCategoriesWithoutKeys(categoryIds);

  if (!dataSheet || !metadataSheet || !categoryIds || !categoriesWithoutGroup) {
    throw new HttpError(StatusCodes.BAD_REQUEST, 'Invalid Template');
  }

  const rawData: string[][] = getRawData(dataSheet);

  if (rawData?.length == 0) {
    throw new HttpError(StatusCodes.BAD_REQUEST, 'Template is Empty');
  }

  let productUpload: IUploadModelV3 = await storeUploadFile(
    {
      file: files[0],
      uid: { userId, supplierCompanyId, supplierId },
      template: v3ProductTemplate,
      categoryIds: categoryIds.map((id) => new mongo.ObjectID(id)),
      type: UploadType.Product,
    },
    platform == 'backoffice',
  );

  const fields: Record<string, FieldType> = await getFieldsFromSheet(
    metadataSheet,
    categoriesWithoutGroup,
    websiteCode,
    isTradelingCompany([supplierCompanyId]),
  );
  const mappedRows: KeyValAny[] = mapRowDataToFields(
    rawData,
    Object.values(fields),
  );
  const productUploadMap: Record<
    string,
    IProductUploadRowDocumentV3
  > = getProductUploadRows(mappedRows, fields, productUpload);

  const productUploadRows: IProductUploadRowDocumentV3[] = await assignMediaToProductUploadRow(
    productUploadMap,
    supplierCompanyId,
  );
  productUpload = await saveProductUploadRows(productUploadRows, productUpload);

  res.json({
    ...productUpload.toJSON(),
    url: joinUrl(appConfig.mediaBaseUrl, productUpload.path),
  });
}
