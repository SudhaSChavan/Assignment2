import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { appConfig } from '@src/config/env';
import { ERRORS } from '@src/types/errors';
import { productUploadRowModelV3 } from '../model-product-upload-row-v3';

interface IReq extends IAppRequest {
  body: Paths.V3ListProductUploadRowAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3ListProductUploadRowAction.Responses.$200) => this;
}

export const validateListProductUploadV3: BaseValidationType = [
  body('page').optional().isInt({ gt: 0 }).withMessage(ERRORS.INVALID),
  body('size')
    .optional()
    .isInt({ lt: appConfig.product.listMaxLimit, gt: 0 })
    .withMessage(ERRORS.INVALID),
  body('state').optional().isString().withMessage(ERRORS.INVALID),
  body('filter.uploadId').optional().isMongoId().withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function listProductUploadRowV3Action(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    userId,
    supplierId,
    supplierCompanyId,
    body: {
      page = 1,
      size = appConfig.product.listDefaultLimit,
      filter: { state = null, uploadId = null } = {},
    },
  } = req;
  const byBackOffice: boolean = !req.supplierId;
  const recordsToSkip: number = (page - 1) * size;
  const query: any = {
    ...(uploadId ? { uploadId } : {}),
    ...(state ? { state } : {}),
    ...(byBackOffice ? {} : { supplierCompanyId }),
  };

  const totalRecords: number = await productUploadRowModelV3.countDocuments(
    query,
  );
  const productUploadRows: Components.Schemas.V3ProductUploadRows = await productUploadRowModelV3
    .find(
      query,
      {
        _id: 1,
        media: 1,
        line: 1,
        state: 1,
        row: 1,
        fields: 1,
        rowType: 1,
        categoryId: 1,
        uploadId: 1,
        userId: 1,
        supplierId: 1,
        supplierCompanyId: 1,
        createdAt: 1,
        isVariant: 1,
        updatedAt: 1,
      },
      {
        sort: {
          line: 1,
        },
        skip: recordsToSkip,
        limit: size,
      },
    )
    .lean();

  res.json({
    currentPage: page,
    totalPages: Math.ceil(totalRecords / size),
    totalRecords,
    size,
    data: productUploadRows,
  });
}
