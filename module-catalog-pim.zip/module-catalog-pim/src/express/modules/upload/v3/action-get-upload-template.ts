import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { ERRORS } from '@src/types/errors';
import { getUploadProductTemplate } from './template-utils';
import Excel from 'exceljs';
import { ICategoryModel } from '../../category/model-category';
import {
  getCategoryAttributes,
  getProductsCategoriesWithoutKeys,
  getProductsCollections,
} from './helpers';
import { CategoryAttributeType } from '../../category/model-category-attribute';
import { keyBy } from 'lodash';
import { ICollectionModel } from '../../collection/model-collection';
import { map } from 'lodash';
import { WebsiteCode } from '@tradeling/web-js-utils';
import { isTradelingCompany } from '@express/modules/upload/v3/partial-update/template-utils';

interface IReq extends IAppRequest {
  body: Paths.V3GetProductUploadTemplateAction.RequestBody;
}

interface IRes extends IAppResponse {
  body: (body: Paths.V3GetProductUploadTemplateAction.Responses.$400) => this;
}

export const validateGetUploadTemplateV3: BaseValidationType = [
  body('categoryIds').optional().isArray({ min: 1 }),
  body('categoryIds.*').isString().isMongoId().withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function getUploadTemplateV3(req: IReq, res: IRes): Promise<void> {
  const {
    store: {
      website: { websiteCode = WebsiteCode.tcom },
    },
    body: { categoryIds },
    supplierCompanyId,
  } = req;

  const categoriesWithoutGroup: Record<
    string,
    ICategoryModel
  > = await getProductsCategoriesWithoutKeys(categoryIds);
  const categories: Record<string, ICategoryModel> = keyBy(
    categoriesWithoutGroup,
    '_id',
  );
  const categoryAttributes: CategoryAttributeType[] = await getCategoryAttributes(
    categoryIds || map(categories, '_id'),
  );
  const collections: Record<
    string,
    ICollectionModel
  > = await getProductsCollections();

  const workbook: Excel.Workbook = getUploadProductTemplate({
    categories,
    categoriesWithoutGroup,
    categoryAttributes,
    websiteCode,
    collections,
    isTradeling: isTradelingCompany([supplierCompanyId]),
  });

  res.setHeader(
    'Content-disposition',
    `attachment; filename=${'product-template'}.xlsx`,
  );
  res.setHeader(
    'content-type',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  );

  await workbook.xlsx.write(res);

  res.end();
}
