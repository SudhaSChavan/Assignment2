import { categoryModel, ICategoryModel } from '../../category/model-category';
import { keyBy, groupBy } from 'lodash';
import {
  categoryAttributeModel,
  CategoryAttributeType,
} from '../../category/model-category-attribute';
import { FilterQuery, mongo, Types } from 'mongoose';
import { DraftState, UploadType } from '../../product/types';
import {
  collectionModel,
  ICollectionModel,
} from '../../collection/model-collection';
import {
  IProductUploadRowDocumentV3,
  productUploadRowModelV3,
} from '../model-product-upload-row-v3';
import {
  IUploadModelV3,
  UPLOAD_STATE,
  uploadModelV3,
} from '../model-upload-v3';
import {
  IProvider,
  providerMapping,
  Providers,
} from '../../media/providers/types';
import { appConfig } from '@src/config/env';
import { getExtension } from '@core/util/file';
import { IMediaFile } from '../../media/types';
import { UserIdentifier } from '@src/types/command';
import {
  ConfigurationAttribute,
  IProductModelV3,
  productModelV3,
} from '../../product/model-product-v3';
import { transformConfigurationAttributes } from '../../product/v3/helpers';
import { HttpError } from '@tradeling/web-js-utils/dist';
import { StatusCodes } from 'http-status-codes';
import { ERRORS } from '@src/types/errors';

type StoreUploadType = {
  file: IMediaFile;
  uid: UserIdentifier;
  template: TemplateType;
  type: UploadType;
  categoryIds?: Types.ObjectId[];
  collectionIds?: string[];
  fields?: string[];
  totalCount?: number;
};

export const v3ProductTemplate: string = 'product-template';
export const v3PartialTemplate: string = 'partial-product-update';
export const v3MediaTemplate: string = 'media-template';

export async function getCategoryAttributes(
  categoryIds: string[],
): Promise<CategoryAttributeType[]> {
  return categoryAttributeModel.aggregate([
    {
      $match: {
        categoryId: { $in: categoryIds.map((id) => new mongo.ObjectID(id)) },
      },
    },
    { $unwind: '$attributes' },
    {
      $group: {
        _id: '$attributes.code',
        type: { $first: '$attributes.type' },
        label: { $first: '$attributes.label' },
        help: { $first: '$attributes.help' },
        valueHelp: { $first: '$attributes.valueHelp' },
        isFilterable: { $first: '$attributes.isFilterable' },
        sort: { $first: '$attributes.sort' },
        code: { $first: '$attributes.code' },
        default: { $first: '$attributes.default' },
        allowedValues: { $first: '$attributes.allowedValues' },
        required: { $first: '$attributes.required' },
        strict: { $first: '$attributes.strict' },
        example: { $first: '$attributes.example' },
        isLocalized: { $first: '$attributes.isLocalized' },
        showCount: { $first: '$attributes.showCount' },
        metadata: { $first: '$attributes.metadata' },
        minValue: { $first: '$attributes.minValue' },
        maxValue: { $first: '$attributes.maxValue' },
        isInteger: { $first: '$attributes.isInteger' },
        categoryIds: { $addToSet: '$categoryId' },
      },
    },
    {
      $sort: {
        _id: 1,
      },
    },
  ]);
}

export async function getProductsCollections(
  collectionIds: string[] = [],
  key: string = 'slug',
): Promise<Record<string, ICollectionModel>> {
  const query: FilterQuery<ICollectionModel> = {};
  if (collectionIds.length) {
    query.$and.push({ _id: { $in: collectionIds } });
  }
  const collections: ICollectionModel[] = await collectionModel
    .find(
      {},
      {
        slug: 1,
      },
    )
    .lean();
  return keyBy(collections, key);
}

export async function getAndValidateUpload(
  uploadId: string,
  supplierId: string,
  byBackoffice: boolean,
): Promise<IUploadModelV3> {
  const upload: IUploadModelV3 = await uploadModelV3.findOne({
    _id: uploadId,
    ...(byBackoffice ? {} : { supplierId }),
  });

  if (!upload) {
    throw new HttpError(StatusCodes.NOT_FOUND, ERRORS.NOT_FOUND);
  }

  if (upload.get('state') !== UPLOAD_STATE.NEW) {
    throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.NOT_ALLOWED);
  }
  return upload;
}

export async function getAndValidateUploadNotExist(
  uploadId: string,
  supplierId: string,
  byBackoffice: boolean,
): Promise<IUploadModelV3> {
  const upload: IUploadModelV3 = await uploadModelV3.findOne({
    _id: uploadId,
    ...(byBackoffice ? {} : { supplierId }),
  });

  if (!upload) {
    throw new HttpError(StatusCodes.NOT_FOUND, ERRORS.NOT_FOUND);
  }
  return upload;
}

export type TemplateType =
  | typeof v3ProductTemplate
  | typeof v3PartialTemplate
  | typeof v3MediaTemplate;

/**
 *
 * @param categoryIds
 */
export async function getProductsCategoriesWithoutKeys(
  categoryIds: string[],
): Promise<Record<string, ICategoryModel>> {
  return categoryModel
    .find(
      {
        ...(categoryIds?.length ? { _id: { $in: categoryIds } } : {}),
      },
      {
        slug: 1,
        moq: 1,
      },
    )
    .lean();
}

export async function saveProductUploadRows(
  productUploadRows: IProductUploadRowDocumentV3[],
  productUpload: IUploadModelV3,
): Promise<IUploadModelV3> {
  await productUploadRowModelV3.insertMany(productUploadRows);
  productUpload.set('totalCount', productUploadRows.length);
  productUpload.set(
    'invalidCount',
    productUploadRows.filter((productUploadRow) => {
      return productUploadRow.state == DraftState.Invalid;
    }).length,
  );

  await productUpload.save();
  return productUpload;
}

/**
 *
 * @param currency
 */
export function isUae(currency: string): boolean {
  return currency?.toUpperCase() === 'AED';
}

/**
 *
 * @param currency
 */
export function getMarketCode(currency: string): string {
  return isUae(currency) ? 'AE' : 'INTL';
}

/**
 *
 * @param currency
 */
export function getMarketLabel(currency: string): string {
  return isUae(currency) ? 'UAE' : 'All Markets';
}

export async function storeUploadFile(
  {
    file,
    uid,
    template,
    categoryIds,
    collectionIds,
    fields,
    type,
    totalCount,
  }: StoreUploadType,
  byBackoffice: boolean = false,
): Promise<IUploadModelV3> {
  const provider: IProvider = providerMapping[appConfig.storage.disk];
  const newFileName: string = `${file.filename}.${getExtension(
    file.originalname,
  )}`;
  const toPath: string = `/${uid.supplierCompanyId}/${newFileName}`;

  await provider.upload(file.path, toPath);
  const productUpload: IUploadModelV3 = new uploadModelV3({
    categoryIds,
    collectionIds,
    fields,
    type,
    state: UPLOAD_STATE.NEW,
    originalName: file.originalname,
    fileSize: file.size,
    provider: Providers.LOCAL,
    totalCount: totalCount || 0,
    invalidCount: 0,
    uploadedCount: 0,
    uploadType: template,
    path: toPath,
    meta: {
      size: file.size,
      encoding: file.encoding,
      mimetype: file.mimetype,
    },
    ...uid,
    byBackoffice,
  });

  await productUpload.save();

  return productUpload;
}

export async function refreshBulkConfigurationAttributes(
  parentSkus: string[],
  supplierCompanyId: string,
): Promise<void> {
  const products: IProductModelV3[] = await productModelV3.find({
    parentSku: { $in: parentSkus },
    supplierCompanyId,
  });
  const groupedProducts: Record<string, IProductModelV3[]> = groupBy(
    products,
    'parentSku',
  );
  const bulkQuery: any[] = [];
  for (const parentSku in groupedProducts) {
    const productsByParentSku: IProductModelV3[] =
      groupedProducts[parentSku] || [];
    const configurationAttributes: ConfigurationAttribute[] = transformConfigurationAttributes(
      productsByParentSku,
    );
    bulkQuery.push({
      updateMany: {
        filter: {
          parentSku,
          supplierCompanyId,
        },
        update: {
          $set: {
            configurationAttributes,
          },
        },
        upsert: true,
      },
    });
  }
  await productModelV3.bulkWrite(bulkQuery);
}
