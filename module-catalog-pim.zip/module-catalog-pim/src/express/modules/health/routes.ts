import { Router } from 'express';
import { Router as IRouter } from 'express-serve-static-core';

import { catchAsyncErrors } from '@core/util/router';
import {
  getElasticsearchHealth,
  getHealthz,
  getMongodbHealth,
  getReadiness,
  getRedisHealth,
  getStats,
  getVersion,
} from './ctrl';

const routes: IRouter = Router();

routes.get('/v1-readiness', catchAsyncErrors(getReadiness));
routes.get('/v1-healthz', catchAsyncErrors(getHealthz));
routes.get('/v1-stats', catchAsyncErrors(getStats));
routes.get('/v1-version', catchAsyncErrors(getVersion));
routes.get('/v1-mongodb-health', catchAsyncErrors(getMongodbHealth));
routes.get('/v1-redis-health', catchAsyncErrors(getRedisHealth));
routes.get(
  '/v1-elasticsearch-health',
  catchAsyncErrors(getElasticsearchHealth),
);
routes.get('', catchAsyncErrors(getVersion));

export { routes as healthRoutes };
