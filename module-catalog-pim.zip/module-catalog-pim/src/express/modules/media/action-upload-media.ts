import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { pick } from 'lodash';

import { IMediaFile } from './types';
import {
  removeMedia,
  uploadMediaFiles,
  UploadMediaReturnType,
  validateMediaSize,
} from './helpers';
import { appConfig } from '@src/config/env';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { validateFileUpload } from '@core/util/validators';
import {
  getMediaUrl,
  IMediaDocument,
  IMediaModel,
  mediaModel,
} from './model-media';
import { EE } from '@src/config/event/emitter';
import { logger } from '@core/util/logger';
import { HttpError } from '@tradeling/web-js-utils';
import { StatusCodes } from 'http-status-codes';
import { ERRORS } from '@src/types/errors';
import { getFileType } from '@core/util/file';
import { body } from 'express-validator';

export enum MediaCreateEvent {
  Success = 'media.create.success',
}

export enum MediaReplaceEvent {
  Success = 'media.replace.success',
}

interface IReq extends IAppRequest {
  body: Paths.V1UploadMediaAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1UploadMediaAction.Responses.$200) => this;
}

export const validateUploadMedia: BaseValidationType = [
  validateFileUpload({
    maxFileSize: appConfig.media.maxFileSizeBytes,
    extensions: appConfig.media.allowedUploadExtensions,
  }),
  validateMediaSize({
    minHeight: appConfig.media.minHeight,
    minWidth: appConfig.media.minWidth,
    minAspectRatio: appConfig.media.minAspectRatio,
    maxAspectRatio: appConfig.media.maxAspectRatio,
    maxResolution: appConfig.media.maxResolution,
  }),
  body('replaceMediaId').optional().isMongoId(),
  reqValidationResult,
];

function toMedia(insertedObj: IMediaModel): Components.Schemas.V1MediaItem {
  return {
    ...insertedObj.toJSON(),
    url: getMediaUrl(insertedObj),
  };
}

export async function uploadMediaAction(req: IReq, res: IRes): Promise<void> {
  const { platform, body } = req;
  const {
    files,
    skuSeparator,
    replaceMediaId,
  }: {
    files: IMediaFile[];
    skuSeparator?: string;
    replaceMediaId: string;
  } = req.body as any;

  const byBackoffice: boolean = platform === 'backoffice';
  const supplierCompanyId: string = byBackoffice
    ? body?.supplierCompanyId
    : req?.supplierCompanyId;
  const supplierId: string = byBackoffice ? body?.supplierId : req?.supplierId;
  const userId: string = byBackoffice ? body?.userId : req?.userId;

  // @todo move replace logic to separate endpoint
  if (replaceMediaId) {
    if (files.length > 1) {
      throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.INVALID);
    }

    const media: IMediaModel = await mediaModel.findOne({
      _id: replaceMediaId,
      supplierCompanyId,
      deletedAt: null,
    });

    if (!media) {
      throw new HttpError(StatusCodes.NOT_FOUND, ERRORS.NOT_FOUND);
    }

    if (getFileType(files[0].originalname) !== media.type) {
      throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.INVALID);
    }

    const { uploadedFiles }: UploadMediaReturnType = await uploadMediaFiles({
      uid: { userId, supplierId, supplierCompanyId },
      files,
      skuSeparator,
      checkForExisting: false,
    });

    const before: IMediaDocument = media.toJSON();

    media.set(
      pick(uploadedFiles[0], [
        'name',
        'originalName',
        'provider',
        'type',
        'path',
        'meta',
      ]),
    );
    await media.save();

    removeMedia(before).catch((e: Error): void => {
      logger.error(
        `Error removing image (id=${before._id}, path=${before.path}, provider=${before.provider}): ${e.message}`,
      );
    });

    EE.emit(MediaReplaceEvent.Success, [media]).catch((error: Error): void => {
      logger.error(`Event ${MediaReplaceEvent.Success} failed: ${error.stack}`);
    });

    res.json([toMedia(media)]);
  } else {
    const {
      uploadedFiles,
      existingFiles,
    }: UploadMediaReturnType = await uploadMediaFiles({
      uid: { userId, supplierId, supplierCompanyId },
      files,
      skuSeparator,
    });

    const insertedObjs: IMediaModel[] = await mediaModel.insertMany(
      uploadedFiles,
    );
    const items: Components.Schemas.V1MediaItem[] = [
      ...insertedObjs,
      ...existingFiles,
    ].map(toMedia);

    EE.emit(MediaCreateEvent.Success, insertedObjs).catch(
      (error: Error): void => {
        logger.error(
          `Event ${MediaCreateEvent.Success} failed: ${error.stack}`,
        );
      },
    );

    res.json(items);
  }
}
