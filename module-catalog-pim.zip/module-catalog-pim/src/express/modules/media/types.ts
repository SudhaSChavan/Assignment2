export interface IMediaFile extends Express.Multer.File {}
export interface IPreparedFile extends IMediaFile {
  originalFileName: string;
  newFileName: string;
  fromPath: string;
  toPath: string;
  skuGroup: string;
  mimetype: string;
  size: number;
}

export enum ImageUploadStatuses {
  New = 'new',
  Success = 'success',
  Failed = 'failed',
}
