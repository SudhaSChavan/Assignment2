import { subscribeImageUploadV3 } from '@express/modules/media/subscribers/subscriber-image-upload-v3';

subscribeImageUploadV3();
