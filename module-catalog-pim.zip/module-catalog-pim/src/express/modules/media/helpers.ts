import { BaseValidationType, HttpError } from '@tradeling/web-js-utils';
import cheerio from 'cheerio';
import { body, ValidationChain } from 'express-validator';
import fs, { ReadStream } from 'fs';
import inRange from 'lodash/inRange';
import map from 'lodash/map';
import path from 'path';
import probe, { ProbeResult } from 'probe-image-size';
import { StatusCodes } from 'http-status-codes';
import { joinUrl } from '@core/util/url';
import { allowedImageExtensions, appConfig } from '@src/config/env';
import { UserIdentifier } from '@src/types/command';
import { ERRORS } from '@src/types/errors';
import { getExtension, getFileType } from '@core/util/file';
import {
  getMediaUrl,
  IMediaDocument,
  IMediaModel,
  mediaModel,
} from './model-media';
import {
  AllowedProvidersType,
  IProvider,
  ProviderFileType,
  providerMapping,
} from './providers/types';
import { IMediaFile, IPreparedFile } from './types';
import V1MediaItem = Components.Schemas.V1MediaItem;

export type UploadMediaReturnType = {
  uploadedFiles: IMediaModel[];
  existingFiles: IMediaModel[];
};

export type UploadMediaArgsType = {
  uid: UserIdentifier;
  files: IMediaFile[];
  skuSeparator?: string;
  checkForExisting?: boolean;
};

/**
 * Uploads the given media files and gives back the documents to insert for collection
 * Set Default value for skuSeparator in case of it's not provided in request
 */
export async function uploadMediaFiles({
  uid,
  files,
  skuSeparator = '_',
  checkForExisting = true,
}: UploadMediaArgsType): Promise<UploadMediaReturnType> {
  const storageDisk: AllowedProvidersType = appConfig.storage
    .disk as AllowedProvidersType;
  const provider: IProvider = providerMapping[storageDisk];

  // Prepare the files metadata to be inserted in database
  let preparedFiles: Partial<IPreparedFile>[] = files.map(
    (file: IMediaFile): Partial<IPreparedFile> => {
      let originalFileName: string = file.originalname;
      const newFileName: string = `${file.filename}.${getExtension(
        originalFileName,
      )}`;
      const fromPath: string = file.path;
      const toPath: string = `/${uid.supplierCompanyId}/${newFileName}`;
      let skuGroup: string = '';

      if (skuSeparator && originalFileName.indexOf(skuSeparator) !== -1) {
        const [skuGroupFound, ...nameParts]: any = originalFileName.split(
          skuSeparator,
        );

        skuGroup = skuGroupFound;

        const newOriginalFileName: string = nameParts.join(skuSeparator);

        // If new name is there and it's not just the extension then use
        // that for the name of the file
        if (newOriginalFileName && !/^\..+?$/.test(newOriginalFileName)) {
          originalFileName = newOriginalFileName;
        }
      }

      return {
        originalFileName,
        newFileName,
        fromPath,
        toPath,
        skuGroup,
        mimetype: file.mimetype,
        size: file.size,
      };
    },
  );

  ////////////////////////////////////////////////////////////////////////
  // Find all the existing media with the given attributes
  ////////////////////////////////////////////////////////////////////////
  const orQuery: any = preparedFiles.map((file: IPreparedFile): any => {
    return {
      originalName: file.originalFileName,
      skuGroup: file.skuGroup,
      'meta.size': file.size,
      'meta.mimetype': file.mimetype,
    };
  });

  const existingFiles: IMediaModel[] = await mediaModel.find({
    $or: orQuery,
    userId: uid.userId,
    supplierId: uid.supplierId,
    supplierCompanyId: uid.supplierCompanyId,
    deletedAt: null,
  });

  if (checkForExisting) {
    ////////////////////////////////////////////////////////////////////////
    // Remove the found media from the existing given media
    ////////////////////////////////////////////////////////////////////////
    preparedFiles = preparedFiles.filter((file: IPreparedFile): boolean => {
      return !existingFiles.some((existingFile: IMediaModel): boolean => {
        return (
          existingFile.originalName === file.originalFileName &&
          existingFile.skuGroup.toUpperCase() === file.skuGroup.toUpperCase() &&
          existingFile.meta?.size === file.size &&
          file.mimetype === existingFile.meta?.mimetype
        );
      });
    });
  }

  //////////////////////////////////////////////////////////////////////////////////////
  // For each of the files, upload them at the given paths and prepare the promises
  //////////////////////////////////////////////////////////////////////////////////////

  const filesPromises: IMediaDocument[] = [];
  for (const file of preparedFiles) {
    const { originalFileName, newFileName, fromPath, toPath, skuGroup } = file;
    const uploadedFile: IMediaDocument = await provider
      .upload(fromPath, toPath)
      .then(
        (): IMediaDocument => {
          return {
            name: newFileName,
            originalName: originalFileName,
            skuGroup,
            group: '',
            provider: storageDisk,
            type: getFileType(newFileName),
            path: toPath,
            meta: {
              size: file.size,
              encoding: file.encoding,
              mimetype: file.mimetype,
            },
            ...uid,
          };
        },
      );
    filesPromises.push(uploadedFile);
  }

  return {
    uploadedFiles: filesPromises as IMediaModel[],
    existingFiles: existingFiles,
  };
}

export async function removeMedia(media: IMediaDocument): Promise<boolean> {
  const provider: IProvider = providerMapping[media.provider];

  return provider.remove(media.path);
}

// ------------------------------------------------------------------------
//  Moves the temporary files in HTML to supplier path and saves them
//  Returns the updated HTML with paths to the saved files
// ------------------------------------------------------------------------
// 1. Gets the images with temporary URLs from the given HTML string
// 2. Generates the path by removing the base temporary URL for each file
// 3. Fetches the files from provider for each file
// 4. For each file, moves it to the supplier path
//    --> Inserts it to the media collection
//    --> Generates the public URL for this file
//    --> replaces the temporary URL in HTML with the given URL
export async function moveFilesToSupplierPath(
  uid: UserIdentifier,
  html: string,
): Promise<{ media: string[]; description: string }> {
  const $: cheerio.Root = cheerio.load(html);
  const disk: string = appConfig.storage.disk;
  const provider: IProvider = providerMapping[disk];

  ////////////////////////////////////////////////////////
  // All the images with temporary paths in the body
  ////////////////////////////////////////////////////////
  const tempImageEls: cheerio.Cheerio = $('[data-path]');
  const existingIds: string[] = [];

  // Keep the ids for existing media items
  $('[data-id]').each((counter: number, existingImg: cheerio.Element): void => {
    existingIds.push($(existingImg).data('id'));
  });

  // If there are not temporary path images, just return the same HTML
  // We don't need to do any further processing
  if (tempImageEls.length === 0) {
    return {
      media: existingIds,
      description: $('body').html(),
    };
  }

  const providerFilePromises: Promise<ProviderFileType>[] = [];

  ////////////////////////////////////////////////////////
  // Get the temp file paths, we will use these to fetch
  // the file details from temp files and then move them
  ////////////////////////////////////////////////////////
  tempImageEls.each(
    async (counter: number, image: cheerio.Element): Promise<void> => {
      const tempFilePath: string = $(image).data('path');
      // @todo make the temp paths to be non relative and remove this `/../` removal regex
      const normalizedPath: string = tempFilePath.replace(/^\/\/?\.\.\//, '');

      providerFilePromises.push(provider.get(normalizedPath));
    },
  );

  ////////////////////////////////////////////////////////
  // Fetch the files from provider
  ////////////////////////////////////////////////////////
  const providerFiles: ProviderFileType[] = await Promise.all(
    providerFilePromises,
  );

  // Prepare the "multer" file format
  const mediaFiles: IMediaFile[] = providerFiles.map(
    (file: ProviderFileType, counter: number): IMediaFile => {
      const fileName: string = path.basename(file.path);
      const fileNameWithoutExt: string = fileName.replace(/\..+$/, '');
      const originalFileName: string =
        $(tempImageEls[counter]).data('name') || fileName;
      const fileSizeBytes: number = fs.lstatSync(file.path).size;

      return {
        path: file.path,
        originalname: originalFileName,
        filename: fileNameWithoutExt,
        mimetype: '',
        encoding: '',
        size: fileSizeBytes,
        buffer: null,
        destination: '',
        stream: undefined,
        fieldname: '',
      };
    },
  );

  ////////////////////////////////////////////////////////
  // Upload the files and create database entries
  ////////////////////////////////////////////////////////
  const {
    uploadedFiles,
    existingFiles,
  }: UploadMediaReturnType = await uploadMediaFiles({ uid, files: mediaFiles });
  const insertedObjs: IMediaModel[] = await mediaModel.insertMany(
    uploadedFiles as IMediaModel[],
  );

  // Get the URLs that we will be replacing the temporary URLs with
  const objsWithUrls: Components.Schemas.V1MediaItem[] = [
    ...insertedObjs,
    ...existingFiles,
  ].map(
    (insertedObj: IMediaModel): V1MediaItem => ({
      ...insertedObj.toJSON(),
      url: getMediaUrl(insertedObj),
    }),
  );

  ////////////////////////////////////////////////////////
  // Replace the temp URLs with actual URLs
  ////////////////////////////////////////////////////////
  tempImageEls.each((index: number, tempImageEl: cheerio.Element): void => {
    const { url: updatedUrl, _id: updatedId } = objsWithUrls[index];

    $(tempImageEl).attr('src', updatedUrl);
    $(tempImageEl).attr('data-id', updatedId);
    $(tempImageEl).removeAttr('data-path');
    $(tempImageEl).removeAttr('data-name');
  });

  return {
    media: [...existingIds, ...map(insertedObjs, '_id')],
    description: $('body').html(),
  };
}

export type ImageMetaType = {
  height: number;
  width: number;
  type: string;
};

export type ValidateMediaSizeType = {
  minHeight: number;
  minWidth: number;
  minAspectRatio: number;
  maxAspectRatio: number;
  maxResolution: number;
};

export function validateMediaSize({
  minHeight,
  minWidth,
  minAspectRatio,
  maxAspectRatio,
  maxResolution,
}: ValidateMediaSizeType): ValidationChain {
  return body('files').custom(
    async (files: IMediaFile[]): Promise<boolean> => {
      for (let counter: number = 0; counter < files.length; counter++) {
        const fileExtension: string = files[counter].originalname
          .split('.')
          .pop();

        if (!allowedImageExtensions.includes(fileExtension)) {
          continue;
        }
        const file: ReadStream = fs.createReadStream(files[counter].path);
        const imageMeta: ProbeResult = await probe(file);
        const { height, width } = imageMeta;

        const currRatio: number = width / height;
        const isRatioInRange: boolean =
          inRange(currRatio, minAspectRatio, maxAspectRatio) ||
          currRatio === maxAspectRatio;

        // Ratio has to be in range and one of the width or height has to be more than allowed min width/height
        if (!isRatioInRange || (height < minHeight && width < minWidth)) {
          throw new HttpError(
            StatusCodes.BAD_REQUEST,
            ERRORS.DIMENSION_INVALID,
          );
        }

        // check if image Resolution is higher than 65mb
        const currentResolution: number = height * width;
        if (currentResolution > maxResolution) {
          throw new HttpError(
            StatusCodes.BAD_REQUEST,
            'Image must be less than 65 megapixels',
          );
        }
      }

      return true;
    },
  );
}

export function getListMeidaValidations(): BaseValidationType {
  return [
    body('page').optional().isInt({ gt: 0 }).withMessage(ERRORS.INVALID),
    body('size')
      .optional()
      .isInt({ lt: appConfig.media.listMaxLimit, gt: 0 })
      .withMessage(ERRORS.INVALID),
    body('filter.ids').optional().isArray().withMessage(ERRORS.INVALID),
    body('filter.ids.*').isMongoId(),
    body('filter.term').optional().isString().withMessage(ERRORS.INVALID),
    body('filter.type').optional().isArray().withMessage(ERRORS.INVALID),
    body('filter.type.*').isString(),
  ];
}

export async function listMedia(params: {
  ids: string[];
  type: string[];
  term: string;
  page: number;
  size: number;
  supplierCompanyId?: string;
}): Promise<{
  totalRecords: number;
  items: Components.Schemas.V1MediaItems;
}> {
  const { ids, type, term, size, page, supplierCompanyId } = params;
  // Subtracting one from the page because page counter is 0 based
  const recordsToSkip: number = (page - 1) * size;
  const query: any = {
    ...(ids?.length ? { _id: { $in: ids } } : {}),
    ...(type?.length ? { type: { $in: type } } : {}),
    //@todo: as discussed with Farag keep it as commented for now, later on will review and remove it
    /*...(term
      ? {
          $or: [
            {
              originalName: {
                $regex: term,
                $options: 'i',
              },
            },
            {
              group: {
                $regex: term,
                $options: 'i',
              },
            },
            {
              skuGroup: term,
            },
          ],
        }
      : {}),*/
    ...(term
      ? {
          $text: { $search: term },
        }
      : {}),
    ...(supplierCompanyId ? { supplierCompanyId } : {}),
    deletedAt: null,
  };

  const totalRecords: number = await mediaModel.countDocuments(query);
  const items: Components.Schemas.V1MediaItems = await mediaModel
    .find(
      query,
      {
        _id: 1,
        name: 1,
        originalName: 1,
        group: 1,
        skuGroup: 1,
        provider: 1,
        path: 1,
        type: 1,
        meta: 1,
        userId: 1,
        supplierId: 1,
        supplierCompanyId: 1,
        deletedAt: 1,
        createdAt: 1,
        updatedAt: 1,
      },
      {
        sort: {
          createdAt: -1,
        },
        skip: recordsToSkip,
        limit: size,
      },
    )
    .lean();

  const transformedItems: Components.Schemas.V1MediaItems = items.map(
    (item: Components.Schemas.V1MediaItem): Components.Schemas.V1MediaItem => ({
      ...item,
      url: joinUrl(appConfig.mediaBaseUrl, item.path),
    }),
  );

  return { items: transformedItems, totalRecords };
}
