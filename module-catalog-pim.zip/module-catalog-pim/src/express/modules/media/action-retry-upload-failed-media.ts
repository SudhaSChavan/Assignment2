import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { ImageUploadStatuses } from './types';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { publishToQueue } from '@src/config/event/kafka';
import {
  V3ImageUploadQueueQueueMessageData,
  V3ImageUploadQueueSubject,
} from '@express/modules/product/queue-message/queue-message-v1-image-upload';
import { body } from 'express-validator';
import { ERRORS } from '@src/types/errors';
import { HttpError } from '@tradeling/web-js-utils';
import { StatusCodes } from 'http-status-codes';
import { imageUploadRowModel } from '@express/modules/media/model-image-upload-row';
import { chunk } from 'lodash';
import { appConfig } from '@src/config/env';

interface IReq extends IAppRequest {
  body: Paths.V1RetryUploadMediaAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1RetryUploadMediaAction.Responses.$200) => this;
}

export const validateRetryUploadedMedia: BaseValidationType = [
  body('uploadId').isString().optional().withMessage(ERRORS.INVALID),
  body('uniqueId').isString().optional().withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function retryUploadedMediaAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { body } = req;
  const { uploadId, uniqueId } = body;
  if (!uploadId && !uniqueId) {
    throw new HttpError(
      StatusCodes.BAD_REQUEST,
      'uploadId or Unique id should be sent',
    );
  }
  if (uniqueId) {
    //this is only one row no extra logic required ..

    // find by unique Id where status is failed and number of tries is less than 3
    const failedUpload = await imageUploadRowModel.findOne({
      uniqueId,
      status: ImageUploadStatuses.Failed,
      // number of tries should be less than 3
      numberOfTries: { $lt: 3 },
    });

    if (failedUpload) {
      await publishToImageUploadQueue(
        failedUpload,
        req?.headers['x-jwt-token'],
      );
      res.json({ totalCount: 1 });
    } else {
      res.json({ totalCount: 0 });
    }
  }

  // else the upload id case
  const failedUploads = await getFailedUploads(uploadId);

  if (failedUploads) {
    // chunk the failed uploads and publish to queue
    await publishToImageUploadQueue(failedUploads, req?.headers['x-jwt-token']);
  }

  res.json({ totalCount: failedUploads.length });
}

async function getFailedUploads(uploadId: string): Promise<any> {
  return imageUploadRowModel
    .find({
      uploadId,
      status: ImageUploadStatuses.Failed,
      // number of tries should be less than 3
      numberOfTries: { $lt: 3 },
    })
    .lean();
}

async function publishToImageUploadQueue(chunkOfMessages, userToken) {
  const tmpArr = [];

  for (const failedChunk of chunkOfMessages) {
    tmpArr.push({
      uniqueId: failedChunk?.uniqueId,
      uploadId: failedChunk?.uploadId,
      userToken,
      userId: failedChunk?.userId,
      supplierId: failedChunk?.supplierId,
      supplierCompanyId: failedChunk?.supplierCompanyId,
      images: failedChunk?.images,
    });
  }

  const chunkedMessages = chunk(tmpArr, appConfig.maxChunkImageUploadSize);
  for (const chunkedMessage of chunkedMessages) {
    await publishToQueue({
      topic: V3ImageUploadQueueSubject,
      data: chunkedMessage as V3ImageUploadQueueQueueMessageData[],
    });
  }
}
