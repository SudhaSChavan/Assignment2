import { join } from 'path';
import { IProvider, providerMapping } from './providers/types';
import { IMediaModel, mediaModel } from './model-media';
import { logger } from '@core/util/logger';

const deletedFilesDir: string = 'deleted-files';

export async function mediaDeleteListener(mediaIds: string[]): Promise<void> {
  const medias: IMediaModel[] = await mediaModel.find({
    _id: { $in: mediaIds },
    deletedAt: { $ne: null },
  });

  for (const media of medias) {
    const provider: IProvider = providerMapping[media.provider];
    const newPath: string = join(deletedFilesDir, media.path);

    await provider.move(media.path, newPath).catch((error: Error): void => {
      logger.error(
        `Unable to move delete media ${media._id}: ${error.message}`,
      );
    });
    media.path = newPath;
    await media.save();
  }
}
