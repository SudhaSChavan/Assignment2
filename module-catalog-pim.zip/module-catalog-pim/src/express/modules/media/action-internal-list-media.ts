import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { appConfig } from '@src/config/env';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { getListMeidaValidations, listMedia } from './helpers';

interface IReq extends IAppRequest {
  body: Paths.V1InternalListMediaAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1InternalListMediaAction.Responses.$200) => this;
}

export const validateInternalListMedia: BaseValidationType = [
  ...getListMeidaValidations(),
  reqValidationResult,
];

export async function internalListMediaAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    page = 1,
    size = appConfig.media.listDefaultLimit,
    filter: { ids = [], type = [], term = '' } = {},
  } = req.body;

  const { totalRecords, items } = await listMedia({
    ids,
    type,
    size,
    page,
    term,
  });

  res.json({
    currentPage: page,
    totalPages: Math.ceil(totalRecords / size),
    totalRecords,
    size,
    items,
  });
}
