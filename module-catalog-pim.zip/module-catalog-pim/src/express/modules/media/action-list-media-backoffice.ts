import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { joinUrl } from '@core/util/url';
import { ERRORS } from '@src/types/errors';
import { appConfig } from '@src/config/env';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { mediaModel } from './model-media';

interface IReq extends IAppRequest {
  body: Paths.V1ListMediaBoBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1ListMediaBoBackofficeAction.Responses.$200) => this;
}

export const validateListMediaBackoffice: BaseValidationType = [
  body('page').optional().isInt({ gt: 0 }).withMessage(ERRORS.INVALID),
  body('size')
    .optional()
    .isInt({ lt: appConfig.media.listMaxLimit, gt: 0 })
    .withMessage(ERRORS.INVALID),
  body('filter.ids').optional().isArray().withMessage(ERRORS.INVALID),
  body('filter.term').optional().isString().withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function listMediaBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    body: {
      page = 1,
      size = appConfig.media.listDefaultLimit,
      filter: { ids = [], type = '', term = '' } = {},
    },
  } = req;

  // Subtracting one from the page because page counter is 0 based
  const recordsToSkip: number = (page - 1) * size;
  const query: any = {
    ...(ids.length ? { _id: { $in: ids } } : {}),
    ...(type ? { type } : {}),
    ...(term
      ? {
          $or: [
            {
              originalName: {
                $regex: term,
                $options: 'i',
              },
            },
            {
              group: {
                $regex: term,
                $options: 'i',
              },
            },
            {
              skuGroup: term,
            },
          ],
        }
      : {}),
    deletedAt: null,
  };

  const totalRecords: number = await mediaModel.countDocuments(query);
  const items: Components.Schemas.V1MediaItems = await mediaModel
    .find(
      query,
      {
        // @todo add projection
      },
      {
        sort: {
          createdAt: -1,
        },
        skip: recordsToSkip,
        limit: size,
      },
    )
    .lean();

  const transformedItems: Components.Schemas.V1MediaItems = items.map(
    (item: Components.Schemas.V1MediaItem): Components.Schemas.V1MediaItem => ({
      ...item,
      url: joinUrl(appConfig.mediaBaseUrl, item.path),
    }),
  );

  res.json({
    currentPage: page,
    totalPages: Math.ceil(totalRecords / size),
    totalRecords,
    size,
    items: transformedItems,
  });
}
