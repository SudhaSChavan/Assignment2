import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { IMediaFile } from './types';
import { joinUrl } from '@core/util/url';
import { appConfig } from '@src/config/env';
import { getExtension } from '@core/util/file';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { validateFileUpload } from '@core/util/validators';
import {
  AllowedProvidersType,
  IProvider,
  providerMapping,
} from './providers/types';

interface IReq extends IAppRequest {
  body: Paths.V1UploadEditorMediaAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1UploadEditorMediaAction.Responses.$200) => this;
}

export const validateUploadEditorMedia: BaseValidationType = [
  validateFileUpload({
    maxFileSize: appConfig.media.maxFileSizeBytes,
    extensions: appConfig.media.allowedUploadExtensions,
  }),
  reqValidationResult,
];

export async function uploadEditorMediaAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { userId, supplierId, supplierCompanyId } = req;
  const { files: [file] = [] }: { files: IMediaFile[] } = req.body as any;

  const originalName: string = file.originalname;
  const newName: string = `${file.filename}.${getExtension(originalName)}`;
  const storageDisk: AllowedProvidersType = appConfig.storage
    .disk as AllowedProvidersType;
  const provider: IProvider = providerMapping[storageDisk];
  const pathInTemp: string = `/${appConfig.storage.tempMediaPath}/${supplierCompanyId}/${newName}`;

  await provider.upload(file.path, pathInTemp);

  res.json({
    link: joinUrl(appConfig.tempMediaBaseUrl, pathInTemp),
    path: pathInTemp,
    name: originalName,
  } as any);
}
