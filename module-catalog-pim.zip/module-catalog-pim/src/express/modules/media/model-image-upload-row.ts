import mongoose from 'mongoose';
import { Images } from '@express/modules/product/queue-message/queue-message-v1-image-upload';
import { logger } from '@tradeling/core';
import { ImageUploadStatuses } from '@express/modules/media/types';

export interface IImageUploadRowDocument {
  error?: string;
  status: ImageUploadStatuses;
  userId?: string;
  supplierId?: string;
  numberOfTries?: number;
  supplierCompanyId?: string;
  images: Images[];
  deletedAt?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface IImageUploadRowModel
  extends IImageUploadRowDocument,
    mongoose.Document {
  _id: string;
}

const imageUploadRowSchema: mongoose.Schema = new mongoose.Schema(
  {
    numberOfTries: {
      type: Number,
      default: 0,
    },
    images: {
      type: Array,
      required: true,
    },

    status: {
      type: String,
      required: true,
      enum: Object.values(ImageUploadStatuses),
    },
    userId: {
      type: String,
      required: true,
    },
    uniqueId: {
      type: String,
      required: true,
    },
    supplierId: {
      type: String,
      required: true,
    },
    supplierCompanyId: {
      type: String,
      required: true,
    },
    error: {
      type: String,
      default: '',
    },
    uploadId: {
      type: String,
      required: true,
    },
    deletedAt: {
      type: Date,
      default: null,
    },
  },
  {
    versionKey: false,
    timestamps: true,
    collection: 'imageUploadRow',
  },
);

imageUploadRowSchema.index({ status: 1, uploadId: 1 });
imageUploadRowSchema.index({ uniqueId: 1, status: 1 });
imageUploadRowSchema.index({ uniqueId: 1 });

export const imageUploadRowModel: mongoose.Model<IImageUploadRowModel> = mongoose.model<IImageUploadRowModel>(
  'imageUploadRow',
  imageUploadRowSchema,
);

imageUploadRowModel.on('index', (err) => {
  if (err) {
    logger.error(err);
  }
});
