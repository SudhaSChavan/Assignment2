import path from 'path';
import fs from 'fs';
import { appConfig } from '@src/config/env';
import { IProvider, ProviderFileType, Providers } from './types';
import { HttpError } from '@tradeling/web-js-utils';

export const localProvider: IProvider = {
  get: async (filePath: string): Promise<ProviderFileType> => {
    const fullUploadPath: string = path.join(
      appConfig.storage.diskPath,
      filePath,
    );
    const dirExists: boolean = await fs.promises
      .access(fullUploadPath)
      .then((): boolean => true)
      .catch((): boolean => false);

    if (!dirExists) {
      throw new HttpError(404, `File not found ${fullUploadPath}`);
    }

    return {
      name: path.basename(fullUploadPath),
      path: fullUploadPath,
      provider: Providers.LOCAL,
    };
  },

  upload: async (fromPath: string, toPath: string): Promise<boolean> => {
    const fullUploadPath: string = path.join(
      appConfig.storage.diskPath,
      toPath,
    );
    const fullUploadPathDir: string = path.dirname(fullUploadPath);

    const dirExists: boolean = await fs.promises
      .access(fullUploadPathDir)
      .then((): boolean => true)
      .catch((): boolean => false);

    // create the directory if it does not exist
    if (!dirExists) {
      await fs.promises.mkdir(fullUploadPathDir, { recursive: true });
    }

    // Move the file to the new path
    return await fs.promises
      .rename(fromPath, fullUploadPath)
      .then((): boolean => true)
      .catch((): boolean => false);
  },

  move: async (fromPath: string, toPath: string): Promise<boolean> => {
    return !(await localProvider.upload(fromPath, toPath));
  },

  remove: async (fromPath: string): Promise<boolean> => {
    return !(await localProvider.upload(fromPath, '/dev/null'));
  },

  copy: async (fromPath: string, toPath: string): Promise<boolean> => {
    return await fs.promises
      .copyFile(fromPath, toPath)
      .then((): boolean => true)
      .catch((): boolean => false);
  },
};
