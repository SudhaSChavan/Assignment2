import fs from 'fs';
import path from 'path';
import { IProvider, ProviderFileType, Providers } from './types';
import { ManagedUpload } from 'aws-sdk/lib/s3/managed_upload';
import { CopyObjectRequest, GetObjectOutput } from 'aws-sdk/clients/s3';
import { appConfig } from '@src/config/env';
import { awsS3Client } from '@core/util/s3-client';
import { AWSError } from 'aws-sdk';
import { logger } from '@core/util/logger';

export const s3Provider: IProvider = {
  get: async (fromPath: string): Promise<ProviderFileType> => {
    return await awsS3Client
      .getObject({
        Key: fromPath,
        Bucket: appConfig.s3.bucket,
      })
      .promise()
      .then(
        (data: GetObjectOutput): ProviderFileType => {
          const fileName: string = path.basename(fromPath);
          const toWritePath: string = path.join(
            appConfig.storage.tempMulterPath,
            fileName,
          );

          // @fixme make it promise based write
          // Write the file and return the data available
          fs.writeFileSync(toWritePath, data.Body as Buffer);

          return {
            name: fileName,
            path: toWritePath,
            provider: Providers.LOCAL,
          };
        },
      )
      .catch(
        (e: AWSError): ProviderFileType => {
          console.log(`Error while downloading file from S3: ${e.message}`);

          return {
            name: '',
            path: '',
            provider: Providers.LOCAL,
          };
        },
      );
  },

  upload: async (fromPath: string, toPath: string): Promise<boolean> => {
    const fullUploadPath: string = path
      .join(appConfig.storage.diskPath, toPath)
      .replace(/^\/|\/$/g, '');

    return await awsS3Client
      .upload({
        ACL: 'public-read',
        Key: fullUploadPath,
        Bucket: appConfig.s3.bucket,
        Body: fs.createReadStream(fromPath),
      })
      .promise()
      .then((data: ManagedUpload.SendData): boolean => {
        // return data.Location;
        return true;
      })
      .catch((): boolean => false);
  },

  move: async (fromPath: string, toPath: string): Promise<boolean> => {
    // Remove trailing slashes from the path because S3 otherwise creates empty dir on S3
    const fullToPath: string = path
      .join(appConfig.storage.diskPath, toPath)
      .replace(/^\/|\/$/g, '');
    const fullFromPath: string = path.join(appConfig.s3.bucket, fromPath);

    return await awsS3Client
      .copyObject({
        Key: fullToPath,
        CopySource: fullFromPath,
        Bucket: appConfig.s3.bucket,
      } as CopyObjectRequest)
      .promise()
      .then(
        (): Promise<any> =>
          awsS3Client
            .deleteObject({
              Key: fullFromPath,
              Bucket: appConfig.s3.bucket,
            } as CopyObjectRequest)
            .promise(),
      )
      .then((): boolean => true)
      .catch((): boolean => false);
  },

  remove: async (fromPath: string): Promise<boolean> => {
    const fullFromPath: string = path.join(appConfig.s3.bucket, fromPath);

    return awsS3Client
      .deleteObject({
        Key: fullFromPath,
        Bucket: appConfig.s3.bucket,
      } as CopyObjectRequest)
      .promise()
      .then((): boolean => true)
      .catch((): boolean => false);
  },

  copy: async (fromPath: string, toPath: string): Promise<boolean> => {
    // Remove trailing slashes from the path because S3 otherwise creates empty dir on S3
    const fullToPath: string = toPath.replace(/^\/|\/$/g, '');
    const fullFromPath: string = path.join(appConfig.s3.bucket, fromPath);

    return await awsS3Client
      .copyObject({
        Key: fullToPath,
        CopySource: fullFromPath,
        Bucket: appConfig.s3.bucket,
      } as CopyObjectRequest)
      .promise()
      .then((): boolean => true)
      .catch((error: Error): boolean => {
        logger.error(
          `failed to copy file: ${error.message} from: ${fullFromPath} to: ${fullToPath}`,
        );
        return false;
      });
  },
};
