import { localProvider } from './local';
import { s3Provider } from './s3';

export enum Providers {
  LOCAL = 'local',
  S3 = 's3',
}

export type AllowedProvidersType = typeof Providers.LOCAL | typeof Providers.S3;

export type ProviderFileType = {
  name: string;
  path: string;
  provider: AllowedProvidersType;
};

export interface IProvider {
  get: (path: string) => Promise<ProviderFileType>;
  upload: (fromPath: string, toPath: string) => Promise<boolean>;
  move: (fromPath: string, toPath: string) => Promise<boolean>;
  remove: (fromPath: string) => Promise<boolean>;
  copy: (fromPath: string, toPath: string) => Promise<boolean>;
}

interface IProviderMapping {
  [key: string]: IProvider;
}

export const providerMapping: IProviderMapping = {
  local: localProvider,
  s3: s3Provider,
};
