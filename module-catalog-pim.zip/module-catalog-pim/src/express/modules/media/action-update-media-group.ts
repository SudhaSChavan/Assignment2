import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { logger } from '@core/util/logger';
import { IMediaModel, mediaModel } from './model-media';
import { ERRORS } from '@src/types/errors';
import { EE } from '@src/config/event/emitter';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { HttpError } from '@tradeling/web-js-utils';
import { StatusCodes } from 'http-status-codes';

export enum MediaUpdateGroup {
  Success = 'media.updateGroup.success',
}

interface IReq extends IAppRequest {
  body: Paths.V1UpdateMediaGroupAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1UpdateMediaGroupAction.Responses.$200) => this;
}

export const validateUpdateMediaGroup: BaseValidationType = [
  body('id')
    .notEmpty()
    .withMessage(ERRORS.MISSING)
    .isMongoId()
    .withMessage(ERRORS.INVALID),
  body('group')
    .notEmpty()
    .withMessage(ERRORS.MISSING)
    .isString()
    .withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function updateMediaGroupAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    userId,
    supplierId,
    supplierCompanyId,
    body: { id: mediaId, group },
  } = req;

  const foundMedia: IMediaModel = await mediaModel.findOne({
    _id: mediaId,
    supplierCompanyId,
  });

  if (!foundMedia) {
    throw new HttpError(StatusCodes.NOT_FOUND, ERRORS.NOT_FOUND);
  }

  const updateResult: any = await mediaModel.updateOne(
    {
      _id: mediaId,
      supplierCompanyId,
    },
    {
      $set: {
        group: group,
      },
    },
  );

  EE.emit(MediaUpdateGroup.Success, { mediaId, group }).catch(
    (error: Error): void => {
      logger.error(`Event ${MediaUpdateGroup.Success} failed: ${error.stack}`);
    },
  );

  res.json({
    isUpdated: updateResult && updateResult.nModified === 1,
  });
}
