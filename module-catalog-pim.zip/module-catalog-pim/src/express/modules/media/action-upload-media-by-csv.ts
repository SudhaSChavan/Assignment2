import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import csv from 'csvtojson';
import { IMediaFile } from './types';
import { validateMediaSize } from './helpers';
import { appConfig } from '@src/config/env';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { validateFileUpload } from '@core/util/validators';
import { isUrl } from '@express/modules/upload/helpers';
import { publishToQueue } from '@src/config/event/kafka';
import { logger } from '@core/util/logger';
import {
  V3ImageUploadQueueQueueMessageData,
  V3ImageUploadQueueSubject,
} from '@express/modules/product/queue-message/queue-message-v1-image-upload';
import {
  storeUploadFile,
  v3MediaTemplate,
} from '@express/modules/upload/v3/helpers';
import { UploadType } from '@express/modules/product/types';
import { joinUrl } from '@core/util/url';
import crypto from 'crypto';
import { BadRequestException } from '@nestjs/common';
import { chunk } from 'lodash';

interface IReq extends IAppRequest {
  body: Paths.V1UploadMediaByCsvAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1UploadMediaByCsvAction.Responses.$200) => this;
}

export const validateUploadMediaByCsv: BaseValidationType = [
  validateFileUpload({
    maxFileSize: appConfig.media.maxFileSizeBytes,
    extensions: appConfig.media.allowedUploadExtensions,
  }),
  validateMediaSize({
    minHeight: appConfig.media.minHeight,
    minWidth: appConfig.media.minWidth,
    minAspectRatio: appConfig.media.minAspectRatio,
    maxAspectRatio: appConfig.media.maxAspectRatio,
    maxResolution: appConfig.media.maxResolution,
  }),
  reqValidationResult,
];

export async function uploadMediaByCsvAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { body, platform } = req;
  const {
    files,
  }: {
    files: IMediaFile[];
  } = req.body as any;

  const byBackoffice: boolean = platform === 'backoffice';
  const supplierCompanyId: string = byBackoffice
    ? body?.supplierCompanyId
    : req?.supplierCompanyId;
  const supplierId: string = byBackoffice ? body?.supplierId : req?.supplierId;
  const userId: string = byBackoffice ? body?.userId : req?.userId;

  const imagesFromCsv: any[] = await csv({}).fromFile(files[0]?.path);

  if (imagesFromCsv.length > appConfig.maxNumberOfImageUploadCsv) {
    throw new BadRequestException(
      `Max ${appConfig.maxNumberOfImageUploadCsv} images can be uploaded at a time - split the file  and try again`,
    );
  }

  const uploadData = await storeUploadFile(
    {
      file: files[0],
      uid: { userId, supplierCompanyId, supplierId },
      template: v3MediaTemplate,
      type: UploadType.Media,
      totalCount: imagesFromCsv.length,
    },
    platform == 'backoffice',
  );

  const tmpArr = [];
  for (const product of imagesFromCsv) {
    let count: number = 1;

    const images = [];
    for (const index in product) {
      if (isUrl(product[index])) {
        images.push({
          url: product[index],
          fileName: `${product['sku']}_${count}.jpg`,
        });

        count++;
      }
    }

    // pick images url only from images array -- then convert it to unique string
    const imagesUrl = images.map((image) => image.url).join('');

    const imagesUrlHash = crypto
      .createHash('md5')
      .update(imagesUrl + product['sku'])
      .digest('hex');

    tmpArr.push({
      uniqueId: imagesUrlHash,
      uploadId: uploadData?._id,
      userToken: req?.headers['x-jwt-token'],
      userId,
      supplierId,
      supplierCompanyId,
      images,
    });
  }

  // chunk and send to queue
  const chunkedData = chunk(tmpArr, appConfig.maxChunkImageUploadSize);

  for (const chunk of chunkedData) {
    await publishToQueue({
      topic: V3ImageUploadQueueSubject,
      data: chunk as V3ImageUploadQueueQueueMessageData[],
    })
      .then(() => {
        logger.info(
          `Message sent to queue ${V3ImageUploadQueueSubject} with Id ${chunk[0].uniqueId}`,
        );
      })
      .catch((error: Error) => {
        logger.error(
          `Failed to publish message ${error.message} to queue ${V3ImageUploadQueueSubject}`,
        );
      });
  }

  res.json({
    ...uploadData.toJSON(),
    url: joinUrl(appConfig.mediaBaseUrl, uploadData.path),
  });
}
