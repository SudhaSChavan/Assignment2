import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { parse } from 'json2csv';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';

interface IReq extends IAppRequest {
  body: any;
}

interface IRes extends IAppResponse {
  body: (body: Paths.V3GetMediaUploadTemplateAction.Responses.$400) => this;
}

export const validateGetUploadMediaTemplate: BaseValidationType = [
  reqValidationResult,
];

export async function getUploadMediaTemplate(
  req: IReq,
  res: IRes,
): Promise<void> {
  const fields: any = {
    sku: '',
    'Image 1': '',
    'Image 2': '',
    'Image 3': '',
    'Image 4': '',
    'Image 5': '',
  };
  const data: any = parse(fields);

  res.setHeader('content-type', 'text/csv');

  res.attachment('media-template.csv');
  res.status(200).send(data);
}
