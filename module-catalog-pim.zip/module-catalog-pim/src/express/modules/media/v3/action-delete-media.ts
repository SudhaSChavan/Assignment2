import { body } from 'express-validator';
import { map } from 'lodash';

import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { ERRORS } from '@src/types/errors';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { appConfig } from '@src/config/env';
import { IMediaModel, mediaModel } from '../model-media';
import { ProductStates } from '../../product/types';
import { EE } from '@src/config/event/emitter';
import { logger } from '@core/util/logger';
import { HttpError } from '@tradeling/web-js-utils';
import { StatusCodes } from 'http-status-codes';
import {
  IProductModelV3,
  productModelV3,
} from '../../product/model-product-v3';
import {
  ProductSyncEvent,
  ProductSyncEventType,
} from '../../product/sync-hlper';

export enum MediaDeleteEvent {
  Success = 'media.delete.success',
}

interface IReq extends IAppRequest {
  body: Paths.V3DeleteMediaAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3DeleteMediaAction.Responses.$200) => this;
}

export const validateDeleteMediaV3: BaseValidationType = [
  body('ids')
    .notEmpty()
    .isArray({ min: 1, max: appConfig.media.listMaxLimit })
    .withMessage(ERRORS.INVALID),
  body('ids.*').notEmpty().isMongoId().withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function deleteMediaActionV3(req: IReq, res: IRes): Promise<void> {
  const {
    supplierCompanyId,
    body: { ids },
  } = req;

  const medias: IMediaModel[] = await mediaModel
    .find({ _id: { $in: ids }, supplierCompanyId }, '_id')
    .lean();
  const mediaIds: string[] = map(medias, '_id');

  if (!mediaIds.length) {
    throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.NOT_FOUND);
  }

  await mediaModel.updateMany(
    { _id: { $in: mediaIds } },
    { $set: { deletedAt: new Date() as any } },
  );

  EE.emit(MediaDeleteEvent.Success, mediaIds).catch((error: Error): void => {
    logger.error(`Event ${MediaDeleteEvent.Success} failed: ${error.stack}`);
  });

  const products: IProductModelV3[] = await productModelV3
    .find(
      {
        supplierCompanyId,
        $or: [
          { 'media.id': { $in: mediaIds } },
          { descriptionMedia: { $in: mediaIds } },
        ],
      },
      '_id',
    )
    .lean();
  const productIds: string[] = map(products, '_id');

  if (productIds.length) {
    // remove media from products
    await productModelV3.updateMany(
      {
        _id: { $in: productIds },
      },
      {
        $pull: {
          // @ts-ignore
          media: { id: { $in: mediaIds } },
          // @ts-ignore
          descriptionMedia: { $in: mediaIds },
        },
        $set: {
          state: ProductStates.Offline,
        },
      },
    );
  }

  EE.emit(ProductSyncEvent.Updated, {
    req,
    productIds,
    priority: 'highest',
  } as ProductSyncEventType).catch((error: Error): void => {
    logger.error(`Event ${ProductSyncEvent.Updated} failed: ${error.stack}`);
  });

  res.json({ isDeleted: true });
}
