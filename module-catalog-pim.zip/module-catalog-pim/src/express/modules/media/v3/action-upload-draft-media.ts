import {
  BaseValidationType,
  HttpError,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { IMediaFile } from '../types';
import { uploadMediaFiles, UploadMediaReturnType } from '../helpers';
import { appConfig } from '@src/config/env';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { validateFileUpload } from '@core/util/validators';
import { getMediaUrl, IMediaModel, mediaModel } from '../model-media';
import { EE } from '@src/config/event/emitter';
import { logger } from '@core/util/logger';
import { body } from 'express-validator';
import { ERRORS } from '@src/types/errors';
import map from 'lodash/map';
import { DraftState } from '../../product/types';
import {
  IProductUploadRowModelV3,
  productUploadRowModelV3,
} from '../../upload/model-product-upload-row-v3';

export enum MediaCreateEvent {
  Success = 'media.create.success',
}

interface IReq extends IAppRequest {
  body: Paths.V3UploadDraftMediaAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3UploadDraftMediaAction.Responses.$200) => this;
}

export const validateUploadDraftMediaV3: BaseValidationType = [
  validateFileUpload({
    maxFileSize: appConfig.media.maxFileSizeBytes,
    extensions: appConfig.media.allowedUploadExtensions,
  }),
  body('productUploadRowId')
    .notEmpty()
    .withMessage(ERRORS.MISSING)
    .isMongoId()
    .withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function uploadDraftMediaActionV3(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { userId, supplierCompanyId } = req;
  const {
    files,
    productUploadRowId,
  }: { files: IMediaFile[]; productUploadRowId: string } = req.body as any;
  const byBackOffice: boolean = !req.supplierId;

  const productUploadRow: IProductUploadRowModelV3 = await productUploadRowModelV3.findOne(
    { _id: productUploadRowId, ...(byBackOffice ? {} : { supplierCompanyId }) },
  );

  ///////////////////////////////////////////////////
  // Validate product upload row existence
  // Product upload row has to be non-invalid state
  ///////////////////////////////////////////////////
  if (!productUploadRow) {
    throw new HttpError(404, ERRORS.NOT_FOUND);
  }

  // Don't allow uploading media to invalid products
  if (productUploadRow.state === DraftState.Invalid) {
    throw new HttpError(400, ERRORS.NOT_ALLOWED);
  }

  ///////////////////////////////////////////////////////////
  // Upload the files and insert the record in media bank
  ///////////////////////////////////////////////////////////
  const {
    uploadedFiles,
    existingFiles,
  }: UploadMediaReturnType = await uploadMediaFiles({
    uid: {
      userId,
      supplierId: productUploadRow.supplierId,
      supplierCompanyId: productUploadRow.supplierCompanyId,
    },
    files,
  });

  const newMediaObjs: IMediaModel[] = await mediaModel.insertMany(
    uploadedFiles,
  );
  const newMediaIds: string[] = map(newMediaObjs, '_id');

  // Assign the media ids in the product upload row
  productUploadRow.state = DraftState.Valid;
  productUploadRow.media = [
    ...(productUploadRow.media || []),
    ...map(existingFiles, '_id'),
    ...newMediaIds,
  ];
  await productUploadRow.save();

  // Put the URLs in each of the media items
  const uploadedMedia: Components.Schemas.V1MediaItem[] = newMediaObjs.map(
    (insertedObj: IMediaModel): Components.Schemas.V1MediaItem => ({
      ...insertedObj.toJSON(),
      url: getMediaUrl(insertedObj),
    }),
  );

  EE.emit(MediaCreateEvent.Success, newMediaObjs).catch(
    (error: Error): void => {
      logger.error(`Event ${MediaCreateEvent.Success} failed: ${error.stack}`);
    },
  );

  res.json(uploadedMedia);
}
