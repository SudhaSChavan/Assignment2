import { body } from 'express-validator';
import { StatusCodes } from 'http-status-codes';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { HttpError } from '@tradeling/web-js-utils';

import { IMediaModel, mediaModel } from '../model-media';
import { ERRORS } from '@src/types/errors';
import { appConfig } from '@src/config/env';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { joinUrl } from '@core/util/url';
import { productModelV3 } from '../../product/model-product-v3';

interface IReq extends IAppRequest {
  body: Paths.V3GetMediaAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3GetMediaAction.Responses.$200) => this;
}

export const validateGetMediaV3: BaseValidationType = [
  body('id').notEmpty().isMongoId().withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function getMediaActionV3(req: IReq, res: IRes): Promise<void> {
  const {
    supplierCompanyId,
    body: { id },
  } = req;

  const media: IMediaModel = await mediaModel
    .findOne({ _id: id, supplierCompanyId })
    .lean();

  if (!media) {
    throw new HttpError(StatusCodes.NOT_FOUND, ERRORS.NOT_FOUND);
  }

  const products: Components.Schemas.V3Products = await productModelV3
    .find({
      supplierCompanyId: supplierCompanyId,
      $or: [{ 'media.id': media._id }, { descriptionMedia: media._id }],
    })
    .lean();

  res.json({
    media: {
      ...media,
      url: joinUrl(appConfig.mediaBaseUrl, media.path),
    },
    products,
  });
}
