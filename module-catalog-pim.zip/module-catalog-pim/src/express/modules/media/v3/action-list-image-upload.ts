import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { body } from 'express-validator';
import { imageUploadRowModel } from '@express/modules/media/model-image-upload-row';
import { appConfig } from '@src/config/env';

interface IReq extends IAppRequest {
  body: Paths.V3ListImageUploadAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3ListImageUploadAction.Responses.$200) => this;
}

export const validateListImageUpload: BaseValidationType = [
  body('uploadId').notEmpty().isString(),
  body('status').optional().isString(),
  reqValidationResult,
];

export async function v3ListImageUploadAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { body } = req;
  const {
    uploadId,
    status,
    page = 1,
    size = appConfig.product.listDefaultLimit,
  } = body;

  const query = { uploadId };
  if (status) {
    query['status'] = status;
  }

  const totalRecords: number = await imageUploadRowModel
    .find(query)
    .countDocuments();

  const recordsToSkip: number = (page - 1) * size;
  const response = await imageUploadRowModel.find(
    query,
    {
      uploadId: 1,
      status: 1,
      uniqueId: 1,
      error: 1,
      createdAt: 1,
      updatedAt: 1,
      images: 1,
    },
    {
      skip: recordsToSkip,
      limit: size,
    },
  );

  res.json({
    currentPage: page,
    totalPages: Math.ceil(totalRecords / size),
    totalRecords,
    size,
    data: response as any,
  });
}
