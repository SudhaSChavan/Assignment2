import { EE } from '@src/config/event/emitter';
import { logger } from '@core/util/logger';
import { MediaCreateEvent, MediaReplaceEvent } from './action-upload-media';
import { IMediaDocument } from './model-media';
import { mediaDeleteListener } from './listener-media-delete';
import { MediaDeleteEvent } from './v3/action-delete-media';

EE.on(MediaCreateEvent.Success, (mediaDocuments: IMediaDocument[]): void => {
  logger.info(
    `Fired ${MediaCreateEvent.Success}, params: ${JSON.stringify(
      mediaDocuments,
    )}`,
  );
});

EE.on(MediaReplaceEvent.Success, (mediaDocuments: IMediaDocument[]): void => {
  logger.info(
    `Fired ${MediaReplaceEvent.Success}, params: ${JSON.stringify(
      mediaDocuments,
    )}`,
  );
});

EE.on(MediaDeleteEvent.Success, mediaDeleteListener);
