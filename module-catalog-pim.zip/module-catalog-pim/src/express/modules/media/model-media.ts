import mongoose from 'mongoose';
import { ValidFileType } from '@core/util/file';
import { AllowedProvidersType } from './providers/types';
import { logger } from '@core/util/logger';
import { appConfig } from '@src/config/env';
import { joinUrl } from '@core/util/url';

export interface IMediaDocument {
  _id?: string;
  name: string;
  originalName: string;
  group: string;
  skuGroup?: string;
  provider: AllowedProvidersType;
  path: string;
  type: ValidFileType;
  meta: {
    size: number;
    encoding: string;
    mimetype: string;
  };
  userId: string;
  supplierId: string;
  supplierCompanyId: string;
  deletedAt?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface IMediaModel extends IMediaDocument, mongoose.Document {
  _id: string;
}

const mediaSchema: mongoose.Schema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    originalName: {
      type: String,
      required: true,
      trim: true,
    },
    group: {
      type: String,
    },
    skuGroup: {
      type: String,
      set: (sku: string): string => (sku || '').toUpperCase(),
    },
    provider: {
      type: String,
      required: true,
    },
    // Relative path where the file was stored
    path: {
      type: String,
      required: true,
    },
    type: {
      type: String,
      required: true,
    },
    meta: {
      type: Object,
      default: {},
    },
    userId: {
      type: String,
      required: true,
    },
    supplierId: {
      type: String,
      required: true,
    },
    supplierCompanyId: {
      type: String,
      required: true,
    },
    deletedAt: {
      type: Date,
      default: null,
    },
  },
  {
    versionKey: false,
    timestamps: true,
    collection: 'media',
  },
);

mediaSchema.index({ skuGroup: -1 });
mediaSchema.index({ originalName: -1 });
mediaSchema.index({ group: -1 });

// list query by { supplierCompanyId, deletedAt: null } and sorting by `createdAt`
mediaSchema.index(
  { supplierCompanyId: -1, createdAt: -1 },
  { partialFilterExpression: { deletedAt: null } },
);
// list query by { supplierCompanyId, deletedAt: null, type } and sorting by `createdAt`
mediaSchema.index(
  { supplierCompanyId: -1, type: -1, createdAt: -1 },
  { partialFilterExpression: { deletedAt: null } },
);

// support text search with tokenization
mediaSchema.index({ originalName: 'text', group: 'text', skuGroup: 'text' });

export const mediaModel: mongoose.Model<IMediaModel> = mongoose.model<IMediaModel>(
  'Media',
  mediaSchema,
);

mediaModel.on('index', (err) => {
  if (err) {
    logger.error(err);
  }
});

export function getMediaUrl(item: IMediaModel): string {
  return joinUrl(appConfig.mediaBaseUrl, item.path);
}
