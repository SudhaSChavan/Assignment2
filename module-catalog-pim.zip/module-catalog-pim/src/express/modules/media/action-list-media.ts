import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { appConfig } from '@src/config/env';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { getListMeidaValidations, listMedia } from './helpers';

interface IReq extends IAppRequest {
  body: Paths.V1ListMediaAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1ListMediaAction.Responses.$200) => this;
}

export const validateListMedia: BaseValidationType = [
  ...getListMeidaValidations(),
  reqValidationResult,
];

export async function listMediaAction(req: IReq, res: IRes): Promise<void> {
  const {
    body: {
      page = 1,
      size = appConfig.media.listDefaultLimit,
      filter: { ids = [], type = [], term = '' } = {},
    },
    supplierCompanyId,
  } = req;

  const { totalRecords, items } = await listMedia({
    ids,
    type,
    size,
    page,
    term,
    ...(ids.length == 0 ? { supplierCompanyId } : {}),
  });

  res.json({
    currentPage: page,
    totalPages: Math.ceil(totalRecords / size),
    totalRecords,
    size,
    items,
  });
}
