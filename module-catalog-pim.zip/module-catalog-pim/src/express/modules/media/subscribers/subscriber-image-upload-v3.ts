import { consumeFromQueue } from '@src/config/event/kafka';
import { logger } from '@core/util/logger';
import { V3ImageUploadQueueSubject } from '@express/modules/product/queue-message/queue-message-v1-image-upload';
import FormData from 'form-data';
import { V1UploadMediaAction } from '@tradeling/sdk/catalog-pim/v1-upload-media-action';
import fetch from 'node-fetch';
import { ImageUploadStatuses } from '../types';
import { imageUploadRowModel } from '@express/modules/media/model-image-upload-row';
import { IConsumerParams } from '@tradeling/core';
import { redis as redisClient } from '@src/config/redis';
import { uploadModelV3 } from '@express/modules/upload/model-upload-v3';

export function subscribeImageUploadV3(): void {
  consumeFromQueue(V3ImageUploadQueueSubject, processMessage).catch(
    (error: Error): void => {
      logger.error(error.message);
    },
  );
}

async function processMessage(params: IConsumerParams): Promise<void> {
  const { message } = params;

  const messages = JSON.parse(message.value.toString());

  for (const data of messages) {
    await imageUploadUtil(data);
  }
}

export async function imageUploadUtil(imageArr: any): Promise<void> {
  try {
    // set the cache in order to avoid duplicate upload
    const cacheKey: string = `image_upload_${imageArr.uniqueId}`;
    const hasCache: number = await redisClient.exists(cacheKey);

    if (hasCache) {
      logger.info(`already exist cache for ${imageArr.uniqueId}`);
      return;
    }
    await redisClient.set(cacheKey, 'XXX', 'EX', 130000);

    // find by uniqueId - if its exist then skip
    const imageUploadRow = await imageUploadRowModel.findOne({
      uniqueId: imageArr.uniqueId,
      status: ImageUploadStatuses.Success,
    });
    if (imageUploadRow) {
      logger.info(`already exist imageUploadRow for ${imageArr.uniqueId}`);
      return;
    }
    const formData = new FormData();

    for (const image of imageArr.images) {
      let buffer;
      try {
        const response = await fetch(image.url);
        buffer = await response.buffer();
      } catch (error) {
        logger.error(error.message);
        continue;
      }

      formData.append('files[]', buffer, {
        filename: image.fileName,
        contentType: 'image/jpeg',
      });
    }
    //append userId, supplierId, supplierCompanyId to formData
    if (
      !!imageArr.userId &&
      !!imageArr.supplierId &&
      !!imageArr.supplierCompanyId
    ) {
      formData.append('userId', imageArr.userId);
      formData.append('supplierId', imageArr.supplierId);
      formData.append('supplierCompanyId', imageArr.supplierCompanyId);
    }

    // insert the first batch of images
    const formDataHeaders = formData.getHeaders();
    formDataHeaders['x-jwt-token'] = imageArr?.userToken;
    // File Upload Error Multipart: Boundary not found
    formDataHeaders['content-type'] =
      'multipart/form-data; boundary=' + formData.getBoundary();

    try {
      await V1UploadMediaAction(formData as any, {
        timeout: 90000,
        headers: formDataHeaders,
      });

      await insertImageUploadRowModel(imageArr, ImageUploadStatuses.Success);
      logger.info(`${imageArr.uniqueId} uploaded successfully`);
    } catch (error) {
      logger.error(error.message);
      await insertImageUploadRowModel(
        imageArr,
        ImageUploadStatuses.Failed,
        error.message,
      );
      logger.error(`failed ${imageArr.uniqueId} ${error.message}`);
    }
  } catch (e) {
    logger.error(e.message);
  }
}

/**
 *
 * @param data
 * @param status
 * @param error
 */
async function insertImageUploadRowModel(
  data: any,
  status: ImageUploadStatuses,
  error?: string,
): Promise<void> {
  // find first if its exist then increment the counter and status not eq success
  const imageUploadRow = await imageUploadRowModel.findOne({
    uniqueId: data.uniqueId,
  });
  if (imageUploadRow) {
    if (imageUploadRow.status !== ImageUploadStatuses.Success) {
      logger.info(`already exist imageUploadRow for ${data.uniqueId}`);

      imageUploadRow.numberOfTries = imageUploadRow.numberOfTries + 1;
      imageUploadRow.status = status;
      imageUploadRow.error = error;
      await imageUploadRow.save();
    }
  } else {
    logger.info(`inserting imageUploadRow for ${data.uniqueId}`);
    await imageUploadRowModel.create({
      uploadId: data?.uploadId,
      uniqueId: data?.uniqueId,
      userId: data?.userId,
      supplierId: data?.supplierId,
      supplierCompanyId: data?.supplierCompanyId,
      status,
      error,
      images: data.images,
    });
  }

  if (status === ImageUploadStatuses.Failed) {
    // increment uploadModelV3 invalidCount
    await uploadModelV3.updateOne(
      { _id: data?.uploadId },
      { $inc: { invalidCount: 1 } },
    );
  } else if (status === ImageUploadStatuses.Success) {
    await uploadModelV3.updateOne(
      { _id: data?.uploadId },
      { $inc: { uploadedCount: 1 } },
    );
  }
}
