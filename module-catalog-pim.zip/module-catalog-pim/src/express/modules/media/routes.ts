import { Router } from 'express';
import { Router as IRouter } from 'express-serve-static-core';
import './listener';
import './subscriber';
import { isAuthenticatedMw } from '@tradeling/web-js-utils';
import { authenticateInternalMw } from '@tradeling/web-js-utils';
import { catchAsyncErrors } from '@core/util/router';
import { multerHandler } from '@src/config/middleware/multer-mw';
import { uploadMediaAction, validateUploadMedia } from './action-upload-media';
import { listMediaAction, validateListMedia } from './action-list-media';
import {
  uploadEditorMediaAction,
  validateUploadEditorMedia,
} from './action-upload-editor-media';
import {
  updateMediaGroupAction,
  validateUpdateMediaGroup,
} from './action-update-media-group';
import {
  validateInternalListMedia,
  internalListMediaAction,
} from './action-internal-list-media';
import {
  validateListMediaBackoffice,
  listMediaBackofficeAction,
} from './action-list-media-backoffice';
import { backOfficeUserMw } from '@src/config/middleware/is-backoffice-user';
import {
  uploadDraftMediaActionV3,
  validateUploadDraftMediaV3,
} from './v3/action-upload-draft-media';
import {
  deleteMediaActionV3,
  validateDeleteMediaV3,
} from './v3/action-delete-media';
import { getMediaActionV3, validateGetMediaV3 } from './v3/action-get-media';
import {
  uploadMediaByCsvAction,
  validateUploadMediaByCsv,
} from '@express/modules/media/action-upload-media-by-csv';
import {
  getUploadMediaTemplate,
  validateGetUploadMediaTemplate,
} from '@express/modules/media/action-get-upload-media-template';
import {
  retryUploadedMediaAction,
  validateRetryUploadedMedia,
} from '@express/modules/media/action-retry-upload-failed-media';
import {
  v3ListImageUploadAction,
  validateListImageUpload,
} from '@express/modules/media/v3/action-list-image-upload';

const router: IRouter = Router();

router.post(
  '/v1-upload-editor-media',
  isAuthenticatedMw(),
  multerHandler,
  validateUploadEditorMedia,
  catchAsyncErrors(uploadEditorMediaAction),
);

router.post(
  '/v1-upload-media-by-csv',
  isAuthenticatedMw(),
  multerHandler,
  validateUploadMediaByCsv,
  catchAsyncErrors(uploadMediaByCsvAction),
);
router.post(
  '/v1-retry-upload-media',
  isAuthenticatedMw(),
  validateRetryUploadedMedia,
  catchAsyncErrors(retryUploadedMediaAction),
);

router.post(
  '/v1-upload-media',
  isAuthenticatedMw(),
  multerHandler,
  validateUploadMedia,
  catchAsyncErrors(uploadMediaAction),
);
router.post(
  '/v1-update-media-group',
  isAuthenticatedMw(),
  validateUpdateMediaGroup,
  catchAsyncErrors(updateMediaGroupAction),
);
router.post(
  '/v1-list-media',
  isAuthenticatedMw(),
  validateListMedia,
  catchAsyncErrors(listMediaAction),
);
router.post(
  '/v1-internal-list-media',
  authenticateInternalMw,
  validateInternalListMedia,
  catchAsyncErrors(internalListMediaAction),
);
router.post(
  '/v1-list-media-backoffice',
  backOfficeUserMw([]),
  validateListMediaBackoffice,
  catchAsyncErrors(listMediaBackofficeAction),
);

router.post(
  '/v3-get-upload-media-template',
  isAuthenticatedMw(),
  validateGetUploadMediaTemplate,
  catchAsyncErrors(getUploadMediaTemplate),
);

// V3 routes
router.post(
  '/v3-upload-draft-media',
  isAuthenticatedMw(),
  multerHandler,
  validateUploadDraftMediaV3,
  catchAsyncErrors(uploadDraftMediaActionV3),
);
router.post(
  '/v3-delete-media',
  isAuthenticatedMw(),
  validateDeleteMediaV3,
  catchAsyncErrors(deleteMediaActionV3),
);
router.post(
  '/v3-get-media',
  isAuthenticatedMw(),
  validateGetMediaV3,
  catchAsyncErrors(getMediaActionV3),
);
router.post(
  '/v3-list-image-upload',
  isAuthenticatedMw(),
  validateListImageUpload,
  catchAsyncErrors(v3ListImageUploadAction),
);

export { router as mediaRoutes };
