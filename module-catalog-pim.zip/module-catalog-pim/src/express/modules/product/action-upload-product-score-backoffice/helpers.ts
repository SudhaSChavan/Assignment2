import Excel from 'exceljs';
import { StatusCodes } from 'http-status-codes';
import { HttpError } from '@tradeling/web-js-utils';
import { isEmpty } from 'lodash';

const minScore: number = 0;
const maxScore: number = 50000;

export type productScoreRow = {
  id: string;
  name: string;
  score: string;
};

export async function getWorkbook(filePath: string): Promise<Excel.Workbook> {
  const workbook: Excel.Workbook = new Excel.Workbook();

  await workbook.csv.readFile(filePath).catch((): void => {
    throw new HttpError(StatusCodes.BAD_REQUEST, 'invalid csv file'); // map parsing error to 400 Bad Request
  });

  const worksheet: Excel.Worksheet = workbook.getWorksheet(1);

  if (!worksheet) {
    throw new HttpError(StatusCodes.BAD_REQUEST, 'no worksheets found');
  }

  if (worksheet.rowCount <= 1) {
    throw new HttpError(StatusCodes.BAD_REQUEST, 'no data found');
  }

  return workbook;
}

export function getRawData(worksheet: Excel.Worksheet): string[][] {
  const rows: any[] = worksheet.getSheetValues();
  const result: string[][] = [];

  rows.forEach((row, index) => {
    // first row is undefined and second for headers, so skip them
    if (index >= 2) {
      if (row && row.length) {
        // each row looks like:
        // [undefined, cell1, cell2, cell3, ...]
        // so we need to remove first undefined and cast everything else to strings
        result.push(row.slice(1).map(String));
      }
    }
  });

  return result;
}

export const isInvalidScore: (score: string) => boolean = (score: string) => {
  if (isEmpty(score)) {
    return true;
  }
  const scoreNumber: number = Number(score);
  return (
    isNaN(scoreNumber) ||
    !Number.isInteger(scoreNumber) ||
    scoreNumber < minScore ||
    scoreNumber > maxScore
  );
};
