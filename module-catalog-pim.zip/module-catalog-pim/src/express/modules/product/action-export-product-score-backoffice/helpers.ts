import { getInternalApiSecret } from '@tradeling/web-js-utils';
import { V1InternalGetProductAction } from '@tradeling/tradeling-sdk/catalog-search/v1-internal-get-product-action';
import { keyBy } from 'lodash';
import { appConfig } from '@src/config/env';
import { KeyValAny } from '@src/types/common';

export async function getProductsByIds(
  productIds: string[],
  language = 'en',
): Promise<KeyValAny> {
  const { data } = await V1InternalGetProductAction(
    {
      filter: {
        productIds: productIds,
      },
    },
    {
      headers: {
        'x-country': 'ae',
        'x-language': language,
        'x-is-internal-request': '1',
        'x-t-secret': getInternalApiSecret({
          to: 'module-catalog-search',
          from: appConfig.name,
        }),
      },
    },
  );

  return keyBy(data, 'id');
}
