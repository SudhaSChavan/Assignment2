import { IBaseQueueMessage } from '@tradeling/web-js-utils';

export const V1UpdateProductInternalReviewStatusSubject: string =
  'module-catalog-pim.v1-update-product-internal-review-status';

export interface V1UpdateProductInternalReviewStatusMessageData
  extends IBaseQueueMessage {
  productIds: string[];
}
