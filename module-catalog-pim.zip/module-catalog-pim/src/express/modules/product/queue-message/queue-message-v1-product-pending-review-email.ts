import { IBaseQueueMessage } from '@tradeling/web-js-utils';

export const V1ProductPendingReviewEmailQueueSubject: string =
  'module-catalog-pim.v1-product-pending-review-email';

export interface V1ProductPendingReviewEmailQueueMessageData
  extends IBaseQueueMessage {
  lang?: 'en' | 'ar';
  userId: string;
  sellerProductsPageLink: string;
}
