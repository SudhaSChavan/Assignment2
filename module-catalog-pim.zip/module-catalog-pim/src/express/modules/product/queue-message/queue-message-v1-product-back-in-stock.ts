import { IBaseQueueMessage } from '@tradeling/web-js-utils';

export const V1ProductBackInStockSubject: string =
  'module-catalog-pim.v1-product-back-in-stock';

export interface V1ProductBackInStockMessageData extends IBaseQueueMessage {
  productIds: string[];
}
