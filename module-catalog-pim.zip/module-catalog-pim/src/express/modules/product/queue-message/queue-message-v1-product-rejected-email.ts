import { IBaseQueueMessage } from '@tradeling/web-js-utils';

export const V1ProductRejectedEmailQueueSubject: string =
  'module-catalog-pim.v1-product-rejected-email';

export interface V1ProductRejectedEmailQueueMessageData
  extends IBaseQueueMessage {
  lang?: 'en' | 'ar';
  userId: string;
  sellerProductsPageLink: string;
}
