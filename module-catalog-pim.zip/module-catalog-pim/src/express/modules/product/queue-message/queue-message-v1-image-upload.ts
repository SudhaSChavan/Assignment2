import { IBaseQueueMessage } from '@tradeling/web-js-utils';

export const V3ImageUploadQueueSubject: string =
  'module-catalog-pim.v3-image-upload';

export type Images = {
  url: string;
  fileName: string;
};

export interface V3ImageUploadQueueQueueMessageData extends IBaseQueueMessage {
  uploadId: string;
  userToken: string;
  userId?: string;
  supplierId?: string;
  supplierCompanyId?: string;
  images: Images[];
}
