import { IBaseQueueMessage } from '@tradeling/web-js-utils';

export const V1ProductOutOfStockSubject: string =
  'module-catalog-pim.v1-product-out-of-stock';

export interface V1ProductOutOfStockMessageData extends IBaseQueueMessage {
  productIds: string[];
}
