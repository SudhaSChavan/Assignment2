import { IBaseQueueMessage } from '@tradeling/web-js-utils';

export const V1ProductInStockSubject: string =
  'module-catalog-pim.v1-product-in-stock';

export interface V1ProductInStockMessageData extends IBaseQueueMessage {
  productIds: string[];
}
