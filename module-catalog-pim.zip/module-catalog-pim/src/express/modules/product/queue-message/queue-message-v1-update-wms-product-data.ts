import { IBaseQueueMessage } from '@tradeling/web-js-utils';

export const V1UpdateWmsProductDataQueueSubject: string =
  'module-shipment.v1-update-wms-product-data';

export interface V1UpdateWmsProductDataMessageData extends IBaseQueueMessage {
  type: string;
  sku: string;
  supplyPrice: number;
}
