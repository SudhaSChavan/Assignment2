import { IBaseQueueMessage } from '@tradeling/web-js-utils';

export const V1UpdateProductStatusSubject: string =
  'module-catalog-pim.v1-update-product-status';

export interface V1UpdateProductStatusMessageData extends IBaseQueueMessage {
  productIds: string[];
  supplierCompanyId: string;
}
