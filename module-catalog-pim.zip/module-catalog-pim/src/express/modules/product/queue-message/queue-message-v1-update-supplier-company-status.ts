import { IBaseQueueMessage } from '@tradeling/web-js-utils';

export const V1UpdateSupplierCompanyStatusSubject: string =
  'module-catalog-pim.v1-update-supplier-company-status';

export interface V1UpdateSupplierCompanyStatusMessageData
  extends IBaseQueueMessage {
  supplierCompanyId: string;
  status: 'pending' | 'accepted' | 'rejected';
}
