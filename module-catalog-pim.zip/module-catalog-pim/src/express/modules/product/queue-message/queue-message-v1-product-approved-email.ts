import { IBaseQueueMessage } from '@tradeling/web-js-utils';

export const V1ProductApprovedEmailQueueSubject: string =
  'module-catalog-pim.v1-product-approved-email';

export interface V1ProductApprovedEmailQueueMessageData
  extends IBaseQueueMessage {
  lang?: 'en' | 'ar';
  userId: string;
  sellerPLP: string;
  supplierCompanyStatus: 'pending' | 'accepted' | 'rejected';
  sellerDashboard: string;
  uploadBusinessDocumentsPath: string;
  moreAboutBusinessPath: string;
  shippingPreferencesPath: string;
  paymentDetailsPath: string;
}
