import { logger } from '@core/util/logger';
import { V1UpdateSupplierCompanyMetaAction } from '@tradeling/tradeling-sdk/account/v1-update-supplier-company-meta-action';
import { IAppHeaders } from '@src/types/app-request';
import { HttpError } from '@tradeling/web-js-utils';
import { map, uniq } from 'lodash';
import { categoryModel, ICategoryModel } from '../category/model-category';
import {
  publishAuditEvent,
  V1AuditEventMessageData,
} from '@tradeling/emit-audit';
import {
  IProductDocumentV3,
  IProductModelV3,
  productModelV3,
} from './model-product-v3';

export function extractSkusFromVariants(
  variants: Components.Schemas.V1CreateVariant[],
): string[] {
  return variants.map((variant) => variant.sku);
}

type ValidateConfigurableProductsProps = {
  variants: Components.Schemas.V1CreateVariant[];
  existingProductId?: string;
  existingProductSku?: string;
};

export function alphaNumericString(length: number): string {
  const charset: string =
    'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let retVal: string = '';
  for (let i: number = 0, n: number = charset.length; i < length; ++i) {
    retVal += charset.charAt(Math.floor(Math.random() * n));
  }
  return retVal;
}

export function generateVariantChangedValues(
  product: any,
  changedValues: any,
): any {
  const generatedChangedValues: any = {};
  for (const value in changedValues) {
    if (typeof changedValues[value] == 'object') {
      generatedChangedValues[value] = {
        ...product[value],
        ...changedValues[value],
      };
    } else {
      generatedChangedValues[value] = changedValues[value];
    }
  }
  return generatedChangedValues;
}

export async function validateConfigurableProducts({
  variants,
  existingProductId,
  existingProductSku,
}: ValidateConfigurableProductsProps): Promise<void> {
  const configurableSkus: string[] = extractSkusFromVariants(variants);
  if (existingProductSku) {
    configurableSkus.push(existingProductSku);
  }

  // Make sure that the SKUs are unique across the supplier
  if (configurableSkus.length > 0) {
    // Find all the products with the given SKU
    const existingProducts: IProductDocumentV3[] = await productModelV3.find({
      $or: [
        // If there is any product with the given SKUs
        { sku: { $in: configurableSkus } },
      ],
      // Id of the product doesn't match the product which is being updated
      ...(existingProductId ? { _id: { $ne: existingProductId } } : {}),
    });

    // If there are any existing products with the given SKUs, throw error
    if (existingProducts.length > 0) {
      throw new HttpError(400, 'Duplicate SKUs found');
    }
  }
}

export function longDescriptionSanitizer(value: string): string {
  return value
    .replace(/(<p><br><\/p>)+/gm, '<p><br></p>')
    .replace(/(&nbsp;\s?){2,}/gm, '') //
    .replace(/(&#xA0;\s?){2,}/gm, '')
    .replace(/(<p>(&#xA0;\s?)+<\/p>)/gm, '')
    .replace(/(<p>(&nbsp;\s?)+<\/p>)/gm, '')
    .replace(/^(<p><br><\/p>)*/gm, '')
    .replace(/(<p><br><\/p>)*$/gm, '')
    .replace(/(<p>\s*<\/p>)/g, '');
}

export async function setSupplierHasProducts(
  headers: IAppHeaders,
): Promise<void> {
  try {
    await V1UpdateSupplierCompanyMetaAction(
      { key: 'hasProducts', value: true },
      {
        headers: headers,
      },
    );
  } catch (e) {
    logger.error(
      `Unable to set hasProduct, server responded: ${
        e?.response?.data?.message ?? e.message
      }`,
    );
    throw e;
  }
}

export async function getProductIdsForSupplier(
  supplierCompanyId: string,
): Promise<string[]> {
  const products: IProductModelV3[] = await productModelV3
    .find({ supplierCompanyId }, { _id: 1 })
    .lean();
  return uniq(map(products, 'productId').concat(map(products, '_id')));
}

export function getDateFilter(from: number | string, to: number | string): any {
  if (from && to) {
    const fromDt: Date = new Date(0);
    fromDt.setUTCSeconds(from as number);

    const toDt: Date = new Date(0);
    toDt.setUTCSeconds(to as number);

    return {
      $gte: fromDt,
      $lte: toDt,
    };
  } else if (from) {
    const fromDt: Date = new Date(0);
    fromDt.setUTCSeconds(from as number);

    return {
      $gte: fromDt,
    };
  } else if (to) {
    const toDt: Date = new Date(0);
    toDt.setUTCSeconds(to as number);

    return {
      $lte: toDt,
    };
  } else {
    return {};
  }
}

export async function findChildCategories(
  categoryId: string,
): Promise<string[]> {
  let childCategoriesIds: string[] = [];
  if (categoryId) {
    const queryCategories: any = {
      parents: categoryId,
    };

    const childCategories: ICategoryModel[] = await categoryModel.find(
      queryCategories,
    );
    childCategoriesIds = childCategories.map((x) => x._id);
    childCategoriesIds.push(categoryId);
  }
  return childCategoriesIds;
}

export async function sendAuditEvent(
  data: V1AuditEventMessageData,
  eventDescription: string,
): Promise<void> {
  publishAuditEvent(data)
    .then(() =>
      logger.debug(
        `Audit: ${eventDescription} event successfully published ${JSON.stringify(
          data,
        )}`,
      ),
    )
    .catch(() =>
      logger.error(
        `Audit: ${eventDescription} event not published:: ${JSON.stringify(
          data,
        )}`,
      ),
    );
}
