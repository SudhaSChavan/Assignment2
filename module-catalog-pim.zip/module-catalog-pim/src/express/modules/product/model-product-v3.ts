import mongoose, { Schema } from 'mongoose';

import { logger } from '@core/util/logger';
import {
  InternalReviewStatuses,
  InternalReviewStatusType,
  paymentOptions,
  ProductMediaType,
  ProductStates,
  productVariantStrategy,
} from './types';
import { map, uniq, uniqBy } from 'lodash';
import { TransportationModeValues } from '../upload/helpers';
import V3Offer = Components.Schemas.V3Offer;

export type LabelValueType = {
  label: string;
  value: string;
};

export enum UPLOAD_STATE {
  NEW = 'new',
  IMPORTED = 'imported',
  CANCELED = 'canceled',
}
export type ProductState = 'online' | 'offline' | 'deleted';

export type RejectionReason = {
  section: string;
  slug: string;
  msg?: string;
};

export type VariantValueV3 = {
  code: string;
  value: { en: string; ar?: string };
};

export type ConfigurationAttribute = {
  code: string;
  label?: string;
  options: string[];
  value?: string;
};

export interface IProductContentV3 extends IProductDocumentV3 {
  _id: string;
  collectionIds?: string[];
  offers: V3Offer[];
}

export interface IProductDocumentV3 {
  shortId: number;
  internalReviewStatus: InternalReviewStatusType;
  internalReviewedBy: {
    email: string;
    userId: string;
  };
  sku: string;
  parentSku: string;
  name: { en: string; ar?: string };
  shortDescription: { en: string; ar?: string };
  longDescription: { en: string; ar?: string };
  categoryId: string | any; // @todo proper typing
  keywords: {
    en: string[];
    ar?: string[];
  };
  media: Components.Schemas.V1ProductMedia[];
  descriptionMedia: string[];
  postfix?: { en: string; ar?: string };
  state: 'online' | 'offline' | 'deleted';
  attributes: {
    brand: { en: string; ar?: string };
    storageTemperature: string;
    [key: string]: any;
  };
  variantValues: VariantValueV3[];
  stockQty?: number;
  collectionIds?: string[];
  barcode?: string;
  variantCode?: string;
  isDefault: boolean;
  isSearchable: boolean;
  packaging: {
    size?: string;
    unit?: string;
    unitsPerCarton?: string;
  };
  packagingFormat?: string;
  dimensions?: {
    length?: number;
    lengthUnit?: string;
    width?: number;
    widthUnit?: string;
    height?: number;
    heightUnit?: string;
    weight?: number;
    weightUnit?: string;
  };
  isReadyToShip: boolean;
  isBuyNow: boolean;
  isInStock: boolean;
  hasVariants: boolean;
  lastUploadDate: Date | string;
  uploadCount: number;
  strategy?: string;
  supplierCompanyId?: string;
  priceIncotermCondition:
    | 'exworks'
    | 'fca'
    | 'fob'
    | 'cnf'
    | 'cif'
    | 'dap'
    | 'delivered';
  type: 'simple' | 'rfq' | 'configurable';
  // product configuration
  configurationAttributes: ConfigurationAttribute[];
  unit: string;
  paymentOptions: string[];
  // Additional attributes that the customer may add
  additionalAttributes: LabelValueType[];
  transportationMode: Components.Schemas.V1TransportationMode;
  userId: string;
  metadata?: {
    [name: string]: any;
    rejectionReasons?: RejectionReason[];
  };
  tags?: string[];
  deletedAt: string;
  isOverSell?: boolean;
  createdAt: string;
  updatedAt: string;
  syncedAt?: Date;
  storeCode?: string;
  websiteCode?: string;
  storeKeyId?: string;
  manualScore?: number;
  supplyPrice?: number;
  stockQtyBreakdown?: [
    {
      Condition?: {
        code?: string;
        guid?: string;
        id?: number;
        name?: string;
      };
      available: number;
      warehouse: {
        guid?: string;
        id?: number;
        label?: string;
        name?: string;
      };
    },
  ];
}

export interface IProductModelV3 extends IProductDocumentV3, mongoose.Document {
  _id: string;
}

const productSchemaV3: mongoose.Schema = new mongoose.Schema(
  {
    shortId: {
      type: Number,
    },
    supplyPrice: {
      type: Number,
    },
    strategy: {
      type: String,
      default: productVariantStrategy.FEFO,
    },
    stockQtyBreakdown: [
      {
        Condition: {
          code: String,
          guid: String,
          id: Number,
          name: String,
        },
        available: Number,
        warehouse: {
          guid: String,
          id: Number,
          label: String,
          name: String,
        },
      },
    ],

    internalReviewStatus: {
      type: Number,
      default: InternalReviewStatuses.Pending,
    },
    internalReviewedAt: {
      type: Date,
    },
    internalReviewedBy: {
      email: {
        type: String,
      },
      userId: {
        type: String,
      },
    },
    sku: {
      type: String,
      required: true,
      trim: true,
      minlength: 2,
      set: (sku: string): string => (sku || '').toUpperCase(),
    },
    parentSku: {
      type: String,
      required: true,
      trim: true,
      minlength: 2,
      set: (sku: string): string => (sku || '').toUpperCase(),
    },
    name: {
      en: {
        type: String,
        required: true,
        trim: true,
      },
      ar: {
        type: String,
        trim: true,
      },
    },
    postfix: {
      en: {
        type: String,
        trim: true,
        default: '',
      },
      ar: {
        type: String,
        trim: true,
      },
    },
    shortDescription: {
      en: {
        type: String,
        trim: true,
        default: '',
      },
      ar: {
        type: String,
        trim: true,
      },
    },
    longDescription: {
      en: {
        type: String,
        trim: true,
        default: '',
      },
      ar: {
        type: String,
        trim: true,
      },
    },
    supplierCompanyId: {
      type: String,
      required: true,
    },
    keywords: {
      en: {
        type: [String],
        required: true,
      },
      ar: {
        type: [String],
      },
    },
    state: {
      type: String,
      required: true,
      enum: Object.values(ProductStates),
      default: ProductStates.Offline,
    },
    attributes: {
      type: Object,
      default: {},
    },
    'attributes.brand': {
      type: Object,
    },
    'attributes.storageTemperature': {
      type: String,
    },
    packaging: {
      size: {
        type: String,
        required: true,
      },
      unit: {
        type: String,
        required: true,
      },
      unitsPerCarton: {
        type: String,
        required: true,
      },
    },
    packagingFormat: {
      type: String,
    },
    isReadyToShip: {
      type: Boolean,
      default: true,
    },
    isInStock: {
      type: Boolean,
      required: true,
      default: true,
    },
    hasVariants: {
      type: Boolean,
      required: true,
      default: false,
    },
    isBuyNow: {
      type: Boolean,
      default: true,
    },
    isOverSell: {
      type: Boolean,
      default: false,
    },

    dimensions: {
      length: {
        type: Number,
        required: true,
      },
      lengthUnit: {
        type: String,
        required: true,
      },
      width: {
        type: Number,
        required: true,
      },
      widthUnit: {
        type: String,
        required: true,
      },
      height: {
        type: Number,
        required: true,
      },
      heightUnit: {
        type: String,
        required: true,
      },
      weight: {
        type: Number,
        required: true,
      },
      weightUnit: {
        type: String,
        required: true,
      },
    },
    additionalAttributes: {
      type: [
        {
          label: String,
          value: String,
        },
      ],
      default: [],
    },
    type: {
      type: String,
    },
    configurationAttributes: [
      {
        code: String,
        label: String,
        options: [String],
        value: String,
      },
    ],
    paymentOptions: {
      type: [String],
      enum: map(paymentOptions, 'code'),
    },
    unit: {
      type: String,
      required: true,
    },
    media: {
      type: [
        {
          _id: false,
          id: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Media',
            required: true,
          },
          type: { type: String /*required: true*/ },
          sort: { type: Number, default: 1 },
          title: String,
        },
      ],
      set: (mediaItems: ProductMediaType[]): ProductMediaType[] => {
        return uniqBy(mediaItems, ({ id }: ProductMediaType): string => id);
      },
      default: [],
    },
    descriptionMedia: {
      type: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Media' }],
      set: (item: string[]): string[] => uniq(item),
      default: [],
    },
    categoryId: {
      type: mongoose.Schema.Types.ObjectId,
      default: null,
      ref: 'Category',
    },
    transportationMode: {
      type: String,
      enum: TransportationModeValues,
      default: 'regular',
    },
    lastUploadDate: {
      type: Date,
      index: true,
    },
    uploadCount: {
      type: Number,
      default: 1,
    },
    metadata: Schema.Types.Mixed,
    tags: {
      type: [String],
    },
    deletedAt: {
      type: Date,
      default: null,
    },
    syncedAt: {
      type: Date,
      default: null,
    },
    storeKeyId: {
      type: String,
      required: true,
    },
    websiteCode: {
      type: String,
      required: true,
    },
    storeCode: {
      type: String,
      required: true,
    },
    manualScore: {
      type: Number,
      default: 0,
    },
    // we need to sanitize these values during update
    variantValues: [
      {
        code: String,
        value: {
          en: {
            type: String,
            trim: true,
            default: '',
          },
          ar: {
            type: String,
            trim: true,
          },
        },
      },
    ],
    isDefault: { type: Boolean, default: true },
    stockQty: Number,
    barcode: String,
    collectionIds: {
      type: [String],
    },
    version: {
      type: Number,
      default: 2,
    },
  },
  {
    versionKey: false,
    timestamps: true,
    //this will make able to use dev
    // without breaking dev en
    collection: 'productV3',
  },
);

productSchemaV3.index({ categoryId: -1, updatedAt: -1 });
productSchemaV3.index({ deletedAt: 1, supplierCompanyId: 1, updatedAt: -1 });
// Used in the listing queries
productSchemaV3.index({ deletedAt: -1, categoryId: -1, websiteCode: 1 });

// For sorting with lastUploadDate
productSchemaV3.index({ lastUploadDate: -1 });

productSchemaV3.index({ sku: 1, supplierCompanyId: 1 }, { unique: true });

productSchemaV3.index({ parentSku: 1 });

// Backoffice filters
productSchemaV3.index({ supplierCompanyId: -1 });
productSchemaV3.index({ sku: -1 });
productSchemaV3.index({ lastUploadDate: -1, _id: 1, websiteCode: 1 });
productSchemaV3.index({
  lastUploadDate: -1,
  internalReviewStatus: -1,
  deletedAt: 1,
});
productSchemaV3.index({
  sku: 'text',
  'name.en': 'text',
  'name.ar': 'text',
  'shortDescription.en': 'text',
  'shortDescription.ar': 'text',
});

// support for sorting in products list without filters
productSchemaV3.index(
  { createdAt: -1, websiteCode: 1 },
  { partialFilterExpression: { deletedAt: null } },
);

export const productModelV3: mongoose.Model<IProductModelV3> = mongoose.model<IProductModelV3>(
  'ProductV3',
  productSchemaV3,
);

productModelV3.on('index', (err) => {
  if (err) {
    logger.error(err);
  }
});
