import { map } from 'lodash';
import {
  V1UpdateProductInternalReviewStatusMessageData,
  V1UpdateProductInternalReviewStatusSubject,
} from '@tradeling/tradeling-sdk/catalog-pim/queue/queue-message-v1-update-product-internal-review-status';

import { publishToQueue } from '@src/config/event/kafka';
import { logger } from '@core/util/logger';
import { InternalReviewStatuses } from './types';
import { UpdateInternalReviewStatusEventType } from './types';
import {
  V1ProductApprovedEmailQueueMessageData,
  V1ProductApprovedEmailQueueSubject,
} from './queue-message/queue-message-v1-product-approved-email';
import {
  V1ProductRejectedEmailQueueMessageData,
  V1ProductRejectedEmailQueueSubject,
} from './queue-message/queue-message-v1-product-rejected-email';
import { redis as redisClient } from '@src/config/redis';
import {
  getSupplierCompanyProfilesBySupplierIds,
  CompanyProfile,
  getUserById,
  User,
  getSupplierByCompanyId,
  SupplierCompany,
} from './action-update-product-internal-review-status-backoffice/helpers';
import { IOfferModelV3, offerModelV3 } from '../offer/model-offers-v3';

export async function listenerUpdateProductInternalReviewStatus(
  params: UpdateInternalReviewStatusEventType,
): Promise<void> {
  const { productIds } = params;
  publishToQueue({
    topic: V1UpdateProductInternalReviewStatusSubject,
    data: {
      productIds,
    } as V1UpdateProductInternalReviewStatusMessageData,
  })
    .then(() => {
      logger.info(`Message sent to queue`);
    })
    .catch((error: Error) => {
      logger.error(`Failed to publish message ${error.message}`);
    });

  await sendProductReviewEmail(params);
}

async function sendProductReviewEmail(
  params: UpdateInternalReviewStatusEventType,
): Promise<void> {
  const { productIds, status, req } = params;
  const { runtimeProto, runtimeTLD } = req;

  const offers: IOfferModelV3[] = await offerModelV3
    .find({ productId: { $in: productIds } })
    .lean();

  const supplierIds: string[] = map(offers, 'supplierId');

  for (const supplierId of supplierIds) {
    const supplier: User = await getUserById(supplierId);

    const cacheKey: string = `${supplierId}_product_internal_review_${status}`;
    // Do not trigger the same approval/rejection email again if it was sent less than 1 hour ago
    if (await redisClient.exists(cacheKey)) {
      continue;
    }

    if (status === InternalReviewStatuses.Accepted) {
      const profiles: CompanyProfile[] = await getSupplierCompanyProfilesBySupplierIds(
        supplierIds,
        req.headers,
      );
      if (profiles.length == 0) {
        logger.error(
          'failed to fetch company profile for supplierId: ',
          supplierId,
        );
        return;
      }
      const supplierInfo: CompanyProfile = profiles[0];
      const supplierCompany: SupplierCompany = await getSupplierByCompanyId(
        supplier.supplierCompanyId,
      );

      publishToQueue({
        topic: V1ProductApprovedEmailQueueSubject,
        data: {
          userId: supplierId,
          sellerPLP: `${runtimeProto.replace(
            '://',
            '',
          )}://www.${runtimeTLD}/@@lang@@/supplier/${supplierInfo?.slug}/${
            supplier.supplierCompanyId
          }/products`,
          supplierCompanyStatus: supplierCompany?.status,
          sellerDashboard: `${runtimeProto.replace(
            '://',
            '',
          )}://seller-center.${runtimeTLD}/@@lang@@`,
          uploadBusinessDocumentsPath:
            '/personal-detail?scrollTo=businessDocuments',
          moreAboutBusinessPath: '/personal-detail',
          shippingPreferencesPath: '/shipping-preferences',
          paymentDetailsPath: '/payment-details',
        } as V1ProductApprovedEmailQueueMessageData,
      })
        .then(() => {
          logger.info(
            `Message sent to queue ${V1ProductApprovedEmailQueueSubject}`,
          );
        })
        .catch((error: Error) => {
          logger.error(
            `Failed to publish message ${error.message} to queue ${V1ProductApprovedEmailQueueSubject}`,
          );
        });
    } else if (status === InternalReviewStatuses.Rejected) {
      publishToQueue({
        topic: V1ProductRejectedEmailQueueSubject,
        data: {
          userId: supplierId,
          sellerProductsPageLink: `${runtimeProto.replace(
            '://',
            '',
          )}://catalog-pim.${runtimeTLD}/@@lang@@/product?tab=102`,
        } as V1ProductRejectedEmailQueueMessageData,
      })
        .then(() => {
          logger.info(
            `Message sent to queue ${V1ProductRejectedEmailQueueSubject}`,
          );
        })
        .catch((error: Error) => {
          logger.error(
            `Failed to publish message ${error.message} to queue ${V1ProductRejectedEmailQueueSubject}`,
          );
        });
    }

    await redisClient.set(cacheKey, '1', 'EX', 60);
  }
}
