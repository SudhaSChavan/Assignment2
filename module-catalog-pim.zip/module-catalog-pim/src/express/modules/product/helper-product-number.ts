import {
  IProductCounterModel,
  modelProductCounter,
} from './model-product-counter';

export async function getProductNumber(): Promise<number> {
  const doc: any = {
    $set: {
      counterKey: 'product',
    },
    $inc: {
      counterValue: 1,
    },
  };

  const productCounter: IProductCounterModel = await modelProductCounter.findOneAndUpdate(
    {
      counterKey: 'product',
    },
    doc,
    {
      upsert: true,
      new: true,
      lean: true,
    },
  );

  return productCounter.counterValue;
}
