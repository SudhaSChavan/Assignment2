import { body } from 'express-validator';
import { FilterQuery, Types } from 'mongoose';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { ERRORS } from '@src/types/errors';
import { appConfig } from '@src/config/env';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { InternalReviewStatuses } from '../types';
import { categoryModel } from '../../category/model-category';
import { IProductModelV3, productModelV3 } from '../model-product-v3';
import { offerModelV3 } from '../../offer/model-offers-v3';
import { OfferRepositoryV3 } from './repositories/offer-repository.v3';
import { transformFinalResultForProducts } from './helpers';

type V3Variants = Components.Schemas.V3Variants;

interface IReq extends IAppRequest {
  body: Paths.V3ListProductAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3ListProductAction.Responses.$200) => this;
}

const offerRepository: any = new OfferRepositoryV3(offerModelV3);

export const validateListProductV3: BaseValidationType = [
  body('page').optional().isInt({ gt: 0 }).withMessage(ERRORS.INVALID),
  body('size')
    .optional()
    .isInt({ lt: appConfig.product.listMaxLimit, gt: 0 })
    .withMessage(ERRORS.INVALID),
  body('sort').optional().isString(),
  body('filter.categoryId').optional().isMongoId().withMessage(ERRORS.INVALID),
  body('filter.categoryIds').optional().isArray().withMessage(ERRORS.INVALID),
  body('filter.categoryIds.*')
    .isString()
    .isMongoId()
    .withMessage(ERRORS.INVALID),
  body('filter.ids').optional().isArray().withMessage(ERRORS.INVALID),
  body('filter.ids.*').isMongoId().withMessage(ERRORS.INVALID),
  body('filter.mediaId').optional().isString().withMessage(ERRORS.INVALID),
  body('filter.term').optional().isString().withMessage(ERRORS.INVALID),
  body('filter.type').optional().isString().withMessage(ERRORS.INVALID),
  body('filter.state')
    .optional()
    .isString()
    .isIn(['online', 'offline'])
    .withMessage(ERRORS.INVALID),
  body('filter.isInStock')
    .optional()
    .isBoolean()
    .isIn([true, false])
    .withMessage(ERRORS.INVALID),
  body('filter.deleted').optional().isBoolean(),
  body('filter.internalReviewStatus')
    .optional()
    .isNumeric()
    .isIn(Object.values(InternalReviewStatuses))
    .withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function listProductActionV3(req: IReq, res: IRes): Promise<void> {
  const {
    supplierCompanyId,
    body: {
      page = 1,
      size = appConfig.product.listDefaultLimit,
      filter: {
        mediaId = null,
        categoryId = null,
        categoryIds = [],
        state = null,
        isInStock = null,
        term = null,
        deleted = false,
        type = null,
        internalReviewStatus = null,
        ids = null,
      },
      sort: sortStr = '',
    } = {},
  } = req;

  const [sortField, sortOrder] = sortStr?.split(':') ?? [];
  const sort: any = {
    ...(sortField && sortOrder
      ? { [sortField]: Number(sortOrder) }
      : { updatedAt: -1 }),
  };
  // Subtracting one from the page because page counter is 0 based
  const recordsToSkip: number = (page - 1) * size;
  const query: FilterQuery<IProductModelV3> = {
    $and: [
      {
        supplierCompanyId,
        deletedAt: deleted ? { $ne: null } : null,
      },
    ],
  };

  if (mediaId) {
    query.$and.push({
      $or: [
        {
          'media.id': mediaId,
        },
        {
          descriptionMedia: mediaId,
        },
      ],
    });
  }
  if (internalReviewStatus) query.$and.push({ internalReviewStatus });
  if (categoryId) query.$and.push({ categoryId });
  if (isInStock !== null) query.$and.push({ isInStock });
  if (state) query.$and.push({ state });
  if (type) query.$and.push({ type });
  if (categoryIds?.length) {
    const childrenCategories: string[] = await categoryModel.distinct('_id', {
      parents: { $in: categoryIds },
    });
    query.$and.push({
      categoryId: { $in: [...categoryIds, ...childrenCategories] },
    });
  }
  if (term) {
    const mappedTerms: string[] = term
      .split(/,/)
      .map((term: any) => term.toUpperCase().trim())
      .filter((t: any) => !!t);
    // @ts-ignore
    const mappedIds: string[] = mappedTerms.filter((term) =>
      // @ts-ignore
      Types.ObjectId.isValid(term),
    );

    if (mappedIds.length > 0) {
      query.$and.push({
        $or: [
          { _id: { $in: mappedIds } },
          {
            $text: { $search: term },
          },
          {
            sku: { $in: mappedTerms },
          },
        ],
      });
    }

    query.$and.push({
      $or: [
        {
          _id: { $in: mappedIds },
        },
        {
          'name.en': {
            $regex: term,
            $options: 'i',
          },
        },
        {
          sku: term.toUpperCase(),
        },
        {
          sku: { $in: mappedTerms },
        },
        {
          'shortDescription.en': {
            $regex: term,
            $options: 'i',
          },
        },
      ],
    });
  }

  if (ids && ids.length) {
    query.$and.push({
      _id: { $in: ids },
    });
  }

  const totalRecords: number = await productModelV3
    .find(query)
    .countDocuments();

  const products: IProductModelV3[] = await productModelV3
    .find(
      query,
      {
        _id: 1,
        name: 1,
        shortDescription: 1,
        categoryId: 1,
        media: 1,
        keywords: 1,
        sku: 1,
        state: 1,
        packaging: 1,
        isInStock: 1,
        type: 1,
        postfix: 1,
        lastUploadDate: 1,
        uploadCount: 1,
        createdAt: 1,
        updatedAt: 1,
        deletedAt: 1,
        shortId: 1,
        internalReviewStatus: 1,
        metadata: 1,
        tags: 1,
        packagingFormat: 1,
        parentSku: 1,
        hasVariants: 1,
        stockQtyBreakdown: 1,
      },
      {
        sort,
        skip: recordsToSkip,
        limit: size,
      },
    )
    .lean();

  res.json({
    currentPage: page,
    totalPages: Math.ceil(totalRecords / size),
    totalRecords,
    size,
    products: await transformFinalResultForProducts(products),
  });
}
