import { body } from 'express-validator';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import {
  BaseValidationType,
  HttpError,
  reqValidationResult,
} from '@tradeling/web-js-utils';
import { keyBy } from 'lodash';
import { ProductRepositoryV3 } from './repositories/product-repository.v3';
import { productModelV3 } from '../model-product-v3';
import { StatusCodes } from 'http-status-codes';
import { ERRORS } from '@src/types/errors';

interface IReq extends IAppRequest {
  body: Paths.V3InternalGetProductCountAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3InternalGetProductCountAction.Responses.$200) => this;
}

export const validateInternalGetProductCountV3: BaseValidationType = [
  body('supplierCompanyIds').isArray().withMessage(ERRORS.INVALID),
  reqValidationResult,
];

const productRepository: any = new ProductRepositoryV3(productModelV3);

export async function getProductCountActionV3(
  req: IReq,
  res: IRes,
): Promise<IRes> {
  const {
    body: { supplierCompanyIds = [] },
  } = req;
  if (supplierCompanyIds.length === 0) {
    throw new HttpError(
      StatusCodes.BAD_REQUEST,
      "supplierCompanyIds field can't be empty",
    );
  }

  const products: Components.Schemas.V3InternalGetProductCount[] = await productRepository.getProductCountBySupplier(
    supplierCompanyIds,
  );

  const resp: Paths.V3InternalGetProductCountAction.Responses.$200 = keyBy(
    products,
    '_id',
  );
  return res.json(resp);
}
