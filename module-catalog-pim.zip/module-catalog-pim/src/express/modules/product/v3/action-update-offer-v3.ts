import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { ERRORS } from '@src/types/errors';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { tiersValidatorV3 } from '@core/util/validatorsV3';
import { IProductModelV3, productModelV3 } from '../model-product-v3';
import { StatusCodes } from 'http-status-codes';
import { HttpError } from '@tradeling/web-js-utils';
import { offerModelV3 } from '../../offer/model-offers-v3';
import { EE } from '@src/config/event/emitter';
import { ProductSyncEvent, ProductSyncEventType } from '../sync-hlper';
import { logger } from '@core/util/logger';

interface IReq extends IAppRequest {
  body: Paths.V3UpdateOfferAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3UpdateOfferAction.Responses.$200) => this;
}

export const validateV3UpdateOffer: BaseValidationType = [
  body('id') //
    .not()
    .isEmpty()
    .withMessage(ERRORS.MISSING)
    .isMongoId()
    .withMessage(ERRORS.INVALID),
  ...tiersValidatorV3,
  reqValidationResult,
];

export async function v3UpdateOffertAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    user: { supplierCompanyId },
    body: { id, tiers },
  } = req;

  const product: IProductModelV3 = await productModelV3
    .findOne({ _id: id })
    .lean();

  if (!product) {
    throw new HttpError(StatusCodes.NOT_FOUND, ERRORS.NOT_FOUND);
  }

  await offerModelV3.findOneAndUpdate(
    {
      productId: id,
      supplierCompanyId,
    },
    {
      $set: {
        'market.tiers': tiers,
      },
    },
    {
      new: true,
      upsert: true,
    },
  );

  EE.emit(ProductSyncEvent.Updated, {
    req,
    productIds: [id],
    priority: 'highest',
  } as ProductSyncEventType).catch((error: Error): void => {
    logger.error(`Event ${ProductSyncEvent.Updated} failed: ${error.stack}`);
  });

  res.json({ isUpdated: true });
}
