import {
  ConfigurationAttribute,
  IProductModelV3,
  productModelV3,
} from '../model-product-v3';
import { uniq, keyBy, map, groupBy, uniqBy } from 'lodash';
import { IOfferModelV3, offerModelV3 } from '../../offer/model-offers-v3';
import { InternalReviewStatuses } from '../types';
import { IMediaModel, mediaModel } from '../../media/model-media';
import { joinUrl } from '@core/util/url';
import { appConfig } from '@src/config/env';
import {
  IProductUpdateRequestDocumentV3,
  IProductUpdateRequestModelV3,
  productUpdateRequestModelV3,
} from '../model-product-update-request-v3';
import { categoryModel, ICategoryModel } from '../../category/model-category';
import { ProductUpdateRequestListExtendedV3 } from '../action-list-product-update-request/types';
import { V1InternalListUsersAction } from '@tradeling/tradeling-sdk/account/v1-internal-list-users-action';
import { getInternalApiSecret } from '@tradeling/web-js-utils';
import { getDateFilter } from '../helpers';
import { FilterQuery } from 'mongoose';

type V3Offer = Components.Schemas.V3Offer;

type V3Product = Components.Schemas.V3Product;
type User = Account.Components.Schemas.V1InternalListUsersResponse['data'][0];

export async function refreshConfigurationAttributes(
  parentSku: string,
  supplierCompanyId: string,
): Promise<string[]> {
  const products: IProductModelV3[] = await productModelV3
    .find(
      {
        parentSku,
        supplierCompanyId,
        internalReviewStatus: InternalReviewStatuses.Accepted,
      },
      { variantValues: 1 },
    )
    .lean();
  const configurationAttributes: ConfigurationAttribute[] = transformConfigurationAttributes(
    products,
  );
  await productModelV3.updateMany(
    { parentSku, supplierCompanyId },
    { configurationAttributes },
  );
  return map(products, '_id');
}

export function transformConfigurationAttributes(
  products: IProductModelV3[],
): ConfigurationAttribute[] {
  const configurationAttributesObj: any = {};
  const configurationAttributes: any[] = [];
  for (const variant of products) {
    if (variant.variantValues) {
      for (const variantValue of variant.variantValues) {
        configurationAttributesObj[variantValue.code] = [
          ...(configurationAttributesObj[variantValue.code] || []),
          variantValue.value?.en,
        ];
      }
    }
  }
  for (const code of Object.keys(configurationAttributesObj)) {
    configurationAttributes.push({
      code,
      options: uniq(configurationAttributesObj[code]),
    });
  }
  return configurationAttributes;
}

export async function transformFinalResultForProducts(
  products: IProductModelV3[],
  shouldEnrichOffers: boolean = false,
): Promise<V3Product[]> {
  const productIds: string[] = map(products, '_id');

  const offers: IOfferModelV3[] = await offerModelV3
    .find({ productId: { $in: productIds } })
    .lean();
  let offerData: any = groupBy(offers, 'productId');
  if (shouldEnrichOffers) {
    offerData = groupBy(await enrichOffersData(offers), 'productId');
  }

  const updateRequests: IProductUpdateRequestModelV3[] = await productUpdateRequestModelV3.find(
    {
      productId: { $in: productIds },
      status: {
        $in: [InternalReviewStatuses.Pending, InternalReviewStatuses.Rejected],
      },
    },
  );
  const groupedUpdateRequests: Record<
    string,
    IProductUpdateRequestModelV3
  > = keyBy(updateRequests, 'productId');
  const mediaIdsUpdateRequests: any[] = map(
    map(
      map(map(updateRequests, 'diff'), 'media').filter(Boolean),
      'newValue',
    ).flat(1),
    'id',
  );

  const mediaIds: string[] = map(map(products, 'media').flat(1), 'id').concat(
    mediaIdsUpdateRequests,
  );
  const media: IMediaModel[] = await mediaModel.find({
    _id: { $in: mediaIds },
  });
  const groupedMedia: Record<string, IMediaModel> = keyBy(media, '_id');

  return products.map((product: IProductModelV3) => {
    const diff: any = groupedUpdateRequests[product._id]?.diff || {};
    const fields: string[] = Object.keys(diff);
    if (!product.metadata) {
      product['metadata'] = {};
    }
    return {
      ...product,
      media: product?.media?.map((media) => {
        return {
          ...media,
          url: joinUrl(appConfig.mediaBaseUrl, groupedMedia[media?.id]?.path),
          type: groupedMedia[media?.id]?.type,
        };
      }),

      /**
       * If the product changes are under review by backoffice
       */
      ...(groupedUpdateRequests[product._id] &&
      groupedUpdateRequests[product._id].status ===
        InternalReviewStatuses.Pending
        ? {
            ...fields.reduce((obj: any, field: string) => {
              if (field == 'media') {
                obj[field] = (diff as any)[field]?.newValue?.map(
                  (media: any) => {
                    return {
                      ...media,
                      url: joinUrl(
                        appConfig.mediaBaseUrl,
                        groupedMedia[media?.id]?.path,
                      ),
                      type: groupedMedia[media?.id]?.type,
                    };
                  },
                );
                return obj;
              }
              obj[field] = (diff as any)[field].newValue;
              return obj;
            }, {}),
            hasUpdateRequest: fields.length > 0,
          }
        : {}),
      /**
       * If the product changes are rejected by backoffice
       */
      ...(groupedUpdateRequests[product._id] &&
      groupedUpdateRequests[product._id].status ===
        InternalReviewStatuses.Rejected
        ? {
            ...(product.metadata
              ? (product.metadata.rejectionReasons =
                  groupedUpdateRequests[product._id].rejectionReasons)
              : (product['metadata'] = {
                  rejectedReason: null,
                  rejectionReasons:
                    groupedUpdateRequests[product._id].rejectionReasons,
                })),
          }
        : {}),
      offers: offerData[product?._id],
    };
  });
}

export async function findChildCategories(
  categoryIds: string[],
): Promise<string[]> {
  let childCategoriesIds: string[] = [];
  if (categoryIds?.length > 0) {
    const queryCategories: any = {
      parents: { $in: categoryIds },
    };
    const childCategories: ICategoryModel[] = await categoryModel.find(
      queryCategories,
    );
    childCategoriesIds = childCategories.map((x) => x._id);
    childCategoriesIds.push(...categoryIds);
  }
  return childCategoriesIds;
}

export function extendProductUpdateRequest(
  productUpdateRequest: IProductUpdateRequestDocumentV3[],
  products: IProductModelV3[],
): ProductUpdateRequestListExtendedV3[] {
  const productsKeyedById: Record<string, IProductModelV3> = keyBy(
    products,
    '_id',
  );
  const productUpdateRequestList: ProductUpdateRequestListExtendedV3[] = productUpdateRequest
    .filter((p) => productsKeyedById[String(p.productId)])
    .map((productUpdateRequest) => {
      const product: IProductModelV3 =
        productsKeyedById[String(productUpdateRequest.productId)];
      const categoryId: string = product?.categoryId;
      const state: string = product?.state;
      return {
        ...productUpdateRequest,
        state,
        categoryId,
        ...(product?.metadata?.userDetail?.isSupplierVerified == null
          ? {}
          : {
              isSupplierVerified:
                product.metadata.userDetail.isSupplierVerified,
            }),
        ...(product ? { variantValues: product.variantValues } : {}),
      };
    });
  return productUpdateRequestList.filter((item) => !!item);
}

export function getDateFilterV3(
  from: number | string,
  to: number | string,
): any {
  if (from && to) {
    const fromDt: Date = new Date(0);
    fromDt.setUTCSeconds(from as number);

    const toDt: Date = new Date(0);
    toDt.setUTCSeconds(to as number);

    return {
      $gte: fromDt,
      $lte: toDt,
    };
  } else if (from) {
    const fromDt: Date = new Date(0);
    fromDt.setUTCSeconds(from as number);

    return {
      $gte: fromDt,
    };
  } else if (to) {
    const toDt: Date = new Date(0);
    toDt.setUTCSeconds(to as number);

    return {
      $lte: toDt,
    };
  } else {
    return {};
  }
}

async function getUserListBySupplierIds(
  supplierIds: string[],
): Promise<User[]> {
  if (supplierIds.length == 0) return [];
  const { data } = await V1InternalListUsersAction(
    { filter: { ids: supplierIds }, pageSize: supplierIds.length },
    {
      headers: {
        'x-is-internal-request': '1',
        'x-t-secret': getInternalApiSecret({
          to: 'module-account',
          from: appConfig.name,
        }),
      },
    },
  );
  return data.data;
}

async function getUserListBySupplierCompanyIds(
  companyIds: string[],
): Promise<User[]> {
  if (companyIds.length == 0) return [];
  const { data } = await V1InternalListUsersAction(
    { filter: { supplierCompanyIds: companyIds }, pageSize: companyIds.length },
    {
      headers: {
        'x-is-internal-request': '1',
        'x-t-secret': getInternalApiSecret({
          to: 'module-account',
          from: appConfig.name,
        }),
      },
    },
  );
  return data.data;
}

async function getSuppliers(
  supplierIds: string[],
  supplierCompanyIds: string[],
): Promise<User[]> {
  const usersBySupplierIds: User[] = await getUserListBySupplierIds(
    supplierIds,
  );
  const usersByCompanyIds: User[] = await getUserListBySupplierCompanyIds(
    supplierCompanyIds,
  );
  return uniqBy(
    [...usersBySupplierIds, ...usersByCompanyIds],
    (user) => user._id,
  );
}

async function enrichOffersData(offers: IOfferModelV3[]): Promise<V3Offer[]> {
  const supplierIds: string[] = map(offers, 'supplierId').filter((id) =>
    Boolean(id),
  );
  const subSupplierCompanyIds: string[] = map(
    map(offers, 'subSupplierCompanies').flat(1),
    'subSupplierCompanyId',
  ).filter((id) => Boolean(id));
  const suppliers: User[] = await getSuppliers(
    supplierIds,
    subSupplierCompanyIds,
  );
  const suppliersObj: Record<string, User> = keyBy(suppliers, '_id');
  const supplierCompaniesObj: Record<string, User> = keyBy(
    suppliersObj,
    'supplierCompanyId',
  );

  return offers.map((offer) => {
    return {
      ...offer,
      subSupplierCompanies: offer.subSupplierCompanies?.map(
        (subSupplierCompany) => ({
          ...subSupplierCompany,
          companyName:
            supplierCompaniesObj[subSupplierCompany.subSupplierCompanyId]
              ?.companyName,
        }),
      ),
    };
  });
}

export async function generateListProductQuery(
  filter: Paths.V3ListProductBoBackofficeAction.RequestBody['filter'],
): Promise<FilterQuery<IProductModelV3>> {
  const {
    mediaId = null,
    categoryId = null,
    categoryIds = [],
    state = null,
    term = null,
    deleted = false,
    type = null,
    supplierCompanyId,
    isInStock = null,
    isBuyNow = null,
    isReadyToShip = null,
    internalReviewStatus = null,
    reviewedBy = null,
    hasCustomDeliveryDay = null,
    lastUploadDateFrom = null,
    lastUploadDateTo = null,
    isFirstUploadProduct = null,
    productIds = null,
    websiteCode = null,
    parentSku = null,
    sku = null,
    createdFrom = null,
    createdTo = null,
    isVerifiedSupplier = null,
  } = filter;

  const childCategoriesIds: string[] = await findChildCategories(
    categoryId ? [categoryId] : categoryIds,
  );

  const query: FilterQuery<IProductModelV3> = {
    $and: [
      {
        deletedAt: deleted ? { $ne: null } : null,
        ...(supplierCompanyId ? { supplierCompanyId } : {}),
      },
    ],
  };
  if (productIds?.length) {
    query.$and.push({
      _id: { $in: productIds },
    });
  }
  if (mediaId) {
    query.$and.push({
      $or: [
        {
          'media.id': mediaId,
        },
        {
          descriptionMedia: mediaId,
        },
      ],
    });
  }
  if (categoryId) query.$and.push({ categoryId: { $in: childCategoriesIds } });
  if (state) query.$and.push({ state });
  if (isInStock) query.$and.push({ isInStock });
  if (hasCustomDeliveryDay !== null)
    query.$and.push(
      hasCustomDeliveryDay
        ? { hasCustomDeliveryDay: true }
        : {
            $or: [
              { hasCustomDeliveryDay: false },
              { hasCustomDeliveryDay: { $exists: false } },
            ],
          },
    );
  if (isBuyNow) query.$and.push({ isBuyNow });
  if (type) query.$and.push({ type });
  if (isReadyToShip) query.$and.push({ isReadyToShip });
  if (internalReviewStatus) query.$and.push({ internalReviewStatus });
  if (isFirstUploadProduct !== null)
    query.$and.push(
      isFirstUploadProduct ? { uploadCount: 1 } : { uploadCount: { $gt: 1 } },
    );
  if (websiteCode !== null) query.$and.push({ websiteCode: websiteCode });
  if (parentSku !== null) query.$and.push({ parentSku: parentSku });
  if (sku !== null) query.$and.push({ sku });
  if (lastUploadDateFrom || lastUploadDateTo) {
    query.$and.push({
      lastUploadDate: getDateFilter(
        filter.lastUploadDateFrom,
        filter.lastUploadDateTo,
      ),
    });
  }

  if (createdFrom || createdTo) {
    query.$and.push({ createdAt: getDateFilter(createdFrom, createdTo) });
  }

  if (term) {
    query.$and.push({
      $text: { $search: term },
    });
    query.$and.push({
      $or: [
        {
          'name.en': {
            $regex: term,
            $options: 'i',
          },
        },
        {
          sku: term.toUpperCase(),
        },
        {
          'shortDescription.en': {
            $regex: term,
            $options: 'i',
          },
        },
      ],
    });
  }
  if (reviewedBy) {
    query.$and.push({
      'internalReviewedBy.email': {
        $regex: reviewedBy.replace(/[-[\]{}()*+?.,\\/^$|#\s]/g, '\\$&'),
        $options: 'i',
      },
    });
  }

  if (isVerifiedSupplier) {
    const isVerifiedSupplierFilterParam: Record<
      'verified' | 'nonVerified' | 'both',
      { [index: string]: boolean }
    > = {
      verified: { 'metadata.userDetail.isSupplierVerified': true },
      nonVerified: { 'metadata.userDetail.isSupplierVerified': false },
      both: {},
    };
    query.$and.push(isVerifiedSupplierFilterParam[isVerifiedSupplier]);
  }
  return query;
}
