import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { ERRORS } from '@src/types/errors';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { IProductModelV3, productModelV3 } from '../model-product-v3';
import { StatusCodes } from 'http-status-codes';
import { HttpError } from '@tradeling/web-js-utils';
import { logger } from '@core/util/logger';
import { EE } from '@src/config/event/emitter';
import { ProductSyncEvent, ProductSyncEventType } from '../sync-hlper';

interface IReq extends IAppRequest {
  body: Components.RequestBodies.V3UpdateProductAttributes[];
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3UpdateProductAttributesAction.Responses.$204) => this;
}

export const validateV3UpdateAttributesProduct: BaseValidationType = [
  // check if array is empty - at least one item is required
  body().isArray({ min: 1 }).withMessage(ERRORS.INVALID),
  // check if all items are objects
  body()
    .custom((value) => value.every((item) => typeof item === 'object'))
    .withMessage(ERRORS.INVALID),

  body('*.id') //
    .notEmpty()
    .withMessage(ERRORS.MISSING)
    .isMongoId()
    .withMessage(ERRORS.INVALID),
  body('*.attributes.htsCode')
    .optional()
    .isString()
    .isLength({ min: 8, max: 16 }),
  reqValidationResult,
];

export async function v3UpdateProductAttributesAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const ids = req.body.map((item) => item.id);

  for (const { id, attributes } of req.body) {
    const product: IProductModelV3 = await productModelV3
      .findOne({ _id: id })
      .lean();

    // if product not found ...
    if (!product) {
      throw new HttpError(StatusCodes.NOT_FOUND, ERRORS.NOT_FOUND);
    }
    await productModelV3.updateOne(
      {
        _id: id,
      },
      {
        $set: {
          attributes: { ...product.attributes, ...attributes },
        },
      },
    );
  }

  // emit event for sync model
  EE.emit(ProductSyncEvent.Updated, {
    req,
    productIds: ids,
    priority: 'highest',
  } as ProductSyncEventType).catch((error: Error): void => {
    logger.error(`Event ${ProductSyncEvent.Updated} failed: ${error.stack}`);
  });
  res.status(204).end();
}
