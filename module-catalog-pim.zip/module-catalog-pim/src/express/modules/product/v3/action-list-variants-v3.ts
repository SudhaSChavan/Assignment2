import { body } from 'express-validator';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import {
  BaseValidationType,
  HttpError,
  reqValidationResult,
} from '@tradeling/web-js-utils';
import { groupBy, isEmpty } from 'lodash';
import { ProductRepositoryV3 } from './repositories/product-repository.v3';
import { IProductModelV3, productModelV3 } from '../model-product-v3';
import { OfferRepositoryV3 } from './repositories/offer-repository.v3';
import { IOfferModelV3, offerModelV3 } from '../../offer/model-offers-v3';
import { ERRORS } from '@src/types/errors';
import { StatusCodes } from 'http-status-codes';

interface IReq extends IAppRequest {
  body: Paths.V3ListVariantsAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3ListVariantsAction.Responses.$200) => this;
}

export const validateListVariantsActionV3: BaseValidationType = [
  body('ids').notEmpty().isArray({ min: 1 }),
  reqValidationResult,
];

const productRepository: any = new ProductRepositoryV3(productModelV3);
const offerRepository: any = new OfferRepositoryV3(offerModelV3);

export async function actionListVariantsV3(
  req: IReq,
  res: IRes,
): Promise<IRes> {
  const { ids } = req.body;

  //Now variants are the part of product documents
  const variants: IProductModelV3[] = await productRepository.getByIds(ids);

  if (isEmpty(variants)) {
    throw new HttpError(StatusCodes.NOT_FOUND, ERRORS.NOT_FOUND);
  }

  const offers: IOfferModelV3[] = await offerRepository.getActiveByProductIds(
    ids,
  );

  const offersObj: Record<string, IOfferModelV3[]> = groupBy(
    offers,
    'productId',
  );
  const resp: Paths.V3ListVariantsAction.Responses.$200 = variants?.map(
    (variant) => {
      return {
        ...variant,
        offers: offersObj[variant._id],
      };
    },
  );
  return res.json(resp);
}
