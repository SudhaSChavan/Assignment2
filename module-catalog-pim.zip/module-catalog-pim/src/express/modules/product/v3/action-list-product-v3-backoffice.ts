import { body } from 'express-validator';
import { keyBy, map } from 'lodash';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { ERRORS } from '@src/types/errors';
import { appConfig } from '@src/config/env';
import { IAppHeaders, IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { FilterQuery } from 'mongoose';
import { InternalReviewStatuses } from './../types';
import { IProductModelV3, productModelV3 } from '../model-product-v3';
import { V1ListCompanyProfileBackofficeAction } from '@tradeling/tradeling-sdk/seller-center/v1-list-company-profile-backoffice-action';
import { generateListProductQuery } from './helpers';

type CompanyProfile = SellerCenter.Components.Schemas.CompanyProfile;

interface IReq extends IAppRequest {
  body: Paths.V3ListProductBoBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body:
      | Paths.V3ListProductBoBackofficeAction.Responses.$200
      | Paths.V3ListProductBoBackofficeAction.Responses.$400,
  ) => this;
}

export const validateListProductV3Backoffice: BaseValidationType = [
  body('page').optional().isInt({ gt: 0 }).withMessage(ERRORS.INVALID),
  body('size')
    .optional()
    .isInt({ lt: appConfig.product.listMaxLimit, gt: 0 })
    .withMessage(ERRORS.INVALID),
  body('filter.categoryId').optional().isMongoId().withMessage(ERRORS.INVALID),
  body('filter.categoryIds').optional({ nullable: true }).isArray(),
  body('filter.categoryIds.*')
    .optional()
    .isMongoId()
    .withMessage(ERRORS.INVALID),
  body('filter.mediaId').optional().isString().withMessage(ERRORS.INVALID),
  body('filter.term').optional().isString().withMessage(ERRORS.INVALID),
  body('filter.parentSku').optional().isString().withMessage(ERRORS.INVALID),
  body('filter.type').optional().isString().withMessage(ERRORS.INVALID),
  body('filter.isInStock').optional().isBoolean().withMessage(ERRORS.INVALID),
  body('filter.isBuyNow').optional().isBoolean().withMessage(ERRORS.INVALID),
  body('filter.isReadyToShip')
    .optional()
    .isBoolean()
    .withMessage(ERRORS.INVALID),
  body('filter.isVerifiedSupplier')
    .optional({ nullable: true })
    .isString()
    .withMessage(ERRORS.INVALID),
  body('filter.state')
    .optional()
    .isString()
    .isIn(['online', 'offline'])
    .withMessage(ERRORS.INVALID),
  body('filter.deleted').optional().isBoolean(),
  body('filter.hasCustomDeliveryDay').optional().isBoolean(),
  body('filter.isSortingActive')
    .optional()
    .isBoolean()
    .withMessage(ERRORS.INVALID),
  body('filter.internalReviewStatus')
    .optional()
    .isNumeric()
    .isIn(Object.values(InternalReviewStatuses)),
  body('filter.reviewedBy')
    .optional()
    .isString()
    .customSanitizer((value: string): string => value.toLowerCase()),
  body('filter.productIds').optional({ nullable: true }).isArray(),
  body('filter.productIds.*')
    .isMongoId()
    .withMessage('Product ID passed is invalid'),
  body('filter.createdFrom').optional().isInt(),
  body('filter.createdTo').optional().isInt(),
  reqValidationResult,
];

export async function listProductBackofficeActionV3(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    body: { page = 1, size = appConfig.product.listDefaultLimit, filter = {} },
  } = req;

  // Subtracting one from the page because page counter is 0 based
  const recordsToSkip: number = (page - 1) * size;
  const query: FilterQuery<IProductModelV3> = await generateListProductQuery(
    filter,
  );

  const totalRecords: number = await productModelV3.countDocuments(query);

  const products: IProductModelV3[] = await productModelV3
    .find(
      query,
      {
        // @todo add projection
      },
      {
        sort: {
          lastUploadDate: -1,
          _id: 1,
        },
        skip: recordsToSkip,
        limit: size,
      },
    )
    .lean();

  res.json({
    currentPage: page,
    totalPages: Math.ceil(totalRecords / size),
    totalRecords,
    size,
    products: await prepareListProduct(products, req.headers),
  });
}

async function prepareListProduct(
  products: any[],
  headers: IAppHeaders,
): Promise<any[]> {
  const supplierCompanyIds: string[] = map(
    products,
    'supplierCompanyId',
  ).filter((id) => Boolean(id));
  const supplierCompanies: CompanyProfile[] = await getSupplierCompanyProfilesByCompanyIds(
    supplierCompanyIds,
    headers,
  );
  const suppliersObj: Record<string, CompanyProfile> = keyBy(
    supplierCompanies,
    'supplierCompanyId',
  );
  return products.map((product) => ({
    ...product,
    supplierCompanyName:
      suppliersObj[product?.supplierCompanyId]?.companyName || '',
  }));
}

export async function getSupplierCompanyProfilesByCompanyIds(
  supplierCompanyIds: string[],
  headers: IAppHeaders,
): Promise<CompanyProfile[]> {
  if (supplierCompanyIds.length === 0) {
    return [];
  }
  const { data } = await V1ListCompanyProfileBackofficeAction(
    {
      filter: { companyIds: supplierCompanyIds },
      limit: supplierCompanyIds.length,
    },
    { headers },
  );
  const supplierCompanies: CompanyProfile[] = data as CompanyProfile[];
  return supplierCompanies;
}
