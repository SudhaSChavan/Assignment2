import { body } from 'express-validator';
import { map, maxBy } from 'lodash';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { ERRORS } from '@src/types/errors';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { IMediaModel, mediaModel } from '../../media/model-media';
import { ProductMediaType } from './../types';
import { EE } from '@src/config/event/emitter';
import { logger } from '@core/util/logger';
import { FilterQuery } from 'mongoose';
import V1MediaItem = Components.Schemas.V1MediaItem;
import { IProductModelV3, productModelV3 } from '../model-product-v3';
import { ProductSyncEvent, ProductSyncEventType } from '../sync-hlper';

export enum ProductReassignMediaEvent {
  Success = 'product.reassignMedia.success',
}

export type ProductReassignMediaEventType = {
  req: IAppRequest;
  productIds: string[];
  addedMedia: string[];
};

interface IReq extends IAppRequest {
  body: Paths.V3ReassignMediaBySkuAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3ReassignMediaBySkuAction.Responses.$200) => this;
}

export const validateReassignMediaBySkuV3: BaseValidationType = [
  body('id').notEmpty().isMongoId().withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function reassignMediaBySkuV3Action(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    supplierCompanyId,
    body: { id: productId },
  } = req;

  const query: FilterQuery<IProductModelV3> = {
    $and: [
      {
        _id: productId,
        supplierCompanyId,
      },
    ],
  };

  const product: IProductModelV3 = await productModelV3.findOne(query);

  const existingMediaIds: string[] = map(product.media, 'id');

  let maxSortValue: number = 0;

  if (product.media.length) {
    maxSortValue = maxBy(product.media, 'sort').sort;
  }

  const media: IMediaModel[] = await mediaModel
    .find({
      deletedAt: null,
      supplierCompanyId,
      skuGroup: product.sku,
      _id: { $nin: existingMediaIds },
    })
    .lean();

  // if media is found, add media to the `product`
  if (media && media.length) {
    const mediaToAdd: ProductMediaType[] = media.map(
      (mediaItem: V1MediaItem, index: number): ProductMediaType => {
        return {
          id: mediaItem._id,
          type: mediaItem.type,
          title: mediaItem.originalName,
          sort: maxSortValue + index + 1,
        };
      },
    );

    product.media = [...product.media, ...mediaToAdd];

    await product.save();

    EE.emit(ProductReassignMediaEvent.Success, {
      req,
      productIds: [product._id],
      addedMedia: map(media, '_id'),
    } as ProductReassignMediaEventType).catch((error: Error): void => {
      logger.error(
        `Event ${ProductReassignMediaEvent.Success} failed: ${error.stack}`,
      );
    });

    EE.emit(ProductSyncEvent.Updated, {
      req,
      productIds: [productId],
      priority: 'highest',
    } as ProductSyncEventType).catch((error: Error): void => {
      logger.error(`Event ${ProductSyncEvent.Updated} failed: ${error.stack}`);
    });
  }

  res.json({
    isUpdated: true,
  });
}
