import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { productModelV3 } from '../model-product-v3';
import { offerModelV3 } from '../../offer/model-offers-v3';
import { appConfig } from '@src/config/env';
import { last } from 'lodash';
import { getCommissionValue } from '@express/modules/util/helpers';
import { BadRequestException, NotFoundException } from '@nestjs/common';

interface IReq extends IAppRequest {
  body: Paths.V3EnsureGuardrailsAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3EnsureGuardrailsAction.Responses.$204) => this;
}

export const validateV3EnsureGuardrails: BaseValidationType = [
  body('*.productId')
    .notEmpty()
    .withMessage('productId is missing')
    .isMongoId()
    .withMessage('productId is invalid'),
  body('*.price')
    .notEmpty()
    .withMessage('price is missing')
    .isNumeric()
    .withMessage('price must be numeric'),
  body('*.quantity')
    .notEmpty()
    .withMessage('quantity is missing')
    .isInt()
    .withMessage('quantity must be an integer'),
  reqValidationResult,
];

export async function v3EnsureGuardrailsAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const items = req.body;
  // loop over product and fetch the product details
  for (const item of items) {
    // function will check the data and validate the rule ...
    const product = await productModelV3
      .findOne({ _id: item.productId })
      .lean();

    if (!product) {
      throw new NotFoundException('Product not found');
    }

    // check supplierCompanyId
    if (!appConfig.tradelingExpressIds.includes(product?.supplierCompanyId)) {
      continue;
    }

    // get product offer
    const offer = await offerModelV3.findOne({ productId: product._id }).lean();

    // match the price with the target tier
    let listingPrice = 0;
    if (offer?.market.tiers?.length > 1) {
      for (const tier of offer.market.tiers) {
        if (item?.quantity >= tier.minQty && item?.quantity <= tier.maxQty) {
          listingPrice = tier.price;
          break;
        }
      }
    } else {
      listingPrice = offer?.market.tiers[0].price;
    }

    // skip if the price equal or greater than the listing price
    if (item.price >= listingPrice) {
      continue;
    }

    const lastSupplierObj: any = last(offer.subSupplierCompanies);
    const costPrice = parseFloat(lastSupplierObj?.costPrice);
    const rebate = parseFloat(lastSupplierObj?.rebate);
    const minPrice = getCommissionValue(costPrice, rebate);
    if (item.price < minPrice) {
      // throw error
      throw new BadRequestException(
        `Price must be greater than or equal ${minPrice}`,
      );
    }
  }
  res.status(204).end();
}
