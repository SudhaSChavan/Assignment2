import { body } from 'express-validator';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils';
import { createSyncEvent, ProductSyncEventType } from '../sync-hlper';
import { logger } from '@core/util/logger';
import { ProductSyncRequestFrom } from '../types';

interface IReq extends IAppRequest {
  body: Paths.V3InternalSyncProductsAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body:
      | Paths.V3InternalSyncProductsAction.Responses.$200
      | Paths.V3InternalSyncProductsAction.Responses.$400,
  ) => this;
}

export const validateInternalSyncProductsV3: BaseValidationType = [
  //
  body('productIds').isArray(),
  body('productIds.*').isMongoId(),
  body('priority').isString(),
  reqValidationResult,
];

export async function actionInternalSyncProductsV3(
  req: IReq,
  res: IRes,
): Promise<IRes> {
  const { productIds, priority } = req.body;

  logger.info(
    `request received for ${
      productIds.length
    } products via internal sync products :: list of products are ${JSON.stringify(
      productIds,
    )}`,
  );

  await createSyncEvent({
    req: null,
    productIds,
    priority,
    requestFrom: ProductSyncRequestFrom.Boost,
  } as ProductSyncEventType);

  logger.info(
    `request successfully initiated for sync products via internal sync products :: list of products are ${JSON.stringify(
      productIds,
    )}`,
  );

  const resp: Paths.V3InternalSyncProductsAction.Responses.$200 = {
    productIds,
  };
  return res.json(resp);
}
