import { uniqBy } from 'lodash';
import {
  BaseValidationType,
  IBaseAppUser,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { body } from 'express-validator';

import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { InternalReviewStatuses } from '../types';
import {
  IProductUpdateRequestDocumentV3,
  productUpdateRequestModelV3,
} from '../model-product-update-request-v3';
import { productModelV3 } from '../model-product-v3';
import { EE } from '@src/config/event/emitter';
import { ProductSyncEvent, ProductSyncEventType } from '../sync-hlper';
import { logger } from '@core/util/logger';

interface IReq extends IAppRequest {
  body: Paths.V3CommitProductUpdatesReviewStatusAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body:
      | Paths.V3CommitProductUpdatesReviewStatusAction.Responses.$200
      | Paths.V3CommitProductUpdatesReviewStatusAction.Responses.$400,
  ) => this;
}

export const validateCommitProductUpdatesReviewStatusV3: BaseValidationType = [
  //
  body('ids').isArray(),
  body('ids.*').isMongoId(),
  body('status')
    .isNumeric()
    .isIn(Object.values(InternalReviewStatuses))
    .notEmpty(),
  body('rejectionReasons').optional({ nullable: true }).isArray(),
  reqValidationResult,
];

export async function updateProductCommitReviewStatusActionV3(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { ids, status, rejectionReasons } = req.body;
  const userJwtDecoded: IBaseAppUser = req.userJwtDecoded as IBaseAppUser;
  const productIds: string[] = [];

  const updateRequests: IProductUpdateRequestDocumentV3[] = await productUpdateRequestModelV3
    .find({ _id: { $in: ids }, status: InternalReviewStatuses.Pending })
    .lean();

  let bulkOperation: any = null;
  if (status === InternalReviewStatuses.Accepted) {
    bulkOperation = updateRequests?.map(
      (updateRequest: IProductUpdateRequestDocumentV3) => {
        const fields: string[] = Object.keys(updateRequest.diff);
        productIds.push(updateRequest?.productId);
        return {
          updateOne: {
            filter: {
              _id: updateRequest.productId,
            },
            update: fields.reduce(
              (obj: any, field: string) => {
                obj[field] = (updateRequest.diff as any)[field].newValue;
                if (field === 'media') {
                  obj[field] = uniqBy(
                    obj[field],
                    (mediaItem: Components.Schemas.V1ProductMedia) =>
                      mediaItem.id?.toString(),
                  );
                }
                return obj;
              },
              {
                ...(status
                  ? {
                      internalReviewStatus: status,
                      internalReviewedAt: new Date(),
                      internalReviewedBy: {
                        userId: userJwtDecoded?._id,
                        email: userJwtDecoded?.email,
                      },
                    }
                  : {}),
              },
            ),
          },
        };
      },
    );
    await productModelV3.bulkWrite(bulkOperation);
  }

  await productUpdateRequestModelV3.updateMany(
    { _id: { $in: ids }, status: InternalReviewStatuses.Pending },
    {
      $set: {
        status,
        ...(status === InternalReviewStatuses.Rejected
          ? { rejectionReasons }
          : {}),
        reviewedAt: new Date().toISOString(),
        reviewedBy: {
          userId: userJwtDecoded?._id,
          email: userJwtDecoded?.email,
        },
      },
    },
  );

  EE.emit(ProductSyncEvent.Updated, {
    req,
    productIds,
    priority: 'highest',
  } as ProductSyncEventType).catch((error: Error): void => {
    logger.error(`Event ${ProductSyncEvent.Updated} failed: ${error.stack}`);
  });

  res.json({
    isUpdated: true,
    productSkusMovedToOffline: [],
  });
}
