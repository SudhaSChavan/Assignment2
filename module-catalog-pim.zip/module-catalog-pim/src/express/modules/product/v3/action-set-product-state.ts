import { body } from 'express-validator';
import { StatusCodes } from 'http-status-codes';
import {
  BaseValidationType,
  HttpError,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { map } from 'lodash';

import {
  InternalReviewStatuses,
  ProductStates,
  UpdateProductStatus,
} from './../types';
import { ERRORS } from '@src/types/errors';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { V1GetSupplierCompanyAction } from '@tradeling/tradeling-sdk/account/v1-get-supplier-company-action';
import { appConfig } from '@src/config/env';
import { FilterQuery } from 'mongoose';
import { EE } from '@src/config/event/emitter';
import { V1UpdateProductStatusMessageData } from './../queue-message/queue-message-v1-update-product-status';
import { logger } from '@core/util/logger';
import { logAuditEventForV3Products } from './../send-product-audit-event';
import { IProductModelV3, productModelV3 } from '../model-product-v3';
import { ProductSyncEvent, ProductSyncEventType } from '../sync-hlper';

interface IReq extends IAppRequest {
  body: Paths.V3SetProductStateAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3SetProductStateAction.Responses.$200) => this;
}

export const validateV3SetProductState: BaseValidationType = [
  body('ids')
    .notEmpty()
    .isArray({ min: 1, max: appConfig.product.listMaxLimit })
    .withMessage(ERRORS.MISSING),
  body('ids.*').notEmpty().isMongoId(),
  body('state')
    .notEmpty()
    .withMessage(ERRORS.MISSING)
    .isString()
    .isIn(Object.values(ProductStates))
    .withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function v3SetProductStateAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    supplierCompanyId,
    body: { ids, state },
  } = req;

  const { data: supplierCompanyInfo } = await V1GetSupplierCompanyAction(
    { id: supplierCompanyId },
    { headers: req.headers },
  );

  if (state === 'online' && !supplierCompanyInfo.isVerified) {
    throw new HttpError(
      StatusCodes.FORBIDDEN,
      'Company must be verified before publishing products',
    );
  }

  let products: IProductModelV3[] = await productModelV3
    .find({ _id: { $in: ids }, state: { $ne: state } })
    .lean();
  if (state == 'online') {
    products = products.filter((product) => {
      return product.media?.length > 0;
    });
  }

  const productIds: string[] = map(products, '_id');

  const query: FilterQuery<IProductModelV3> = {
    $and: [
      {
        _id: { $in: productIds },
        ...(state === 'online'
          ? {
              internalReviewStatus: InternalReviewStatuses.Accepted,
            }
          : {}),
      },
      {
        supplierCompanyId,
      },
    ],
  };

  const updateResult: any = await productModelV3.updateMany(query, {
    $set: {
      state,
    },
  });

  EE.emit(ProductSyncEvent.Updated, {
    req,
    productIds: productIds,
    priority: 'highest',
  } as ProductSyncEventType).catch((error: Error): void => {
    logger.error(`Event ${ProductSyncEvent.Updated} failed: ${error.stack}`);
  });

  await logAuditEventForV3Products(query, req, {
    name: 'state',
    old: state === 'online' ? 'offline' : 'online',
    new: state,
  });

  if (state === ProductStates.Offline) {
    EE.emit(UpdateProductStatus.Success, {
      supplierCompanyId,
      productIds,
    } as V1UpdateProductStatusMessageData).catch((error: Error): void => {
      logger.error(
        `Event ${UpdateProductStatus.Success} failed: ${error.stack}`,
      );
    });
  }

  res.json({
    isUpdated: updateResult.nModified > 0,
  });
}
