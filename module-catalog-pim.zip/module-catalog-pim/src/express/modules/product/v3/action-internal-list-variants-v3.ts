import { body } from 'express-validator';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import {
  BaseValidationType,
  HttpError,
  reqValidationResult,
} from '@tradeling/web-js-utils';
import { groupBy, isEmpty } from 'lodash';
import { ProductRepositoryV3 } from './repositories/product-repository.v3';
import { IProductModelV3, productModelV3 } from '../model-product-v3';
import { OfferRepositoryV3 } from './repositories/offer-repository.v3';
import { IOfferModelV3, offerModelV3 } from '../../offer/model-offers-v3';
import { ERRORS } from '@src/types/errors';
import { StatusCodes } from 'http-status-codes';

interface IReq extends IAppRequest {
  body: Paths.V3InternalListVariantsByIdAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3InternalListVariantsByIdAction.Responses.$200) => this;
}

export const validateInternalListVariantsByIdV3: BaseValidationType = [
  body('ids').optional().isArray(),
  body('ids.*').isMongoId(),
  body('parentSkus').optional().isArray(),
  body('parentSkus.*').isString(),
  body('isDefault').optional().isBoolean(),
  reqValidationResult,
];

const productRepository: any = new ProductRepositoryV3(productModelV3);
const offerRepository: any = new OfferRepositoryV3(offerModelV3);

export async function actionInternalListVariantsV3(
  req: IReq,
  res: IRes,
): Promise<IRes> {
  const { ids = [], parentSkus = [] } = req.body;
  if (ids.length === 0 && parentSkus.length === 0) {
    throw new HttpError(
      StatusCodes.BAD_REQUEST,
      "both ids and parentSku fields can't be empty",
    );
  }

  //Now variants are the part of product documents
  const variants: IProductModelV3[] = await productRepository.getByIdsOrParentSkus(
    req.body,
  );
  if (isEmpty(variants)) {
    throw new HttpError(StatusCodes.NOT_FOUND, ERRORS.NOT_FOUND);
  }

  const offers: IOfferModelV3[] = await offerRepository.getActiveByProductIds(
    ids,
  );

  const offersObj: Record<string, IOfferModelV3[]> = groupBy(
    offers,
    'productId',
  );
  const resp: Paths.V3InternalListVariantsByIdAction.Responses.$200 = variants?.map(
    (variant) => {
      return {
        ...variant,
        offers: offersObj[variant._id],
      };
    },
  );
  return res.json(resp);
}
