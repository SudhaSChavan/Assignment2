import { body } from 'express-validator';

import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import {
  BaseValidationType,
  HttpError,
  reqValidationResult,
} from '@tradeling/web-js-utils';
import { differenceBy, isEmpty, uniq } from 'lodash';
import { StatusCodes } from 'http-status-codes';
import { ProductRepositoryV3 } from './repositories/product-repository.v3';
import { IProductModelV3, productModelV3 } from '../model-product-v3';

interface IReq extends IAppRequest {
  body: Paths.V3InternalVerifyProductsAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3InternalVerifyProductsAction.Responses.$200) => this;
}

const productRepository: any = new ProductRepositoryV3(productModelV3);
export const validateInternalVariantsActionV3: BaseValidationType = [
  body('productIds').notEmpty().isArray({ min: 1 }),
  reqValidationResult,
];

export function validateRequest(productIds: string[]): void {
  if (productIds.length != uniq(productIds).length) {
    throw new HttpError(StatusCodes.BAD_REQUEST, 'duplicate product ids found');
  }
}

export async function actionValidateProductsV3(
  req: IReq,
  res: IRes,
): Promise<IRes> {
  const { productIds } = req.body;
  validateRequest(productIds);

  const products: IProductModelV3[] = await productRepository.getByIds(
    productIds,
  );

  if (isEmpty(products)) {
    throw new HttpError(StatusCodes.BAD_REQUEST, 'no product found');
  }

  const foundProducts: string[] =
    products.map((product) => {
      return product._id.toString();
    }) || [];
  const getDiff: string[] = differenceBy(productIds, foundProducts);

  if (getDiff.length > 0) {
    throw new HttpError(
      StatusCodes.BAD_REQUEST,
      'product ids are not found',
      getDiff,
    );
  }

  const resp: Paths.V3InternalVerifyProductsAction.Responses.$200 = {
    productIds: foundProducts,
  };
  return res.json(resp);
}
