import { body } from 'express-validator';
import { FilterQuery } from 'mongoose';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { ERRORS } from '@src/types/errors';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { InternalReviewStatuses } from '../types';
import { Dictionary, keyBy } from 'lodash';
import {
  IProductUpdateRequestModelV3,
  productUpdateRequestModelV3,
} from '../model-product-update-request-v3';

interface IReq extends IAppRequest {
  body: Paths.V3GetProductUpdateAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Dictionary<Components.Schemas.V3ProductUpdatesListItem>) => this;
}

export const validateGetProductUpdateV3: BaseValidationType = [
  //
  body('productIds').optional().isArray().withMessage(ERRORS.INVALID),
  body('productIds.*').optional().isMongoId().withMessage(ERRORS.INVALID),
  body('status').optional().toArray(),
  body('status.*')
    .isNumeric()
    .isIn(Object.values(InternalReviewStatuses))
    .withMessage('Invalid status code'),
  reqValidationResult,
];

export async function getProductUpdateActionV3(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    supplierCompanyId,
    body: { status = [], productIds = [] } = {},
  } = req;

  const query: FilterQuery<IProductUpdateRequestModelV3> = {
    supplierCompanyId,
    deletedAt: null,
    ...(productIds ? { productId: { $in: productIds } } : {}),
    ...(status?.length ? { status: { $in: status } } : {}),
  };

  const updates: Components.Schemas.V3ProductUpdatesListItem[] = await productUpdateRequestModelV3
    .find(
      query,
      {
        _id: 1,
        productId: 1,
        supplierId: 1,
        supplierCompanyId: 1,
        status: 1,
        diff: 1,
        metadata: 1,
        rejectionReasons: 1,
        createdAt: 1,
        updatedAt: 1,
        websiteCode: 1,
      },
      {
        sort: { updatedAt: -1 },
      },
    )
    .lean();

  // todo check this with @omar
  res.json(keyBy(updates, 'variantId'));
}
