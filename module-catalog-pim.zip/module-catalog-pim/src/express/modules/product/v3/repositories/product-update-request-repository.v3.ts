import { Model } from 'mongoose';
import { IRepository } from './IRepository';
import { IProductUpdateRequestModelV3 } from '../../model-product-update-request-v3';

export class ProductUpdateRequestRepositoryV3 implements IRepository {
  constructor(private _model: Model<IProductUpdateRequestModelV3>) {}

  async getById(id: string): Promise<IProductUpdateRequestModelV3> {
    try {
      return await this._model.findOne({ _id: id }).lean();
    } catch (e) {
      console.info(e);
      throw e;
    }
  }

  async getByIds(ids: string[]): Promise<IProductUpdateRequestModelV3[]> {
    try {
      return await this._model.find({ _id: { $in: ids } }).lean();
    } catch (e) {
      console.info(e);
      throw e;
    }
  }

  async getOneByQuery(
    query: Record<string, any>,
    filterFields?: Record<string, any>,
  ): Promise<IProductUpdateRequestModelV3> {
    try {
      return await this._model.findOne(query, filterFields).lean();
    } catch (e) {
      throw e;
    }
  }

  async getAllByQuery(
    query: Record<string, any>,
    filterFields?: Record<string, any>,
  ): Promise<IProductUpdateRequestModelV3[]> {
    try {
      return await this._model.find(query, filterFields).lean();
    } catch (e) {
      throw e;
    }
  }
}
