import { Model } from 'mongoose';
import { IRepository } from './IRepository';
import {
  IOfferDocumentV3,
  IOfferModelV3,
} from '../../../offer/model-offers-v3';

export class OfferRepositoryV3 implements IRepository {
  constructor(private _model: Model<IOfferModelV3>) {}

  async getById(id: string): Promise<IOfferDocumentV3> {
    try {
      return this._model.findOne({ _id: id, deletedAt: null }).lean().exec();
    } catch (e) {
      console.info(e);
    }
  }

  async getByIds(ids: string[]): Promise<IOfferDocumentV3[]> {
    try {
      return this._model
        .find({ _id: { $in: ids }, deletedAt: null })
        .lean()
        .exec();
    } catch (e) {
      console.info(e);
    }
  }

  async getActiveByProductId(productId: string): Promise<IOfferDocumentV3> {
    try {
      return this._model
        .findOne({ productId, isActive: true, deletedAt: null })
        .lean()
        .exec();
    } catch (e) {
      console.info(e);
    }
  }

  async getActiveByProductIds(
    productIds: string[],
    supplierCompanyId: string = null,
  ): Promise<IOfferDocumentV3[]> {
    try {
      return this._model
        .find({
          productId: { $in: productIds },
          isActive: true,
          deletedAt: null,
          ...(supplierCompanyId ? { supplierCompanyId } : {}),
        })
        .lean()
        .exec();
    } catch (e) {
      console.info(e);
    }
  }
}
