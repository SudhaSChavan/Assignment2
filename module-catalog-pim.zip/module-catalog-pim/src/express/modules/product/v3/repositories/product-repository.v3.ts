import { Model } from 'mongoose';
import { IProductModelV3 } from '../../model-product-v3';
import { IRepository } from './IRepository';
import { Types } from 'mongoose';
import { ProductCountType } from '../../types';

export type listParams = {
  ids?: string[];
  parentSkus?: string[];
  isDefault?: boolean;
};

export class ProductRepositoryV3 implements IRepository {
  constructor(private _model: Model<IProductModelV3>) {}

  async getById(id: string): Promise<IProductModelV3> {
    try {
      return await this._model.findOne({ _id: id }).lean();
    } catch (e) {
      console.info(e);
    }
  }

  async getByIds(ids: string[]): Promise<IProductModelV3[]> {
    try {
      return await this._model.find({ _id: { $in: ids } }).lean();
    } catch (e) {
      console.info(e);
    }
  }

  async getOneByQuery(
    query: Record<string, any>,
    filterFields?: Record<string, any>,
  ): Promise<IProductModelV3> {
    try {
      return await this._model.findOne(query, filterFields).lean();
    } catch (e) {
      throw e;
    }
  }

  async getAllByQuery(
    query: Record<string, any>,
    filterFields?: Record<string, any>,
  ): Promise<IProductModelV3[]> {
    try {
      return await this._model.find(query, filterFields).lean();
    } catch (e) {
      throw e;
    }
  }

  async getByIdsOrParentSkus(params: listParams): Promise<IProductModelV3[]> {
    try {
      const { ids = [], parentSkus = [], isDefault = null } = params;
      const queryConditions: any[] = [];
      if (ids.length > 0) {
        queryConditions.push({
          _id: {
            $in: ids
              // @ts-ignore
              .filter((id) => Types.ObjectId.isValid(id))
              .map((id) => {
                // @ts-ignore
                return new Types.ObjectId(id);
              }),
          },
        });
      }
      if (parentSkus.length > 0) {
        queryConditions.push({ parentSku: { $in: parentSkus } });
      }
      if (isDefault != null) {
        queryConditions.push({ isDefault: isDefault });
      }
      const query: Record<string, any> = { $and: queryConditions };

      return await this._model.find(query).lean();
    } catch (e) {
      console.info(e);
    }
  }

  async getProductCountBySupplier(
    supplierCompanyIds: string[],
  ): Promise<ProductCountType[]> {
    try {
      return this._model.aggregate([
        {
          $match: { supplierCompanyId: { $in: supplierCompanyIds } },
        },
        {
          $group: {
            _id: '$supplierCompanyId',
            totalProducts: { $sum: 1 },
            totalOnlineProducts: {
              $sum: {
                $cond: [{ $eq: ['$state', 'online'] }, 1, 0],
              },
            },
            totalOfflineProducts: {
              $sum: {
                $cond: [{ $eq: ['$state', 'offline'] }, 1, 0],
              },
            },
          },
        },
      ]);
    } catch (e) {
      console.info(e);
    }
  }
}
