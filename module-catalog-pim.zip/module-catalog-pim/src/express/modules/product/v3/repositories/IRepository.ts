export interface IRepository {
  getById(id: string): Promise<any>;
  getByIds(ids: string[]): Promise<any[]>;
}
