import { body } from 'express-validator';
import { groupBy, keyBy, isString } from 'lodash';
import { Workbook, Worksheet } from 'exceljs';
import { reqValidationResult } from '@tradeling/web-js-utils';
import { BaseValidationType, IBaseAppUser } from '@tradeling/web-js-utils/dist';
import { IAppResponse } from '@src/types/app-response';
import { IAppRequest } from '@src/types/app-request';
import { ERRORS } from '@src/types/errors';
import { FilterQuery } from 'mongoose';
import { InternalReviewStatuses } from '../types';
import { ProductRepositoryV3 } from './repositories/product-repository.v3';
import {
  IProductModelV3,
  productModelV3,
  RejectionReason,
} from '../model-product-v3';
import { ProductUpdateRequestRepositoryV3 } from './repositories/product-update-request-repository.v3';
import {
  IProductUpdateRequestDocumentV3,
  productUpdateRequestModelV3,
} from '../model-product-update-request-v3';

interface IReq extends IAppRequest {
  body: Paths.V3ExportRejectedProductAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3ExportRejectedProductAction.Responses.$400) => this;
}

export const validateExportRejectedProductsV3: BaseValidationType = [
  body('filter').notEmpty().optional(),
  body('filter.productIds').optional().isMongoId().withMessage(ERRORS.INVALID),
  body('filter.slug').optional().isString(),
  reqValidationResult,
];

const productRepository: any = new ProductRepositoryV3(productModelV3);
const productUpdateRequestRepository: any = new ProductUpdateRequestRepositoryV3(
  productUpdateRequestModelV3,
);

export async function exportRejectedProductsActionV3(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { supplierCompanyId, body, language: lang } = req;
  const { filter } = body;
  const { slug, productIds } = filter;
  const workbook: Workbook = new Workbook();
  const fileName: string = 'product-rejection-export';
  // generate csv
  const sheet: Worksheet = workbook.addWorksheet('My Sheet');
  sheet.addRow([
    'SKU',
    'Product name(en)',
    'Product name(ar)',
    'Seller company name',
    'Review status',
    'General',
    'Images',
    'Description',
    'Attributes',
    'Title',
    'Keyfeatures',
    'Keywords',
  ]);
  const { companyName } = req.userJwtDecoded as IBaseAppUser;

  const editsRejectionRows: string[][] = await getUpdatedProductRejectionRows(
    supplierCompanyId,
    productIds,
    slug,
    companyName,
    lang,
  );
  const productRejectionRows: string[][] = await getNewProductRejectionRows(
    supplierCompanyId,
    productIds,
    slug,
    companyName,
    lang,
  );
  sheet.addRows([...editsRejectionRows, ...productRejectionRows]);

  res.setHeader('Content-disposition', `attachment; filename=${fileName}.csv`);
  res.setHeader('content-type', 'text/csv');

  await workbook.csv.write(res);
  res.end();
}

enum RejectionReasonSections {
  general = 'general',
  images = 'images',
  description = 'description',
  attributes = 'attributes',
  titles = 'titles',
  keyFeatures = 'keyfeatures',
  keywords = 'keywords',
}

async function getNewProductRejectionRows(
  supplierCompanyId: string,
  productIds: string[],
  slug: string,
  companyName: string,
  lang: 'en' | 'ar',
) {
  const condition: FilterQuery<IProductModelV3> = {
    internalReviewStatus: InternalReviewStatuses.Rejected,
    supplierCompanyId,
    deletedAt: null,
    ...(productIds?.length ? { _id: { $in: productIds } } : {}),
    ...(slug ? { 'metadata.rejectionReasons.slug': slug } : {}),
  };

  const products: IProductModelV3[] = await productRepository.getAllByQuery(
    condition,
  );

  return products?.map((product) => {
    const rejectionReasons: RejectionReason[] =
      product?.metadata?.rejectionReasons || [];
    return getRejectionRow({ rejectionReasons, product, companyName, lang });
  });
}

async function getUpdatedProductRejectionRows(
  supplierCompanyId: string,
  productIds: string[],
  slug: string,
  companyName: string,
  lang: 'en' | 'ar',
): Promise<string[][]> {
  const editRejections: IProductUpdateRequestDocumentV3[] = await productUpdateRequestRepository.getAllByQuery(
    {
      status: InternalReviewStatuses.Rejected,
      supplierCompanyId,
      deleteAt: null,
      ...(productIds?.length ? { productId: { $in: productIds } } : {}),
      ...(slug ? { 'rejectionReasons.slug': slug } : {}),
    },
  );
  // get rejected edit products
  const editRejectionsMap: Record<
    string,
    IProductUpdateRequestDocumentV3
  > = keyBy(editRejections, 'productId');
  const editedProductIds: string[] = editRejections.map(
    (editRejection) => editRejection.productId,
  );
  const editRejectedProduct: IProductModelV3[] = await productRepository.getAllByQuery(
    {
      supplierCompanyId,
      deletedAt: null,
      _id: {
        $in: editedProductIds,
      },
    },
  );

  return editRejectedProduct?.map((rejectedProduct) => {
    const rejectionReasons: RejectionReason[] =
      editRejectionsMap[rejectedProduct._id]?.rejectionReasons;
    return getRejectionRow({
      rejectionReasons,
      product: rejectedProduct,
      companyName,
      lang,
      isEdited: true,
    });
  });
}

function getRejectionRow(props: {
  rejectionReasons: RejectionReason[];
  product: IProductModelV3;
  companyName: string;
  lang: 'en' | 'ar';
  isEdited?: boolean;
}): string[] {
  const {
    rejectionReasons,
    product,
    isEdited = false,
    companyName = '',
    lang,
  } = props;
  const sku: string = product.sku;
  const name: { ar?: string; en: string } = product.name;
  const status: string = isEdited ? 'Edits Rejected' : 'Product Rejected';
  const groupedReason: Record<string, any[]> = groupBy(
    rejectionReasons,
    'section',
  );
  let generalReasons: string =
    groupedReason[RejectionReasonSections.general]
      ?.map((rejection) => getRejectionMsg(rejection, lang))
      ?.join() || 'NA';
  // Fallback to old rejected reason key
  // from metadata
  if (generalReasons === 'NA' && isString(product?.metadata?.rejectedReason)) {
    generalReasons =
      product?.metadata?.rejectedReason.replace(/\s+/g, ' ') || 'NA';
  }

  const imagesReasons: string =
    groupedReason[RejectionReasonSections.images]
      ?.map((rejection) => getRejectionMsg(rejection, lang))
      ?.join() || 'NA';
  const descriptionReasons: string =
    groupedReason[RejectionReasonSections.description]
      ?.map((rejection) => getRejectionMsg(rejection, lang))
      ?.join() || 'NA';
  const attributeReasons: string =
    groupedReason[RejectionReasonSections.attributes]
      ?.map((rejection) => getRejectionMsg(rejection, lang))
      ?.join() || 'NA';
  const titleReason: string =
    groupedReason[RejectionReasonSections.titles]
      ?.map((rejection) => getRejectionMsg(rejection, lang))
      ?.join() || 'NA';
  const keyFeaturesReasons: string =
    groupedReason[RejectionReasonSections.keyFeatures]
      ?.map((rejection) => getRejectionMsg(rejection, lang))
      ?.join() || 'NA';
  const keyWordsReasons: string =
    groupedReason[RejectionReasonSections.keywords]
      ?.map((rejection) => getRejectionMsg(rejection, lang))
      ?.join() || 'NA';

  return [
    sku,
    name.en,
    name?.ar || 'NA',
    companyName,
    status,
    generalReasons,
    imagesReasons,
    descriptionReasons,
    attributeReasons,
    titleReason,
    keyFeaturesReasons,
    keyWordsReasons,
  ];
}

function getRejectionMsg(
  rejection: RejectionReason,
  lang: 'en' | 'ar' = 'en',
): string {
  if (rejection?.slug === 'others') {
    return rejection?.msg;
  }

  return rejectionReasons?.[rejection?.slug]?.[lang];
}

// todo to use arabic content
const rejectionReasons: Record<string, { en: string; ar: string }> = {
  sku_contains_duplicated_content: {
    en: 'SKU contains duplicated content',
    ar: 'يحتوى رقم SKU على محتوى مكرر',
  },
  sku_contains_irrelevant_keywords: {
    en: 'SKU contains a high volume of irrelevant keywords or keyword variety',
    ar:
      'يحتوي رقم SKU على عدد كبير من الكلمات الدالة غير المتصلة بالمنتج أو مجموعة متنوعة من الكلمات الدالة',
  },
  sku_contains_information_about_multiple_products: {
    en:
      'SKU contains information about multiple products or variety of the product model',
    ar:
      'يحتوي رقم SKU على معلومات حول منتجات متعددة أو مجموعة متنوعة من نفس طراز المنتج',
  },
  sku_details_do_not_clearly_describe_the_item: {
    en: 'SKU details do not clearly describe the item',
    ar: 'تفاصيل رقم SKU لا تصف المنتج بوضوح',
  },
  sku_content_contains_conflicting_information: {
    en: 'SKU content contains conflicting information or images',
    ar: 'يتضمن محتوى رقم SKU معلومات أو صور متعارضة',
  },
  sku_contains_content_in_language_not_allowed: {
    en: 'SKU contains content in a language other than English and Arabic.',
    ar: 'يحتوي رقم SKU على محتوى بلغة أخرى غير الإنجليزية والعربية.',
  },
  list_as_new_product_instead: {
    en: 'Please list a new product instead of changing the existing product.',
    ar: 'الرجاء إدراج منتج جديد بدلاً من تغيير المنتج الحالي.',
  },
  new_edit_does_not_improve_the_quality: {
    en:
      "The existing version is more useful or more compatible. The new edit doesn't improve the quality of the product content.",
    ar:
      'الإصدار الحالي أكثر فائدة أو أكثر توافقًا. لا يؤدي التعديل الجديد إلى تحسين جودة محتوى المنتج.',
  },
  image_does_not_fall_within_allowed_dimensions: {
    en:
      'Image does not fall within the range of dimensions allowed in the system Image does not have a white background',
    ar:
      'لا تقع الصورة ضمن نطاق الأبعاد المسموح بها في النظام. خلفية الصورة ليست بيضاء',
  },
  image_file_does_not_fall_within_allowed_sizes: {
    en:
      'Image file does not fall within the range of sizes allowed in the system',
    ar: 'لا يقع ملف الصورة ضمن نطاق الأحجام المسموح بها في النظام',
  },
  image_contains_multiple_products_of_the_same_model: {
    en:
      'Image contains multiple products or multiple varieties of the same model',
    ar: 'تحتوي الصورة على منتجات متعددة أو مجموعة متنوعة من نفس طراز المنتج',
  },
  image_contains_watermarks_or_special_characters: {
    en: 'Image contains watermarks or special characters',
    ar: 'تحتوي الصورة على علامات مائية أو رموز خاصة',
  },
  image_contains_a_text_or_contact_information: {
    en: 'Image contains a text or contact information',
    ar: 'تحتوي الصورة على نص أو معلومات اتصال',
  },
  main_image_is_a_lifestyle_image: {
    en: 'Main image is a lifestyle image',
    ar: 'الصورة الرئيسية هي عبارة عن صورة للمنتج في نمط الحياة',
  },
  image_conflicts_with_the_product_attributes: {
    en: 'Image conflicts with the product attributes, description, or title.',
    ar: 'تتعارض الصورة مع سمات المنتج أو الوصف أو العنوان.',
  },
  image_contains_extra_accessories: {
    en:
      'Image contains accessories that are not included with the physical product',
    ar: 'تحتوي الصورة على ملحقات غير مرفقة مع المنتج الفعلي',
  },
  image_does_not_reflect_the_product_clearly: {
    en: 'Image does not reflect the product clearly',
    ar: 'الصورة لا تعكس المنتج بشكل واضح',
  },
  description_conflicts_with_images_title_or_attributes: {
    en: 'Description conflicts with Images, title, or attributes',
    ar: 'يتعارض الوصف مع الصورة أو العنوان أو السمات',
  },
  description_does_not_describe_the_product: {
    en: 'Description does not clearly and sufficiently describe the product',
    ar: 'الوصف لا يصف المنتج بشكل واضح وكافٍ',
  },
  description_contains_information_about_same_model: {
    en:
      'Description contains information about multiple products or multiple varieties of the same model.',
    ar:
      'يحتوي الوصف على معلومات حول منتجات متعددة أو مجموعة متنوعة من نفس طراز المنتج.',
  },
  description_contains_contact_information: {
    en:
      'Description contains contact information, price information, or warranty details',
    ar: 'يحتوي الوصف على معلومات الاتصال أو معلومات الأسعار أو تفاصيل الضمان',
  },
  description_contains_promotional_content: {
    en: 'Description contains promotional content',
    ar: 'يحتوي الوصف على محتوى ترويجي',
  },
  description_contains_special_characters: {
    en: 'Description contains special characters',
    ar: 'يحتوي الوصف على رموز خاصة',
  },
  description_contains_irrelevant_keywords: {
    en:
      'Description contains a high volume of irrelevant keywords or keyword variety',
    ar:
      'يحتوي الوصف على عدد كبير من الكلمات الدالة غير المتصلة بالمنتج أو مجموعة متنوعة من الكلمات الدالة',
  },
  sku_is_missing_important_product_attributes: {
    en: 'SKU is missing important product attributes',
    ar: 'يفتقد رقم SKU إلى سمات المنتج المهمة',
  },
  product_attributes_conflict_with_the_description: {
    en: 'Product attributes conflict with the description, Images, or title',
    ar: 'تتعارض سمات المنتج مع الصور أو الوصف أو العنوان',
  },
  product_attributes_have_been_filled_with_the_value_other: {
    en: `Product attributes have been filled with the value "other"`,
    ar: 'تم ملء سمات المنتج بالقيمة "أخرى"',
  },
  product_attributes_values_wrong_format: {
    en:
      'Product attributes values do not follow the correct format as referred to in the guidelines',
    ar: 'قيم سمات المنتج لا تتبع التنسيق الصحيح كما هو مشار إليه في الإرشادات',
  },
  product_attribute_contains_more_than_one_value: {
    en: 'Product attribute contains more than one value',
    ar: 'سمة المنتج تحتوي على أكثر من قيمة واحدة',
  },
  product_missing_dimensions: {
    en: 'Product missing dimensions',
    ar: 'يفتقد المنتج إلى الأبعاد',
  },
  product_missing_stock_location: {
    en: 'Product missing Stock Location',
    ar: 'يفتقد المنتج إلى موقع المخزون',
  },
  product_missing_country_of_origin: {
    en: 'Product missing Country of Origin',
    ar: 'يفتقد المنتج إلى بلد المنشأ',
  },
  product_missing_sizes: {
    en: 'Product missing sizes',
    ar: 'يفتقد المنتج إلى القياسات',
  },
  product_missing_weight: {
    en: 'Product missing weight',
    ar: 'يفتقد المنتج إلى الوزن',
  },
  edits_on_sku_numbers_are_not_permitted: {
    en: 'Edits on SKU numbers are not permitted',
    ar: 'لا يُسمح بإجراء تعديلات على أرقام SKU',
  },
  product_name_contains_irrelevant_keywords: {
    en:
      'Product name contains a high volume of irrelevant keywords or keyword variety.',
    ar:
      'يحتوي اسم المنتج على عدد كبير من الكلمات الدالة غير المتصلة بالمنتج أو مجموعة متنوعة من الكلمات الدالة.',
  },
  product_name_conflicts_with_the_images: {
    en:
      'Product name conflicts with the images, description, or attributes of the product.',
    ar: 'يتعارض اسم المنتج مع الصور أو الوصف أو سمات المنتج.',
  },
  product_name_contains_information_of_the_same_model: {
    en:
      'Product name contains information regarding multiple products or multiple varieties of the same model. Product name contains sales information, pricing details or promotional content',
    ar:
      'يحتوي اسم المنتج على معلومات حول منتجات متعددة أو مجموعة متنوعة من نفس طراز المنتج. يحتوي اسم المنتج على معلومات تتعلق بالمبيعات أو تفاصيل التسعير أو محتوى ترويجي',
  },
  product_name_contains_contact_information: {
    en: 'Product name contains contact information',
    ar: 'يحتوي اسم المنتج على معلومات اتصال',
  },
  product_name_contains_typos: {
    en: 'Product name contains typos',
    ar: 'يحتوي اسم المنتج على أخطاء إملائية',
  },
  product_name_does_not_describe_the_product: {
    en: 'Product name does not clearly and sufficiently describe the product',
    ar: 'اسم المنتج لا يصف المنتج بشكل واضح وكافٍ',
  },
  product_name_contains_special_characters: {
    en: 'Product name contains special characters',
    ar: 'يحتوي اسم المنتج على رموز خاصة',
  },
  product_name_is_not_in_sentence_case: {
    en: 'Product name is not in sentence case',
    ar: 'اسم المنتج ليس في حالة الجملة',
  },
  image_does_not_have_a_white_background: {
    en: 'Image does not have a white background',
    ar: 'الصورة ليس لها خلفية بيضاء',
  },
  minimum_of_two_key_features_related_to_the_product_and_up_to_six_features: {
    en:
      'All products must have a minimum of two key features related to the product and up to six features',
    ar:
      'يجب أن تحتوي جميع المنتجات على ميزتين رئيسيتين على الأقل تتعلقان بالمنتج وما يصل إلى ست ميزات',
  },
  same_products_with_different_variants_must_be_listed_separately: {
    en:
      'Same products with different variants (different sizes, colors, etc..) must be listed separately',
    ar:
      'يجب إدراج نفس المنتجات ذات المنتجات الفرعية المختلفة (أحجام وألوان مختلفة وما إلى ذلك) بشكل منفصل',
  },
  title_and_key_features_must_be_in_sentence_case: {
    en: 'Title and key features must be in sentence case',
    ar:
      'يجب كتابة الحرف الأول من كل كلمة في العنوان والميزات الرئيسية بحرف كبير',
  },
  give_key_features_related_to_the_product_describe_the_product_in_sentences: {
    en:
      'Please give key features related to the product (describe the product in sentences)',
    ar:
      'يرجى تقديم ميزات رئيسية متعلقة بالمنتج (قم بوصف المنتج باستخدام الجمل)',
  },
  dont_use_the_title_as_key_feature: {
    en: 'Please do not use the title as key feature',
    ar: 'يرجى عدم استخدام العنوان كميزة رئيسية',
  },
  dont_repeat_the_key_features_sentences: {
    en: 'Please do not repeat the key features sentences',
    ar: 'يرجى عدم تكرار جمل الميزات الرئيسية',
  },
  products_must_have_minimum_of_two_key_words_up_to_15_keywords: {
    en:
      'All products must have a minimum of two key words and up to 15 keywords',
    ar:
      'يجب أن تحتوي جميع المنتجات على كلمتين مفتاحيتين على الأقل وما يصل إلى 15 كلمة مفتاحية',
  },
  keywords_must_be_related_to_the_product_you_are_selling: {
    en: 'All keywords must be related to the product you are selling',
    ar: 'يجب أن تكون جميع الكلمات المفتاحية مرتبطة بالمنتج الذي تبيعه',
  },
  adjust_keywords_to_be_in_words_or_phrases_not_in_sentences: {
    en: 'Please adjust the keywords to be in words or phrases not in sentences',
    ar: 'يرجى ضبط الكلمات الرئيسية لتكون بكلمات أو عبارات وليست في جمل',
  },
};
