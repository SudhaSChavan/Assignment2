import {
  BaseValidationType,
  HttpError,
  reqValidationResult,
  validateFileUpload,
} from '@tradeling/web-js-utils/dist';

import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import Excel from 'exceljs';
import {
  getRawData,
  getWorkbook,
  isInvalidScore,
  productScoreRow,
} from '../action-upload-product-score-backoffice/helpers';
import { appConfig } from '@src/config/env';
import { logger } from '@core/util/logger';
import { isValidObjectId, Types } from 'mongoose';
import { StatusCodes } from 'http-status-codes';
import { IProductModelV3, productModelV3 } from '../model-product-v3';
import { ProductSyncEvent, ProductSyncEventType } from '../sync-hlper';
import { EE } from '@src/config/event/emitter';

interface IReq extends IAppRequest {
  body: any;
}

interface IRes extends IAppResponse {
  json: (
    body: Paths.V3UploadProductScoreBackofficeAction.Responses.$200,
  ) => this;
}

export const validateUploadProductScoreBackoffice: BaseValidationType = [
  validateFileUpload({
    maxFiles: 1,
    maxFileSize: appConfig.media.maxFileSizeBytes,
    extensions: ['csv'],
  }),
  reqValidationResult,
];

export async function uploadProductScoreBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<any> {
  const { files } = req.body as any;

  const workbook: Excel.Workbook = await getWorkbook(files[0].path);
  const dataSheet: Excel.Worksheet = workbook.getWorksheet(1);
  const rawData: string[][] = getRawData(dataSheet);

  let products: productScoreRow[] = rawData.map((product) => ({
    id: product[0],
    name: product[1],
    score: product[3],
  }));
  const productIds: string[] = products.map(
    (product: productScoreRow) => product.id,
  );
  const correctIds: string[] = (
    await productModelV3
      .find({
        _id: {
          $in: productIds.filter(isValidObjectId).map(Types.ObjectId) as any,
        },
      })
      .lean()
  ).map((product: IProductModelV3) => product._id.toString());
  const incorrectIds: string[] = productIds.filter(
    (id) => !correctIds.includes(id),
  );

  const invalidIdRows: number[] = [];
  const invalidScoreRows: number[] = [];

  // validate ID and scores, push to errors if there are some
  // Ignore the row if the manual score is '-' or empty string ''
  products = products.map((product, index) => {
    if (product.score && product.score.trim() !== '-') {
      const id: string = (product.id || '').trim();
      const score: string = product.score.trim().replace(/[,]/g, '');

      // row number will be index + 2 because first row is undefined and second for headers
      const rowNr: number = index + 2;

      if (incorrectIds.includes(id)) {
        invalidIdRows.push(rowNr);
      }

      if (isInvalidScore(score)) {
        invalidScoreRows.push(rowNr);
      }

      return { ...product, score };
    }
  });

  if (invalidScoreRows.length || invalidIdRows.length) {
    const errMsg: string = `Product score upload failed. ${
      invalidScoreRows.length
        ? `Invalid score (row ${invalidScoreRows.join(', ')}). `
        : ''
    }  ${
      invalidIdRows.length
        ? `Invalid ID (row ${invalidIdRows.join(', ')}).`
        : ''
    }`;
    throw new HttpError(StatusCodes.BAD_REQUEST, errMsg);
  }
  // bulkwrite to DB
  try {
    const bulkQuery: Record<any, any>[] = products.map((product) => ({
      updateOne: {
        filter: { _id: Types.ObjectId(product.id) },
        update: { $set: { manualScore: Number(product.score) } },
      },
    }));
    // Running unordered operations so that if there are errors
    // it will display each error in an array.
    await productModelV3.bulkWrite(bulkQuery, { ordered: false });

    const productIds = products.map((product) => product.id);

    EE.emit(ProductSyncEvent.Updated, {
      req,
      productIds,
      priority: 'highest',
    } as ProductSyncEventType).catch((error: Error): void => {
      logger.error(`Event ${ProductSyncEvent.Updated} failed: ${error.stack}`);
    });
  } catch (err) {
    logger.error(`Failed to bulk write product score: ${err}`);
    const nError: number = products.length - (err.nModified || 0);
    throw new HttpError(
      StatusCodes.INTERNAL_SERVER_ERROR,
      `Error uploading product scores. ${
        nError ? `${nError} products failed to update.` : ''
      } `,
    );
  }
  res.json({ isUploaded: true });
}
