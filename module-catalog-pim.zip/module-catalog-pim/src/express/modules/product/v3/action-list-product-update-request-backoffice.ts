import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { ERRORS } from '@src/types/errors';
import { appConfig } from '@src/config/env';
import { map } from 'lodash';
import { FilterQuery } from 'mongoose';
import {
  IProductUpdateRequestDocumentV3,
  productUpdateRequestModelV3,
} from '../model-product-update-request-v3';
import { IAppRequest } from '@src/types/app-request';
import {
  extendProductUpdateRequest,
  findChildCategories,
  getDateFilterV3,
} from './helpers';
import { IProductModelV3, productModelV3 } from '../model-product-v3';
import { ProductUpdateRequestListExtendedV3 } from '../action-list-product-update-request/types';
import { IAppResponse } from '@src/types/app-response';

interface IReq extends IAppRequest {
  body: Paths.V3ListProductUpdateRequestBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body:
      | Paths.V3ListProductUpdateRequestBackofficeAction.Responses.$200
      | Paths.V3ListProductUpdateRequestBackofficeAction.Responses.$400,
  ) => this;
}

export const validateListProductUpdateRequestBackofficeV3: BaseValidationType = [
  body('page').optional().isInt({ gt: 0 }).withMessage(ERRORS.INVALID),
  body('size')
    .optional()
    .isInt({ lt: appConfig.product.listMaxLimit, gt: 0 })
    .withMessage(ERRORS.INVALID),
  body('filter.supplierCompanyId')
    .optional()
    .isMongoId()
    .withMessage(ERRORS.INVALID),
  body('filter.supplierId').optional().isMongoId().withMessage(ERRORS.INVALID),
  body('filter.productId').optional().isMongoId().withMessage(ERRORS.INVALID),
  body('filter.status').optional().isNumeric().withMessage(ERRORS.INVALID),
  body('filter.isVerifiedSupplier')
    .optional({ nullable: true })
    .isString()
    .withMessage(ERRORS.INVALID),
  body('filter.state')
    .optional()
    .isString()
    .isIn(['online', 'offline'])
    .withMessage(ERRORS.INVALID),
  body('filter.categoryId').optional().isMongoId().withMessage(ERRORS.INVALID),
  body('filter.websiteCode')
    .optional({ nullable: true })
    .isString()
    .withMessage(ERRORS.INVALID),
  body('filter.reviewedBy')
    .optional()
    .isString()
    .customSanitizer((value: string): string => value.toLowerCase()),
  reqValidationResult,
];

export async function listProductUpdateRequestBackofficeActionV3(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    body: {
      page = 1,
      size = appConfig.product.listDefaultLimit,
      filter: {
        status,
        supplierCompanyId,
        supplierId,
        productId,
        term,
        categoryId,
        state,
        isVerifiedSupplier,
        reviewedBy,
        updatedAtAfter,
        updatedAtBefore,
        websiteCode,
      },
    },
  } = req;

  const childCategoriesIds: string[] = await findChildCategories(
    categoryId ? [categoryId] : [],
  );
  const recordsToSkip: number = (page - 1) * size;

  const query: FilterQuery<IProductUpdateRequestDocumentV3> = {
    ...(supplierId ? { supplierId } : {}),
    ...(websiteCode ? { websiteCode } : {}),
    ...(supplierCompanyId ? { supplierCompanyId } : {}),
    ...(productId ? { productId } : {}),
    ...(status ? { status } : {}),
    ...(term
      ? {
          $or: [
            {
              'metadata.name.en': {
                $regex: term,
                $options: 'i',
              },
            },
            {
              'metadata.name.ar': {
                $regex: term,
                $options: 'i',
              },
            },
            {
              'metadata.sku': term.toUpperCase(),
            },
          ],
        }
      : {}),
    ...(reviewedBy
      ? {
          'reviewedBy.email': {
            $regex: reviewedBy.replace(/[-[\]{}()*+?.,\\/^$|#\s]/g, '\\$&'),
            $options: 'i',
          },
        }
      : {}),
    ...(updatedAtAfter || updatedAtBefore
      ? { updatedAt: getDateFilterV3(updatedAtAfter, updatedAtBefore) }
      : {}),
  };

  const totalRecords: number = await productUpdateRequestModelV3.countDocuments(
    query,
  );

  const productUpdateRequest: IProductUpdateRequestDocumentV3[] = await productUpdateRequestModelV3
    .find(
      query,
      {},
      {
        limit: size,
        skip: recordsToSkip,
        sort: {
          updatedAt: -1,
        },
      },
    )
    .lean();

  const isVerifiedSupplierFilterParam: Record<
    'verified' | 'nonVerified' | 'both',
    { [index: string]: boolean }
  > = {
    verified: { 'metadata.userDetail.isSupplierVerified': true },
    nonVerified: { 'metadata.userDetail.isSupplierVerified': false },
    both: {},
  };

  const productConditions: any = {
    _id: { $in: map(productUpdateRequest, 'productId') },
    ...(categoryId ? { categoryId: childCategoriesIds } : {}),
    ...(state ? { state } : {}),
    ...(isVerifiedSupplier
      ? { ...isVerifiedSupplierFilterParam[isVerifiedSupplier] }
      : {}),
  };

  const products: IProductModelV3[] = await productModelV3
    .find(productConditions)
    .lean();
  const productUpdateRequestExtended: ProductUpdateRequestListExtendedV3[] = extendProductUpdateRequest(
    productUpdateRequest,
    products,
  );

  res.json({
    currentPage: page,
    totalPages: Math.ceil(totalRecords / size),
    totalRecords,
    size,
    data: productUpdateRequestExtended,
  });
}
