import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { ERRORS } from '@src/types/errors';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import {
  InternalReviewStatuses,
  InternalReviewStatusType,
  ProductStates,
} from '../types';
import { productValidatorsV3 } from '@core/util/validatorsV3';
import { IProductModelV3, productModelV3 } from '../model-product-v3';
import { StatusCodes } from 'http-status-codes';
import { HttpError } from '@tradeling/web-js-utils';
import {
  get,
  isBoolean,
  isEmpty,
  isEqual,
  isNumber,
  keyBy,
  map,
  uniq,
  xor,
} from 'lodash';
import { mediaModel } from '../../media/model-media';
import { joinUrl } from '@core/util/url';
import { appConfig } from '@src/config/env';
import {
  IProductUpdateRequestModelV3,
  productUpdateRequestModelV3,
} from '../model-product-update-request-v3';
import { IOfferModelV3, offerModelV3 } from '../../offer/model-offers-v3';
import { FilterQuery } from 'mongoose';
import { logger } from '@core/util/logger';
import {
  refreshConfigurationAttributes,
  transformFinalResultForProducts,
} from './helpers';
import { EE } from '@src/config/event/emitter';
import { ProductSyncEvent, ProductSyncEventType } from '../sync-hlper';
import { moveFilesToSupplierPath } from '../../media/helpers';
import {
  formatPackagingInfo,
  getAuditForCostPrice,
  getAuditForOffers,
} from '../../upload/helpers';
import {
  auditFields,
  logAuditEventForV3Products,
} from '@express/modules/product/send-product-audit-event';

type V3UpdateProduct = Components.RequestBodies.V3UpdateProduct;
type V3Product = Components.Schemas.V3Product;

interface IReq extends IAppRequest {
  body: Paths.V3UpdateProductAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3UpdateProductAction.Responses.$200) => this;
}

export const validateV3UpdateProduct: BaseValidationType = [
  body('id') //
    .not()
    .isEmpty()
    .withMessage(ERRORS.MISSING)
    .isMongoId()
    .withMessage(ERRORS.INVALID),
  ...productValidatorsV3,
  reqValidationResult,
];

export enum UpdateProductStatusV3 {
  Success = 'product.UpdateProductStatus.success',
}

export async function v3UpdateProductAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    supplierCompanyId,
    supplierId,
    userId,
    body: { id, offers, sku, collectionIds = [] },
    body,
  } = req;

  const product: IProductModelV3 = await productModelV3
    .findOne({ _id: id })
    .lean();

  // if product not found ...
  if (!product) {
    throw new HttpError(StatusCodes.NOT_FOUND, ERRORS.NOT_FOUND);
  }

  // this working fine . but not sure if it's the best way to do it
  if (product.internalReviewStatus == InternalReviewStatuses.Accepted) {
    await updateProductRequest(product, body, supplierCompanyId);
  } else {
    await updateProduct(product, body, supplierCompanyId, supplierId, userId);
  }
  // update offers ...
  await updateOffers(product, offers, supplierCompanyId, supplierId, req);

  const updatedOffers: IOfferModelV3[] = await offerModelV3
    .find({
      productId: product?._id,
    })
    .lean();

  // update the status ...
  const updatedProduct: IProductModelV3 = await updateProductUploadStatus(
    product,
    sku,
    body,
  );

  await refreshConfigurationAttributes(body?.parentSku, supplierCompanyId);

  // emit event for sync model
  EE.emit(ProductSyncEvent.Updated, {
    req,
    productIds: [product._id],
    priority: 'highest',
  } as ProductSyncEventType).catch((error: Error): void => {
    logger.error(`Event ${ProductSyncEvent.Updated} failed: ${error.stack}`);
  });

  const productWithUpdateRequest: V3Product[] = await transformFinalResultForProducts(
    [await productModelV3.findById(body?.id).lean()],
  );

  res.json(productWithUpdateRequest[0]);
}

async function updateProductUploadStatus(
  product: IProductModelV3,
  sku: string,
  body: any,
): Promise<IProductModelV3> {
  const approvedDiff: Record<string, any> = diffApprovedValues(body, product);
  const approvedFields: string[] = Object.keys(approvedDiff);
  const shouldChangeProductValues: boolean =
    product.internalReviewStatus != InternalReviewStatuses.Accepted;
  return productModelV3
    .findOneAndUpdate(
      {
        _id: product._id,
      },
      {
        internalReviewStatus: shouldChangeProductValues
          ? InternalReviewStatuses.Pending
          : InternalReviewStatuses.Accepted,
        ...(!product.hasVariants && shouldChangeProductValues
          ? { sku: sku }
          : {}),
        ...approvedFields.reduce((obj: any, field: string) => {
          obj[field] = (approvedDiff as any)[field].newValue;
          return obj;
        }, {}),
        lastUploadDate: shouldChangeProductValues
          ? new Date()
          : product?.lastUploadDate,
        uploadCount: shouldChangeProductValues
          ? (product.uploadCount || 0) + 1
          : product?.uploadCount,
        postfix: { en: map(body?.variantValues, 'value.en').join(',') || '' },
      },
    )
    .lean();
}

// you will get offer then compare received offer with default
// if default offer > received offer
// then update received offer to be default offer -- delete old offer after creating the received offer
//
// --- else escape the updating
async function updateOffers(
  product: any,
  offers: any,
  supplierCompanyId: string,
  supplierId: string,
  req: IReq,
): Promise<IOfferModelV3[]> {
  const offerIds: string[] = map(offers, '_id');
  let fields: auditFields[] = [];
  let costPriceFields: auditFields[] = [];
  const sourceOffers: Record<string, IOfferModelV3> = keyBy(
    await offerModelV3
      .find({ _id: { $in: offerIds } }, { _id: 1, delivery: 1 })
      .lean(),
    '_id',
  );
  const updatedOffers: IOfferModelV3[] = [];
  for (let i: number = 0; i < offers?.length; i++) {
    const conditions: FilterQuery<any> = {
      productId: product._id,
    };
    const defaultOffer: IOfferModelV3 = await offerModelV3
      .findOne(conditions)
      .lean();

    fields = getAuditForOffers(defaultOffer, offers[i]);
    costPriceFields = getAuditForCostPrice(defaultOffer, offers[i]);
    const defaultPrice: number = defaultOffer?.market?.tiers[0]?.price;
    if (
      defaultOffer &&
      defaultPrice > offers[i].market.tiers[0]?.price &&
      !defaultOffer?.isManualDefault
    ) {
      await offerModelV3.updateOne(conditions, { isDefault: false });
    }

    const sourceOffer: IOfferModelV3 = get<IOfferModelV3>(
      sourceOffers,
      offers[i]._id,
    );
    try {
      updatedOffers.push(
        await offerModelV3
          .findOneAndUpdate(
            {
              productId: product._id,
              supplierCompanyId,
              'market.code': offers[i].market.code,
            },
            {
              $set: {
                isActive: true,
                isManualDefault: offers[i].isManualDefault,
                isDefault:
                  !defaultOffer ||
                  (defaultOffer?.market?.tiers[0]?.price >
                    offers[i]?.market.tiers[0]?.price &&
                    !defaultOffer.isManualDefault),
                market: offers[i].market,
                delivery: {
                  ...sourceOffer?.delivery,
                  leadTimeValue: offers[i].delivery.leadTimeValue,
                  leadTimeUnit: offers[i].delivery.leadTimeUnit,
                },
                subSupplierCompanies: offers[i].subSupplierCompanies || [],
                supplierCompanyId,
                supplierId,
              },
            },
            {
              new: true,
              upsert: true,
            },
          )
          .lean(),
      );
    } catch (e) {
      logger.error(e.message);
      if (defaultOffer) {
        await offerModelV3.updateOne(conditions, { isDefault: true });
      }
    }
  }
  if (!isEmpty(fields)) {
    await logAuditEventForV3Products({ _id: product._id }, req, fields);
  }

  if (!isEmpty(costPriceFields)) {
    await logAuditEventForV3Products(
      { _id: product._id },
      req,
      costPriceFields,
    );
  }
  // why we do this ??
  await offerModelV3.deleteMany({
    deletedAt: null,
    productId: product._id,
    supplierId: supplierId,
    'market.code': {
      $nin: map(offers, 'market.code'),
    },
  });
  return updatedOffers;
}

export function diffProductValues(
  body: Paths.V3UpdateProductAction.RequestBody,
  product: IProductModelV3,
): Record<string, any> {
  const productObj: Components.Schemas.V3Product = JSON.parse(
    JSON.stringify(product),
  );

  const fieldsToCompare: string[] = [
    'categoryId',
    'longDescription',
    'name',
    'shortDescription',
    'unit',
    'packaging',
    'transportationMode',
    'attributes',
    'descriptionMedia',
    'keywords',
    'dimensions',
    'additionalAttributes.*.label',
    'additionalAttributes.*.value',
    'media.*.id',
    'media.*.sort',
  ];

  return getDiffOfSpecificFields(body, fieldsToCompare, productObj);
}

//
function getDiffOfSpecificFields(
  body: Paths.V3UpdateProductAction.RequestBody,
  fieldsToCompare: string[],
  productObj: Components.Schemas.V3Product,
) {
  const diff: Record<string, any> = {};
  for (const key of fieldsToCompare) {
    if (
      isSame(productObj, body, key) ||
      (!key.includes('.*.') && [undefined].includes(get(body, key)))
    ) {
      continue;
    }

    // if key is array, set its key name by extracting
    if (key.includes('.*.')) {
      const baseKey: string = key.split('.*.')[0];
      if ([undefined].includes(get(body, baseKey))) {
        continue;
      }
      diff[baseKey] = {
        oldValue: get(productObj, baseKey),
        newValue: get(body, baseKey),
      };
    } else {
      diff[key] = {
        oldValue: ![null, undefined].includes(get(productObj, key))
          ? get(productObj, key)
          : null,
        newValue: get(body, key),
      };
    }
  }

  // remove diffs that have empty-like values, undefined, null, ''
  for (const label of Object.keys(diff)) {
    if (
      isEqual(
        removeEmptyValues(diff[label]?.oldValue),
        removeEmptyValues(diff[label]?.newValue),
      )
    ) {
      delete diff[label];
    }
  }

  return diff;
}

function removeEmptyValues(value: any): any {
  if (typeof value === 'undefined') {
    return '';
  }

  return JSON.parse(JSON.stringify(value), (key, value) => {
    if (!isBoolean(value) && !isNumber(value) && isEmpty(value)) {
      return undefined;
    }
    return value;
  });
}

//
export function isSame(product: any, body: any, field: string): boolean {
  // For indexed arrays match the field value without sorting except for media
  if (field.includes('.*.')) {
    const [lField, rField] = field.split('.*.');
    const newValue: any = map(get(body, lField), rField);
    const oldValue: any = map(get(product, lField), rField);
    if (lField === 'media') {
      return isEqual(newValue, oldValue);
    }
    return xor(newValue, oldValue).length === 0;
  }

  const newValue: any = get(body, field);
  const oldValue: any = ![null, undefined].includes(get(product, field))
    ? get(product, field)
    : {};

  // If either old or new value is bool, we don't check the emptiness because _.isEmpty returns true for both
  if (!isBoolean(oldValue) && (isEmpty(oldValue) || isEmpty(newValue))) {
    return isEmpty(oldValue) === isEmpty(newValue);
  }

  // normal equality checks
  return isEqual(oldValue, newValue);
}

async function updateProductRequest(
  product: IProductModelV3,
  body: V3UpdateProduct,
  supplierCompanyId: string,
): Promise<IProductUpdateRequestModelV3> {
  const diff: Record<string, any> = diffProductValues(body, product);

  // get metadata for the product
  let allMedia: Components.Schemas.V1MediaItems = [];
  if ('media' in diff) {
    // prettier-ignore
    const mediaIds: string[] = uniq([
      ...(diff.media?.oldValue ? diff.media.oldValue : []),
      ...(diff.media?.newValue ? diff.media.newValue : [])
    ].map((item) => item.id));

    // prettier-ignore
    const mediaItems: Components.Schemas.V1MediaItems = await mediaModel.find({
      _id: {
        $in: mediaIds
      }
    }, {
      name: 1,
      type: 1,
      path: 1
    }).lean();

    allMedia = mediaItems.map(
      (
        item: Components.Schemas.V1MediaItem,
      ): Components.Schemas.V1MediaItem => ({
        ...item,
        url: joinUrl(appConfig.mediaBaseUrl, item.path),
      }),
    );
  }

  if (
    Object.keys(diff).length &&
    product.internalReviewStatus == InternalReviewStatuses.Accepted
  ) {
    return productUpdateRequestModelV3
      .findOneAndUpdate(
        {
          productId: product?._id,
          supplierCompanyId,
          status: { $ne: InternalReviewStatuses.Accepted },
        },
        {
          $set: {
            diff: diff as any,
            rejectionReasons: [],
            status: InternalReviewStatuses.Pending,
            // websiteCode: product?.websiteCode,
            metadata: {
              createdAt: product.createdAt,
              name: product?.name || product.name,
              sku: product.sku,
              media: {
                ...keyBy(allMedia, '_id'),
              },
            },
          },
        },
        {
          sort: { updatedAt: -1 },
          upsert: true,
        },
      )
      .lean();
  }

  return null;
}

export function diffApprovedValues(
  body: Paths.V3UpdateProductAction.RequestBody,
  product: Components.Schemas.V3Product,
) {
  const productObj: Components.Schemas.V3Product = JSON.parse(
    JSON.stringify(product),
  );

  const fieldsToCompare: string[] = [
    'isInStock',
    'isReadyToShip',
    'isBuyNow',
    'barcode',
    'collectionIds',
    'variantValues',
    'tags',
  ];

  return getDiffOfSpecificFields(body, fieldsToCompare, productObj);
}

async function updateProduct(
  product: IProductModelV3,
  body: V3UpdateProduct,
  supplierCompanyId: string,
  supplierId: string,
  userId: string,
): Promise<IProductModelV3> {
  if (!body.media?.length) {
    body.state = ProductStates.Offline;
  }

  let internalReviewStatus: InternalReviewStatusType =
    product.internalReviewStatus;
  if (product.internalReviewStatus === InternalReviewStatuses.Rejected) {
    internalReviewStatus = InternalReviewStatuses.Pending;
  }

  /**
   * Get all images from long description
   * Move temporary images from content to media collection
   * Generate the public Uri's so could be available publicly along with product
   */
  if (body?.longDescription?.en) {
    const {
      media: editorMedia,
      description: updatedDescription,
    } = await moveFilesToSupplierPath(
      { userId, supplierId, supplierCompanyId },
      body.longDescription.en,
    );

    body.longDescription.en = updatedDescription;
    body.descriptionMedia = editorMedia;
  }

  return productModelV3.findOneAndUpdate(
    {
      _id: product._id,
      supplierCompanyId,
    },
    {
      $set: {
        ...(body as any),
        packagingFormat: formatPackagingInfo(body.unit, body.packaging),
        postfix: { en: map(body?.variantValues, 'value.en').join(',') || '' },
        internalReviewStatus,
        metadata: {
          ...product.metadata,
          rejectedReason: '',
          rejectionReasons: [],
        },
      },
    },
  );
}
