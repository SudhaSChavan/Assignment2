import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { ERRORS } from '@src/types/errors';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { InternalReviewStatuses } from './../types';
import { StatusCodes } from 'http-status-codes';
import { HttpError } from '@tradeling/web-js-utils';
import { productUpdateRequestModelV3 } from '../model-product-update-request-v3';

interface IReq extends IAppRequest {
  body: Paths.V3DismissProductRejectionsAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3DismissProductRejectionsAction.Responses.$200) => this;
}

export const validateDismissProductRejectionsV3: BaseValidationType = [
  body('id').optional().isString().isMongoId(),
  body('productId').optional().isString().isMongoId(),
  reqValidationResult,
];

export async function dismissProductRejectionsActionV3(
  req: IReq,
  res: IRes,
): Promise<IRes> {
  const { id, productId } = req.body;

  if (!id && !productId) {
    throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.MISSING);
  }

  const { nModified } = await productUpdateRequestModelV3.updateOne(
    {
      status: InternalReviewStatuses.Rejected,
      $or: [{ productId: productId }, { _id: id }],
    },
    {
      status: InternalReviewStatuses.Dismissed,
    },
  );

  return res.json({
    isDismissed: nModified > 0,
  });
}
