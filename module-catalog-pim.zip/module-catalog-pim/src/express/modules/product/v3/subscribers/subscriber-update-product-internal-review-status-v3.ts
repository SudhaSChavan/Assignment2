import { logger } from '@core/util/logger';
import {
  V1UpdateProductInternalReviewStatusMessageData,
  V1UpdateProductInternalReviewStatusSubject,
} from './../../queue-message/queue-message-v1-update-product-internal-review-status';
import { getProductNumber } from './../../helper-product-number';
import { consumeFromQueue, IConsumerParams } from '@src/config/event/kafka';
import { IProductModelV3, productModelV3 } from '../../model-product-v3';
import { ProductSyncEvent, ProductSyncEventType } from '../../sync-hlper';
import { EE } from '@src/config/event/emitter';

export function subscriberUpdateProductInternalReviewStatusV3(): void {
  consumeFromQueue(
    V1UpdateProductInternalReviewStatusSubject,
    processMessage,
  ).catch((error: Error): void => {
    logger.error(error.message);
  });
}

async function processMessage(params: IConsumerParams): Promise<void> {
  try {
    const { message } = params;
    const {
      productIds,
    }: V1UpdateProductInternalReviewStatusMessageData = JSON.parse(
      message.value.toString(),
    );

    if (!productIds.length) {
      return;
    }

    logger.debug(
      `Message received: ${V1UpdateProductInternalReviewStatusSubject}`,
    );

    const products: IProductModelV3[] = await productModelV3.find({
      _id: {
        $in: productIds,
      },
    });

    // Assign the short id if it does not exist
    for (const product of products) {
      if (product?.shortId) {
        continue;
      }

      product.shortId = await getProductNumber();
      await product.save();
    }

    EE.emit(ProductSyncEvent.Created, {
      req: null,
      productIds,
      priority: 'highest',
    } as ProductSyncEventType).catch((error: Error): void => {
      logger.error(`Event ${ProductSyncEvent.Updated} failed: ${error.stack}`);
    });
  } catch (error) {
    logger.error(
      `<subscriber_failed_kafka> for ${V1UpdateProductInternalReviewStatusSubject} with error ${error.message}`,
    );
  }
}
