import { consumeFromQueue, IConsumerParams } from '@src/config/event/kafka';
import { logger } from '@core/util/logger';
import {
  V1UpdateSupplierCompanyStatusMessageData,
  V1UpdateSupplierCompanyStatusSubject,
} from './../../queue-message/queue-message-v1-update-supplier-company-status';
import { InternalReviewStatuses, ProductStates } from './../../types';
import { FilterQuery } from 'mongoose';
import { logAuditEventForV3Products } from '../../send-product-audit-event';
import { IProductModelV3, productModelV3 } from '../../model-product-v3';
import { EE } from '@src/config/event/emitter';
import { ProductSyncEvent, ProductSyncEventType } from '../../sync-hlper';

export function subscriberUpdateSupplierCompanyStatusV3(): void {
  consumeFromQueue(V1UpdateSupplierCompanyStatusSubject, processMessage).catch(
    (error: Error): void => {
      logger.error(error.message);
    },
  );
}

async function processMessage(params: IConsumerParams): Promise<void> {
  const { message } = params;
  const {
    supplierCompanyId,
    status,
  }: V1UpdateSupplierCompanyStatusMessageData = JSON.parse(
    message.value.toString(),
  );

  if (!supplierCompanyId) {
    return;
  }

  logger.debug(`Message received: ${V1UpdateSupplierCompanyStatusSubject}`);

  if (status === 'accepted') {
    await makeProductsOnline(supplierCompanyId);
  } else if (status === 'rejected') {
    await makeProductsOffline(supplierCompanyId);
  }
}

async function makeProductsOnline(supplierCompanyId: string): Promise<void> {
  const conditions: FilterQuery<any> = {
    supplierCompanyId,
    internalReviewStatus: InternalReviewStatuses.Accepted,
    state: ProductStates.Offline,
    tags: 'verification-rejected',
  };
  await logAuditEventForV3Products(
    conditions,
    null,
    { name: 'state', old: ProductStates.Offline, new: ProductStates.Online },
    'make.product.online.update.success',
  );
  const productIds: IProductModelV3[] = await productModelV3
    .find(conditions, {
      _id: 1,
    })
    .lean();

  await productModelV3.updateMany(conditions, {
    $pull: {
      // @ts-ignore
      tags: 'verification-rejected',
    },
    $set: {
      state: ProductStates.Online,
    },
  });

  EE.emit(ProductSyncEvent.Created, {
    req: null,
    productIds: productIds.map((p) => p._id),
    priority: 'highest',
  } as ProductSyncEventType).catch((error: Error): void => {
    logger.error(`Event ${ProductSyncEvent.Updated} failed: ${error.stack}`);
  });
}

async function makeProductsOffline(supplierCompanyId: string): Promise<void> {
  const conditions: FilterQuery<any> = {
    supplierCompanyId,
    state: ProductStates.Online,
  };
  const productIds: IProductModelV3[] = await productModelV3
    .find(conditions, {
      _id: 1,
    })
    .lean();

  await logAuditEventForV3Products(
    conditions,
    null,
    { name: 'state', old: ProductStates.Online, new: ProductStates.Offline },
    'make.product.offline.update.success',
  );

  EE.emit(ProductSyncEvent.Created, {
    req: null,
    productIds: productIds.map((p) => p._id),
    priority: 'highest',
  } as ProductSyncEventType).catch((error: Error): void => {
    logger.error(`Event ${ProductSyncEvent.Updated} failed: ${error.stack}`);
  });

  await productModelV3.updateMany(conditions, {
    $push: {
      // @ts-ignore
      tags: 'verification-rejected',
    },
    $set: {
      state: ProductStates.Offline,
    },
  });
}
