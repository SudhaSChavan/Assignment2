import { consumeFromQueue, IConsumerParams } from '@src/config/event/kafka';
import { logger } from '@core/util/logger';
import {
  V1UpdateWmsProductDataMessageData,
  V1UpdateWmsProductDataQueueSubject,
} from '../../queue-message/queue-message-v1-update-wms-product-data';
import isEmpty from 'lodash/isEmpty';
import { logAuditEventForV3Products } from '../../send-product-audit-event';
import { IProductModelV3, productModelV3 } from '../../model-product-v3';
import { appConfig } from '@src/config/env';
import { ProductSyncEvent, ProductSyncEventType } from '../../sync-hlper';
import { EE } from '@src/config/event/emitter';

export const AuditDescription: string = 'update-supply-price-wms';

export function subscriberUpdateWmsProductDataV3(): void {
  consumeFromQueue(V1UpdateWmsProductDataQueueSubject, processMessage).catch(
    (error: Error): void => {
      logger.error(error.message);
    },
  );
}

/**
 *
 * @param params
 */
async function processMessage(params: IConsumerParams): Promise<void> {
  const { message } = params;
  const {
    type,
    sku,
    supplyPrice,
  }: V1UpdateWmsProductDataMessageData = JSON.parse(message.value.toString());
  logger.info(
    `${V1UpdateWmsProductDataQueueSubject} --- ${sku}-- ${type} -- ${supplyPrice}`,
  );
  await updateSupplyPrice(sku, supplyPrice);
}

/**
 *
 * @param sku
 * @param supplyPrice
 */
async function updateSupplyPrice(
  sku: string,
  supplyPrice: number,
): Promise<void> {
  const foundProducts: IProductModelV3[] = await productModelV3.find({
    sku: sku,
    supplierCompanyId: { $in: appConfig.tradelingExpressIds },
  });
  for (const product of foundProducts) {
    if (!isEmpty(product)) {
      logger.info(
        `${V1UpdateWmsProductDataQueueSubject} --updating product- ${sku}-- ${supplyPrice}`,
      );
      await logAuditEventForV3Products(
        { sku },
        null,
        { name: 'supplyPrice', old: product.supplyPrice, new: supplyPrice },
        AuditDescription,
      );
      await productModelV3.updateOne({ sku }, { supplyPrice });
    }
  }

  const productIds: string[] = foundProducts.map((product) => product._id);
  EE.emit(ProductSyncEvent.Created, {
    req: null,
    productIds,
    priority: 'highest',
  } as ProductSyncEventType).catch((error: Error): void => {
    logger.error(`Event ${ProductSyncEvent.Updated} failed: ${error.stack}`);
  });
}
