import { logger } from '@core/util/logger';
import {
  V1UpdateWMSStockData,
  V1UpdateWMSStockDataSubject,
} from '@tradeling/tradeling-sdk/shipping/queue/queue-message-v1-update-wms-stock-data';
import { consumeFromQueue, IConsumerParams } from '@src/config/event/kafka';
import { isEmpty, keyBy, get } from 'lodash';
import { V1GetStoreByStoreIdAction } from '@tradeling/tradeling-sdk/www/v1-get-store-by-store-id-action';
import { StoreType } from '@tradeling/web-js-utils/dist';
import { isAfter, isBefore } from 'date-fns';
import { KeyValAny } from '@src/types/common';
import { FilterQuery } from 'mongoose';
import { appConfig } from '@src/config/env';
import { IProductModelV3, productModelV3 } from '../../model-product-v3';
import { IOfferModelV3, offerModelV3 } from '../../../offer/model-offers-v3';
import {
  auditFields,
  logAuditEventForV3Products,
} from '../../send-product-audit-event';
import { EE } from '@src/config/event/emitter';
import { ProductSyncEvent, ProductSyncEventType } from '../../sync-hlper';
import { MatchKeysAndValues } from 'mongodb';
import { WebsiteCode } from '@tradeling/web-js-utils';

export function subscriberUpdateStockV3(): void {
  consumeFromQueue(V1UpdateWMSStockDataSubject, processMessage).catch(
    (error: Error): void => {
      logger.error(error.message);
    },
  );
}

export const AuditDescription: string = 'updateStock-wms';

export async function updateProductStock(
  sku: string,
  stockQty: number,
  stockQtyBreakdown: any[],
  expressIds: string[],
): Promise<void> {
  try {
    // add created supplier company ids ...
    const products: IProductModelV3[] = await productModelV3.find({
      sku: sku,
      supplierCompanyId: { $in: expressIds },
    });
    if (isEmpty(products)) {
      logger.error(`No product found with sku ${sku}`);
      return;
    }

    for (const product of products) {
      if (isEmpty(product)) {
        logger.error(`No master product found with sku ${sku}`);
        return;
      }

      const foundOffers: IOfferModelV3 = await offerModelV3.findOne({
        productId: product._id.toString(),
      });
      if (isEmpty(foundOffers)) {
        logger.error(`No product offers with sku ${sku}`);
        return;
      }

      const defaultMinQty: number =
        foundOffers.market.tiers[0]?.defaultMoq || 0;
      const ws: string = await getOperatingWS(product.storeKeyId);
      let wsStock: number = stockQty;
      if (!isEmpty(ws)) {
        const wmsMap: KeyValAny = keyBy(stockQtyBreakdown, 'warehouse.label');
        wsStock = !isEmpty(wmsMap[ws]) ? wmsMap[ws].available : 0;
      }
      const minQty: number = foundOffers?.market?.tiers[0]?.minQty || 0;
      const isOverSell: boolean = product?.isOverSell || false;
      const isInWmsStock: boolean = wsStock > 0;

      const isOverSellOrInWmsStock: boolean = isOverSell || isInWmsStock;
      const isInStockProduct: boolean =
        product?.isInStock || !isOverSellOrInWmsStock;

      const auditFields: auditFields[] = [
        { name: `stockQty -- ${sku}`, old: product?.stockQty, new: stockQty },
        {
          name: `isInStock -- ${sku}`,
          old: isInStockProduct,
          new: isOverSellOrInWmsStock,
        },
      ];

      const conditions: FilterQuery<any> = { _id: product?._id };
      await productModelV3.findOneAndUpdate(conditions, {
        $set: {
          stockQty: stockQty,
          stockQtyBreakdown: stockQtyBreakdown,
          isInStock: isOverSellOrInWmsStock,
        },
      });

      // then update the stock
      if (wsStock < minQty) {
        // we need the updating defaultMinQty part
        logger.info(
          `wsStock ${wsStock} is less than minimum order quantity ${minQty} with sku ${sku} :: logged at ${V1UpdateWMSStockDataSubject}`,
        );
      }

      if (product.websiteCode === WebsiteCode.tcom) {
        // if its in stock and has the stock
        if (wsStock > 0 && !product.tags?.includes('express')) {
          await productModelV3.findOneAndUpdate(conditions, {
            $push: {
              // @ts-ignore
              tags: 'express',
            },
          });
        } else if (wsStock === 0) {
          await productModelV3.findOneAndUpdate(conditions, {
            $pull: {
              // @ts-ignore
              tags: 'express',
            },
          });
        }
      }

      const tiers: any = {
        'delivery.hasCustomDeliveryDay': true,
      };

      // reset the MOQ - in case if there is a stock
      if (
        defaultMinQty > 0 &&
        stockQty >= defaultMinQty &&
        defaultMinQty !== minQty
      ) {
        // reset the moq to default value
        tiers['market.tiers.0.defaultMoq'] = 0;
        tiers['market.tiers.0.minQty'] = defaultMinQty;
        auditFields.push({
          name: `Reset MOQ -- ${sku}`,
          old: minQty,
          new: defaultMinQty,
        });
        await updatedProductsVariantsOffers(product?._id, tiers);
      }
      // receiving stock and no default MOQ
      else if (
        (stockQty >= minQty && defaultMinQty === 0) ||
        (stockQty < minQty && stockQty < defaultMinQty && stockQty > 0)
      ) {
        // @ts-ignore
        await updatedProductsVariantsOffers(product?._id, {
          // @ts-ignore
          'delivery.hasCustomDeliveryDay': true,
        });
      }
      // update the MOQ in case stock less than MOQ
      else if (stockQty > 0 && stockQty <= minQty) {
        const tiers: any = {
          'delivery.hasCustomDeliveryDay': true,
          'market.tiers.0.minQty': stockQty,
        };
        // only override if it's zero or undefined
        if (defaultMinQty === 0 || defaultMinQty === undefined) {
          tiers['market.tiers.0.defaultMoq'] = minQty;
        }
        await updatedProductsVariantsOffers(product?._id, tiers);
        auditFields.push({ name: `MOQ -- ${sku}`, old: minQty, new: stockQty });
      }
      // reset the MOQ in case of stock zero - all stock Qty sold
      else if (
        stockQty === 0 &&
        defaultMinQty > 0 &&
        minQty !== defaultMinQty
      ) {
        await updatedProductsVariantsOffers(product?._id, {
          // @ts-ignore
          'delivery.hasCustomDeliveryDay': false,
          // @ts-ignore
          'market.tiers.0.minQty': defaultMinQty,
          // @ts-ignore
          'market.tiers.0.defaultMoq': 0,
        });
        auditFields.push({
          name: `Reset MOQ -- ${sku}`,
          old: minQty,
          new: defaultMinQty,
        });
      } else {
        // @ts-ignore
        await updatedProductsVariantsOffers(product?._id, {
          // @ts-ignore
          'delivery.hasCustomDeliveryDay': false,
        });
      }

      if (stockQty === 0 && isOverSell) {
        await productModelV3.findOneAndUpdate(conditions, {
          $unset: {
            stockQty: 1,
            stockQtyBreakdown: 1,
          },
        });
      }
      const productConditions: FilterQuery<any> = { _id: product._id };
      if (stockQty !== product?.stockQty) {
        await logAuditEventForV3Products(
          productConditions,
          null,
          auditFields,
          AuditDescription,
        );
      }
    }

    // update products subscribers model
    const productIds: string[] = products.map((product) => product._id);
    //emit event for sync model
    EE.emit(ProductSyncEvent.Created, {
      req: null,
      productIds,
      priority: 'highest',
    } as ProductSyncEventType).catch((error: Error): void => {
      logger.error(`Event ${ProductSyncEvent.Updated} failed: ${error.stack}`);
    });
  } catch (error) {
    logger.error(
      `<subscriber_failed_kafka> for ${V1UpdateWMSStockDataSubject} with error ${error.message}`,
    );
  }
}

async function processMessage(params: IConsumerParams): Promise<void> {
  const { message } = params;
  const { variant }: V1UpdateWMSStockData = JSON.parse(
    message.value.toString(),
  );
  const {
    sku,
    stockQty,
    stockQtyBreakdown,
  }: IProductModelV3 = variant as IProductModelV3;

  logger.info(
    `v3 stock -- Message received: ${V1UpdateWMSStockDataSubject} for product ${JSON.stringify(
      variant,
    )}`,
  );

  await updateProductStock(
    sku,
    stockQty,
    stockQtyBreakdown,
    appConfig.tradelingExpressIds,
  );
}

async function getStore(storeKeyId: string): Promise<StoreType> {
  const { data: store } = await V1GetStoreByStoreIdAction(
    {},
    {},
    { storeKeyId: storeKeyId },
  );
  return store as StoreType;
}

/**
 * @TODO Revisit this part -- to check WMS configs  DDC && DXB1
 * @param storeKeyId
 */
async function getOperatingWS(storeKeyId: string): Promise<string> {
  const store: StoreType = await getStore(storeKeyId);
  if (isEmpty(store)) {
    logger.error(
      `failed to get store for store-id ${storeKeyId} in wms stock update`,
    );
    return '';
  }

  const wms: any = get(store, 'settings.wms', undefined);
  if (isEmpty(wms)) {
    logger.error(`wms configs not found for ${storeKeyId} in wms stock update`);
    return '';
  }

  for (const ws of wms) {
    const now: Date = new Date();
    const operatingFrom: Date = new Date(ws.operatingFrom);
    const operatingTo: any = ws.operatingTo
      ? new Date(ws.operatingTo)
      : undefined;
    if (
      isBefore(operatingFrom, now) &&
      (!operatingTo || isAfter(operatingTo, now))
    ) {
      return ws.warehouseLabel;
    }
  }
  logger.error(`no operating wms found for store ${storeKeyId} `);
  return '';
}

/**
 *
 * * @param  productId
 *  * @param setData
 *  */
export async function updatedProductsVariantsOffers(
  productId: string,
  setData: MatchKeysAndValues<any>,
): Promise<void> {
  await offerModelV3.updateOne(
    {
      deletedAt: null,
      productId,
    },
    { $set: setData },
    { upsert: false },
  );
}
