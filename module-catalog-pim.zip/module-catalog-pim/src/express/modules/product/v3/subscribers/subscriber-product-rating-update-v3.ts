import { logger } from '@core/util/logger';
import { consumeFromQueue, IConsumerParams } from '@src/config/event/kafka';
import {
  V2ProductReviewApprovedQueueMessage,
  V2ProductReviewApprovedQueueSubject,
} from '@tradeling/tradeling-sdk/oms/queue/queue-message-v2-product-review';
import { productModelV3 } from '../../model-product-v3';
import { ProductSyncEvent, ProductSyncEventType } from '../../sync-hlper';
import { EE } from '@src/config/event/emitter';

export function subscriberRatingChangedV3(): void {
  consumeFromQueue(V2ProductReviewApprovedQueueSubject, processMessage).catch(
    (error: Error): void => {
      logger.error(error.message);
    },
  );
}

async function processMessage(params: IConsumerParams): Promise<void> {
  try {
    const { message } = params;
    const rating: V2ProductReviewApprovedQueueMessage = JSON.parse(
      message.value.toString(),
    );
    const { productId, ratingAverage, ratingCount } = rating;

    logger.info(
      `Message received: ${V2ProductReviewApprovedQueueSubject} for product ${JSON.stringify(
        rating,
      )}`,
    );

    const { nModified } = await productModelV3.updateOne(
      { _id: productId },
      { $set: { ratingAverage, ratingCount } },
    );

    if (nModified !== 1) {
      logger.error(`Failed to update product ${productId}`);
    }

    EE.emit(ProductSyncEvent.Created, {
      req: null,
      productIds: [productId],
      priority: 'highest',
    } as ProductSyncEventType).catch((error: Error): void => {
      logger.error(`Event ${ProductSyncEvent.Updated} failed: ${error.stack}`);
    });
  } catch (error) {
    logger.error(
      `<subscriber_failed_kafka> for ${V2ProductReviewApprovedQueueSubject} with error ${error.message}`,
    );
  }
}
