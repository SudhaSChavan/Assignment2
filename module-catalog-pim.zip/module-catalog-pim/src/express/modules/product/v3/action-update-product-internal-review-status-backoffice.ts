import { difference, map, keyBy, uniq } from 'lodash';
import { body } from 'express-validator';
import {
  BaseValidationType,
  IBaseAppUser,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import {
  InternalReviewStatuses,
  ProductStates,
  UpdateInternalReviewStatusEvent,
  UpdateInternalReviewStatusEventType,
} from '../types';
import {
  getSupplierByCompanyIds,
  SupplierCompany,
  updateSupplierHasApprovedProducts,
} from '../action-update-product-internal-review-status-backoffice/helpers';
import { IProductModelV3, productModelV3 } from '../model-product-v3';
import { IOfferModelV3, offerModelV3 } from '../../offer/model-offers-v3';
import { EE } from '@src/config/event/emitter';
import { ProductSyncEvent, ProductSyncEventType } from '../sync-hlper';
import { logger } from '@core/util/logger';
import { logAuditEventForV3Products } from '../send-product-audit-event';
import { refreshConfigurationAttributes } from './helpers';

interface IReq extends IAppRequest {
  body: Paths.V3UpdateProductInternalReviewStatusBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body:
      | Paths.V3UpdateProductInternalReviewStatusBackofficeAction.Responses.$200
      | Paths.V3UpdateProductInternalReviewStatusBackofficeAction.Responses.$400,
  ) => this;
}

export const v3ValidateUpdateProductInternalReviewStatusBackoffice: BaseValidationType = [
  //
  body('ids').isArray(),
  body('ids.*').isString(),
  body('status')
    .isNumeric()
    .isIn(Object.values(InternalReviewStatuses))
    .notEmpty(),
  body('rejectionReasons').optional({ nullable: true }).isArray(),
  reqValidationResult,
];

export async function v3UpdateProductInternalReviewStatusBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<any> {
  const { ids, status, rejectionReasons } = req.body;
  const userJwtDecoded: IBaseAppUser = req.userJwtDecoded as IBaseAppUser;
  let productSkusFailedToBeUpdated: string[] = [];
  let syncedProductIds: string[] = [];

  if (status === InternalReviewStatuses.Rejected) {
    await productModelV3.updateMany(
      { _id: { $in: ids } },
      {
        $set: {
          state: ProductStates.Offline,
          internalReviewStatus: status,
          internalReviewedAt: new Date().toISOString(),
          internalReviewedBy: {
            userId: userJwtDecoded?._id,
            email: userJwtDecoded?.email,
          },
          'metadata.rejectionReasons': rejectionReasons,
        },
      },
    );
  }

  //handling the pending state here if by somehow a request came changing the state to pending
  if (status === InternalReviewStatuses.Pending) {
    await productModelV3.updateMany(
      { _id: { $in: ids } },
      {
        $set: {
          state: ProductStates.Offline,
          internalReviewStatus: status,
          internalReviewedAt: new Date().toISOString(),
          internalReviewedBy: {
            userId: userJwtDecoded?._id,
            email: userJwtDecoded?.email,
          },
        },
      },
    );
  }

  // if status is accepted, we need to check to update only products that have all required information
  // we will return error message for products that do not have all required information
  // Put the product Offline if the supplier company still needs to be verified
  if (status === InternalReviewStatuses.Accepted) {
    const products: IProductModelV3[] = await productModelV3.find({
      _id: { $in: ids },
      'media.0': { $exists: true },
    });
    const offers: IOfferModelV3[] = await offerModelV3.find({
      productId: { $in: ids },
      deletedAt: null,
    });
    const variantsHasOffer: string[] = uniq(
      offers.map((offer) => offer.productId),
    );
    const idsToBeUpdated: string[] = products
      .filter((product) => variantsHasOffer.includes(product._id.toString()))
      .map((product) => product?._id.toString());

    const supplierCompanyIds: string[] = map(products, 'supplierCompanyId');
    const supplierCompanies: SupplierCompany[] = await getSupplierByCompanyIds(
      supplierCompanyIds,
    );
    const supplierCompaniesMap: Record<string, SupplierCompany> = keyBy(
      supplierCompanies,
      '_id',
    );
    const bulkOperation: any = products.map((p) => {
      const supplierCompany: SupplierCompany =
        supplierCompaniesMap[p.supplierCompanyId];
      return {
        updateOne: {
          filter: { _id: p._id },
          update: {
            state: supplierCompany?.isVerified
              ? ProductStates.Online
              : ProductStates.Offline,
            internalReviewStatus: status,
            internalReviewedAt: new Date().toISOString(),
            internalReviewedBy: {
              userId: userJwtDecoded?._id,
              email: userJwtDecoded?.email,
            },
          },
        },
      };
    });

    await productModelV3.bulkWrite(bulkOperation);
    const companyIdsWithOutProducts: string[] = supplierCompanies
      .filter((c) => !c.metadata?.hasApprovedProduct)
      .map((c) => c._id);

    await logAuditEventForV3Products({ _id: { $in: idsToBeUpdated } }, req, {
      name: 'state',
      old: 'offline',
      new: 'online',
    });
    await updateSupplierHasApprovedProducts({
      supplierCompanyIds: companyIdsWithOutProducts,
      hasApprovedProduct: true,
      productApprovedAt: new Date().toISOString(),
    });
    const productsFailedToBeApproved: IProductModelV3[] = await productModelV3
      .find(
        {
          _id: { $in: difference(ids, idsToBeUpdated) },
        },
        { sku: 1 },
      )
      .lean();

    productSkusFailedToBeUpdated = productsFailedToBeApproved.map(
      (product) => product.sku,
    );

    for (const product of products) {
      syncedProductIds = syncedProductIds.concat(
        await refreshConfigurationAttributes(
          product?.parentSku,
          product?.supplierCompanyId,
        ),
      );
    }
  }

  EE.emit(ProductSyncEvent.Updated, {
    req,
    productIds: ids.concat(syncedProductIds),
    priority: 'highest',
  } as ProductSyncEventType).catch((error: Error): void => {
    logger.error(`Event ${ProductSyncEvent.Updated} failed: ${error.stack}`);
  });

  // internal review event .. for emails
  EE.emit(UpdateInternalReviewStatusEvent.Success, {
    productIds: ids,
    status,
    req,
  } as UpdateInternalReviewStatusEventType).catch((error: Error): void => {
    logger.error(
      `Event ${UpdateInternalReviewStatusEvent.Success} failed: ${error.stack}`,
    );
  });

  res.json({
    isUpdated: true,
    productSkusFailedToBeUpdated,
  });
}
