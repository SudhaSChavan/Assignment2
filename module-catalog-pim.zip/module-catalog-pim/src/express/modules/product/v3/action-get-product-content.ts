import { body } from 'express-validator';
import {
  BaseValidationType,
  HttpError,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { ERRORS } from '@src/types/errors';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { StatusCodes } from 'http-status-codes';
import { FilterQuery } from 'mongoose';
import { IProductModelV3, productModelV3 } from '../model-product-v3';
import {
  IProductUpdateRequestModelV3,
  productUpdateRequestModelV3,
} from '../model-product-update-request-v3';
import { InternalReviewStatuses } from '../types';
import { transformFinalResultForProducts } from './helpers';

type V3ProductContent = Components.Schemas.V3ProductContent;

interface IReq extends IAppRequest {
  body: Paths.V3GetProductContentAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3GetProductContentAction.Responses.$200) => this;
}

export const validateGetProductContentV3: BaseValidationType = [
  body('parentSku').notEmpty().isString(),
  reqValidationResult,
];

export async function getProductContentActionV3(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    body: { parentSku },
    supplierCompanyId,
  } = req;

  res.json(await getProductContent(parentSku, supplierCompanyId));
}

export async function getProductContent(
  parentSku: string,
  supplierCompanyId: string,
): Promise<V3ProductContent> {
  const query: FilterQuery<IProductModelV3> = {
    supplierCompanyId,
    parentSku,
  };

  const products: IProductModelV3[] = await productModelV3
    .find(query, {})
    .lean();

  if (!products.length) {
    throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.NOT_FOUND);
  }

  return prepareProductDetails(products);
}

async function prepareProductDetails(
  products: IProductModelV3[],
): Promise<V3ProductContent> {
  const firstProduct: IProductModelV3 = products[0];

  const updateRequests: IProductUpdateRequestModelV3 = await productUpdateRequestModelV3.findOne(
    {
      productId: firstProduct?._id,
      status: InternalReviewStatuses.Pending,
    },
  );

  const diff: any = updateRequests?.diff;

  return {
    parentSku: firstProduct?.parentSku,
    name: diff?.name?.newValue || firstProduct?.name,
    unit: diff?.unit?.newValue || firstProduct?.unit,
    brand: diff?.attributes?.newValue?.brand || firstProduct?.attributes?.brand,
    categoryId: diff?.categoryId?.newValue || firstProduct?.categoryId,
    variants: await transformFinalResultForProducts(products, true),
  };
}
