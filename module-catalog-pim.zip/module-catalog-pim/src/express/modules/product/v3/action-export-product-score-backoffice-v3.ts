import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { map, get } from 'lodash';
import { ERRORS } from '@src/types/errors';
import { getProductsByIds } from '../action-export-product-score-backoffice/helpers';
import { Workbook, Worksheet } from 'exceljs';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { KeyValAny } from '@src/types/common';
import { categoryModel, ICategoryModel } from '../../category/model-category';
import { IProductModelV3, productModelV3 } from '../model-product-v3';

interface IReq extends IAppRequest {
  body: Paths.V3ExportProductScoreBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body: Paths.V3ExportProductScoreBackofficeAction.Responses.$400,
  ) => this;
}

export const validateExportProductScoreBackofficeV3: BaseValidationType = [
  //
  body('filter.categoryId').optional().isMongoId().withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function exportProductScoreBackofficeActionV3(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    body: { categoryId },
  } = req;

  const limit: number = 200;

  const projection: any = {
    _id: 1,
    'name.en': 1,
    manualScore: 1,
  };
  const workbook: Workbook = new Workbook();
  const fileName: string = 'product-score-export';

  // get all level 4 categories if categoryId level is not 4
  const category: ICategoryModel = await categoryModel
    .findById(categoryId)
    .lean();

  let query: KeyValAny = { ...(categoryId ? { categoryId } : {}) };
  if (category.level < 3) {
    // Find all the leaf category under the given target category ids
    const leafCategories: ICategoryModel[] = await categoryModel.find({
      $or: [
        {
          parents: {
            $in: [categoryId],
          },
          children: { $size: 0 },
        },
        {
          _id: {
            $in: [categoryId],
          },
          children: { $size: 0 },
        },
      ],
    });

    const leafCategoryIds: string[] = leafCategories.map(
      (category: ICategoryModel): string => String(category._id),
    );

    query = {
      ...(leafCategoryIds ? { categoryId: { $in: leafCategoryIds } } : {}),
    };
  }

  const sheet: Worksheet = workbook.addWorksheet('My Sheet');
  sheet.addRow(['ID', 'Name', 'Relevance Score', 'Manual Score']);

  let products: IProductModelV3[] = await productModelV3
    .find(query, projection, { limit, sort: { _id: 1 } })
    .lean();
  let lastId: string = products.length
    ? products[products.length - 1]._id
    : null;
  /**
   * @todo: getProductsByIds is getting data from V1InternalGetProductAction of catalog-search
   * @Note: Needs to update accordingly when new v3 product data sync to elastic and endpoint expose changes
   */
  let productInfo: { [key: string]: any } = await getProductsByIds(
    map(products, '_id'),
  );
  while (lastId) {
    for (const record of products) {
      const productId: string = record._id.toString();
      const relevanceScore: number =
        get(productInfo, productId)?.relevanceScore || 0;
      sheet.addRow([
        productId,
        record.name?.en,
        relevanceScore,
        record.manualScore || 0,
      ]);
    }

    products = await productModelV3
      .find(
        { ...query, ...(lastId ? { _id: { $gt: lastId } } : {}) },
        projection,
        { limit, sort: { _id: 1 } },
      )
      .lean();
    /**
     * @todo: getProductsByIds is getting data from V1InternalGetProductAction of catalog-search
     * @Note: Needs to update accordingly when new v3 product data sync to elastic and endpoint expose changes
     */
    productInfo = await getProductsByIds(map(products, '_id'));
    lastId = products.length ? products[products.length - 1]._id : null;
  }

  res.setHeader('Content-disposition', `attachment; filename=${fileName}.csv`);
  res.setHeader('content-type', 'text/csv');

  await workbook.csv.write(res);
  res.end();
}
