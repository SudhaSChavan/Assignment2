import ms from 'ms';
import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
  WebsiteCode,
} from '@tradeling/web-js-utils';

import { SkusAggregate } from './../types';
import { ERRORS } from '@src/types/errors';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { redis as redisClient, redis } from '@src/config/redis';
import { productModelV3 } from '../model-product-v3';
import { isEmpty } from 'lodash';

interface IReq extends IAppRequest {
  body: Paths.V3SkuGenerationBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3SkuGenerationBackofficeAction.Responses.$200) => this;
}

export const validateV3SkuGenerationBackoffice: BaseValidationType = [
  body('count').isInt({ gt: 0 }).withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function skuGenerationBackofficeV3Action(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { count } = req.body;

  const excludeSkus: (string | number)[] = await getSkusToExclude();
  const uniqueSkus: number[] = generateSkus(count, excludeSkus);

  res.json(uniqueSkus);
}

function generateSkus(count: number, exclude: (string | number)[]): number[] {
  const skus: number[] = [];

  while (skus.length < count) {
    const randomSku: number = Math.floor(1e12 + Math.random() * 9e12);

    if (exclude.indexOf(randomSku) === -1) skus.push(randomSku);
  }

  return skus;
}

async function getSkusToExclude(): Promise<(string | number)[]> {
  let excludeSkus: (string | number)[] = JSON.parse(
    await redisClient.get('excludeSkus'),
  );
  if (excludeSkus) {
    return excludeSkus;
  }

  const skusAggregate: SkusAggregate[] = await productModelV3.aggregate<SkusAggregate>(
    [
      { $match: { websiteCode: WebsiteCode.edukaan } },
      { $unwind: '$sku' },
      { $group: { _id: null, skus: { $push: '$sku' } } },
      { $project: { skus: true, _id: false } },
    ],
  );
  if (isEmpty(skusAggregate)) {
    ({ skus: excludeSkus } = { skus: [] });
  } else {
    ({ skus: excludeSkus } = skusAggregate[0]);
  }

  await redis.set(
    'excludeSkus',
    JSON.stringify(excludeSkus || []),
    'EX',
    ms('15m'),
  );

  return excludeSkus;
}
