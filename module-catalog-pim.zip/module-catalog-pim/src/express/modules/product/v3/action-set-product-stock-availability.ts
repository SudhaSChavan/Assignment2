import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { ERRORS } from '@src/types/errors';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { appConfig } from '@src/config/env';
import { FilterQuery } from 'mongoose';
import { EE } from '@src/config/event/emitter';
import { V1UpdateProductStatusMessageData } from './../queue-message/queue-message-v1-update-product-status';
import { logger } from '@core/util/logger';
import { logAuditEventForV3Products } from './../send-product-audit-event';
import {
  IProductDocumentV3,
  IProductModelV3,
  productModelV3,
} from '../model-product-v3';
import { map } from 'lodash';
import { ProductSyncEvent, ProductSyncEventType } from '../sync-hlper';
import { UpdateProductStatus } from '../types';

interface IReq extends IAppRequest {
  body: Paths.V3SetProductStockAvailabilityAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body: Paths.V3SetProductStockAvailabilityAction.Responses.$200,
  ) => this;
}

export const validateV3SetProductStockAvailability: BaseValidationType = [
  body('ids')
    .notEmpty()
    .withMessage(ERRORS.MISSING)
    .isArray({ min: 1, max: appConfig.product.listMaxLimit })
    .withMessage(ERRORS.INVALID),
  body('ids.*').notEmpty().isMongoId().withMessage(ERRORS.INVALID),
  body('isInStock')
    .notEmpty()
    .withMessage(ERRORS.MISSING)
    .isBoolean()
    .withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function setProductStockAvailabilityV3Action(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    supplierCompanyId,
    body: { ids: productIds, isInStock },
  } = req;

  const query: FilterQuery<IProductModelV3> = {
    $and: [
      {
        _id: { $in: productIds },
      },
      {
        supplierCompanyId: supplierCompanyId,
      },
    ],
  };

  const updateResult: any = await productModelV3.updateMany(query, {
    $set: {
      isInStock,
    },
  });

  await logAuditEventForV3Products(query, req, {
    name: 'isInStock',
    old: !isInStock,
    new: isInStock,
  });

  if (!isInStock) {
    const variantIds: string[] = await getProductIds(productIds);
    EE.emit(UpdateProductStatus.Success, {
      supplierCompanyId,
      productIds: variantIds,
    } as V1UpdateProductStatusMessageData).catch((error: Error): void => {
      logger.error(
        `Event ${UpdateProductStatus.Success} failed: ${error.stack}`,
      );
    });
  }

  EE.emit(ProductSyncEvent.Updated, {
    req,
    productIds,
    priority: 'highest',
  } as ProductSyncEventType).catch((error: Error): void => {
    logger.error(`Event ${ProductSyncEvent.Updated} failed: ${error.stack}`);
  });

  res.json({
    isUpdated: updateResult.nModified > 0,
  });
}

export async function getProductIds(productIds: string[]): Promise<string[]> {
  const products: IProductDocumentV3[] = await productModelV3
    .find({ _id: { $in: productIds } })
    .lean();
  return map(products, '_id');
}
