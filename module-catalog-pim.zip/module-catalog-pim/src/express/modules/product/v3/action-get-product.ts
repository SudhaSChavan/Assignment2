import { body } from 'express-validator';
import {
  BaseValidationType,
  HttpError,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { ERRORS } from '@src/types/errors';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { StatusCodes } from 'http-status-codes';
import { IProductModelV3, productModelV3 } from '../model-product-v3';
import { transformFinalResultForProducts } from './helpers';
type V3Product = Components.Schemas.V3Product;

interface IReq extends IAppRequest {
  body: Paths.V3GetProductAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3GetProductAction.Responses.$200) => this;
}

export const validateGetProductV3: BaseValidationType = [
  body('id').optional().isMongoId().withMessage(ERRORS.INVALID),
  body('sku').optional().isString(),
  reqValidationResult,
];

export async function getProductActionV3(req: IReq, res: IRes): Promise<void> {
  const {
    body: { id = null, sku },
  } = req;

  if (!id && !sku) {
    throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.MISSING);
  }

  const query: any = {};

  if (id) {
    query._id = id;
  }
  if (sku) {
    query.sku = sku;
  }

  const product: IProductModelV3 = await productModelV3
    .findOne(query, {})
    .lean();

  if (!product) {
    throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.NOT_FOUND);
  }

  const products: V3Product[] = await transformFinalResultForProducts(
    [product],
    true,
  );
  res.json(products[0]);
}
