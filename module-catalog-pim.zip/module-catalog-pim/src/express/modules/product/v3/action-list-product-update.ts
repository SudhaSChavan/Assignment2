import { body } from 'express-validator';
import { FilterQuery } from 'mongoose';
import isEmpty from 'lodash/isEmpty';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { ERRORS } from '@src/types/errors';
import { appConfig } from '@src/config/env';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { InternalReviewStatuses } from './../types';
import {
  IProductUpdateRequestModelV3,
  productUpdateRequestModelV3,
} from '../model-product-update-request-v3';

interface IReq extends IAppRequest {
  body: Paths.V3ListProductUpdateAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3ListProductUpdateAction.Responses.$200) => this;
}

export const validateListProductUpdateV3: BaseValidationType = [
  body('page').optional().isInt({ gt: 0 }).withMessage(ERRORS.INVALID),
  body('size')
    .optional()
    .isInt({ lt: appConfig.product.listMaxLimit, gt: 0 })
    .withMessage(ERRORS.INVALID),
  body('filter.productIds').optional().isArray(),
  body('filter.productIds.*').isMongoId().withMessage(ERRORS.INVALID),
  body('filter.status').optional().toArray(),
  body('filter.status.*')
    .isNumeric()
    .isIn(Object.values(InternalReviewStatuses))
    .withMessage('Invalid status code'),
  reqValidationResult,
];

export async function listProductUpdateActionV3(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    supplierCompanyId,
    body: {
      //
      page = 1,
      size = appConfig.product.listDefaultLimit,
      filter: { productIds = [], status = [] } = {},
    },
  } = req;

  // Subtracting one from the page because page counter is 0 based
  const recordsToSkip: number = (page - 1) * size;
  const query: FilterQuery<IProductUpdateRequestModelV3> = {
    supplierCompanyId,
    deletedAt: null,
    ...(isEmpty(productIds) ? {} : { productId: { $in: productIds } }),
    ...(status?.length ? { status: { $in: status } } : {}),
  };

  const totalRecords: number = await productUpdateRequestModelV3.countDocuments(
    query,
  );
  const updates: Components.Schemas.V3ProductUpdatesList = await productUpdateRequestModelV3
    .find(
      query,
      {
        _id: 1,
        productId: 1,
        supplierId: 1,
        supplierCompanyId: 1,
        status: 1,
        diff: 1,
        metadata: 1,
        rejectionReasons: 1,
        createdAt: 1,
        updatedAt: 1,
        websiteCode: 1,
      },
      {
        sort: {
          updatedAt: -1,
        },
        skip: recordsToSkip,
        limit: size,
      },
    )
    .lean();

  res.json({
    currentPage: page,
    totalPages: Math.ceil(totalRecords / size),
    totalRecords,
    size,
    updates,
  });
}
