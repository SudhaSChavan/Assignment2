import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { ERRORS } from '@src/types/errors';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { isEmpty } from 'lodash';
import { HttpError } from '@tradeling/web-js-utils';
import { StatusCodes } from 'http-status-codes';
import { V3ImmediateSubject } from '@tradeling/tradeling-sdk/catalog-index/queue/queue-message-v3-index-immediate-sync-product';
import { IProductModelV3, productModelV3 } from '../model-product-v3';
import { EE } from '@src/config/event/emitter';
import { ProductSyncEvent, ProductSyncEventType } from '../sync-hlper';
import { logger } from '@core/util/logger';

interface IReq extends IAppRequest {
  body: Paths.V3ImmediateSyncAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3ImmediateSyncAction.Responses.$200) => this;
}

export const validateImmediateSyncV3: BaseValidationType = [
  body('topic').optional().isString().withMessage(ERRORS.INVALID),
  body('productIds').notEmpty().isArray(),
  body('productIds.*').isMongoId().withMessage(ERRORS.INVALID),
  reqValidationResult,
];

/**
 *
 * @param req
 * @param res
 */
export async function immediateSyncActionV3(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    body: { topic, productIds },
  } = req;
  // set topic if it's exist -- else make it default topic
  const topicName: string = topic || V3ImmediateSubject;
  //check if is empty
  const products: IProductModelV3[] = await productModelV3
    .find({ _id: { $in: productIds } })
    .lean();
  if (isEmpty(products)) {
    throw new HttpError(StatusCodes.NOT_FOUND, ERRORS.NOT_FOUND);
  }
  // update default topic and updatedAt values
  await productModelV3.updateMany(
    { _id: { $in: req.body.productIds } },
    {
      $set: {
        topic: topicName,
        updatedAt: new Date().toISOString(),
      },
    },
  );

  EE.emit(ProductSyncEvent.Updated, {
    req,
    productIds,
    priority: 'highest',
  } as ProductSyncEventType).catch((error: Error): void => {
    logger.error(`Event ${ProductSyncEvent.Updated} failed: ${error.stack}`);
  });

  res.json({
    isSyncTriggered: true,
  });
}
