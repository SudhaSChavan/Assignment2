import { body } from 'express-validator';
import { map } from 'lodash';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { ERRORS } from '@src/types/errors';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { InternalReviewStatuses, ProductStates } from './../types';
import { FilterQuery } from 'mongoose';
import { logAuditEventForV3Products } from './../send-product-audit-event';
import { IProductModelV3, productModelV3 } from '../model-product-v3';
import { EE } from '@src/config/event/emitter';
import { ProductSyncEvent, ProductSyncEventType } from '../sync-hlper';
import { logger } from '@core/util/logger';

interface IReq extends IAppRequest {
  body: Paths.V3InternalUpdateProductStateAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3InternalUpdateProductStateAction.Responses.$200) => this;
}

export const validateV3InternalUpdateProductState: BaseValidationType = [
  body('supplierCompanyId').isMongoId().withMessage(ERRORS.INVALID),
  body('isVerified').isBoolean().withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function internalUpdateProductStateV3Action(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    body: { supplierCompanyId, isVerified },
  } = req;

  const productIds: string[] = [];
  if (isVerified) {
    productIds.concat(await makeProductsOnline(req, supplierCompanyId));
  } else {
    productIds.concat(await makeProductsOffline(req, supplierCompanyId));
  }

  EE.emit(ProductSyncEvent.Updated, {
    req,
    productIds,
    priority: 'highest',
  } as ProductSyncEventType).catch((error: Error): void => {
    logger.error(`Event ${ProductSyncEvent.Updated} failed: ${error.stack}`);
  });

  res.json({ isUpdated: true });
}

async function makeProductsOnline(
  req: IAppRequest,
  supplierCompanyId: string,
): Promise<string[]> {
  const conditions: FilterQuery<any> = {
    supplierCompanyId,
    internalReviewStatus: InternalReviewStatuses.Accepted,
    state: ProductStates.Offline,
    tags: 'verification-rejected',
  };
  await logAuditEventForV3Products(conditions, req, {
    name: 'state',
    old: ProductStates.Offline,
    new: ProductStates.Online,
  });
  await productModelV3.updateMany(conditions, {
    $pull: {
      // @ts-ignore
      tags: 'verification-rejected',
    },
    $set: {
      state: ProductStates.Online,
    },
  });

  const products: IProductModelV3[] = await productModelV3.find(conditions);
  return map(products, '_id');
}
// @ts-ignore
async function makeProductsOffline(
  req: IAppRequest,
  supplierCompanyId: string,
): Promise<string[]> {
  const conditions: FilterQuery<any> = {
    supplierCompanyId,
    state: ProductStates.Online,
  };
  await logAuditEventForV3Products(conditions, req, {
    name: 'state',
    old: ProductStates.Online,
    new: ProductStates.Offline,
  });

  await productModelV3.updateMany(conditions, {
    $push: {
      // @ts-ignore
      tags: 'verification-rejected',
    },
    $set: {
      state: ProductStates.Offline,
    },
  });
  const products: IProductModelV3[] = await productModelV3.find(conditions);
  return map(products, '_id');
}
