import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { ERRORS } from '@src/types/errors';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { InternalReviewStatuses } from './../types';
import { productBasicInformationValidatorV3 } from '@core/util/validatorsV3';
import { IProductModelV3, productModelV3 } from '../model-product-v3';
import { StatusCodes } from 'http-status-codes';
import { HttpError } from '@tradeling/web-js-utils';
import { map } from 'lodash';
import { productUpdateRequestModelV3 } from '../model-product-update-request-v3';
import { logger } from '@core/util/logger';
import { EE } from '@src/config/event/emitter';
import { ProductSyncEvent, ProductSyncEventType } from '../sync-hlper';
import { diffProductValues } from './action-update-product-v3';
import { getProductContent } from './action-get-product-content';
type V3ProductContent = Components.Schemas.V3ProductContent;

interface IReq extends IAppRequest {
  body: Paths.V3UpdateProductBasicInformationAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body: Paths.V3UpdateProductBasicInformationAction.Responses.$200,
  ) => this;
}

export const validateV3UpdateProductBasicInformation: BaseValidationType = [
  ...productBasicInformationValidatorV3,
  reqValidationResult,
];

export async function v3UpdateProductBasicInformationAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    supplierCompanyId,
    body: { parentSku },
    body,
  } = req;

  const products: IProductModelV3[] = await productModelV3
    .find({ parentSku: parentSku })
    .lean();

  // if product not found ...
  if (!products.length) {
    throw new HttpError(StatusCodes.NOT_FOUND, ERRORS.NOT_FOUND);
  }

  // this working fine . but not sure if it's the best way to do it
  await updateProductRequest(
    products.filter((product) => {
      return product?.internalReviewStatus == InternalReviewStatuses.Accepted;
    }),
    body,
    supplierCompanyId,
  );

  await updateBaseProduct(
    products.filter((product) => {
      return product?.internalReviewStatus !== InternalReviewStatuses.Accepted;
    }),
    body,
    supplierCompanyId,
  );

  // emit event for sync model
  EE.emit(ProductSyncEvent.Updated, {
    req,
    productIds: map(products, '_id'),
    priority: 'highest',
  } as ProductSyncEventType).catch((error: Error): void => {
    logger.error(`Event ${ProductSyncEvent.Updated} failed: ${error.stack}`);
  });

  const productContent: V3ProductContent = await getProductContent(
    parentSku,
    supplierCompanyId,
  );

  res.json(productContent);
}

async function updateBaseProduct(
  products: IProductModelV3[],
  body: any,
  supplierCompanyId: string,
) {
  if (!products.length) {
    return;
  }
  const diff: Record<string, any> = diffProductValues(body, products[0]);
  const fields: string[] = Object.keys(diff);
  console.log(diff);
  await productModelV3.updateMany(
    {
      _id: { $in: map(products, '_id') },
    },
    {
      $set: {
        ...fields.reduce((obj: any, field: string) => {
          obj[field] = (diff as any)[field].newValue;
          return obj;
        }, {}),
        'attributes.brand': body.brand,
        internalReviewStatus: InternalReviewStatuses.Pending,
      },
    },
    {},
  );
}

async function updateProductRequest(
  products: IProductModelV3[],
  body: any,
  supplierCompanyId: string,
) {
  if (!products.length) {
    return;
  }
  const bodyWithAttributes: any = {
    ...body,
    attributes: {
      ...products[0].attributes,
      brand: body?.brand,
    },
  };
  const diff: Record<string, any> = diffProductValues(
    bodyWithAttributes,
    products[0],
  );
  const firstProduct: IProductModelV3 = products[0];
  if (Object.keys(diff).length === 0) {
    return;
  }
  const bulkOperation: any = products.map((product) => {
    return {
      updateOne: {
        filter: {
          productId: product?._id,
          supplierCompanyId,
          status: { $ne: InternalReviewStatuses.Accepted },
        },
        update: {
          $set: {
            diff: diff as any,
            rejectionReasons: [],
            productId: product?._id,
            supplierCompanyId,
            status: InternalReviewStatuses.Pending,
            // websiteCode: product?.websiteCode,
            metadata: {
              createdAt: firstProduct.createdAt,
              name: firstProduct?.name || firstProduct.name,
              sku: firstProduct.sku,
            },
          },
        },
        upsert: true,
      },
    };
  });

  await productUpdateRequestModelV3.bulkWrite(bulkOperation);
}
