import {
  BaseValidationType,
  HttpError,
  reqValidationResult,
  StoreType,
} from '@tradeling/web-js-utils/dist';
import { body } from 'express-validator';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { moveFilesToSupplierPath } from '../../media/helpers';
import { formatPackagingInfo } from '../../upload/helpers';
import { productRfqValidatorsV3 } from '@core/util/validatorsV3';
import { IProductModelV3, productModelV3 } from '../model-product-v3';
import { UserIdentifier } from '@src/types/command';
import { offerModelV3 } from '../../offer/model-offers-v3';
import { logger } from '@core/util/logger';
import { EE } from '@src/config/event/emitter';
import { getMarketCode, getMarketLabel } from '../../upload/v3/helpers';
import V3Offer = Components.Schemas.V3Offer;
import { ProductSyncEvent, ProductSyncEventType } from '../sync-hlper';
import { ProductCreateEvent, ProductCreateEventType } from '../types';

interface IReq extends IAppRequest {
  body: Paths.V3CreateRfqProductAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3CreateRfqProductAction.Responses.$200) => this;
}

export const validateCreateRfqProductV3: BaseValidationType = [
  ...productRfqValidatorsV3,
  body('packaging.unit') //
    .notEmpty()
    .isString(),
  body('packaging.size') //
    .notEmpty()
    .isString(),
  body('packaging.unitsPerCarton') //
    .notEmpty()
    .isString(),
  reqValidationResult,
];

export async function createProductRfqActionV3(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { userId, supplierId, supplierCompanyId, store } = req;

  const { body } = req;

  const { offers } = body;

  if (!offers) {
    throw new HttpError(
      400,
      'Create product should receive at least one offer',
    );
  }

  // Get all the images from the long description
  // Find the items that were served from the temporary URL
  // Move those create entries for those in the media collection
  // Update the URLs setting them to be public URLs
  if (body?.longDescription?.en) {
    const {
      media: editorMedia,
      description: updatedDescription,
    } = await moveFilesToSupplierPath(
      { userId, supplierId, supplierCompanyId },
      body.longDescription.en,
    );

    body.longDescription.en = updatedDescription;
    body.descriptionMedia = editorMedia;
  }

  // save base product
  const baseProduct: any = await saveBaseProduct(
    body,
    supplierCompanyId,
    store,
  );
  await createProductOffers(baseProduct, offers, {
    userId,
    supplierId,
    supplierCompanyId,
  });
  EE.emit(ProductCreateEvent.Success, {
    req,
    productIds: [baseProduct._id],
  } as ProductCreateEventType).catch((error: Error): void => {
    logger.error(`Event ${ProductCreateEvent.Success} failed: ${error.stack}`);
  });

  EE.emit(ProductSyncEvent.Created, {
    req,
    productIds: [baseProduct._id],
    priority: 'highest',
  } as ProductSyncEventType).catch((error: Error): void => {
    logger.error(`Event ${ProductSyncEvent.Updated} failed: ${error.stack}`);
  });

  res.json(baseProduct);
}

async function saveBaseProduct(
  body: any,
  supplierCompanyId: string,
  store: StoreType,
): Promise<IProductModelV3> {
  const { parentSku, sku } = body;
  return await productModelV3.create({
    ...body,
    type: 'rfq',
    parentSku: parentSku || sku,
    packagingFormat: formatPackagingInfo(body?.unit, body?.packaging),
    supplierCompanyId,
    lastUploadDate: new Date(),
    uploadCount: 1,
    hasVariants: body.variantValues?.length > 0,
    storeKeyId: store?.storeKeyId,
    websiteCode: store?.website?.websiteCode,
    storeCode: store?.storeCode,
  });
}

/**
 *
 * @param product
 * @param offers
 * @param userIdentifier
 */
async function createProductOffers(
  product: any,
  offers: V3Offer[],
  userIdentifier: UserIdentifier,
): Promise<void> {
  for (let i: number = 0; i < offers.length; i++) {
    const market: any = offers[i]?.market;
    const currency: string = market?.currency;
    market.code = getMarketCode(currency);
    market.label = getMarketLabel(currency);
    await offerModelV3.create({
      productId: product._id,
      isActive: true,
      isDefault: true,
      market,
      version: 2,
      delivery: offers[i]?.delivery,
      subSupplierCompanies: offers[i].subSupplierCompanies,
      ...userIdentifier,
    });
  }
}
