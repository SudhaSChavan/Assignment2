import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { InternalReviewStatuses, ProductStates } from './../types';
import { productModelV3 } from '../model-product-v3';

interface IReq extends IAppRequest {
  body: Paths.V3SellerProductsStatsAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3SellerProductsStatsAction.Responses.$200) => this;
}

export const validateV3SellerProductsStats: BaseValidationType = [
  reqValidationResult,
];

export async function sellerProductsStatsV3Action(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { supplierCompanyId } = req;
  const query: Record<string, any> = { supplierCompanyId, deletedAt: null };
  const totalRecords: number = await productModelV3
    .find(query)
    .countDocuments();
  const totalApproved: number = await productModelV3
    .find({ ...query, internalReviewStatus: InternalReviewStatuses.Accepted })
    .countDocuments();
  const totalPending: number = await productModelV3
    .find({ ...query, internalReviewStatus: InternalReviewStatuses.Pending })
    .countDocuments();
  const totalRejected: number = totalRecords - (totalApproved + totalPending);
  const liveProducts: number = await productModelV3
    .find({ ...query, state: ProductStates.Online })
    .countDocuments();
  const outOfStock: number = await productModelV3
    .find({ ...query, isInStock: false })
    .countDocuments();

  res.json({
    live: liveProducts,
    outOfStock: outOfStock ?? 0,
    totalRecords,
    totalApproved,
    totalPending,
    totalRejected,
  });
}
