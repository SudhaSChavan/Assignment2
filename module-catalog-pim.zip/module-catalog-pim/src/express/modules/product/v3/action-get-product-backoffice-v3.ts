import { body } from 'express-validator';
import {
  BaseValidationType,
  getInternalApiSecret,
  HttpError,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { ERRORS } from '@src/types/errors';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { StatusCodes } from 'http-status-codes';
import { keyBy, map, uniqBy } from 'lodash';
import { V1InternalListUsersAction } from '@tradeling/tradeling-sdk/account/v1-internal-list-users-action';
import { appConfig } from '@src/config/env';
import { IProductModelV3, productModelV3 } from '../model-product-v3';
import { IOfferModelV3, offerModelV3 } from '../../offer/model-offers-v3';
import { ProductRepositoryV3 } from './repositories/product-repository.v3';
import { OfferRepositoryV3 } from './repositories/offer-repository.v3';

interface IReq extends IAppRequest {
  body: Paths.V3GetProductBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3GetProductBackofficeAction.Responses.$200) => this;
}

export const validateGetProductBackofficeV3: BaseValidationType = [
  //
  body('id').optional().isMongoId().withMessage(ERRORS.INVALID),
  body('sku').optional().isString(),
  reqValidationResult,
];

const productRepository: any = new ProductRepositoryV3(productModelV3);
const offerRepository: any = new OfferRepositoryV3(offerModelV3);
export async function getProductBackofficeActionV3(
  req: IReq,
  res: IRes,
): Promise<IRes> {
  const {
    body: { id = null, sku },
  } = req;

  if (!id && !sku) {
    throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.MISSING);
  }

  const query: any = {};

  if (id) {
    query._id = id;
  }
  if (sku) {
    query.sku = sku;
  }

  const product: IProductModelV3 = await productRepository.getOneByQuery(
    query,
    {},
  );

  if (!product) {
    throw new HttpError(StatusCodes.NOT_FOUND, ERRORS.NOT_FOUND);
  }

  return res.json(await prepareProductDetails(product));
}

async function prepareProductDetails(product: IProductModelV3): Promise<any> {
  const offers: IOfferModelV3[] = await offerRepository.getActiveByProductIds([
    product._id,
  ]);
  const supplierIds: string[] = map(offers, 'supplierId').filter((id) =>
    Boolean(id),
  );
  const subSupplierCompanyIds: string[] = map(
    map(offers, 'subSupplierCompanies').flat(1),
    'subSupplierCompanyId',
  ).filter((id) => Boolean(id));
  const suppliers: User[] = await getSuppliers(
    supplierIds,
    subSupplierCompanyIds,
  );
  const suppliersObj: Record<string, User> = keyBy(suppliers, '_id');

  const supplierCompaniesObj: Record<string, User> = keyBy(
    suppliersObj,
    'supplierCompanyId',
  );

  const offersWithSupplier: Components.Schemas.V3Offer[] = offers.map(
    (offer) => {
      return {
        ...offer,
        metadata: {
          userDetail: suppliersObj[offer.supplierId],
        },
        subSupplierCompanies: offer.subSupplierCompanies?.map(
          (subSupplierCompany) => ({
            ...subSupplierCompany,
            companyName:
              supplierCompaniesObj[subSupplierCompany.subSupplierCompanyId]
                ?.companyName,
          }),
        ),
      };
    },
  );

  return {
    ...product,
    offers: offersWithSupplier,
  };
}

type User = Account.Components.Schemas.V1InternalListUsersResponse['data'][0];

async function getUserListBySupplierIds(
  supplierIds: string[],
): Promise<User[]> {
  if (supplierIds.length == 0) return [];
  const { data } = await V1InternalListUsersAction(
    { filter: { ids: supplierIds }, pageSize: supplierIds.length },
    {
      headers: {
        'x-is-internal-request': '1',
        'x-t-secret': getInternalApiSecret({
          to: 'module-account',
          from: appConfig.name,
        }),
      },
    },
  );
  return data.data;
}

async function getUserListBySupplierCompanyIds(
  companyIds: string[],
): Promise<User[]> {
  if (companyIds.length == 0) return [];
  const { data } = await V1InternalListUsersAction(
    { filter: { supplierCompanyIds: companyIds }, pageSize: companyIds.length },
    {
      headers: {
        'x-is-internal-request': '1',
        'x-t-secret': getInternalApiSecret({
          to: 'module-account',
          from: appConfig.name,
        }),
      },
    },
  );
  return data.data;
}

async function getSuppliers(
  supplierIds: string[],
  supplierCompanyIds: string[],
): Promise<User[]> {
  const usersBySupplierIds: User[] = await getUserListBySupplierIds(
    supplierIds,
  );
  const usersByCompanyIds: User[] = await getUserListBySupplierCompanyIds(
    supplierCompanyIds,
  );
  return uniqBy(
    [...usersBySupplierIds, ...usersByCompanyIds],
    (user) => user._id,
  );
}
