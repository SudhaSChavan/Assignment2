import { EE } from '@src/config/event/emitter';
import { listenerProductPendingReviewEmail } from './listener-product-pending-review-email';
import { setSupplierHasProducts } from './helpers';
import { listenerUpdateProductStatus } from './listener-update-product-status';
import { listenerUpdateProductInternalReviewStatus } from './listener-update-product-internal-review-status';
import {
  ProductCreateEvent,
  ProductCreateEventType,
  UpdateInternalReviewStatusEvent,
  UpdateInternalReviewStatusEventType,
  UpdateProductStatus,
} from './types';
import {
  fireAuditEventEvent,
  sendProductAuditEvent,
} from './send-product-audit-event';
import { createSyncEvent, ProductSyncEvent } from './sync-hlper';

EE.on(
  ProductCreateEvent.Success,
  async ({ req, productIds }: ProductCreateEventType): Promise<void> => {
    await Promise.all([
      listenerProductPendingReviewEmail({ req, productIds }),
      setSupplierHasProducts(req.headers),
    ]);
  },
);
EE.on(UpdateProductStatus.Success, listenerUpdateProductStatus);
EE.on(
  UpdateInternalReviewStatusEvent.Success,
  async (params: UpdateInternalReviewStatusEventType): Promise<void> => {
    await Promise.all([listenerUpdateProductInternalReviewStatus(params)]);
  },
);

EE.on(fireAuditEventEvent.product, sendProductAuditEvent);
EE.on(fireAuditEventEvent.variant, sendProductAuditEvent);

// product events to sync product data ...
EE.on(ProductSyncEvent.Created, createSyncEvent);
EE.on(ProductSyncEvent.Updated, createSyncEvent);
EE.on(ProductSyncEvent.BulkUpload, createSyncEvent);
EE.on(ProductSyncEvent.PartialUpdated, createSyncEvent);
