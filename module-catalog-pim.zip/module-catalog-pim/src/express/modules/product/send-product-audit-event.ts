import { makeProductsOnlineEventType } from './types';
import {
  DatabaseType,
  Event,
  V1AuditEventMessageData,
} from '@tradeling/emit-audit';
import { appConfig, isAuditEnabled } from '@src/config/env';
import { sendAuditEvent } from './helpers';
import { logger } from '@core/util/logger';
import { FilterQuery } from 'mongoose';
import { EE } from '@src/config/event/emitter';
import { isEmpty, map } from 'lodash';
import { IAppRequest } from '@src/types/app-request';
import { IBaseAppUser } from '@tradeling/web-js-utils';
import { EntityType } from '@tradeling/emit-audit/dist/common-audit/src';
import { IProductModelV3, productModelV3 } from './model-product-v3';

export enum fireAuditEventEvent {
  product = 'fire.audit.event.product',
  variant = 'fire.audit.event.variant',
}

export type auditFields = {
  name: string;
  old: any;
  new: any;
};

export function sendProductAuditEvent(
  params: makeProductsOnlineEventType,
): void {
  if (!isAuditEnabled) {
    logger.info(`listener audit event is disabled`);
    return;
  }

  const { productIds, actionType, description, data, req, entityType } = params;

  const userJwtDecoded: IBaseAppUser = req?.userJwtDecoded as IBaseAppUser;

  const userName: string =
    userJwtDecoded?.username ||
    `${userJwtDecoded?.firstName} ${userJwtDecoded?.lastName}` ||
    '';
  const isLoggedInAs: boolean = userJwtDecoded?.isLoggedInAs;
  const impersonatingEmail: string =
    userJwtDecoded?.metadata?.loggedInAsDetail?.requesterEmail || '';
  const loginDetails: string = isLoggedInAs
    ? `impersonating user ${userName} from ${impersonatingEmail} `
    : userName;
  const descriptiveMessage: string = `${
    req?.url || description || 'undefined action'
  } Fired`;
  productIds.map((product) => {
    const params: V1AuditEventMessageData = {
      entityType,
      username: loginDetails,
      description: descriptiveMessage,
      userId: userJwtDecoded?._id || null,
      dataSource: 'module-catalog-pim',
      dbActionType: actionType,
      databaseType: DatabaseType.MongoDB,
      time: Date.now(),
      Affected: [
        {
          key: product,
          fields: Array.isArray(data) ? data : [data],
        },
      ],
      eventSource: {
        module: appConfig.name,
        host: 'external-host',
      },
    };
    sendAuditEvent(params, descriptiveMessage);
  });
}

export async function logAuditEventForV3Products(
  conditions: FilterQuery<any>,
  req: IAppRequest,
  fields: any = null,
  description = '',
): Promise<void> {
  if (isEmpty(fields)) {
    return;
  }
  const products: IProductModelV3[] = await productModelV3
    .find(conditions, {
      _id: 1,
    })
    .lean();

  EE.emit(fireAuditEventEvent.variant, {
    actionType: Event.Updated,
    productIds: map(products, '_id'),
    req,
    description,
    data: {
      ...fields,
    },
    entityType: EntityType.Product,
  } as makeProductsOnlineEventType).catch((error: Error): void => {
    logger.error(`Event ${fireAuditEventEvent.variant} failed: ${error.stack}`);
  });
}
