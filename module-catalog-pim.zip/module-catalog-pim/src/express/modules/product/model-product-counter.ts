import { Document, Model, model, Schema } from 'mongoose';

export interface IProductCounterDocument {
  counterKey: string;
  counterValue: number;
}

export interface IProductCounterModel
  extends IProductCounterDocument,
    Document {}

const productCounterSchema: Schema = new Schema(
  {
    counterKey: {
      type: String,
      required: true,
    },
    counterValue: {
      type: Number,
      required: true,
    },
  },
  {
    versionKey: false,
    minimize: false,
    timestamps: false,
    collection: 'product_counter',
  },
);

productCounterSchema.index({ counterKey: -1 });

export const modelProductCounter: Model<IProductCounterModel> = model<IProductCounterModel>(
  'ProductCounter',
  productCounterSchema,
);
