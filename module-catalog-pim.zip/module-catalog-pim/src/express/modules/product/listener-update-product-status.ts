import { UpdateProductStatusListenerType } from './types';
import { publishToQueue } from '@src/config/event/kafka';
import { logger } from '@core/util/logger';
import {
  V1UpdateProductStatusMessageData,
  V1UpdateProductStatusSubject,
} from './queue-message/queue-message-v1-update-product-status';

export async function listenerUpdateProductStatus(
  params: UpdateProductStatusListenerType,
) {
  const { supplierCompanyId, productIds } = params;
  publishToQueue({
    topic: V1UpdateProductStatusSubject,
    data: {
      supplierCompanyId,
      productIds,
    } as V1UpdateProductStatusMessageData,
  }).catch((error: Error) => {
    logger.error(`Failed to publish message ${error.message}`);
    return false;
  });
}
