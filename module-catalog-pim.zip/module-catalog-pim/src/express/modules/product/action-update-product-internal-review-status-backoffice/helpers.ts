import { V1ListCompanyProfileBackofficeAction } from '@tradeling/tradeling-sdk/seller-center/v1-list-company-profile-backoffice-action';
import { IAppHeaders } from '@src/types/app-request';
import { V1InternalListUsersAction } from '@tradeling/tradeling-sdk/account/v1-internal-list-users-action';
import { getInternalApiSecret } from '@tradeling/web-js-utils';
import { appConfig } from '@src/config/env';
import { V1InternalListSupplierCompanyAction } from '@tradeling/tradeling-sdk/account/v1-internal-list-supplier-company-action';
import { V1InternalUpdateSupplierHasApprovedProductAction } from '@tradeling/tradeling-sdk/account/v1-internal-update-supplier-has-approved-product-action';

export type CompanyProfile = SellerCenter.Components.Schemas.CompanyProfile;

export async function getSupplierCompanyProfilesBySupplierIds(
  supplierIds: string[],
  headers: IAppHeaders,
): Promise<CompanyProfile[]> {
  if (supplierIds.length === 0) {
    return [];
  }
  const { data } = await V1ListCompanyProfileBackofficeAction(
    { filter: { supplierIds: supplierIds }, limit: supplierIds.length },
    { headers },
  );
  const supplierCompanies: CompanyProfile[] = data as CompanyProfile[];
  return supplierCompanies;
}

export type User = Account.Components.Schemas.V1InternalListUsersResponse['data'][0] & {
  isVerified?: boolean;
};

export async function getUserById(id: string): Promise<User> {
  const { data } = await V1InternalListUsersAction(
    { filter: { ids: [id] }, pageSize: 1 },
    {
      headers: {
        'x-is-internal-request': '1',
        'x-t-secret': getInternalApiSecret({
          to: 'module-account',
          from: appConfig.name,
        }),
      },
    },
  );
  return data.data[0];
}

export type SupplierCompany = Account.Components.Schemas.V1SupplierCompany;

export async function getSupplierByCompanyId(
  id: string,
): Promise<SupplierCompany> {
  const { data } = await V1InternalListSupplierCompanyAction(
    { filter: { ids: [id] } },
    {
      headers: {
        'x-is-internal-request': '1',
        'x-t-secret': getInternalApiSecret({
          to: 'module-account',
          from: appConfig.name,
        }),
      },
    },
  );
  return data.items[0];
}

export async function getSupplierByCompanyIds(
  ids: string[],
): Promise<SupplierCompany[]> {
  const { data } = await V1InternalListSupplierCompanyAction(
    { filter: { ids: ids } },
    {
      headers: {
        'x-is-internal-request': '1',
        'x-t-secret': getInternalApiSecret({
          to: 'module-account',
          from: appConfig.name,
        }),
      },
    },
  );
  return data.items;
}

export async function updateSupplierHasApprovedProducts(
  body: Account.Paths.V1InternalUpdateSupplierHasApprovedProductAction.RequestBody,
): Promise<void> {
  await V1InternalUpdateSupplierHasApprovedProductAction(body, {
    headers: {
      'x-is-internal-request': '1',
      'x-t-secret': getInternalApiSecret({
        to: 'module-account',
        from: appConfig.name,
      }),
    },
  });
}
