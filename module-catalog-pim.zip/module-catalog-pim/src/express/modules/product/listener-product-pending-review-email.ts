import { publishToQueue } from '@src/config/event/kafka';
import {
  V1ProductPendingReviewEmailQueueMessageData,
  V1ProductPendingReviewEmailQueueSubject,
} from './queue-message/queue-message-v1-product-pending-review-email';
import { ProductPendingReviewListenerType } from './types';
import { logger } from '@core/util/logger';

export async function listenerProductPendingReviewEmail(
  params: ProductPendingReviewListenerType,
): Promise<void> {
  const { req } = params;
  const { runtimeProto, runtimeTLD, supplierId } = req;
  publishToQueue({
    topic: V1ProductPendingReviewEmailQueueSubject,
    data: {
      userId: supplierId,
      sellerProductsPageLink: `${runtimeProto.replace(
        '://',
        '',
      )}://catalog-pim.${runtimeTLD}/@@lang@@/product`,
    } as V1ProductPendingReviewEmailQueueMessageData,
  }).catch((error: Error) => {
    logger.error(`Failed to publish message ${error.message}`);
    return false;
  });
}
