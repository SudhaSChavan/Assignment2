import { subscriberUpdateProductInternalReviewStatusV3 } from './v3/subscribers/subscriber-update-product-internal-review-status-v3';
import { subscriberUpdateSupplierCompanyStatusV3 } from './v3/subscribers/subscriber-update-supplier-company-status-v3';
import { subscriberUpdateStockV3 } from './v3/subscribers/subscriber-update-wms-stock-v3';
import { subscriberRatingChangedV3 } from './v3/subscribers/subscriber-product-rating-update-v3';
import { subscriberUpdateWmsProductDataV3 } from './v3/subscribers/subscribe-update-wms-product-data-v3';

// will be enabled after migrations to v3
subscriberUpdateProductInternalReviewStatusV3();
subscriberUpdateSupplierCompanyStatusV3();
subscriberUpdateStockV3();
subscriberRatingChangedV3();
subscriberUpdateWmsProductDataV3();
