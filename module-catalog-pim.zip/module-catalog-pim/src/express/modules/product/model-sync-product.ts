import mongoose from 'mongoose';
import { logger } from '@core/util/logger';
import { SyncPriority } from './sync-hlper';

export interface IProductSyncDocument {
  executeAfter?: number;
  productId: string;
  status?: string;
  priority: SyncPriority;
  requestFrom?: string;
}

export interface IProductSyncModel
  extends IProductSyncDocument,
    mongoose.Document {
  _id: string;
}

const productSyncSchema: mongoose.Schema = new mongoose.Schema(
  {
    priority: {
      type: String,
    },
    status: {
      type: String,
      // new - in-progress - synced - failed
      default: 'new',
    },
    executeAfter: {
      type: Number,
    },
    productId: {
      type: String,
    },
    requestFrom: {
      type: String,
    },
  },
  {
    versionKey: false,
    timestamps: true,
    collection: 'product-sync',
  },
);

productSyncSchema.index({ productIds: -1 });
export const productSyncModel: mongoose.Model<IProductSyncModel> = mongoose.model<IProductSyncModel>(
  'Product-sync',
  productSyncSchema,
);

productSyncModel.on('index', (err) => {
  if (err) {
    logger.error(err);
  }
});
