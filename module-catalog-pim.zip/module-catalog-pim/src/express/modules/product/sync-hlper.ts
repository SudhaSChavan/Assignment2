import { IBaseAppUser } from '@tradeling/web-js-utils';
import { IAppRequest } from '@src/types/app-request';
import { productSyncModel } from './model-sync-product';
import { ProductSyncRequestFrom } from './types';

export type SyncPriority = 'lowest' | 'low' | 'normal' | 'high' | 'highest';

export enum ProductSyncEvent {
  Created = 'event.product.success',
  Updated = 'event.product.success',
  PartialUpdated = 'event.product.partial-updated',
  BulkUpload = 'event.product.bulk-updated',
}

export type ProductSyncEventType = {
  req?: IAppRequest;
  productIds: string[];
  priority: SyncPriority;
  requestFrom?: string;
};

export async function createSyncEvent(params: ProductSyncEventType) {
  const { req, productIds, priority, requestFrom } = params;
  const userJwtDecoded: IBaseAppUser = req?.userJwtDecoded as IBaseAppUser;
  // const supplierId: string = userJwtDecoded?.metadata?.supplierId || '';

  // now we have new document created
  // need to build the logic of how to execute this document
  // chunk productIds into groups of 50
  // continue tomorrow ...))
  // const productIdsChunks: string[][] = chunk(productIds, 50);

  // set time based on product size
  // for each chunk, make a request to the server
  const productsSync: any[] = [];

  //To track initiated request by
  const requestFromTransformed: string =
    requestFrom ?? ProductSyncRequestFrom.Default;
  for (const productId of productIds) {
    productsSync.push({
      executeAfter: getExecuteTimeBasedOnPriority(priority),
      productId,
      priority,
      requestFrom: requestFromTransformed,
    });
  }
  await productSyncModel.insertMany(productsSync);
}

export function getExecuteTimeBasedOnPriority(priority: string) {
  switch (priority) {
    case 'highest':
      return getRandomSeconds(3, 8);
    case 'high':
      return getRandomSeconds(9, 15);
    case 'normal':
      return getRandomSeconds(15, 25);
    case 'low':
      return getRandomSeconds(27, 100);
    case 'lowest':
      return getRandomSeconds(100, 200);
    default:
      return 10;
  }
}

export function getRandomSeconds(min: number, max: number): number {
  return Math.floor(Math.random() * (1 + max - min)) + min;
}
