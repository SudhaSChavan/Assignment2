import { IMediaModel } from '../media/model-media';
import { ValidFileType } from '@core/util/file';
import { IAppRequest } from '@src/types/app-request';
import { EntityType } from '@tradeling/emit-audit/dist/common-audit/src/types/entityType';
// eslint-disable-next-line
export const InternalReviewStatuses = {
  Pending: 100,
  Accepted: 101,
  Rejected: 102,
  Dismissed: 103,
} as const;

export type InternalReviewStatusType = typeof InternalReviewStatuses[keyof typeof InternalReviewStatuses];

export enum ProductStates {
  Online = 'online',
  Offline = 'offline',
}

export type ProductCountType = {
  _id: string;
  totalProducts: number;
  totalOnlineProducts: number;
  getProductCount(supplierCompanyIds: string[]): Promise<ProductCountType[]>;
};

export enum Template {
  ProductTemplate = 'product',
  OfferTemplate = 'offer',
}

export enum CommitUploadEvent {
  Success = 'product.commitUpload.success',
}

export type CommitUploadEventType = {
  req: IAppRequest;
  uploadId: string;
  uploadType: string;
  productIds: string[];
};

export enum UpdateProductStatus {
  Success = 'product.UpdateProductStatus.success',
}

export enum ProductCreateEvent {
  Success = 'product.create.success',
}

export type ProductCreateEventType = {
  req: IAppRequest;
  productIds: string[];
};

export enum UpdateInternalReviewStatusEvent {
  Success = 'internalReview.update.success',
}

export enum Project {
  Name = 'Tradeling',
}

export type DraftCell = {
  label: string;
  value: string;
  error?: string;
  field: string;
};

export enum UploadType {
  Product = 'product',
  Media = 'media',
}

export enum DraftState {
  Draft = 'draft',
  Valid = 'valid',
  Invalid = 'invalid',
  Published = 'published',
}

export enum UploadRowType {
  New = 'new',
  Existing = 'existing',
}

export enum productVariantStrategy {
  FEFO = 'FEFO', //First expired first out
  FIFO = 'FIFO', //First in first out
  LIFO = 'LIFO', //Last in first out
}

export type DraftStateType =
  | DraftState.Draft
  | DraftState.Valid
  | DraftState.Invalid
  | DraftState.Published;

export type ProductMediaType = {
  id: string;
  type: ValidFileType;
  sort?: number;
  title?: string;
};

export const paymentOptions: { code: string; label: string }[] = [
  {
    code: 'bank_transfer',
    label: 'Bank Transfer',
  },
  {
    code: 'da',
    label: 'D/A - Documents against Acceptance',
  },
  {
    code: 'dp',
    label: 'DP - Documents against Payment',
  },
  {
    code: 'lc',
    label: 'L/C - Credit Letter',
  },
  {
    code: 'money_gram',
    label: 'MoneyGram',
  },
  {
    code: 'western_union',
    label: 'Western Union',
  },
  {
    code: 'other',
    label: 'Other',
  },
];

export type MarketType = {
  code: string;
  label: string;
  defaultCurrency: string;
};

export type ConfigurationAttributeType = {
  code: string;
  label?: string;
  values: string[];
};

interface IMarketsMap {
  [code: string]: MarketType;
}

export type LeanMediaType = Pick<IMediaModel, '_id' | 'skuGroup'>;

export type ProductPendingReviewListenerType = {
  productIds: string[];
  req: IAppRequest;
};

export type UpdateProductStatusListenerType = {
  productIds: string[];
  supplierCompanyId: string;
};

export type UpdateInternalReviewStatusEventType = {
  productIds: string[];
  status: InternalReviewStatusType;
  req: IAppRequest;
};

export type SkusAggregate = {
  skus: (string | number)[];
};

export type makeProductsOnlineEventType = {
  actionType: number;
  req?: IAppRequest;
  entityType?: EntityType;
  description?: string;
  productIds: string[];
  data: {
    name: string;
    old: string;
    new: string;
  };
};

export enum ProductSyncRequestFrom {
  BulkUpload = 'bulk-upload',
  SingleSave = 'single-create-or-update',
  Boost = 'product-boost',
  CLi = 'cli-command',
  Default = 'sync_product',
}
