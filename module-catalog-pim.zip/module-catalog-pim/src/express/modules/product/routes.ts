import { Router } from 'express';
import { Router as IRouter } from 'express-serve-static-core';
import {
  authenticateInternalMw,
  isAuthenticatedMw,
} from '@tradeling/web-js-utils';

import './listeners';
import './subscriber';
import { catchAsyncErrors } from '@core/util/router';
import { backOfficeUserMw } from '@src/config/middleware/is-backoffice-user';
import {
  reassignMediaBySkuV3Action,
  validateReassignMediaBySkuV3,
} from './v3/action-reassign-media-by-sku';
import {
  createProductActionV3,
  validateCreateProductV3,
} from './v3/action-create-product';
import {
  getProductActionV3,
  validateGetProductV3,
} from './v3/action-get-product';
import {
  v3UpdateProductAction,
  validateV3UpdateProduct,
} from './v3/action-update-product-v3';
import {
  v3UpdateProductInternalReviewStatusBackofficeAction,
  v3ValidateUpdateProductInternalReviewStatusBackoffice,
} from './v3/action-update-product-internal-review-status-backoffice';
import {
  v3UpdateOffertAction,
  validateV3UpdateOffer,
} from './v3/action-update-offer-v3';
import {
  setProductStockAvailabilityV3Action,
  validateV3SetProductStockAvailability,
} from './v3/action-set-product-stock-availability';
import {
  v3SetProductStateAction,
  validateV3SetProductState,
} from './v3/action-set-product-state';
import {
  actionListVariantsV3,
  validateListVariantsActionV3,
} from './v3/action-list-variants-v3';
import {
  listProductBackofficeActionV3,
  validateListProductV3Backoffice,
} from './v3/action-list-product-v3-backoffice';
import {
  getProductUpdateActionV3,
  validateGetProductUpdateV3,
} from './v3/action-get-product-update-v3';
import {
  createProductRfqActionV3,
  validateCreateRfqProductV3,
} from './v3/action-create-rfq-product';
import {
  skuGenerationBackofficeV3Action,
  validateV3SkuGenerationBackoffice,
} from './v3/action-sku-generation-backoffice';
import {
  internalUpdateProductStateV3Action,
  validateV3InternalUpdateProductState,
} from './v3/action-internal-update-product-state';
import {
  sellerProductsStatsV3Action,
  validateV3SellerProductsStats,
} from './v3/action-seller-products-stats';
import {
  actionInternalListVariantsV3,
  validateInternalListVariantsByIdV3,
} from './v3/action-internal-list-variants-v3';
import {
  getProductCountActionV3,
  validateInternalGetProductCountV3,
} from './v3/action-internal-get-product-count-v3';
import {
  exportProductScoreBackofficeActionV3,
  validateExportProductScoreBackofficeV3,
} from './v3/action-export-product-score-backoffice-v3';
import {
  listProductActionV3,
  validateListProductV3,
} from './v3/action-list-product-v3';
import {
  actionValidateProductsV3,
  validateInternalVariantsActionV3,
} from './v3/action-v3-internal-verify-products';
import {
  exportRejectedProductsActionV3,
  validateExportRejectedProductsV3,
} from './v3/action-export-rejected-products-v3';
import {
  getProductContentActionV3,
  validateGetProductContentV3,
} from './v3/action-get-product-content';
import {
  updateProductCommitReviewStatusActionV3,
  validateCommitProductUpdatesReviewStatusV3,
} from './v3/action-internal-commit-product-update';
import {
  getProductBackofficeActionV3,
  validateGetProductBackofficeV3,
} from './v3/action-get-product-backoffice-v3';
import {
  v3UpdateProductBasicInformationAction,
  validateV3UpdateProductBasicInformation,
} from './v3/action-update-product-basic-information';
import {
  listProductUpdateRequestBackofficeActionV3,
  validateListProductUpdateRequestBackofficeV3,
} from './v3/action-list-product-update-request-backoffice';
import {
  listProductUpdateActionV3,
  validateListProductUpdateV3,
} from './v3/action-list-product-update';
import { ensureStore } from '@src/config/middleware/ensure-store';
import {
  immediateSyncActionV3,
  validateImmediateSyncV3,
} from './v3/action-immediate-sync-backoffice';
import {
  actionInternalSyncProductsV3,
  validateInternalSyncProductsV3,
} from './v3/action-internal-sync-products-v3';
import {
  listProductDetailsBackofficeActionV3,
  validateListProductDetailsV3Backoffice,
} from './v3/action-list-product-v3-details-backoffice';
import { multerHandler } from '@src/config/middleware/multer-mw';
import {
  uploadProductScoreBackofficeAction,
  validateUploadProductScoreBackoffice,
} from './v3/action-upload-product-score-backoffice';
import {
  v3UpdateProductAttributesAction,
  validateV3UpdateAttributesProduct,
} from './v3/action-update-product-attributes-v3';
import {
  dismissProductRejectionsActionV3,
  validateDismissProductRejectionsV3,
} from '@express/modules/product/v3/action-dismiss-product-rejections-v3';
import {
  v3EnsureGuardrailsAction,
  validateV3EnsureGuardrails,
} from '@express/modules/product/v3/action-ensure-guradrails-v3';

const router: IRouter = Router();

router.post(
  '/v3-reassign-media-by-sku',
  isAuthenticatedMw(),
  validateReassignMediaBySkuV3,
  catchAsyncErrors(reassignMediaBySkuV3Action),
);
router.post(
  '/v3-create-product',
  ensureStore,
  isAuthenticatedMw(),
  validateCreateProductV3,
  catchAsyncErrors(createProductActionV3),
);
router.post(
  '/v3-update-product',
  isAuthenticatedMw(),
  validateV3UpdateProduct,
  catchAsyncErrors(v3UpdateProductAction),
);
router.post(
  '/v3-update-offer',
  isAuthenticatedMw(),
  validateV3UpdateOffer,
  catchAsyncErrors(v3UpdateOffertAction),
);
router.post(
  '/v3-get-product',
  isAuthenticatedMw(),
  validateGetProductV3,
  catchAsyncErrors(getProductActionV3),
);
router.post(
  '/v3-update-product-review-status-backoffice',
  backOfficeUserMw([]),
  v3ValidateUpdateProductInternalReviewStatusBackoffice,
  catchAsyncErrors(v3UpdateProductInternalReviewStatusBackofficeAction),
);
router.post(
  '/v3-set-product-stock-availability',
  isAuthenticatedMw(),
  validateV3SetProductStockAvailability,
  catchAsyncErrors(setProductStockAvailabilityV3Action),
);
router.post(
  '/v3-set-product-state',
  isAuthenticatedMw(),
  validateV3SetProductState,
  catchAsyncErrors(v3SetProductStateAction),
);
router.post(
  '/v3-list-product-backoffice',
  backOfficeUserMw([]),
  validateListProductV3Backoffice,
  catchAsyncErrors(listProductBackofficeActionV3),
);
router.post(
  '/v3-sku-generation-backoffice',
  backOfficeUserMw([]),
  validateV3SkuGenerationBackoffice,
  catchAsyncErrors(skuGenerationBackofficeV3Action),
);
router.post(
  '/v3-internal-update-product-state',
  authenticateInternalMw,
  validateV3InternalUpdateProductState,
  catchAsyncErrors(internalUpdateProductStateV3Action),
);
router.post(
  '/v3-get-product-update',
  isAuthenticatedMw(),
  validateGetProductUpdateV3,
  catchAsyncErrors(getProductUpdateActionV3),
);
router.post(
  '/v3-create-rfq-product',
  isAuthenticatedMw(),
  validateCreateRfqProductV3,
  catchAsyncErrors(createProductRfqActionV3),
);
router.post(
  '/v3-seller-products-stats',
  isAuthenticatedMw(),
  validateV3SellerProductsStats,
  catchAsyncErrors(sellerProductsStatsV3Action),
);
router.post(
  '/v3-get-product-content',
  isAuthenticatedMw(),
  validateGetProductContentV3,
  catchAsyncErrors(getProductContentActionV3),
);
router.post(
  '/v3-list-variants',
  isAuthenticatedMw(),
  validateListVariantsActionV3,
  catchAsyncErrors(actionListVariantsV3),
);
router.post(
  '/v3-internal-list-variants-by-id',
  authenticateInternalMw,
  validateInternalListVariantsByIdV3,
  catchAsyncErrors(actionInternalListVariantsV3),
);
router.post(
  '/v3-internal-get-product-count',
  authenticateInternalMw,
  validateInternalGetProductCountV3,
  catchAsyncErrors(getProductCountActionV3),
);
router.post(
  '/v3-export-product-score-backoffice',
  backOfficeUserMw([]),
  validateExportProductScoreBackofficeV3,
  catchAsyncErrors(exportProductScoreBackofficeActionV3),
);
router.post(
  '/v3-list-product',
  isAuthenticatedMw(),
  validateListProductV3,
  catchAsyncErrors(listProductActionV3),
);
router.post(
  '/v3-internal-verify-products',
  authenticateInternalMw,
  validateInternalVariantsActionV3,
  catchAsyncErrors(actionValidateProductsV3),
);
router.post(
  '/v3-export-rejected-products',
  isAuthenticatedMw(),
  validateExportRejectedProductsV3,
  catchAsyncErrors(exportRejectedProductsActionV3),
);
router.post(
  '/v3-commit-product-updates-review-status',
  backOfficeUserMw([]),
  validateCommitProductUpdatesReviewStatusV3,
  catchAsyncErrors(updateProductCommitReviewStatusActionV3),
);
router.post(
  '/v3-get-product-backoffice',
  backOfficeUserMw([]),
  validateGetProductBackofficeV3,
  catchAsyncErrors(getProductBackofficeActionV3),
);
router.post(
  '/v3-update-product-basic-information',
  isAuthenticatedMw(),
  validateV3UpdateProductBasicInformation,
  catchAsyncErrors(v3UpdateProductBasicInformationAction),
);
router.post(
  '/v3-immediate-sync',
  backOfficeUserMw([]),
  validateImmediateSyncV3,
  catchAsyncErrors(immediateSyncActionV3),
);
router.post(
  '/v3-internal-sync-products',
  authenticateInternalMw,
  validateInternalSyncProductsV3,
  catchAsyncErrors(actionInternalSyncProductsV3),
);
router.post(
  '/v3-list-product-details-backoffice',
  backOfficeUserMw([]),
  validateListProductDetailsV3Backoffice,
  catchAsyncErrors(listProductDetailsBackofficeActionV3),
);
router.post(
  '/v3-upload-product-score-backoffice',
  backOfficeUserMw([]),
  multerHandler,
  validateUploadProductScoreBackoffice,
  catchAsyncErrors(uploadProductScoreBackofficeAction),
);

// product updates
router.post(
  '/v3-list-product-update',
  isAuthenticatedMw(),
  validateListProductUpdateV3,
  catchAsyncErrors(listProductUpdateActionV3),
);
router.post(
  '/v3-list-product-update-request-backoffice',
  backOfficeUserMw([]),
  validateListProductUpdateRequestBackofficeV3,
  catchAsyncErrors(listProductUpdateRequestBackofficeActionV3),
);
router.post(
  '/v3-update-product-attributes',
  backOfficeUserMw([]),
  validateV3UpdateAttributesProduct,
  catchAsyncErrors(v3UpdateProductAttributesAction),
);
router.post(
  '/v3-ensure-guardrails',
  backOfficeUserMw([]),
  validateV3EnsureGuardrails,
  catchAsyncErrors(v3EnsureGuardrailsAction),
);

router.post(
  '/v3-dismiss-product-rejections',
  isAuthenticatedMw(),
  validateDismissProductRejectionsV3,
  catchAsyncErrors(dismissProductRejectionsActionV3),
);

export { router as productRoutes };
