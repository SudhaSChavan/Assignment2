import mongoose, { model, Types } from 'mongoose';
import {
  InternalReviewStatuses,
  InternalReviewStatusType,
  ProductStates,
} from './types';

export interface IProductContentTranslationDocument {
  name: { en: string; ar?: string };
  shortDescription: { en: string; ar?: string };
  longDescription: { en: string; ar?: string };
  categoryId: Types.ObjectId;
  keywords: {
    en: string[];
    ar?: string[];
  };
  state: 'online' | 'offline' | 'deleted';
  attributes: {
    [key: string]: any;
  };
  isInStock: boolean;
  internalReviewedAt?: Date;
  internalReviewStatus: InternalReviewStatusType;
  websiteCode?: string;
  pageViews: number; // sum of all variants page views count from catalog-search
  hasTranslations: 'no' | 'partial' | 'yes'; // indicates combined status of translation of all variants
  deletedAt?: string;
}

// model uses master product id
export interface IProductContentTranslationModel
  extends IProductContentTranslationDocument,
    mongoose.Document {
  _id: string;
}

const productContentTranslationSchema: mongoose.Schema = new mongoose.Schema(
  {
    _id: {
      type: mongoose.Types.ObjectId,
      required: true,
    },
    name: {
      en: {
        type: String,
        required: true,
        trim: true,
      },
      ar: {
        type: String,
        trim: true,
      },
    },
    shortDescription: {
      en: {
        type: String,
        trim: true,
        default: '',
      },
      ar: {
        type: String,
        trim: true,
      },
    },
    longDescription: {
      en: {
        type: String,
        trim: true,
        default: '',
      },
      ar: {
        type: String,
        trim: true,
      },
    },
    categoryId: {
      type: mongoose.Schema.Types.ObjectId,
      default: null,
      ref: 'Category',
    },
    keywords: {
      en: {
        type: [String],
      },
      ar: {
        type: [String],
      },
    },
    state: {
      type: String,
      required: true,
      enum: Object.values(ProductStates),
      default: ProductStates.Offline,
    },
    attributes: {
      type: Object,
      default: {},
    },
    isInStock: {
      type: Boolean,
      required: true,
      default: true,
    },
    internalReviewStatus: {
      type: Number,
      default: InternalReviewStatuses.Pending,
    },
    internalReviewedAt: {
      type: Date,
    },
    websiteCode: {
      type: String,
    },
    pageViews: Number,
    hasTranslations: String,
    deletedAt: {
      type: Date,
      default: null,
    },
  },
  {
    versionKey: false,
    timestamps: true,
    collection: 'product-content-translation',
  },
);

productContentTranslationSchema.index({
  deletedAt: 1,
  internalReviewStatus: 1,
  internalReviewedAt: 1,
});

export const productContentTranslationModel: mongoose.Model<IProductContentTranslationModel> = model<IProductContentTranslationModel>(
  'ProductContentTranslation',
  productContentTranslationSchema,
);
