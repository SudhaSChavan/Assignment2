import mongoose from 'mongoose';
import { InternalReviewStatuses } from './types';
import { IProductContentV3 } from './model-product-v3';

export interface IProductUpdateRequestDocumentV3 {
  productId?: string;
  supplierId: string;
  supplierCompanyId: string;
  reviewedAt: string;
  reviewedBy: {
    email: string;
    userId: string;
  };
  status: number;
  diff: Record<keyof IProductContentV3, any>[];
  rejectionReasons?: {
    section: string;
    slug: string;
    msg?: string;
  }[];
  type: string;
  websiteCode?: string;
  metadata: Record<any, any>;
}

export interface IProductUpdateRequestModelV3
  extends IProductUpdateRequestDocumentV3,
    mongoose.Document {
  _id: string;
}

const productUpdateRequestSchemaV3: mongoose.Schema = new mongoose.Schema(
  {
    productId: {
      type: mongoose.Schema.Types.ObjectId,
      required: false,
    },
    supplierId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
    },
    supplierCompanyId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
    },
    reviewedAt: {
      type: Date,
    },
    reviewedBy: {
      type: Object,
    },
    status: {
      type: Number,
      default: InternalReviewStatuses.Pending,
    },
    type: {
      type: String,
      default: 'product',
    },
    websiteCode: {
      type: String,
    },
    rejectionReasons: {
      type: [
        {
          slug: {
            type: String,
            required: true,
          },
          section: {
            type: String,
            required: true,
          },
          msg: String,
        },
      ],
      default: [],
    },
    diff: {
      type: Object,
    },
    metadata: {
      type: Object,
    },
  },
  {
    versionKey: false,
    timestamps: true,
    collection: 'productUpdateRequestV3',
  },
);

productUpdateRequestSchemaV3.index({ supplierCompanyId: 1 });
productUpdateRequestSchemaV3.index({ productId: 1 });
productUpdateRequestSchemaV3.index({ status: 1 });

export const productUpdateRequestModelV3: mongoose.Model<IProductUpdateRequestModelV3> = mongoose.model<IProductUpdateRequestModelV3>(
  'ProductUpdateRequestV3',
  productUpdateRequestSchemaV3,
);
