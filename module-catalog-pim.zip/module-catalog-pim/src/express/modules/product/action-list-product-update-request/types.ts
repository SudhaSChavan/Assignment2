import { IProductUpdateRequestDocumentV3 } from '../model-product-update-request-v3';
import { VariantValueV3 } from '../model-product-v3';

export interface ProductUpdateRequestListExtendedV3
  extends IProductUpdateRequestDocumentV3 {
  state: string;
  categoryId: string;
  isSupplierVerified?: boolean;
  variantValues?: VariantValueV3[];
}
