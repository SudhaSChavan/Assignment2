import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { ERRORS } from '@src/types/errors';
import { categoryModel } from './model-category';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';

interface IReq extends IAppRequest {
  body: Paths.V1SearchCategoryAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1SearchCategoryAction.Responses.$200) => this;
}

export const validateSearchCategory: BaseValidationType = [
  body('term') //
    .notEmpty()
    .isString()
    .withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function searchCategoryAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { store } = req;
  const { term } = req.body;

  const query: Record<string, any> = {
    $and: [
      {
        $or: [
          {
            'name.en': {
              $regex: term,
              $options: 'ig',
            },
          },
          {
            'name.ar': {
              $regex: term,
              $options: 'ig',
            },
          },
          {
            'description.en': {
              $regex: term,
              $options: 'ig',
            },
          },
          {
            'description.ar': {
              $regex: term,
              $options: 'ig',
            },
          },
        ],
      },
      {
        $or: [
          {
            active: true,
          },
          {
            active: {
              $exists: false,
            },
          },
        ],
      },
    ],
    'children.0': {
      $exists: false,
    },
    ...(store?.website?.websiteCode !== undefined
      ? { websiteCode: store?.website?.websiteCode }
      : {}),
  };

  const categories: Components.Schemas.V1SearchCategory[] = await categoryModel
    .find(
      query,
      {},
      {
        limit: 100,
        sort: {
          'name.en': 1,
        },
      },
    )
    .populate('parents', 'name level')
    .lean();

  res.json(categories);
}
