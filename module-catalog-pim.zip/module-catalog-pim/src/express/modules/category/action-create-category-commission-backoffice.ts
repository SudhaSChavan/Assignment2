import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { body } from 'express-validator';
import { validateCategoryId } from '@core/util/validators';
import { categoryCommissionModel } from './model-category-commission';

interface IReq extends IAppRequest {
  body: Paths.V1CreateCategoryCommissionBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body: Paths.V1CreateCategoryCommissionBackofficeAction.Responses.$200,
  ) => this;
}

export const validateCreateCategoryCommissionBackoffice: BaseValidationType = [
  body('categoryId').notEmpty().isMongoId().custom(validateCategoryId),
  body('commission').notEmpty().isInt({ max: 10, min: 0 }),
  reqValidationResult,
];

export async function createCategoryCommissionBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { categoryId, commission } = req.body;

  const categoryCommission: boolean = await categoryCommissionModel.exists({
    categoryId: categoryId,
  });
  if (categoryCommission) {
    res.json({ isCreated: false });
    return;
  }

  await categoryCommissionModel.create({
    categoryId,
    commission,
  });

  res.json({ isCreated: true });
}
