import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { body } from 'express-validator';
import { categoryCommissionModel } from './model-category-commission';

interface IReq extends IAppRequest {
  body: Paths.V1DeleteCategoryCommissionBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body: Paths.V1DeleteCategoryCommissionBackofficeAction.Responses.$200,
  ) => this;
}

export const validateDeleteCategoryCommissionBackoffice: BaseValidationType = [
  body('id').notEmpty().isMongoId(),
  reqValidationResult,
];

export async function deleteCategoryCommissionBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { id } = req.body;

  await categoryCommissionModel.findByIdAndDelete(id);

  res.json({ isDeleted: true });
}
