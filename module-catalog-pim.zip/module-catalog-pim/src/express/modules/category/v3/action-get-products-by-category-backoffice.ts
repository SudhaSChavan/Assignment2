import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { ERRORS } from '@src/types/errors';
import { queryHelper } from '@tradeling/web-js-utils';
import { categoryModel, ICategoryModel } from './../model-category';
import { productModelV3 } from '../../product/model-product-v3';

interface IReq extends IAppRequest {
  body: Paths.V3GetProductsByCategoryBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body:
      | Paths.V3GetProductsByCategoryBackofficeAction.Responses.$200
      | Paths.V3GetProductsByCategoryBackofficeAction.Responses.$400,
  ) => this;
}

export const validateV3GetProductsByCategoryBackoffice: BaseValidationType = [
  body('filter.categoryIds') //
    .notEmpty()
    .isArray()
    .withMessage(ERRORS.INVALID),
  body('filter.term') //
    .optional()
    .isString()
    .withMessage(ERRORS.INVALID),
  body('page') //
    .optional()
    .isInt({ gt: 0 })
    .withMessage(ERRORS.INVALID),
  body('size') //
    .optional()
    .isInt({ gt: 0 })
    .withMessage(ERRORS.INVALID),
  body('sort') //
    .optional()
    .isString()
    .withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function getProductsByCategoryBackofficeV3Action(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    filter: { categoryIds, term },
    page = 1,
    size = 50,
    sort = '',
  } = req.body;

  let sortQuery: Record<any, any> = {};

  if (sort) {
    sortQuery = queryHelper.getSortObject(sort);
  }

  // Find all the leaf category under the given target category ids
  const leafCategories: ICategoryModel[] = await categoryModel.find({
    $or: [
      {
        parents: {
          $in: categoryIds,
        },
        children: { $size: 0 },
      },
      {
        _id: {
          $in: categoryIds,
        },
        children: { $size: 0 },
      },
    ],
  });

  const leafCategoryIds: string[] = leafCategories.map(
    (category: ICategoryModel): string => String(category._id),
  );

  const conditions: Record<string, any> = {
    categoryId: {
      $in: leafCategoryIds,
    },
    ...(term
      ? {
          $or: [
            {
              'name.en': {
                $regex: term,
                $options: 'i',
              },
            },
            {
              sku: term.toUpperCase(),
            },
          ],
        }
      : {}),
  };
  const totalRecords: number = await productModelV3.countDocuments(conditions);
  const products: any = await productModelV3.find(
    conditions,
    {},
    { skip: (page - 1) * size, limit: size, sort: sortQuery || {} },
  );

  res.json({
    currentPage: page,
    totalPages: Math.ceil(totalRecords / size),
    totalRecords,
    size,
    products,
  });
}
