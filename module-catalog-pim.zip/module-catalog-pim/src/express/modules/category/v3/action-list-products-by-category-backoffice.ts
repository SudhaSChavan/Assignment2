import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { ERRORS } from '@src/types/errors';
import { appConfig } from '@src/config/env';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { productModelV3 } from '../../product/model-product-v3';

interface IReq extends IAppRequest {
  body: Paths.V3ListProductsByCategoryBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body:
      | Paths.V3ListProductsByCategoryBackofficeAction.Responses.$200
      | Paths.V3ListProductsByCategoryBackofficeAction.Responses.$400,
  ) => this;
}

export const validateV3ListProductsByCategoryBackoffice: BaseValidationType = [
  body('filter.categoryId').notEmpty().isMongoId(),
  body('page').optional().isInt({ gt: 0 }).withMessage(ERRORS.INVALID),
  body('size')
    .optional()
    .isInt({ lt: appConfig.category.listMaxLimit + 1, gt: 0 })
    .withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function listProductsByCategoryBackofficeV3Action(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    page = 1,
    size = appConfig.category.listDefaultLimit,
    filter: { categoryId } = {},
  } = req.body;

  const query: Record<string, any> = {
    categoryId,
  };

  const totalRecords: number = await productModelV3.countDocuments(query);
  const products: Components.Schemas.V3Product[] = await productModelV3
    .find(
      query,
      {},
      {
        skip: (page - 1) * size,
        limit: size,
      },
    )
    .lean();

  res.json({
    currentPage: page,
    totalPages: Math.ceil(totalRecords / size),
    totalRecords,
    size,
    products,
  });
}
