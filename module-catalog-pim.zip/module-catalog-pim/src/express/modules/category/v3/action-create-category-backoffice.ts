import { body } from 'express-validator';
import { StatusCodes } from 'http-status-codes';
import {
  BaseValidationType,
  HttpError,
  reqValidationResult,
  WebsiteType,
} from '@tradeling/web-js-utils/dist';

import { Event as TargetEvent } from '@tradeling/emit-audit';
import { ERRORS } from '@src/types/errors';
import { appConfig } from '@src/config/env';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import {
  validateCategoryId,
  validateKeywords,
  validateLevel,
} from '@core/util/validators';
import { logger } from '@core/util/logger';
import { V1GetWebsiteByCodeAction } from '@tradeling/tradeling-sdk/www/v1-get-website-by-code-action';
import {
  categoryAttributeModel,
  ICategoryAttributeModel,
} from './../model-category-attribute';
import { categoryModel, ICategoryModel } from '../model-category';
import { productModelV3 } from '../../product/model-product-v3';
import {
  CategoryAuditEventEnum,
  fireCategoryAuditEvent,
} from '@express/modules/category/dispatch-category-audit-event';
import { auditFields } from '@express/modules/product/send-product-audit-event';

interface IReq extends IAppRequest {
  body: Paths.V3CreateCategoryBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3CreateCategoryBackofficeAction.Responses.$200) => this;
}

export const validateV3CreateCategoryBackoffice: BaseValidationType = [
  body('websiteCode')
    .notEmpty()
    .isString()
    .custom(
      async (websiteCode: string, meta): Promise<void> => {
        try {
          const { data: website } = await V1GetWebsiteByCodeAction(
            {},
            {
              headers: {
                ...meta.req.headers,
              },
            },
            {
              code: websiteCode,
            },
          );
          //await redisClient.set('store', JSON.stringify(store || {}), 'EX', cacheTTLSec);
          const foundWebsite: WebsiteType = website as WebsiteType;
          if (foundWebsite?.websiteCode !== websiteCode) {
            throw new HttpError(
              StatusCodes.BAD_REQUEST,
              `Failed to get website with code ${websiteCode}`,
            );
          }
        } catch (error) {
          throw new HttpError(
            StatusCodes.BAD_REQUEST,
            `Failed to get website with code ${websiteCode} with error :: `,
            error,
          );
        }
      },
    ),
  body('slug')
    .notEmpty()
    .isString()
    .isLength({ min: 3 })
    .trim()
    .custom(
      async (slug: string): Promise<void> => {
        const slugExists: boolean = await categoryModel.exists({ slug });
        if (slugExists) {
          throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.DUPLICATE);
        }
      },
    ),
  body('name.en')
    .notEmpty()
    .withMessage(ERRORS.MISSING)
    .isString()
    .withMessage(ERRORS.INVALID)
    .isLength({ min: 3 })
    .withMessage(ERRORS.INVALID)
    .trim(),
  body('name.ar')
    .if((value: string, { req }: any) => {
      return req.body.websiteCode !== 'edukaan';
    })
    .notEmpty()
    .isString()
    .withMessage(ERRORS.INVALID)
    .isLength({ min: 3 })
    .withMessage(ERRORS.INVALID)
    .trim(),
  body('description.en')
    .optional()
    .isString()
    .withMessage(ERRORS.INVALID)
    .isLength({ min: 3 })
    .withMessage(ERRORS.INVALID)
    .trim(),
  body('description.ar')
    .if((value: string, { req }: any) => {
      return req.body.websiteCode !== 'edukaan';
    })
    .notEmpty()
    .isString()
    .withMessage(ERRORS.INVALID)
    .isLength({ min: 3 })
    .withMessage(ERRORS.INVALID)
    .trim(),
  body('keywords.en')
    .notEmpty()
    .isArray({ max: appConfig.category.keywordsLimit })
    .custom(validateKeywords),
  body('keywords.ar')
    .if((value: string, { req }: any) => {
      return req.body.websiteCode !== 'edukaan';
    })
    .notEmpty()
    .isArray({ max: appConfig.category.keywordsLimit })
    .custom(validateKeywords),
  body('active').optional().isBoolean(),
  body('weight').optional().isInt(),
  body('parentId').custom(validateCategoryId),
  body('level')
    .notEmpty()
    .withMessage(ERRORS.MISSING)
    .custom(validateLevel)
    .withMessage(ERRORS.INVALID),
  reqValidationResult,
];

async function moveProductsToCategory(
  fromCategoryId: string,
  toCategoryId: string,
): Promise<any> {
  return productModelV3.updateMany(
    {
      categoryId: fromCategoryId,
    },
    {
      $set: {
        categoryId: toCategoryId,
      },
    },
  );
}

async function moveAttributesToChildCategory(
  parentCategoryId: string,
  newCategoryId: string,
): Promise<any> {
  const parentCategoryAttribute: ICategoryAttributeModel = await categoryAttributeModel.findOne(
    {
      categoryId: parentCategoryId,
    },
  );

  // The parent doesn't have any attributes
  if (!parentCategoryAttribute?.attributes?.length) {
    return;
  }

  const newCategory: ICategoryModel = await categoryModel.findOne({
    _id: newCategoryId,
  });

  if (!newCategory) {
    logger.error(`Category not found for id ${newCategoryId}`);

    return;
  }

  await categoryAttributeModel.updateOne(
    {
      categoryId: parentCategoryId,
    },
    {
      $set: {
        categoryId: newCategory._id,
        categoryTree: [...(newCategory?.parents || []), newCategory._id],
      },
    },
  );
}

export async function createCategoryBackofficeV3Action(
  req: IReq,
  res: IRes,
): Promise<void> {
  let parents: string[] = [];
  let parentCategory: ICategoryModel;

  const { parentId, websiteCode } = req.body;

  if (parentId) {
    parentCategory = await categoryModel.findById(parentId);
    parents = [...(parentCategory.parents || []), parentId];
  }

  // We do not allow adding more children after level 3
  if (parents.length >= 4) {
    throw new HttpError(
      StatusCodes.BAD_REQUEST,
      "Can't add more parents after level 3",
    );
  }

  const category: ICategoryModel = new categoryModel({
    ...req.body,
    parents,
    moq: parentCategory?.moq || 1,
    level: parents?.length || 0,
    children: [],
    websiteCode: websiteCode,
  });

  await category.save();

  if (parentId) {
    parentCategory.children.push(category._id);
    await parentCategory.save();

    // We only have the products in the leaf categories. Adding a product
    // under this "parent" means it is not a leaf anymore, and we need to move the
    // products associated with this category to this newly created category
    await moveProductsToCategory(parentId, String(category._id));

    // We only have the product attributes in the leaf categories. Adding a product
    // under this child means it is not a leaf anymore, and we need to move the
    // products associated with this category to this newly created category
    await moveAttributesToChildCategory(parentId, String(category._id));
  }

  fireCategoryAuditEvent(
    CategoryAuditEventEnum.Created,
    [category._id.toString()],
    TargetEvent.Inserted,
    req,
    auditFieldsForCreateCategory(category),
    'New category creation action performed',
  );

  res.json(
    (await category.save()).toJSON() as Components.Schemas.V1CategoryBackoffice,
  );
}

export function auditFieldsForCreateCategory(
  category: ICategoryModel,
): auditFields[] {
  const diffFields: auditFields[] = [];

  if (category.name.en) {
    for (const key of Object.keys(category.name)) {
      diffFields.push({
        name: `category.name.${key}`,
        old: null,
        new: category.name[key],
      });
    }
  }

  return diffFields;
}
