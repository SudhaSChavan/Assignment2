import { body } from 'express-validator';
import { map } from 'lodash';
import {
  BaseValidationType,
  HttpError,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { StatusCodes } from 'http-status-codes';
import {
  IProductModelV3,
  productModelV3,
} from '../../product/model-product-v3';
import { EE } from '@src/config/event/emitter';
import {
  ProductSyncEvent,
  ProductSyncEventType,
} from '../../product/sync-hlper';
import { logger } from '@core/util/logger';

interface IReq extends IAppRequest {
  body: Paths.V3MoveProductsToCategoryBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body:
      | Paths.V3MoveProductsToCategoryBackofficeAction.Responses.$200
      | Paths.V3MoveProductsToCategoryBackofficeAction.Responses.$400,
  ) => this;
}

export const validateV3MoveProductsToCategoryBackoffice: BaseValidationType = [
  // prettier-ignore
  body('sourceCategoryId')
    .notEmpty()
    .isMongoId(),
  // prettier-ignore
  body('targetCategoryId')
    .notEmpty()
    .isMongoId(),
  body('moveState').notEmpty().isIn(['partial', 'full']),
  body('productIds')
    .isArray()
    .custom((productIds: string, { req }: any): boolean => {
      return req.body.moveState === 'full' || productIds.length > 0;
    }),
  reqValidationResult,
];

export async function moveProductsToCategoryBackofficeV3Action(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    sourceCategoryId,
    targetCategoryId,
    productIds,
    moveState,
  } = req.body;

  // check if source category has any products, otherwise throw error
  const products: IProductModelV3[] = await productModelV3.find({
    categoryId: sourceCategoryId,
  });

  if (!products.length) {
    throw new HttpError(
      StatusCodes.BAD_REQUEST,
      'Source category has no products',
    );
  }

  const conditions: Record<string, any> =
    moveState === 'full'
      ? { categoryId: sourceCategoryId }
      : { categoryId: sourceCategoryId, _id: { $in: productIds } };

  // update products where categoryId is sourceCategoryId to targetCategoryId
  await productModelV3.updateMany(conditions, {
    $set: {
      categoryId: targetCategoryId,
    },
  });

  EE.emit(ProductSyncEvent.Updated, {
    req,
    productIds: map(products, '_id'),
    priority: 'highest',
  } as ProductSyncEventType).catch((error: Error): void => {
    logger.error(`Event ${ProductSyncEvent.Updated} failed: ${error.stack}`);
  });

  res.json({ isUpdated: true });
}
