import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import mongoose from 'mongoose';

import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { InternalReviewStatuses } from '../../product/types';
import { productModelV3 } from '../../product/model-product-v3';

interface IReq extends IAppRequest {
  body: Paths.V3GetPersonalizedCategoriesAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V3GetPersonalizedCategoriesAction.Responses.$200) => this;
}

export const validateV3GetPersonalizedCategories: BaseValidationType = [
  reqValidationResult,
];

function mapAggregatedCategories(categories: any): string[] {
  const aggregatedCategories: [{ _id: string; parents: string[] }] = categories;
  let allCategories: string[] = [];

  for (const cat of aggregatedCategories) {
    allCategories = [
      ...allCategories,
      String(cat._id),
      ...cat.parents.map(String),
    ];
  }

  return Array.from(new Set(allCategories));
}

export async function getPersonalizedCategoriesV3Action(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { productIds } = req.body;

  const result: any = await productModelV3.aggregate([
    {
      $match: {
        //
        ...(productIds?.length
          ? { _id: { $in: productIds.map(mongoose.Types.ObjectId) } }
          : {}),
        supplierCompanyId: mongoose.Types.ObjectId(req.supplierCompanyId),
        internalReviewStatus: InternalReviewStatuses.Accepted,
      },
    },
    { $group: { _id: null, uniqueCategories: { $addToSet: '$categoryId' } } },
    {
      $lookup: {
        from: 'category',
        let: { leafCategories: '$uniqueCategories' },
        pipeline: [
          {
            $match: {
              $expr: {
                $in: ['$_id', '$$leafCategories'],
              },
            },
          },
          { $project: { parents: 1 } },
        ],
        as: 'allCategories',
      },
    },
  ]);

  let uniqueCategories: string[] = [];

  if (result?.length) {
    const [{ allCategories }] = result;
    uniqueCategories = mapAggregatedCategories(allCategories);
  }

  res.json({
    categories: uniqueCategories,
  });
}
