import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { categoryModel, ICategoryModel } from './../model-category';
import { V1GetProductStatsAction } from '@tradeling/tradeling-sdk/catalog-search/v1-get-product-stats-action';
import { KeyValAny } from '@src/types/common';
import { AxiosError } from 'axios';
import { logger } from '@core/util/logger';
import { InternalReviewStatuses } from '../../product/types';
import V1GetProductStatsResponse = CatalogSearch.Components.Schemas.V1GetProductStatsResponse;
import { fetchSupplierCompanies } from './../action-get-category-product-stats-backoffice/helpers';
import { productModelV3 } from '../../product/model-product-v3';

interface IReq extends IAppRequest {
  body: Paths.V3GetCategoryProductsStatsBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body:
      | Paths.V3GetCategoryProductsStatsBackofficeAction.Responses.$200
      | Paths.V3GetCategoryProductsStatsBackofficeAction.Responses.$400,
  ) => this;
}

export const validateV3GetCategoryProductsStatsBackoffice: BaseValidationType = [
  //
  body('categoryId').optional().isMongoId(),
  reqValidationResult,
];

export async function getCategoryProductsStatsV3Action(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { categoryId } = req.body;
  let condition: KeyValAny = {};
  if (categoryId) {
    condition = {
      $or: [{ _id: categoryId }, { parents: categoryId }],
    };
  }

  // get children categories
  const categories: ICategoryModel[] = await categoryModel
    .find(condition, { _id: 1 })
    .lean();

  const categoryIds: string[] = categories.map((category) =>
    String(category._id),
  );

  const productCompanyIds: string[] = await productModelV3.distinct(
    'createdSupplierCompanyId',
    { deletedAt: null, categoryId: { $in: categoryIds } },
  );

  let verified: number = 0;
  let unverified: number = 0;
  for await (const companies of fetchSupplierCompanies(productCompanyIds)) {
    verified += companies.filter((company) => company.isVerified).length;
    unverified += companies.filter((company) => !company.isVerified).length;
  }

  const [
    totalProducts,
    onlineProducts,
    offlineProducts,
    outOfStockProducts,
    pendingProducts,
    rejectedProducts,
    totalActiveSuppliers,
    totalInactiveSuppliers,
  ] = await Promise.all([
    productModelV3.countDocuments({
      deletedAt: null,
      categoryId: { $in: categoryIds },
    }),
    productModelV3.countDocuments({
      deletedAt: null,
      categoryId: { $in: categoryIds },
      state: 'online',
      isInStock: true,
      internalReviewStatus: {
        $nin: [InternalReviewStatuses.Pending, InternalReviewStatuses.Rejected],
      },
    }),
    productModelV3.countDocuments({
      deletedAt: null,
      categoryId: { $in: categoryIds },
      state: 'offline',
    }),
    productModelV3.countDocuments({
      deletedAt: null,
      categoryId: { $in: categoryIds },
      state: 'online',
      isInStock: false,
      internalReviewStatus: {
        $nin: [InternalReviewStatuses.Pending, InternalReviewStatuses.Rejected],
      },
    }),
    productModelV3.countDocuments({
      deletedAt: null,
      categoryId: { $in: categoryIds },
      internalReviewStatus: InternalReviewStatuses.Pending,
    }),
    productModelV3.countDocuments({
      deletedAt: null,
      categoryId: { $in: categoryIds },
      internalReviewStatus: InternalReviewStatuses.Rejected,
    }),
    verified,
    unverified,
  ]);

  const productStats: V1GetProductStatsResponse = await getProductStatsFromCatalogSearch(
    categoryId,
  );

  res.json({
    totalProducts,
    offlineProducts,
    onlineProducts,
    outOfStockProducts,
    pendingProducts: pendingProducts,
    rejectedProducts: rejectedProducts,
    totalSuppliers: totalActiveSuppliers + totalInactiveSuppliers,
    totalActiveSuppliers,
    totalInactiveSuppliers,
    totalCatalogSearchProduct: productStats?.productsCount ?? 0,
    totalOnlineCatalogSearchProduct: productStats?.onlineProductsCount ?? 0,
    totalOfflineCatalogSearchProduct: productStats?.offlineProductsCount ?? 0,
    totalOutOfStockCatalogSearchProduct:
      productStats?.outOfStockProductsCount ?? 0,
    totalPendingCatalogSearchProduct: productStats?.pendingProductsCount ?? 0,
    totalRejectedCatalogSearchProduct: productStats?.rejectedProductsCount ?? 0,
  } as Paths.V3GetCategoryProductsStatsBackofficeAction.Responses.$200);
}

async function getProductStatsFromCatalogSearch(
  categoryId: string,
): Promise<V1GetProductStatsResponse> {
  const { data } = await V1GetProductStatsAction(
    {
      filter: {
        categoryId,
      },
    },
    {
      headers: {
        'x-language': 'en',
        'x-country': 'ae',
      },
    },
  ).catch((error: AxiosError) => {
    logger.error(error.message);
    return { data: null };
  });

  return data as V1GetProductStatsResponse;
}
