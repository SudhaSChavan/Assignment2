import { body } from 'express-validator';
import { StatusCodes } from 'http-status-codes';
import {
  BaseValidationType,
  HttpError,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { EE } from '@src/config/event/emitter';
import { logger } from '@core/util/logger';
import { IDeleteCategoryListener } from './../listener-delete-category-backoffice';
import { deleteCategoryCommisions } from './../action-delete-category/helpers';
import { categoryModel, ICategoryModel } from './../model-category';
import { categoryAttributeModel } from './../model-category-attribute';
import { productModelV3 } from '../../product/model-product-v3';
import { Event as TargetEvent } from '@tradeling/emit-audit';
import {
  CategoryAuditEventEnum,
  fireCategoryAuditEvent,
} from '@express/modules/category/dispatch-category-audit-event';

export enum CategoryDeleteEvent {
  Success = 'category.delete.success',
}

interface IReq extends IAppRequest {
  body: Paths.V3DeleteCategoryBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body:
      | Paths.V3DeleteCategoryBackofficeAction.Responses.$200
      | Paths.V3DeleteCategoryBackofficeAction.Responses.$400,
  ) => this;
}

export const validateV3DeleteCategoryBackoffice: BaseValidationType = [
  // prettier-ignore
  body('categoryId')
    .notEmpty()
    .isMongoId(),
  reqValidationResult,
];

export async function deleteCategoryBackofficeV3Action(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { categoryId } = req.body;

  // Find all the leaf category under the given target category ids
  const leafCategories: ICategoryModel[] = await categoryModel.find({
    $or: [
      {
        parents: categoryId,
        children: { $size: 0 },
      },
      {
        _id: categoryId,
        children: { $size: 0 },
      },
    ],
  });

  const leafCategoryIds: string[] = leafCategories.map(
    (category: ICategoryModel): string => String(category._id),
  );

  const productCount: number = await productModelV3.countDocuments({
    categoryId: {
      $in: leafCategoryIds,
    },
  });

  if (productCount > 0) {
    // cannot delete category as it has products
    throw new HttpError(
      StatusCodes.BAD_REQUEST,
      'Cannot delete category that has products',
    );
  }

  //////////////////////////////////////////////////////////////////////////////
  // Get the IDs we are going to delete (children of category to be deleted and
  // the category itself), we need to delete them from elasticsearch also
  //////////////////////////////////////////////////////////////////////////////
  const categoryDocumentsToDelete: Pick<
    ICategoryModel,
    '_id'
  >[] = await categoryModel.find(
    {
      $or: [
        {
          parents: { $in: [categoryId] },
        },
        {
          _id: categoryId,
        },
      ],
    },
    '_id',
  );

  const categoryIdsToDelete: string[] = categoryDocumentsToDelete.map(
    (categoryModel: Pick<ICategoryModel, '_id'>): string => categoryModel._id,
  );

  ////////////////////////////////////////////////////////////////////////
  // Delete all the children of this category and this category
  ////////////////////////////////////////////////////////////////////////
  await categoryModel.deleteMany({
    $or: [
      {
        parents: { $in: [categoryId] },
      },
      {
        _id: categoryId,
      },
    ],
  });

  /////////////////////////////////////////////////////////////////////////////
  // also remove all the attributes attached to this category and its children
  /////////////////////////////////////////////////////////////////////////////
  await categoryAttributeModel.deleteMany({
    categoryTree: categoryId,
  });

  /////////////////////////////////////////////////////////////////////////////
  // Remove this category id from the children array of any of the categories
  /////////////////////////////////////////////////////////////////////////////
  await categoryModel.updateMany(
    {
      children: categoryId,
    },
    {
      $pull: {
        // @ts-ignore
        children: categoryId,
      },
    },
  );

  await deleteCategoryCommisions(categoryId);

  EE.emit(CategoryDeleteEvent.Success, {
    categoryIds: categoryIdsToDelete,
  } as IDeleteCategoryListener).catch((error: Error): void => {
    logger.error(`Event ${CategoryDeleteEvent.Success} failed: ${error.stack}`);
  });

  fireCategoryAuditEvent(
    CategoryAuditEventEnum.Deleted,
    [categoryId],
    TargetEvent.Deleted,
    req,
    {},
    'Category deletion action performed',
  );

  res.json({ isDeleted: true });
}
