import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { ERRORS } from '@src/types/errors';
import { categoryModel, ICategoryModel } from './../model-category';
import { productModelV3 } from '../../product/model-product-v3';

interface IReq extends IAppRequest {
  body: Paths.V3BulkGetAffectableProductsBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body: Paths.V3BulkGetAffectableProductsBackofficeAction.Responses.$200,
  ) => this;
}

export const validateV3GetBulkAffectableProductsBackoffice: BaseValidationType = [
  body('filter.newParentId') //
    .notEmpty()
    .isMongoId()
    .withMessage(ERRORS.INVALID),
  body('filter.categoryId') //
    .optional()
    .isMongoId()
    .withMessage(ERRORS.INVALID),
  body('page') //
    .optional()
    .isInt({ gt: 0 })
    .withMessage(ERRORS.INVALID),
  body('size') //
    .optional()
    .isInt({ gt: 0 })
    .withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function getBulkAffectableProductsV3Action(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    filter: { newParentId, categoryId },
    size = 50,
    page = 1,
  } = req.body;

  // newParentId => only itself
  // categoryId => itself and it's children

  // Find all the leaf categories under the given target category ids
  let leafCategories: ICategoryModel[] = [];
  if (categoryId) {
    leafCategories = await categoryModel.find({
      $or: [
        {
          parents: categoryId,
          children: { $size: 0 },
        },
        {
          _id: categoryId,
          children: { $size: 0 },
        },
      ],
    });
  }

  const leafCategoryIds: string[] = leafCategories.map(
    (category: ICategoryModel): string => String(category._id),
  );

  const conditions: Record<string, any> = {
    categoryId: {
      $in: [...leafCategoryIds, newParentId],
    },
  };

  const totalRecords: number = await productModelV3.countDocuments(conditions);
  const products: any = await productModelV3.find(
    conditions,
    {},
    { skip: (page - 1) * size, limit: size, sort: { updatedAt: -1 } },
  );

  res.json({
    currentPage: page,
    totalPages: Math.ceil(totalRecords / size),
    totalRecords,
    size,
    products,
  });
}
