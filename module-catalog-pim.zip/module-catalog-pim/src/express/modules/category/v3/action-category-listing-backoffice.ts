import { body } from 'express-validator';
import { ERRORS } from '@src/types/errors';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { appConfig } from '@src/config/env';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { categoryModel } from './../model-category';
import { enrichCategoriesWithProductCountV3 } from './util';

interface IReq extends IAppRequest {
  body: Paths.V3CategoryListingBoBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body:
      | Paths.V3CategoryListingBoBackofficeAction.Responses.$200
      | Paths.V3CategoryListingBoBackofficeAction.Responses.$400,
  ) => this;
}

export const validateV3CategoryListingBackoffice: BaseValidationType = [
  body('filter.parentId')
    .optional({ nullable: true })
    .isString()
    .withMessage(ERRORS.INVALID),
  body('filter.websiteCode')
    .optional({ nullable: true })
    .isString()
    .withMessage(ERRORS.INVALID),
  body('filter.level')
    .optional({ nullable: true })
    .isNumeric()
    .withMessage(ERRORS.INVALID),
  body('filter.text')
    .optional({ nullable: true })
    .isString()
    .withMessage(ERRORS.INVALID),
  body('filter.status')
    .optional({ nullable: true })
    .isString()
    .withMessage(ERRORS.INVALID),
  body('filter.ids.*')
    .optional({ nullable: true })
    .isString()
    .withMessage(ERRORS.INVALID),
  body('page').optional().isInt({ gt: 0 }).withMessage(ERRORS.INVALID),
  body('size')
    .optional()
    .isInt({ lt: appConfig.category.listMaxLimit + 1, gt: 0 })
    .withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function categoryListingBackofficeV3Action(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    page = 1,
    size = appConfig.category.listDefaultLimit,
    filter: {
      parentId = undefined,
      level = undefined,
      ids = undefined,
      term = undefined,
      status = undefined,
      websiteCode = undefined,
    } = {},
  } = req.body;
  let active: boolean;

  if (status) {
    active = status === 'active';
  }

  const query: Record<string, any> = {
    ...(websiteCode !== undefined ? { websiteCode } : {}),
    ...(parentId !== undefined ? { parentId } : {}),
    ...(ids ? { _id: { $in: ids } } : {}),
    ...(typeof level === 'number' ? { level } : {}),
    ...(active !== undefined ? { active } : {}),
    ...(term
      ? {
          'name.en': {
            $regex: term,
            $options: 'i',
          },
        }
      : {}),
  };

  const totalRecords: number = await categoryModel.countDocuments(query);
  const categories: Components.Schemas.V1ListCategory = await categoryModel
    .find(
      query,
      {},
      {
        skip: (page - 1) * size,
        limit: size,
        sort: {
          level: 0,
          'name.en': 1,
        },
      },
    )
    .lean();

  const categoriesRes: Components.Schemas.V1ListCategory = await enrichCategoriesWithProductCountV3(
    categories,
  );

  res.json({
    currentPage: page,
    totalPages: Math.ceil(totalRecords / size),
    totalRecords,
    size,
    categories: categoriesRes,
  });
}
