/// <reference path="./../../../types/modules/swagger.d.ts"/>
import { Router } from 'express';
import { Router as IRouter } from 'express-serve-static-core';

import './listener';
import { isAuthenticatedMw } from '@tradeling/web-js-utils';
import { catchAsyncErrors } from '@core/util/router';
import {
  listCategoryAction,
  validateListCategories,
} from './action-list-category';
import {
  getCategoryParentsAction,
  validateGetCategoryParents,
} from './action-get-category-parents';
import {
  getCategoryAttributesAction,
  validateGetCategoryAttributes,
} from './action-get-category-attributes';
import {
  searchCategoryAction,
  validateSearchCategory,
} from './action-search-category';
import {
  getCategoryCommissionAction,
  validateGetCategoryCommission,
} from './action-get-category-commission';
import { backOfficeUserMw } from '@src/config/middleware/is-backoffice-user';
import {
  listCategoryBackofficeAction,
  validateListCategoriesBackoffice,
} from './action-list-category-backoffice';
import {
  validateCreateCategoryCommissionBackoffice,
  createCategoryCommissionBackofficeAction,
} from './action-create-category-commission-backoffice';
import {
  validateGetCategoryCommissionBackoffice,
  getCategoryCommissionBackofficeAction,
} from './action-get-category-commission-backoffice';
import {
  validateDeleteCategoryCommissionBackoffice,
  deleteCategoryCommissionBackofficeAction,
} from './action-delete-category-commission-backoffice';
import {
  validateBulkUpdateCategoryAttributesBackoffice,
  bulkUpdateCategoryAttributesBackofficeAction,
} from './action-bulk-update-category-attributes-backoffice';
import {
  getCategoryTreeValidatorBackoffice,
  getCategoryTreeBackofficeAction,
} from './action-get-category-tree-backoffice';
import {
  validateListCategoryCommissionBackoffice,
  listCategoryCommissionBackofficeAction,
} from './action-list-category-commission-backoffice';
import {
  validateGetFilterableCategoriesBackoffice,
  getFilterableCategoriesBackofficeAction,
} from './action-get-filterable-categories-backoffice';
import {
  validateListCategoryAttributesActionsBackoffice,
  listCategoryAttributesActionsBackofficeAction,
} from './action-list-category-attributes-actions-backoffice';
import {
  attachmentCategoryValidatorBackoffice,
  attachmentCategoryBackofficeAction,
} from './action-attachment-category-backoffice';
import { multerHandler } from '@src/config/middleware/multer-mw';
import {
  validateUpdateCategoryBackoffice,
  updateCategoryBackofficeAction,
} from './action-update-category-backoffice';
import {
  validateUpdateCategoryCommissionBackoffice,
  updateCategoryCommissionBackofficeAction,
} from './action-update-category-commission-backoffice';
import {
  validateCopyCategoryAttributesBackoffice,
  copyCategoryAttributesBackofficeAction,
} from './action-copy-category-attributes-backoffice';
import {
  validateDeleteCategoryAttributesBackoffice,
  deleteCategoryAttributesBackofficeAction,
} from './action-delete-category-attributes-backoffice';
import {
  validateGetCategoryByIdBackoffice,
  getCategoryByIdBackofficeAction,
} from './action-get-category-by-id-backoffice';
import {
  validateGetCategoryParentsBackoffice,
  getCategoryParentsBackofficeAction,
} from './action-get-category-parents-backoffice';
import {
  validateGetCategorySlugBackoffice,
  getCategorySlugBackofficeAction,
} from './action-get-category-slug-backoffice';
import {
  validateIsSlugExistsBackoffice,
  isSlugExistsBackofficeAction,
} from './action-is-slug-exists-backoffice';
import {
  validateListCategoryAttributesBackoffice,
  listCategoryAttributesBackofficeAction,
} from './action-list-category-attributes-backoffice';
import {
  validateListLeafCategoriesBackoffice,
  listLeafCategoryBackofficeAction,
} from './action-list-leaf-category-backoffice';
import {
  validateSearchCategoryBackoffice,
  searchCategoryBackofficeAction,
} from './action-search-category-backoffice';
import {
  validateUpdateCategoryAttributesBackoffice,
  updateCategoryAttributesBackofficeAction,
} from './action-update-category-attributes-backoffice';
import {
  updateCategoryMoqBackofficeAction,
  validateUpdateCategoryMoqBackoffice,
} from './action-update-category-moq-backoffice';
import {
  getCategoryAttributesCountAction,
  getCategoryAttributesCountActionValidator,
} from './action-get-category-attributes-count-backoffice';
import {
  syncCategoryAttributesBackofficeAction,
  syncCategoryAttributesBackofficeValidator,
} from './action-sync-category-attribute-backoffice';
import { authenticateInternalMw } from '@tradeling/web-js-utils';
import {
  internalListCategoryAttributesAction,
  validateInternalListCategoryAttributes,
} from './action-internal-list-category-attributes';
import {
  listCategoryMoqBackofficeAction,
  validateListCategoryMoqBackoffice,
} from './action-list-category-moq-backoffice';
import {
  createCategoryBackofficeV3Action,
  validateV3CreateCategoryBackoffice,
} from './v3/action-create-category-backoffice';
import {
  deleteCategoryBackofficeV3Action,
  validateV3DeleteCategoryBackoffice,
} from './v3/action-delete-category-backoffice';
import {
  getCategoryProductsStatsV3Action,
  validateV3GetCategoryProductsStatsBackoffice,
} from './v3/action-get-category-products-stats-backoffice';
import {
  getPersonalizedCategoriesV3Action,
  validateV3GetPersonalizedCategories,
} from './v3/action-get-personalized-categories';
import {
  getProductsByCategoryBackofficeV3Action,
  validateV3GetProductsByCategoryBackoffice,
} from './v3/action-get-products-by-category-backoffice';
import {
  listProductsByCategoryBackofficeV3Action,
  validateV3ListProductsByCategoryBackoffice,
} from './v3/action-list-products-by-category-backoffice';
import {
  moveProductsToCategoryBackofficeV3Action,
  validateV3MoveProductsToCategoryBackoffice,
} from './v3/action-move-products-to-category-backoffice';
import {
  getBulkAffectableProductsV3Action,
  validateV3GetBulkAffectableProductsBackoffice,
} from './v3/action-bulk-get-affectable-products-backoffice';
import {
  categoryListingBackofficeV3Action,
  validateV3CategoryListingBackoffice,
} from './v3/action-category-listing-backoffice';

const router: IRouter = Router();

router.post(
  '/v1-list-category',
  validateListCategories,
  catchAsyncErrors(listCategoryAction),
);
router.post(
  '/v1-search-category',
  validateSearchCategory,
  catchAsyncErrors(searchCategoryAction),
);
router.post(
  '/v1-get-category-parents',
  isAuthenticatedMw(),
  validateGetCategoryParents,
  catchAsyncErrors(getCategoryParentsAction),
);
router.post(
  '/v1-get-category-attributes',
  isAuthenticatedMw(),
  validateGetCategoryAttributes,
  catchAsyncErrors(getCategoryAttributesAction),
);
router.post(
  '/v1-get-category-commission',
  validateGetCategoryCommission,
  catchAsyncErrors(getCategoryCommissionAction),
);

router.post(
  '/v1-list-category-backoffice',
  backOfficeUserMw([]),
  validateListCategoriesBackoffice,
  catchAsyncErrors(listCategoryBackofficeAction),
);
router.post(
  '/v1-create-category-commission-backoffice',
  backOfficeUserMw([]),
  validateCreateCategoryCommissionBackoffice,
  catchAsyncErrors(createCategoryCommissionBackofficeAction),
);
router.post(
  '/v1-get-category-commission-backoffice',
  backOfficeUserMw([]),
  validateGetCategoryCommissionBackoffice,
  catchAsyncErrors(getCategoryCommissionBackofficeAction),
);
router.post(
  '/v1-delete-category-commission-backoffice',
  backOfficeUserMw([]),
  validateDeleteCategoryCommissionBackoffice,
  catchAsyncErrors(deleteCategoryCommissionBackofficeAction),
);
router.post(
  '/v1-bulk-update-category-attributes-backoffice',
  backOfficeUserMw([]),
  validateBulkUpdateCategoryAttributesBackoffice,
  catchAsyncErrors(bulkUpdateCategoryAttributesBackofficeAction),
);
router.post(
  '/v1-get-category-tree-backoffice',
  backOfficeUserMw([]),
  getCategoryTreeValidatorBackoffice,
  catchAsyncErrors(getCategoryTreeBackofficeAction),
);
router.post(
  '/v1-list-category-commission-backoffice',
  backOfficeUserMw([]),
  validateListCategoryCommissionBackoffice,
  catchAsyncErrors(listCategoryCommissionBackofficeAction),
);
router.post(
  '/v1-get-filterable-categories-backoffice',
  backOfficeUserMw([]),
  validateGetFilterableCategoriesBackoffice,
  catchAsyncErrors(getFilterableCategoriesBackofficeAction),
);
router.post(
  '/v1-list-category-attributes-actions-backoffice',
  backOfficeUserMw([]),
  validateListCategoryAttributesActionsBackoffice,
  catchAsyncErrors(listCategoryAttributesActionsBackofficeAction),
);
router.post(
  '/v1-attachment-category-backoffice',
  backOfficeUserMw([]),
  multerHandler,
  attachmentCategoryValidatorBackoffice,
  catchAsyncErrors(attachmentCategoryBackofficeAction),
);
router.post(
  '/v1-update-category-backoffice',
  backOfficeUserMw([]),
  validateUpdateCategoryBackoffice,
  catchAsyncErrors(updateCategoryBackofficeAction),
);
router.post(
  '/v1-update-category-commission-backoffice',
  backOfficeUserMw([]),
  validateUpdateCategoryCommissionBackoffice,
  catchAsyncErrors(updateCategoryCommissionBackofficeAction),
);
router.post(
  '/v1-copy-category-attributes-backoffice',
  backOfficeUserMw([]),
  validateCopyCategoryAttributesBackoffice,
  catchAsyncErrors(copyCategoryAttributesBackofficeAction),
);
router.post(
  '/v1-delete-category-attributes-backoffice',
  backOfficeUserMw([]),
  validateDeleteCategoryAttributesBackoffice,
  catchAsyncErrors(deleteCategoryAttributesBackofficeAction),
);
router.post(
  '/v1-get-category-by-id-backoffice',
  backOfficeUserMw([]),
  validateGetCategoryByIdBackoffice,
  catchAsyncErrors(getCategoryByIdBackofficeAction),
);
router.post(
  '/v1-get-category-parents-backoffice',
  backOfficeUserMw([]),
  validateGetCategoryParentsBackoffice,
  catchAsyncErrors(getCategoryParentsBackofficeAction),
);
router.post(
  '/v1-get-category-slug-backoffice',
  backOfficeUserMw([]),
  validateGetCategorySlugBackoffice,
  catchAsyncErrors(getCategorySlugBackofficeAction),
);
router.post(
  '/v1-is-slug-exit-backoffice',
  backOfficeUserMw([]),
  validateIsSlugExistsBackoffice,
  catchAsyncErrors(isSlugExistsBackofficeAction),
);
router.post(
  '/v1-list-category-attributes-backoffice',
  backOfficeUserMw([]),
  validateListCategoryAttributesBackoffice,
  catchAsyncErrors(listCategoryAttributesBackofficeAction),
);
router.post(
  '/v1-list-category-attributes-actions-backoffice',
  backOfficeUserMw([]),
  validateListCategoryAttributesActionsBackoffice,
  catchAsyncErrors(listCategoryAttributesBackofficeAction),
);
router.post(
  '/v1-list-leaf-category-backoffice',
  backOfficeUserMw([]),
  validateListLeafCategoriesBackoffice,
  catchAsyncErrors(listLeafCategoryBackofficeAction),
);
router.post(
  '/v1-search-category-backoffice',
  backOfficeUserMw([]),
  validateSearchCategoryBackoffice,
  catchAsyncErrors(searchCategoryBackofficeAction),
);
router.post(
  '/v1-update-category-attributes-backoffice',
  backOfficeUserMw([]),
  validateUpdateCategoryAttributesBackoffice,
  catchAsyncErrors(updateCategoryAttributesBackofficeAction),
);
router.post(
  '/v1-get-category-attributes-count-backoffice',
  backOfficeUserMw([]),
  getCategoryAttributesCountActionValidator,
  catchAsyncErrors(getCategoryAttributesCountAction),
);
router.post(
  '/v1-list-category-moq-backoffice',
  backOfficeUserMw([]),
  validateListCategoryMoqBackoffice,
  catchAsyncErrors(listCategoryMoqBackofficeAction),
);

router.post(
  '/v1-update-category-moq-backoffice',
  backOfficeUserMw([]),
  validateUpdateCategoryMoqBackoffice,
  catchAsyncErrors(updateCategoryMoqBackofficeAction),
);
router.post(
  '/v1-sync-category-attribute-backoffice',
  backOfficeUserMw([]),
  syncCategoryAttributesBackofficeValidator,
  syncCategoryAttributesBackofficeAction,
);
router.post(
  '/v1-internal-list-category-attributes',
  authenticateInternalMw,
  validateInternalListCategoryAttributes,
  catchAsyncErrors(internalListCategoryAttributesAction),
);

// v3 routes
router.post(
  '/v3-create-category-backoffice',
  backOfficeUserMw([]),
  validateV3CreateCategoryBackoffice,
  catchAsyncErrors(createCategoryBackofficeV3Action),
);
router.post(
  '/v3-delete-category-backoffice',
  backOfficeUserMw([]),
  validateV3DeleteCategoryBackoffice,
  catchAsyncErrors(deleteCategoryBackofficeV3Action),
);
router.post(
  '/v3-get-category-products-stats-backoffice',
  backOfficeUserMw([]),
  validateV3GetCategoryProductsStatsBackoffice,
  catchAsyncErrors(getCategoryProductsStatsV3Action),
);
router.post(
  '/v3-list-personalized-categories',
  validateV3GetPersonalizedCategories,
  catchAsyncErrors(getPersonalizedCategoriesV3Action),
);
router.post(
  '/v3-get-products-by-category-backoffice',
  backOfficeUserMw([]),
  validateV3GetProductsByCategoryBackoffice,
  catchAsyncErrors(getProductsByCategoryBackofficeV3Action),
);
router.post(
  '/v3-list-products-by-category-backoffice',
  backOfficeUserMw([]),
  validateV3ListProductsByCategoryBackoffice,
  catchAsyncErrors(listProductsByCategoryBackofficeV3Action),
);

router.post(
  '/v3-move-products-to-category-backoffice',
  backOfficeUserMw([]),
  validateV3MoveProductsToCategoryBackoffice,
  catchAsyncErrors(moveProductsToCategoryBackofficeV3Action),
);
router.post(
  '/v3-bulk-get-affectable-products-backoffice',
  backOfficeUserMw([]),
  validateV3GetBulkAffectableProductsBackoffice,
  catchAsyncErrors(getBulkAffectableProductsV3Action),
);
router.post(
  '/v3-category-listing-backoffice',
  backOfficeUserMw([]),
  validateV3CategoryListingBackoffice,
  catchAsyncErrors(categoryListingBackofficeV3Action),
);

export { router as categoryRoutes };
