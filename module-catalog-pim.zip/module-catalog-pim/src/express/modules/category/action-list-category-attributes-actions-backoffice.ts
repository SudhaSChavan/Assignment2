import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import {
  categoryAttributeModel,
  CategoryAttributeType,
} from './model-category-attribute';

interface IReq extends IAppRequest {
  body: Paths.V1ListCategoryAttributesBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body:
      | Paths.V1ListCategoryAttributesBackofficeAction.Responses.$200
      | Paths.V1ListCategoryAttributesBackofficeAction.Responses.$400,
  ) => this;
}

export const validateListCategoryAttributesActionsBackoffice: BaseValidationType = [
  reqValidationResult,
];

export async function listCategoryAttributesActionsBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const attributes: CategoryAttributeType[] = await getAttributes();

  res.json(attributes);
}

async function getAttributes(): Promise<CategoryAttributeType[]> {
  return categoryAttributeModel.aggregate([
    { $unwind: '$attributes' },
    {
      $group: {
        _id: '$attributes.code',
        type: { $first: '$attributes.type' },
        label: { $first: '$attributes.label' },
        help: { $first: '$attributes.help' },
        valueHelp: { $first: '$attributes.valueHelp' },
        isFilterable: { $first: '$attributes.isFilterable' },
        sort: { $first: '$attributes.sort' },
        code: { $first: '$attributes.code' },
        default: { $first: '$attributes.default' },
        allowedValues: { $first: '$attributes.allowedValues' },
        required: { $first: '$attributes.required' },
        strict: { $first: '$attributes.strict' },
        example: { $first: '$attributes.example' },
        isLocalized: { $first: '$attributes.isLocalized' },
        showCount: { $first: '$attributes.showCount' },
        metadata: { $first: '$attributes.metadata' },
        minValue: { $first: '$attributes.minValue' },
        maxValue: { $first: '$attributes.maxValue' },
        isInteger: { $first: '$attributes.isInteger' },
      },
    },
    {
      $sort: {
        code: 1,
      },
    },
  ]);
}
