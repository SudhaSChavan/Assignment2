import {
  find as lodashFind,
  isBoolean,
  isEmpty,
  isEqual,
  isNull,
  isObject,
  isString,
  map,
} from 'lodash';
import { categoryModel, ICategoryModel } from './model-category';
import { categoryUpdateListener } from './listener-category-update';
import {
  categoryAttributeModel,
  ICategoryAttributeModel,
} from './model-category-attribute';
import { categoryAttributeUpdateListener } from './listener-category-attribute-update';
import { auditFields } from '@express/modules/product/send-product-audit-event';

const importCategoriesMaxLimit: number = 20;
const importAttributesMaxLimit: number = 10;

export async function syncCategories(): Promise<void> {
  const categoryIds: string[] = map(
    await categoryModel.find({}, '_id').lean(),
    '_id',
  ).map(String);

  while (categoryIds.length) {
    const ids: string[] = categoryIds.splice(0, importCategoriesMaxLimit);

    await categoryUpdateListener(ids);
  }

  const categoryAttributeIds: string[] = map(
    await categoryAttributeModel.find({}, '_id').lean(),
    '_id',
  ).map(String);

  while (categoryAttributeIds.length) {
    const ids: string[] = categoryAttributeIds.splice(
      0,
      importAttributesMaxLimit,
    );

    await categoryAttributeUpdateListener(ids);
  }
}

export function getAuditForCategory(
  body: Paths.V1UpdateCategoryBackofficeAction.RequestBody,
  category: ICategoryModel,
): auditFields[] {
  const fieldsToCompare: string[] = [
    'active',
    'description',
    'keywords',
    'slug',
    'weight',
    'name',
    'parentId',
    'listingPageTitle',
    'listingPageSubtitle',
    'listingPageImageMediaId',
    'listingPageImageLink',
    'listingPageImagePath',
  ];

  const diffFields: auditFields[] = [];
  for (const key of fieldsToCompare) {
    if (
      (isString(body[key]) || isBoolean(body[key])) &&
      body[key] != category[key]
    ) {
      diffFields.push({
        name: key,
        old: category[key],
        new: body[key],
      });
    }

    if (
      isObject(body[key]) &&
      !isEmpty(body[key]) &&
      !isEqual(body[key], category[key])
    ) {
      for (const subKey of Object.keys(body[key])) {
        if (
          JSON.stringify(body[key][subKey]) ===
            JSON.stringify(category[key][subKey]) ||
          (isEmpty(body[key][subKey]) && isEmpty(category[key][subKey]))
        ) {
          continue;
        }
        diffFields.push({
          name: `${key}.${subKey}`,
          old: category[key][subKey],
          new: body[key][subKey],
        });
      }
    }

    /**
     * in case previously values exists and now its becoming null
     */
    if (
      isObject(body[key]) &&
      isNull(body[key]) &&
      !isEqual(body[key], category[key])
    ) {
      diffFields.push({
        name: key,
        old: category[key],
        new: body[key],
      });
    }
  }

  return diffFields;
}

export async function getAuditForCategoryAttributes(
  categoryAttributesBody: Components.Schemas.V1CategoryAttributeBackoffice[],
  categoryId: string,
): Promise<auditFields[]> {
  const fieldsToCompare: string[] = [
    'sort',
    'allowedValues',
    'isFilterable',
    'isLocalized',
    'showCount',
    'type',
    'label',
    'help',
    'valueHelp',
    'code',
    'default',
    'required',
    'strict',
    'example',
    'metadata',
    'minValue',
    'maxValue',
    'isInteger',
  ];

  const categoryAttributes: ICategoryAttributeModel = await categoryAttributeModel.findOne(
    {
      categoryId,
    },
  );

  const diffFields: auditFields[] = [];

  for (const attributeItems of categoryAttributesBody) {
    const dbValues: Record<string, any> = lodashFind(
      categoryAttributes.attributes,
      (attribute) => {
        return attribute.id.toString() === attributeItems['id'];
      },
    );

    if (!dbValues) {
      continue;
    }

    for (const key of fieldsToCompare) {
      if (
        (isString(attributeItems[key]) || isBoolean(attributeItems[key])) &&
        attributeItems[key] != dbValues[key]
      ) {
        diffFields.push({
          name: `${attributeItems.code}.${key}`,
          old: dbValues[key],
          new: attributeItems[key],
        });
      }

      if (
        isObject(attributeItems[key]) &&
        !isEmpty(attributeItems[key]) &&
        !isEqual(attributeItems[key], dbValues[key])
      ) {
        for (const subKey of Object.keys(dbValues[key])) {
          if (
            JSON.stringify(attributeItems[key][subKey]) ===
              JSON.stringify(dbValues[key][subKey]) ||
            (isEmpty(attributeItems[key][subKey]) &&
              isEmpty(dbValues[key][subKey]))
          ) {
            continue;
          }
          diffFields.push({
            name: `${attributeItems.code}.${key}.${subKey}`,
            old: dbValues[key][subKey],
            new: attributeItems[key][subKey],
          });
        }
      }

      /**
       * in case previously values exists and now its becoming null
       */
      if (
        isObject(attributeItems[key]) &&
        isNull(attributeItems[key]) &&
        !isEqual(attributeItems[key], dbValues[key])
      ) {
        diffFields.push({
          name: `${attributeItems.code}.${key}`,
          old: dbValues[key],
          new: attributeItems[key],
        });
      }
    }
  }

  return diffFields;
}
