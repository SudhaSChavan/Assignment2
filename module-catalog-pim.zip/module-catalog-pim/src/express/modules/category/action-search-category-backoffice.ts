import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { ERRORS } from '@src/types/errors';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { categoryModel, ICategoryModel } from './model-category';

interface IReq extends IAppRequest {
  body: Paths.V1SearchCategoryBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body:
      | Paths.V1SearchCategoryBackofficeAction.Responses.$200
      | Paths.V1SearchCategoryBackofficeAction.Responses.$400,
  ) => this;
}

export const validateSearchCategoryBackoffice: BaseValidationType = [
  body('term').notEmpty().isString().withMessage(ERRORS.INVALID),
  body('websiteCode').notEmpty().isString().withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function searchCategoryBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { term, websiteCode } = req.body;

  const query: Record<string, any> = {
    $or: [
      {
        'name.en': {
          $regex: term,
          $options: 'i',
        },
      },
      {
        'description.en': {
          $regex: term,
          $options: 'i',
        },
      },
    ],
    websiteCode: websiteCode,
    active: true,
    'children.0': {
      $exists: false,
    },
  };

  const categories: ICategoryModel[] = await categoryModel
    .find(
      query,
      {},
      {
        limit: 100,
      },
    )
    .populate('parents', 'name level')
    .lean();

  res.json(categories as any);
}
