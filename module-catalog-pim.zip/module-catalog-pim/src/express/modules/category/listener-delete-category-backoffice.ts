import { V1DeleteCategoryAction } from '@tradeling/tradeling-sdk/catalog-search/v1-delete-category-action';

export interface IDeleteCategoryListener {
  categoryIds: string[];
}

export async function deleteCategoryListener(
  data: IDeleteCategoryListener,
): Promise<void> {
  if (!data?.categoryIds?.length) {
    return;
  }

  await V1DeleteCategoryAction({ ids: data.categoryIds });
}
