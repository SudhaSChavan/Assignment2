import { categoryModel, ICategoryModel } from './model-category';
import { V1IndexCategoryAction } from '@tradeling/tradeling-sdk/catalog-search/v1-index-category-action';

export async function categoryUpdateListener(
  categoryIds: string[],
): Promise<void> {
  const categories: ICategoryModel[] = await categoryModel
    .find({ _id: { $in: categoryIds } })
    .lean();
  const data: any[] = categories.map((category: ICategoryModel): any => {
    return {
      _id: category._id,
      id: category._id,
      name: category.name,
      slug: category.slug,
      level: category.level,
      active: Boolean(category.active),
      parentId: category.parentId,
      parents: category.parents,
      keywords: category.keywords,
      children: category.children,
      weight: category.weight,
      listingPageImageLink: category.listingPageImageLink,
      listingPageImageMediaId: category.listingPageImageMediaId,
    };
  });

  await V1IndexCategoryAction(
    { data },
    { headers: { 'x-country': 'ae', 'x-language': 'en' } },
  );
}
