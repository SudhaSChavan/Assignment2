import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import V1CategoryCommission = Components.Schemas.V1CategoryCommission;
import { body } from 'express-validator';
import {
  categoryCommissionModel,
  ICategoryCommissionModel,
} from './model-category-commission';
import { categoryModel, ICategoryModel } from './model-category';

interface IReq extends IAppRequest {
  body: Paths.V1GetCategoryCommissionBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body: Paths.V1GetCategoryCommissionBackofficeAction.Responses.$200,
  ) => this;
}

export const validateGetCategoryCommissionBackoffice: BaseValidationType = [
  body('id').notEmpty().isMongoId(),
  reqValidationResult,
];

export async function getCategoryCommissionBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { id } = req.body;

  const categoryCommission: ICategoryCommissionModel = await categoryCommissionModel
    .findById(id)
    .lean();
  const transformedCategoryCommission: V1CategoryCommission = await transformCategoryCommission(
    categoryCommission,
  );

  res.json(transformedCategoryCommission);
}

async function transformCategoryCommission(
  categoryCommission: ICategoryCommissionModel,
): Promise<V1CategoryCommission> {
  const category: ICategoryModel = await categoryModel
    .findById(categoryCommission.categoryId)
    .lean();
  return {
    ...categoryCommission,
    name: category.name.en,
  } as V1CategoryCommission;
}
