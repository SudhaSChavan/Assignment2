import { FilterQuery } from 'mongoose';
import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils';

import { ERRORS } from '@src/types/errors';
import { appConfig } from '@src/config/env';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { categoryModel, ICategoryModel } from './model-category';

interface IReq extends IAppRequest {
  body: Paths.V1ListCategoryMoqBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1ListCategoryMoqBackofficeAction.Responses.$200) => this;
}

export const validateListCategoryMoqBackoffice: BaseValidationType = [
  body('page').optional().isInt({ gt: 0 }).withMessage(ERRORS.INVALID),
  body('limit')
    .optional()
    .isInt({ lt: appConfig.category.listMaxLimit, gt: 0 })
    .withMessage(ERRORS.INVALID),
  body('filter.term').optional().isString().withMessage(ERRORS.INVALID),
  body('filter.websiteCode').optional().isString().withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function listCategoryMoqBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    page = 1,
    filter: { term = '', websiteCode = undefined } = {},
    limit = appConfig.category.listDefaultLimit,
  } = req.body;

  const query: FilterQuery<ICategoryModel> = {
    ...(websiteCode !== undefined ? { websiteCode } : {}),
    $or: [
      {
        'name.en': {
          $regex: term,
          $options: 'ig',
        },
      },
      {
        'name.ar': {
          $regex: term,
          $options: 'ig',
        },
      },
    ],
  };

  const totalRecords: number = await categoryModel.countDocuments(query);
  const categoryMoqs: Components.Schemas.V1CategoryMoq[] = await categoryModel
    .find(
      query,
      {
        moq: 1,
        _id: 1,
        name: 1,
        createdAt: 1,
        updatedAt: 1,
        level: 1,
        children: 1,
      },
      {
        limit,
        skip: (page - 1) * limit,
        sort: {
          'name.en': 1,
        },
      },
    )
    .lean();

  res.json({
    limit,
    totalRecords,
    currentPage: page,
    categoryMoqs,
    total: Math.ceil(totalRecords / limit),
  });
}
