import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { ERRORS } from '@src/types/errors';
import { categoryModel } from './model-category';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { validateCategoryId } from '@core/util/validators';

interface IReq extends IAppRequest {
  body: Paths.V1GetCategoryParentsAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1GetCategoryParentsAction.Responses.$200) => this;
}

export const validateGetCategoryParents: BaseValidationType = [
  body('id').notEmpty().custom(validateCategoryId).withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function getCategoryParentsAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { id: categoryId } = req.body;

  const category: Components.Schemas.V1Category = await categoryModel.findById(
    categoryId,
  );

  const parentIds: string[] = category.parents;
  let parentCategories: Components.Schemas.V1Category[] = [];

  if (parentIds && parentIds.length !== 0) {
    parentCategories = await categoryModel.find(
      {
        _id: {
          $in: parentIds,
        },
      },
      {},
      {
        sort: {
          level: 1,
        },
      },
    );
  }

  res.json([...parentCategories, category]);
}
