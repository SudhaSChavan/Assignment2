import { appConfig, isAuditEnabled } from '@src/config/env';
import { logger } from '@core/util/logger';
import { sendAuditEvent } from '@express/modules/product/helpers';
import { CategoryAuditEventType } from '@express/modules/category/types';
import { IBaseAppUser } from '@tradeling/web-js-utils';
import { DatabaseType, V1AuditEventMessageData } from '@tradeling/emit-audit';
import { isArray } from 'lodash';
import { IAppRequest } from '@src/types/app-request';

import { EE } from '@src/config/event/emitter';
import { EntityType } from '@tradeling/emit-audit/dist/common-audit/src';

export enum CategoryAuditEventEnum {
  Created = 'event.category.created',
  Updated = 'event.category.updated',
  Deleted = 'event.category.deleted',
  AttributeChange = 'event.category.attributes.updated',
  AttributeDelete = 'event.category.attributes.delete',
  AttributeCopy = 'event.category.attributes.copy',
}

function assembleData(
  entityType,
  loginDetails: string,
  descriptiveMessage: string,
  userJwtDecoded,
  actionType: number,
  categoryId: string,
  data:
    | { name: string; old: string; new: string }
    | ({ name: string; old: string; new: string } & any[]),
): V1AuditEventMessageData {
  return {
    entityType,
    username: loginDetails,
    description: descriptiveMessage,
    userId: userJwtDecoded?._id || null,
    dataSource: 'module-catalog-pim',
    dbActionType: actionType,
    databaseType: DatabaseType.MongoDB,
    time: Date.now(),
    Affected: [
      {
        key: categoryId,
        fields: Array.isArray(data) ? data : [data],
      },
    ],
    eventSource: {
      module: appConfig.name,
      host: 'external-host',
    },
  };
}
function transmitMultipleEvents(
  categoryIds: string[],
  entityType,
  loginDetails: string,
  descriptiveMessage: string,
  userJwtDecoded,
  actionType: number,
  data:
    | { name: string; old: string; new: string }
    | ({ name: string; old: string; new: string } & any[]),
) {
  categoryIds.map((categoryId) => {
    const stats: V1AuditEventMessageData = assembleData(
      entityType,
      loginDetails,
      descriptiveMessage,
      userJwtDecoded,
      actionType,
      categoryId,
      data,
    );

    sendAuditEvent(stats, descriptiveMessage);
  });
}

export function dispatchCategoryAuditEvent(
  params: CategoryAuditEventType,
): void {
  if (!isAuditEnabled) {
    logger.info(`listener audit event is disabled`);
    return;
  }

  const {
    categoryIds,
    actionType,
    description,
    data,
    req,
    entityType,
  } = params;

  if (!isArray(categoryIds)) {
    logger.error(`Audit-Category-Event: categoryIds could not be empty`);
    return;
  }

  const userJwtDecoded: IBaseAppUser = req?.userJwtDecoded as IBaseAppUser;

  const userName: string =
    userJwtDecoded?.username ||
    `${userJwtDecoded?.firstName} ${userJwtDecoded?.lastName}` ||
    '';
  const isLoggedInAs: boolean = userJwtDecoded?.isLoggedInAs;
  const impersonatingEmail: string =
    userJwtDecoded?.metadata?.loggedInAsDetail?.requesterEmail || '';
  const loginDetails: string = isLoggedInAs
    ? `impersonating user ${userName} from ${impersonatingEmail} `
    : userName;
  const descriptiveMessage: string = `${
    req?.url || description || 'undefined action'
  } Fired`;

  transmitMultipleEvents(
    categoryIds,
    entityType,
    loginDetails,
    descriptiveMessage,
    userJwtDecoded,
    actionType,
    data,
  );
}

export function fireCategoryAuditEvent(
  eventToEmit: CategoryAuditEventEnum,
  categoryIds: string[],
  actionType: number,
  req: IAppRequest,
  fields: any = null,
  description = '',
): void {
  EE.emit(eventToEmit, {
    actionType: actionType,
    categoryIds,
    req,
    description,
    data: {
      ...fields,
    },
    entityType: EntityType.Category,
  } as CategoryAuditEventType).catch((error: Error): void => {
    logger.error(`Event ${eventToEmit} failed: ${error.stack}`);
  });
}
