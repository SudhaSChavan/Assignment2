import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { ERRORS } from '@src/types/errors';
import { appConfig } from '@src/config/env';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import {
  categoryAttributeModel,
  ICategoryAttributeModel,
} from './model-category-attribute';

interface IReq extends IAppRequest {
  body: Paths.V1ListCategoryAttributesBoBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body:
      | Paths.V1ListCategoryAttributesBoBackofficeAction.Responses.$200
      | Paths.V1ListCategoryAttributesBoBackofficeAction.Responses.$400,
  ) => this;
}

export const validateListCategoryAttributesBackoffice: BaseValidationType = [
  body('filter.categoryIds').isArray(),
  body('page').optional().isInt({ gt: 0 }).withMessage(ERRORS.INVALID),
  body('size')
    .optional()
    .isInt({ lt: appConfig.category.listMaxLimit + 1, gt: 0 })
    .withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function listCategoryAttributesBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    page = 1,
    size = appConfig.category.listDefaultLimit,
    filter: { categoryIds },
  } = req.body;

  const totalRecords: number = await categoryAttributeModel.countDocuments();
  const attributes: ICategoryAttributeModel[] = await categoryAttributeModel
    .find(
      {
        ...(categoryIds?.length
          ? {
              categoryId: {
                $in: categoryIds,
              },
            }
          : {}),
      },
      {},
      {
        skip: (page - 1) * size,
        limit: size,
      },
    )
    .lean();

  res.json({
    currentPage: page,
    totalPages: Math.ceil(totalRecords / size),
    totalRecords,
    size,
    attributes: attributes as any,
  });
}
