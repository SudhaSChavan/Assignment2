import { range } from 'lodash';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { ICategoryTree } from './types';
import { redis as redisClient } from '@src/config/redis';
import { appConfig } from '@src/config/env';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { categoryModel, ICategoryModel } from './model-category';

interface IReq extends IAppRequest {
  body: Paths.V1GetCategoryTreeBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1GetCategoryTreeBackofficeAction.Responses.$200) => this;
}

export const getCategoryTreeValidatorBackoffice: BaseValidationType = [
  reqValidationResult,
];

export async function getCategoryTreeBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<IRes> {
  const { maxLevel = 4 } = req.body;
  const language: string = req.headers['x-language'];
  const cacheKey: string = `cat_tree_${language}_${maxLevel}`;

  const hasCache: number = await redisClient.exists(cacheKey);

  if (hasCache) {
    return res.json(JSON.parse(await redisClient.get(cacheKey)));
  }

  let flatCategories: ICategoryModel[] = [];

  for (const level of range(maxLevel)) {
    flatCategories = [...flatCategories, ...(await getCategories(level))];
  }

  const categoryTree: ICategoryTree[] = prepareTree(flatCategories);

  if (categoryTree.length) {
    await redisClient.set(
      cacheKey,
      JSON.stringify(categoryTree),
      'EX',
      appConfig.categoryTTLSecs,
    );
  }

  return res.json(categoryTree as any);
}

function prepareTree(
  categories: ICategoryModel[],
  parentId: string = null,
): ICategoryTree[] {
  const categoryTree: ICategoryTree[] = [];
  for (const category of categories) {
    if (category.parentId?.toString() != parentId?.toString()) {
      continue;
    }

    const categoryTreeNode: ICategoryTree = {
      label: category.name.en,
      value: category._id,
    };
    const children: ICategoryTree[] = prepareTree(categories, category._id);

    if (children.length) {
      categoryTreeNode.children = children;
    }

    categoryTree.push(categoryTreeNode);
  }
  return categoryTree;
}

async function getCategories(level: number): Promise<ICategoryModel[]> {
  return categoryModel
    .find({
      level,
    })
    .lean();
}
