import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { categoryAttributeModel } from './model-category-attribute';
import { syncOneCategoryAttributes } from './action-sync-category-attribute-backoffice';
import {
  CategoryAuditEventEnum,
  fireCategoryAuditEvent,
} from '@express/modules/category/dispatch-category-audit-event';
import { Event as TargetEvent } from '@tradeling/emit-audit';

interface IReq extends IAppRequest {
  body: Paths.V1DeleteCategoryAttributesBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body:
      | Paths.V1DeleteCategoryAttributesBackofficeAction.Responses.$200
      | Paths.V1DeleteCategoryAttributesBackofficeAction.Responses.$400,
  ) => this;
}

export const validateDeleteCategoryAttributesBackoffice: BaseValidationType = [
  // prettier-ignore
  body('categoryIds')
    .notEmpty()
    .isArray()
    .isMongoId(),
  reqValidationResult,
];

export async function deleteCategoryAttributesBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { categoryIds } = req.body;

  await categoryAttributeModel.deleteMany({
    categoryId: {
      $in: categoryIds,
    },
  });

  // sync category attributes
  await syncOneCategoryAttributes(categoryIds);

  fireCategoryAuditEvent(
    CategoryAuditEventEnum.AttributeDelete,
    categoryIds,
    TargetEvent.Deleted,
    req,
    {},
    'Category attribute deletion action performed',
  );

  res.json({ isDeleted: true });
}
