import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { EE } from '@src/config/event/emitter';
import { logger } from '@core/util/logger';
import {
  categoryAttributeModel,
  CategoryAttributeType,
  ICategoryAttributeModel,
} from './model-category-attribute';
import { categoryModel, ICategoryModel } from './model-category';
import { syncOneCategoryAttributes } from './action-sync-category-attribute-backoffice';
import {
  CategoryAuditEventEnum,
  fireCategoryAuditEvent,
} from '@express/modules/category/dispatch-category-audit-event';
import { Event as TargetEvent } from '@tradeling/emit-audit';

export enum CopyCategoryAttributesEvent {
  Success = 'category.attributes.copy.success',
}

interface IReq extends IAppRequest {
  body: Paths.V1CopyCategoryAttributesBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body: Paths.V1CopyCategoryAttributesBackofficeAction.Responses.$200,
  ) => this;
}

export const validateCopyCategoryAttributesBackoffice: BaseValidationType = [
  // prettier-ignore
  body('sourceCategoryId')
    .notEmpty()
    .isMongoId(),
  // prettier-ignore
  body('targetCategoryIds')
    .notEmpty()
    .isArray()
    .isMongoId(),
  reqValidationResult,
];

export async function copyCategoryAttributesBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { sourceCategoryId, targetCategoryIds } = req.body;
  const bulkQuery: Record<any, any>[] = [];

  const sourceCategoryAttributes: ICategoryAttributeModel = await categoryAttributeModel
    .findOne({
      categoryId: sourceCategoryId,
    })
    .lean();

  // _id and id must be unique in attributes, omit them while copying
  const attributesToCopy: Partial<CategoryAttributeType>[] = sourceCategoryAttributes?.attributes?.map(
    (attribute: CategoryAttributeType): Partial<CategoryAttributeType> => {
      // tslint:disable-next-line:ext-variable-name
      const { id, _id, ...rest } = attribute as any;

      return rest;
    },
  );

  // Find all the leaf category under the given target category ids
  const targetLeafCategories: ICategoryModel[] = await categoryModel.find({
    $or: [
      {
        parents: { $in: targetCategoryIds },
        children: { $size: 0 },
      },
      {
        _id: { $in: targetCategoryIds },
        children: { $size: 0 },
      },
    ],
  });

  // For each of the leaf categories, assign the categoryId, categoryTree
  targetLeafCategories?.forEach((targetCategory: ICategoryModel): void => {
    bulkQuery.push({
      updateOne: {
        filter: {
          categoryId: targetCategory._id,
        },
        update: {
          $set: {
            categoryId: targetCategory._id,
            categoryTree: [
              ...(targetCategory?.parents || []),
              targetCategory._id,
            ],
            attributes: attributesToCopy,
          },
        },
        upsert: true,
      },
    });
  });

  await categoryAttributeModel.bulkWrite(bulkQuery);
  // sync category attributes - in background
  targetLeafCategories?.forEach((targetCategory: ICategoryModel): void => {
    logger.info(
      `Syncing category attributes for category ${targetCategory._id}`,
    );
    syncOneCategoryAttributes([targetCategory._id]);
  });

  EE.emit(CopyCategoryAttributesEvent.Success, {}).catch(
    (error: Error): void => {
      logger.error(
        `Event ${CopyCategoryAttributesEvent.Success} failed: ${error.stack}`,
      );
    },
  );

  fireCategoryAuditEvent(
    CategoryAuditEventEnum.AttributeCopy,
    targetCategoryIds,
    TargetEvent.Inserted,
    req,
    {},
    'New copy category attributes action performed',
  );

  res.json({ isUpdated: true });
}
