import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { ERRORS } from '@src/types/errors';
import { appConfig } from '@src/config/env';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { categoryModel } from './model-category';

interface IReq extends IAppRequest {
  body: Paths.V1ListLeafCategoryBoBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body:
      | Paths.V1ListLeafCategoryBoBackofficeAction.Responses.$200
      | Paths.V1ListLeafCategoryBoBackofficeAction.Responses.$400,
  ) => this;
}

export const validateListLeafCategoriesBackoffice: BaseValidationType = [
  body('filter.parentId')
    .optional({ nullable: true })
    .isString()
    .withMessage(ERRORS.INVALID),
  body('filter.level')
    .optional({ nullable: true })
    .isNumeric()
    .withMessage(ERRORS.INVALID),
  body('filter.text')
    .optional({ nullable: true })
    .isString()
    .withMessage(ERRORS.INVALID),
  body('filter.status')
    .optional({ nullable: true })
    .isString()
    .withMessage(ERRORS.INVALID),
  body('filter.ids.*')
    .optional({ nullable: true })
    .isString()
    .withMessage(ERRORS.INVALID),
  body('page').optional().isInt({ gt: 0 }).withMessage(ERRORS.INVALID),
  body('size')
    .optional()
    .isInt({ lt: appConfig.category.listMaxLimit + 1, gt: 0 })
    .withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function listLeafCategoryBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    page = 1,
    size = appConfig.category.listDefaultLimit,
    filter: {
      parentId = undefined,
      level = undefined,
      ids = undefined,
      term = undefined,
    } = {},
  } = req.body;

  const query: Record<string, any> = {
    children: { $exists: true, $eq: [] },
    ...(parentId !== undefined ? { parentId } : {}),
    ...(ids ? { _id: { $in: ids } } : {}),
    ...(typeof level === 'number' ? { level } : {}),
    ...(term
      ? {
          'name.en': {
            $regex: term,
            $options: 'i',
          },
        }
      : {}),
  };

  const totalRecords: number = await categoryModel.countDocuments(query);
  const categories: Components.Schemas.V1CategoryBackoffice[] = await categoryModel
    .find(
      query,
      {},
      {
        skip: (page - 1) * size,
        limit: size,
      },
    )
    .lean();

  res.json({
    currentPage: page,
    totalPages: Math.ceil(totalRecords / size),
    totalRecords,
    size,
    categories,
  });
}
