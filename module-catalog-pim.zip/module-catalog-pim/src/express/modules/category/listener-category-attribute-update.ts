import { V1IndexCategoryMetadataAction } from '@tradeling/tradeling-sdk/catalog-search/v1-index-category-metadata-action';
import {
  categoryAttributeModel,
  CategoryAttributeType,
  ICategoryAttributeModel,
} from './model-category-attribute';

export async function categoryAttributeUpdateListener(
  categoryAttributeIds: string[],
): Promise<void> {
  const attributes: ICategoryAttributeModel[] = await categoryAttributeModel
    .find({ _id: { $in: categoryAttributeIds } })
    .lean();

  const data: any[] = attributes.flatMap(
    (attribute: ICategoryAttributeModel): any => {
      return attribute.attributes.map((attr: CategoryAttributeType): any => {
        return {
          _id: attr.id,
          id: attr.id,
          categoryId: attribute.categoryId,
          categoryTree: attribute.categoryTree,
          code: attr.code,
          label: {
            en: attr.label.en,
            ar: attr.label.ar,
          },
          type: attr.type,
          allowedValues: attr.allowedValues,
          isFilterable: attr.isFilterable,
          isLocalized: attr.isLocalized,
          showCount: attr.showCount,
          strict: attr.strict,
          required: attr.required,
          help: attr.help.en,
          default: attr.default,
        };
      });
    },
  );

  await V1IndexCategoryMetadataAction(
    { data },
    { headers: { 'x-country': 'ae', 'x-language': 'en' } },
  );
}
