import { IMediaFile } from '@src/types/common';
import { KeyValStr } from '@tradeling/web-js-utils';
import { IAppRequest } from '@src/types/app-request';
import { EntityType } from '@tradeling/emit-audit/dist/common-audit/src/types/entityType';

// Mapping for where the short ids for different levels start
export const levelIdStartMapping: {
  [key: number]: number;
} = {
  0: 100,
  1: 2000,
  2: 3000,
  3: 8000,
};

export interface ICategoryTree {
  label: string;
  value: string;
  children?: ICategoryTree[];
}
export type AttachmentCategoryType = {
  files: IMediaFile[];
  metadata: KeyValStr;
  categoryId: string;
};

export type CategoryAuditEventType = {
  actionType: number;
  req?: IAppRequest;
  entityType?: EntityType;
  description?: string;
  categoryIds: string[];

  data: {
    name: string;
    old: string;
    new: string;
  };
};
