import { EE } from '@src/config/event/emitter';
import { deleteCategoryListener } from './listener-delete-category-backoffice';
import { CategoryDeleteEvent } from './v3/action-delete-category-backoffice';
import {
  CategoryAuditEventEnum,
  dispatchCategoryAuditEvent,
} from '@express/modules/category/dispatch-category-audit-event';

EE.on(CategoryDeleteEvent.Success, deleteCategoryListener);

// log Category performed action
EE.on(CategoryAuditEventEnum.Created, dispatchCategoryAuditEvent);
EE.on(CategoryAuditEventEnum.Updated, dispatchCategoryAuditEvent);
EE.on(CategoryAuditEventEnum.Deleted, dispatchCategoryAuditEvent);
EE.on(CategoryAuditEventEnum.AttributeChange, dispatchCategoryAuditEvent);
EE.on(CategoryAuditEventEnum.AttributeDelete, dispatchCategoryAuditEvent);
EE.on(CategoryAuditEventEnum.AttributeCopy, dispatchCategoryAuditEvent);
