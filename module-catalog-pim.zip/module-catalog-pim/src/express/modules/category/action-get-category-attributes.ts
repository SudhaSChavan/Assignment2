import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { ERRORS } from '@src/types/errors';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { validateCategoryId } from '@core/util/validators';
import {
  categoryAttributeModel,
  ICategoryAttributeModel,
} from './model-category-attribute';

interface IReq extends IAppRequest {
  body: Paths.V1GetCategoryAttributesAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1GetCategoryAttributesAction.Responses.$200) => this;
}

export const validateGetCategoryAttributes: BaseValidationType = [
  body('id').notEmpty().custom(validateCategoryId).withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function getCategoryAttributesAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { id: categoryId } = req.body;

  const attributes: ICategoryAttributeModel = await categoryAttributeModel
    .findOne({
      categoryId,
    })
    .lean();

  res.json(attributes || {});
}
