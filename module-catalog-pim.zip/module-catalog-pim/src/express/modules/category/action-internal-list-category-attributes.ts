import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { FilterQuery } from 'mongoose';
import {
  categoryAttributeModel,
  ICategoryAttributeModel,
} from './model-category-attribute';
interface IReq extends IAppRequest {
  body: Paths.V1InternalListCategoryAttributesAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body: Paths.V1InternalListCategoryAttributesAction.Responses.$200,
  ) => this;
}

export const validateInternalListCategoryAttributes: BaseValidationType = [
  body('filter.ids').optional().isArray(),
  body('filter.ids.*').isMongoId(),
  body('filter.categoryIds').optional().isArray(),
  body('filter.categoryIds.*').optional().isString(),
  body('limit').optional().isInt({ max: 1000 }),
  body('page').optional().isInt({ gt: 0 }),
  reqValidationResult,
];

export async function internalListCategoryAttributesAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { limit = 1000, page = 1 } = req.body;
  const { ids = [], categoryIds = [] } = req.body?.filter ?? {};
  const query: FilterQuery<ICategoryAttributeModel> = {};

  if (ids.length > 0) {
    query._id = {
      $in: ids,
    };
  }

  if (categoryIds.length > 0) {
    query.categoryId = {
      $in: categoryIds,
    };
  }

  const attributes: Partial<
    ICategoryAttributeModel[]
  > = await categoryAttributeModel
    .find(query)
    .limit(limit)
    .skip((page - 1) * limit)
    .lean();

  res.json(attributes as any);
}
