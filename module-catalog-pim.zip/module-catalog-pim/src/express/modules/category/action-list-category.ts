import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { appConfig } from '@src/config/env';
import { ERRORS } from '@src/types/errors';
import { categoryModel } from './model-category';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';

interface IReq extends IAppRequest {
  body: Paths.V1ListCategoryAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1ListCategoryAction.Responses.$200) => this;
}

export const validateListCategories: BaseValidationType = [
  body('filter.parentId')
    .optional({ nullable: true })
    .isString()
    .withMessage(ERRORS.INVALID),
  body('filter.level')
    .optional({ nullable: true })
    .isNumeric()
    .withMessage(ERRORS.INVALID),
  body('filter.text')
    .optional({ nullable: true })
    .isString()
    .withMessage(ERRORS.INVALID),
  body('filter.status')
    .optional({ nullable: true })
    .isString()
    .withMessage(ERRORS.INVALID),
  body('filter.ids.*')
    .optional({ nullable: true })
    .isString()
    .withMessage(ERRORS.INVALID),
  body('page').optional().isInt({ gt: 0 }).withMessage(ERRORS.INVALID),
  body('size')
    .optional()
    .isInt({ lt: appConfig.category.listMaxLimit + 1, gt: 0 })
    .withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function listCategoryAction(req: IReq, res: IRes): Promise<void> {
  const { store } = req;
  const {
    page = 1,
    size = appConfig.category.listDefaultLimit,
    filter: {
      parentId = undefined,
      level = undefined,
      ids = undefined,
      term = undefined,
    } = {},
  } = req.body;

  const query: Record<string, any> = {
    ...(store?.website?.websiteCode !== undefined
      ? { websiteCode: store?.website?.websiteCode }
      : {}),
    ...(parentId !== undefined ? { parentId } : {}),
    ...(ids ? { _id: { $in: ids } } : {}),
    ...(level ? { level } : {}),
    ...(term
      ? {
          'name.en': {
            $regex: term,
            $options: 'i',
          },
        }
      : {}),
  };

  const totalRecords: number = await categoryModel.countDocuments(query);
  const categories: Components.Schemas.V1Category[] = await categoryModel
    .find(
      query,
      {
        _id: 1,
        slug: 1,
        name: 1,
        keywords: 1,
        description: 1,
        moq: 1,
        level: 1,
        parentId: 1,
        parents: 1,
        children: 1,
        active: 1,
        weight: 1,
        createdAt: 1,
        updatedAt: 1,
        websiteCode: 1,
      },
      {
        skip: (page - 1) * size,
        limit: size,
        sort: {
          level: 1,
          'name.en': 1,
        },
      },
    )
    .lean();

  res.json({
    currentPage: page,
    totalPages: Math.ceil(totalRecords / size),
    totalRecords,
    size,
    categories,
  });
}
