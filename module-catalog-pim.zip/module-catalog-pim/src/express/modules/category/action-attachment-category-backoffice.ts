import FormData from 'form-data';
import { createReadStream } from 'fs';
import { StatusCodes } from 'http-status-codes';
import { HttpError } from '@tradeling/web-js-utils';
import {
  BaseValidationType,
  reqValidationResult,
  validateFileUpload,
} from '@tradeling/web-js-utils/dist';

import { appConfig } from '@src/config/env';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { AttachmentCategoryType } from './types';
import { V1TempCategoryUploadAction } from '@tradeling/tradeling-sdk/media-storage/v1-temp-category-upload-action';
import { categoryModel, ICategoryDocument } from './model-category';

interface IReq extends IAppRequest {
  body: AttachmentCategoryType;
}

interface IRes extends IAppResponse {
  json: (
    body: Paths.V1AttachmentCategoryBackofficeAction.Responses.$200,
  ) => this;
}

export const attachmentCategoryValidatorBackoffice: BaseValidationType = [
  validateFileUpload({
    maxFiles: 1,
    maxFileSize: appConfig.media.maxFileSizeBytes,
    extensions: appConfig.media.allowedUploadExtensions,
  }),
  reqValidationResult,
];

export async function attachmentCategoryBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { headers } = req;
  const {
    files = [],
    metadata = {},
    categoryId,
  }: AttachmentCategoryType = req.body;

  const category: ICategoryDocument = await categoryModel
    .findOne({ _id: categoryId })
    .lean();

  if (!category) {
    throw new HttpError(StatusCodes.NOT_FOUND, 'Category not found');
  }

  const form: FormData = new FormData();

  form.append('categoryId', categoryId);

  form.append('path', `categories/${categoryId}`);
  form.append(
    'files[]',
    createReadStream(files[0].path),
    files[0].originalname,
  );

  Object.keys(metadata).forEach((metadataKey) =>
    form.append(`metadata[${metadataKey}]`, metadata[metadataKey]),
  );

  const {
    'content-length': contentLength, // remove
    'content-type': contentType, // remove
    'x-jwt-token': jwtToken, // remove
    cookie: cookie, // remove
    ...reqHeaders
  } = headers;

  const { data } = await V1TempCategoryUploadAction(form as any, {
    headers: {
      ...reqHeaders,
      ...form.getHeaders(),
    },
  });

  res.json(data as any);
}
