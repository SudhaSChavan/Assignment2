import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { body } from 'express-validator';
import {
  categoryAttributeModel,
  CategoryAttributeType,
  ICategoryAttributeModel,
} from './model-category-attribute';
import { V1IndexCategoryMetadataAction } from '@tradeling/tradeling-sdk/catalog-search/v1-index-category-metadata-action';
import { logger } from '@core/util/logger';

interface IReq extends IAppRequest {
  body: Paths.V1SyncCategoryAttributeBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body: Paths.V1SyncCategoryAttributeBackofficeAction.Responses.$200,
  ) => this;
}

export const syncCategoryAttributesBackofficeValidator: BaseValidationType = [
  body('batchIndex').isInt(),
  body('batchSize').isInt({ max: 1000 }),
  reqValidationResult,
];

export async function syncCategoryAttributesBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { batchIndex, batchSize } = req.body;
  await syncAllCategoryAttributes(batchIndex, batchSize);
  res.json({ isUpdated: true });
}

export async function syncAllCategoryAttributes(
  batchSize: number,
  batchIndex: number,
): Promise<void> {
  const attributes: ICategoryAttributeModel[] = await categoryAttributeModel
    .find({})
    .sort({ _id: 1 })
    .limit(batchSize)
    .skip(batchIndex * batchSize)
    .lean();
  const data: any[] = getCategoryData(attributes);
  return syncCategoryAttributes(data);
}

/**
 *
 * @param data
 */
export async function syncCategoryAttributes(data: any[]): Promise<void> {
  if (data.length <= 0) {
    return;
  }
  await V1IndexCategoryMetadataAction(
    { data },
    {
      headers: {
        // TODO: update to correct lang when localization feature is finalized
        'x-language': 'en',
        'x-country': 'ae',
      },
    },
  );
}

/**
 *
 * @param categoryIds
 */
export async function syncOneCategoryAttributes(
  categoryIds: string[],
): Promise<void> {
  const attributes: ICategoryAttributeModel[] = await categoryAttributeModel
    .find({ categoryId: { $in: categoryIds } })
    .lean();
  logger.info(
    `syncOneCategoryAttributes: ${attributes.length} --- ${JSON.stringify(
      categoryIds,
    )}`,
  );
  const data: any[] = getCategoryData(attributes);
  return syncCategoryAttributes(data);
}

/**
 *
 * @param attributes
 */
export function getCategoryData(
  attributes: ICategoryAttributeModel[],
): ICategoryAttributeModel[] {
  return attributes.flatMap((attribute: ICategoryAttributeModel): any => {
    return attribute?.attributes?.map((attr: CategoryAttributeType): any => {
      return {
        _id: attr.id,
        id: attr.id,
        categoryId: attribute.categoryId,
        categoryTree: attribute.categoryTree,
        code: attr.code,
        label: {
          en: attr.label.en,
          ar: attr.label.ar,
        },
        type: attr.type,
        allowedValues: attr.allowedValues,
        isFilterable: attr.isFilterable,
        showCount: attr.showCount,
        strict: attr.strict,
        required: attr.required,
        help: attr.help.en,
        default: attr.default,
      };
    });
  });
}
