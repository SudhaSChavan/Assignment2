import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { categoryModel } from './model-category';

interface IReq extends IAppRequest {
  body: Paths.V1IsSlugExistBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1IsSlugExistBackofficeAction.Responses.$200) => this;
}

export const validateIsSlugExistsBackoffice: BaseValidationType = [
  body('slug').notEmpty().isString().isLength({ min: 3 }).trim(),
  reqValidationResult,
];

export async function isSlugExistsBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { slug } = req.body;
  const slugExists: boolean = await categoryModel.exists({ slug });

  res.json({ slugExists });
}
