import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { categoryAttributeModel } from './model-category-attribute';
interface IReq extends IAppRequest {
  body: Paths.V1GetCategoryAttributesCountBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body: Paths.V1GetCategoryAttributesCountBackofficeAction.Responses.$200,
  ) => this;
}

export const getCategoryAttributesCountActionValidator: BaseValidationType = [
  reqValidationResult,
];

export async function getCategoryAttributesCountAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const entityCount: number = await categoryAttributeModel.estimatedDocumentCount();
  res.json({ count: entityCount });
}
