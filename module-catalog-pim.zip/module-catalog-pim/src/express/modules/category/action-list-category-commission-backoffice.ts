import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { map, keyBy } from 'lodash';
import V1CategoryCommission = Components.Schemas.V1CategoryCommission;
import { generateSkip } from '../util/helpers';
import {
  categoryCommissionModel,
  ICategoryCommissionModel,
} from './model-category-commission';
import { categoryModel, ICategoryModel } from './model-category';

interface IReq extends IAppRequest {
  body: Paths.V1ListCategoryCommissionBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body: Paths.V1ListCategoryCommissionBackofficeAction.Responses.$200,
  ) => this;
}

export const validateListCategoryCommissionBackoffice: BaseValidationType = [
  reqValidationResult,
];

export async function listCategoryCommissionBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { limit = 50, page = 1 } = req.body;
  const skipCount: number = generateSkip(limit, page);

  const totalCount: number = await buildCategoryCommissionQuery().countDocuments();
  const categoryCommissions: ICategoryCommissionModel[] = await buildCategoryCommissionQuery()
    .skip(skipCount)
    .limit(limit)
    .lean();
  const transformedCategoryCommissions: V1CategoryCommission[] = await transformCategoryCommission(
    categoryCommissions,
  );
  res.json({
    total: totalCount,
    limit,
    currentPage: page,
    lastPage: Math.ceil(totalCount / limit) || 1,
    data: transformedCategoryCommissions,
  });
}

function buildCategoryCommissionQuery() {
  return categoryCommissionModel.find({}).sort({ createdAt: -1 });
}

async function transformCategoryCommission(
  categoryCommissions: ICategoryCommissionModel[],
): Promise<V1CategoryCommission[]> {
  const categoryCommissionIds: string[] = map(
    categoryCommissions,
    'categoryId',
  );
  const categories: ICategoryModel[] = await categoryModel
    .find({ _id: { $in: categoryCommissionIds } }, { name: 1 })
    .lean();
  const categoriesObj: { [key: string]: ICategoryModel } = keyBy(
    categories,
    '_id',
  );

  return categoryCommissions.map(
    (categoryCommission: ICategoryCommissionModel): V1CategoryCommission => {
      (categoryCommission as V1CategoryCommission).name =
        categoriesObj[categoryCommission.categoryId]?.name?.en;
      return categoryCommission as V1CategoryCommission;
    },
  );
}
