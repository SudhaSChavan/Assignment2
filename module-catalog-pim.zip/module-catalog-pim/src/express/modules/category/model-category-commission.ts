import mongoose from 'mongoose';

export interface ICategoryCommissionDocument {
  categoryId: string;
  commission: number;
  createdAt: string;
  updatedAt: string;
}

export interface ICategoryCommissionModel
  extends ICategoryCommissionDocument,
    mongoose.Document {}

const categoryCommissionSchema: mongoose.Schema = new mongoose.Schema(
  {
    categoryId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Category',
      required: true,
    },
    commission: {
      type: Number,
      required: true,
    },
  },
  {
    versionKey: false,
    timestamps: true,
    collection: 'categoryCommission',
  },
);

export const categoryCommissionModel: mongoose.Model<ICategoryCommissionModel> = mongoose.model<ICategoryCommissionModel>(
  'CategoryCommission',
  categoryCommissionSchema,
);
