import { Dictionary, keyBy } from 'lodash';
import { productModelV3 } from '../product/model-product-v3';

export type CategoryProductsCount = { _id: string; productCount: number };

type EnrichCategoriesWithProductCount = Promise<
  Paths.V3CategoryListingBoBackofficeAction.Responses.$200['categories']
>;
type Categories = Components.Schemas.V1ListCategory;

export async function enrichCategoriesWithProductCount(
  categories: Categories,
): EnrichCategoriesWithProductCount {
  const productCounts: CategoryProductsCount[] = await productModelV3.aggregate(
    [
      {
        $match: { categoryId: { $in: categories.map((cat) => cat._id) } },
      },
      {
        $group: {
          _id: '$categoryId',
          productCount: { $sum: 1 },
        },
      },
    ],
  );
  const categoryProductCount: Dictionary<CategoryProductsCount> = keyBy(
    productCounts,
    '_id',
  );
  return categories.map((category) => ({
    ...category,
    productCount: categoryProductCount[category._id]?.productCount || 0,
  }));
}
