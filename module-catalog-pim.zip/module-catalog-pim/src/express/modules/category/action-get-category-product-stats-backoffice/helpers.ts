import { V1InternalListSupplierCompanyAction } from '@tradeling/tradeling-sdk/account/v1-internal-list-supplier-company-action';
import { getInternalApiSecret } from '@tradeling/web-js-utils';
import { chunk } from 'lodash';
import { appConfig } from '@src/config/env';

export type SupplierCompany = Account.Components.Schemas.V1SupplierCompany;

export async function getSupplierCompanies(
  companyIds: string[],
): Promise<SupplierCompany[]> {
  if (companyIds.length == 0) return [];
  const { data } = await V1InternalListSupplierCompanyAction(
    { filter: { ids: companyIds }, limit: companyIds.length },
    {
      headers: {
        'x-is-internal-request': '1',
        'x-t-secret': getInternalApiSecret({
          to: 'module-account',
          from: appConfig.name,
        }),
      },
    },
  );
  return data.items;
}

export async function* fetchSupplierCompanies(companyIds: string[]): any {
  const batches: string[][] = chunk(companyIds);
  for (let i: number = 0; i < batches.length; i++) {
    const companies: SupplierCompany[] = await getSupplierCompanies(batches[i]);
    yield companies;
  }
}
