import mongoose from 'mongoose';
import { logger } from '@core/util/logger';

export interface ICategoryDocument {
  slug: string;
  name: { en: string; ar: string };
  description: { en: string; ar: string };
  keywords: { en: string[]; ar: string[] };
  level: number;
  moq: number;
  shortId: number;
  parentId?: string;
  parents?: string[];
  children?: string[];
  active: boolean;
  weight: number;
  listingPageTitle?: { en?: string; ar?: string };
  listingPageSubtitle?: { en?: string; ar?: string };
  listingPageImageMediaId?: string;
  listingPageImagePath?: string;
  listingPageImageLink?: string;
  websiteCode: string;
  createdAt: string;
  updatedAt: string;
}

export interface ICategoryModel extends ICategoryDocument, mongoose.Document {
  _id: string;
}

const categorySchema: mongoose.Schema = new mongoose.Schema(
  {
    slug: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
    },
    name: {
      en: {
        type: String,
        trim: true,
      },
      ar: {
        type: String,
        trim: true,
      },
    },
    listingPageTitle: {
      en: {
        type: String,
        trim: true,
      },
      ar: {
        type: String,
        trim: true,
      },
    },
    listingPageSubtitle: {
      en: {
        type: String,
        trim: true,
      },
      ar: {
        type: String,
        trim: true,
      },
    },
    listingPageImageMediaId: {
      type: String,
      trim: true,
    },
    listingPageImageLink: {
      type: String,
      trim: true,
    },
    listingPageImagePath: {
      type: String,
      trim: true,
    },
    description: {
      en: {
        type: String,
        trim: true,
      },
      ar: {
        type: String,
        trim: true,
      },
    },
    keywords: {
      en: {
        type: [String],
        required: true,
      },
      ar: {
        type: [String],
        required: true,
      },
    },
    level: {
      type: mongoose.Schema.Types.Number,
      default: 0,
    },
    moq: {
      type: mongoose.Schema.Types.Number,
      default: 1,
    },
    parentId: {
      type: mongoose.Schema.Types.ObjectId,
      default: null,
      ref: 'Category',
    },
    parents: [
      {
        type: mongoose.Schema.Types.ObjectId,
        default: [],
        ref: 'Category',
      },
    ],
    children: [
      {
        type: mongoose.Schema.Types.ObjectId,
        default: [],
        ref: 'Category',
      },
    ],
    active: {
      type: Boolean,
      required: false,
      default: true,
    },
    weight: {
      type: Number,
      required: true,
      default: 0,
    },
    websiteCode: {
      type: String,
      required: true,
    },
  },
  {
    versionKey: false,
    timestamps: true,
    collection: 'category',
  },
);

categorySchema.index({ slug: 1 }, { unique: true });
// support sorting
categorySchema.index({ level: 1, 'name.en': 1, websiteCode: 1 });
// supporting category search query
categorySchema.index({ 'name.en': 1, websiteCode: 1 });
categorySchema.index({ 'description.en': 1, websiteCode: 1 });
categorySchema.index({ children: 1, websiteCode: 1 });
categorySchema.index({ active: -1, children: -1, websiteCode: 1 });
categorySchema.index({ parentId: -1, level: -1, active: -1, websiteCode: 1 });

export const categoryModel: mongoose.Model<ICategoryModel> = mongoose.model<ICategoryModel>(
  'Category',
  categorySchema,
);

categoryModel.on('index', (err) => {
  if (err) {
    logger.error(err);
  }
});
