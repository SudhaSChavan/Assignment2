import { categoryCommissionModel } from '../model-category-commission';

export async function deleteCategoryCommisions(
  categoryId: string,
): Promise<void> {
  await categoryCommissionModel.deleteMany({ categoryId: categoryId });
}
