import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { body } from 'express-validator';
import { categoryCommissionModel } from './model-category-commission';

interface IReq extends IAppRequest {
  body: Paths.V1UpdateCategoryCommissionBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body: Paths.V1UpdateCategoryCommissionBackofficeAction.Responses.$200,
  ) => this;
}

export const validateUpdateCategoryCommissionBackoffice: BaseValidationType = [
  body('id').notEmpty().isMongoId(),
  body('commission').notEmpty().isInt({ max: 10, min: 0 }),
  reqValidationResult,
];

export async function updateCategoryCommissionBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { commission, id } = req.body;

  await categoryCommissionModel.findByIdAndUpdate(id, {
    commission,
  });

  res.json({ isUpdated: true });
}
