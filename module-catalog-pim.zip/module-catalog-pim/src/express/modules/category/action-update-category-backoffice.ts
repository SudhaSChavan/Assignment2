import pull from 'lodash/pull';
import { body } from 'express-validator';
import { StatusCodes } from 'http-status-codes';
import {
  BaseValidationType,
  HttpError,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { ERRORS } from '@src/types/errors';
import { appConfig } from '@src/config/env';
import { IAppHeaders, IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { validateCategoryId, validateKeywords } from '@core/util/validators';
import { logger } from '@core/util/logger';
import { V1SaveCategoryUploadAction } from '@tradeling/tradeling-sdk/media-storage/v1-save-category-upload-action';
import { omit } from 'lodash';
import {
  categoryAttributeModel,
  ICategoryAttributeModel,
} from './model-category-attribute';
import { categoryModel, ICategoryModel } from './model-category';
import { productModelV3 } from '../product/model-product-v3';
import { auditFields } from '@express/modules/product/send-product-audit-event';
import { getAuditForCategory } from '@express/modules/category/helpers';
import {
  CategoryAuditEventEnum,
  fireCategoryAuditEvent,
} from '@express/modules/category/dispatch-category-audit-event';
import { Event as TargetEvent } from '@tradeling/emit-audit';

interface IReq extends IAppRequest {
  body: Paths.V1UpdateCategoryBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1UpdateCategoryBackofficeAction.Responses.$200) => this;
}

type UpdateCategoryResponse = MediaStorage.Paths.V1SaveCategoryUploadAction.Responses.$200;

export const validateUpdateCategoryBackoffice: BaseValidationType = [
  body('id').notEmpty().isMongoId(),
  body('slug').optional().isString().isLength({ min: 3 }).trim(),
  body('name.en')
    .optional()
    .isString()
    .withMessage(ERRORS.INVALID)
    .isLength({ min: 3 })
    .withMessage(ERRORS.INVALID)
    .trim(),
  body('name.ar')
    .optional()
    .isString()
    .withMessage(ERRORS.INVALID)
    .isLength({ min: 3 })
    .withMessage(ERRORS.INVALID)
    .trim(),
  body('description.en')
    .optional()
    .isString()
    .withMessage(ERRORS.INVALID)
    .isLength({ min: 3 })
    .withMessage(ERRORS.INVALID)
    .trim(),
  body('description.ar')
    .optional()
    .isString()
    .withMessage(ERRORS.INVALID)
    .isLength({ min: 3 })
    .withMessage(ERRORS.INVALID)
    .trim(),
  body('keywords.en')
    .optional()
    .isArray({ max: appConfig.category.keywordsLimit })
    .custom(validateKeywords),
  body('keywords.ar')
    .optional()
    .isArray({ max: appConfig.category.keywordsLimit })
    .custom(validateKeywords),
  body('active').optional().isBoolean(),
  body('weight').optional().isInt(),
  body('parentId').custom(validateCategoryId),
  reqValidationResult,
];

async function moveAttributesToChildCategory(
  fromCategoryId: string,
  toCategoryId: string,
): Promise<any> {
  const parentCategoryAttribute: ICategoryAttributeModel = await categoryAttributeModel.findOne(
    {
      categoryId: fromCategoryId,
    },
  );
  const newCategory: ICategoryModel = await categoryModel.findOne({
    _id: toCategoryId,
  });

  // The parent doesn't have any attributes
  // Or if it's not the leaf category (has children)
  if (
    !parentCategoryAttribute?.attributes?.length ||
    newCategory?.children?.length
  ) {
    return;
  }

  if (!newCategory) {
    logger.error(`Category not found for id ${toCategoryId}`);

    return;
  }

  await categoryAttributeModel.updateOne(
    {
      categoryId: fromCategoryId,
    },
    {
      $set: {
        categoryId: newCategory._id,
        categoryTree: [...(newCategory?.parents || []), newCategory._id],
      },
    },
  );
}

async function moveProductsToCategory(
  fromCategoryId: string,
  toCategoryId: string,
): Promise<any> {
  // Find the leaf of the category to which we are moving the products
  const toCategoryChild: ICategoryModel[] = await categoryModel.find(
    {
      $or: [{ parents: toCategoryId }, { _id: toCategoryId }],
      'children.0': {
        $exists: false,
      },
    },
    null,
    {
      sort: {
        level: 0,
        'name.en': 1,
      },
    },
  );

  if (!toCategoryChild[0]?._id) {
    return;
  }

  return productModelV3.updateMany(
    {
      categoryId: fromCategoryId,
    },
    {
      $set: {
        categoryId: toCategoryChild[0]._id,
      },
    },
  );
}

async function updateCategoryParent(
  categoryIdToUpdate: string,
  newParentId: string,
): Promise<string[]> {
  const foundParent: ICategoryModel = newParentId
    ? await categoryModel.findById(newParentId)
    : null;
  const newParents: string[] = [
    ...(foundParent?.parents || []),
    ...(newParentId ? [newParentId] : []),
  ];

  await categoryModel.updateOne(
    {
      _id: categoryIdToUpdate,
    },
    {
      $set: {
        parentId: newParentId,
        parents: newParents,
        level: newParents.length,
      },
    },
  );

  // Update the parent for each of the children of category being updated
  const currCategoryChildren: ICategoryModel[] = await categoryModel
    .find({
      parentId: categoryIdToUpdate,
    })
    .lean();

  currCategoryChildren.forEach((currCategoryChild: ICategoryModel): void => {
    updateCategoryParent(currCategoryChild._id, categoryIdToUpdate);
  });

  return newParents;
}

async function doesParentChangeExceedHierarchy(
  categoryId: string,
  newParentId: string,
  maxAllowedDepth: number = 3,
): Promise<boolean> {
  const newParent: ICategoryModel = await categoryModel.findById(newParentId);
  const currentCategory: ICategoryModel = await categoryModel.findById(
    categoryId,
  );

  const categoryMaxLeaf: ICategoryModel[] = await categoryModel.find(
    {
      parents: categoryId,
    },
    null,
    {
      sort: {
        level: -1,
      },
    },
  );

  const currentCategoryLevel: number = currentCategory?.level || 0;
  const currentCategoryDepth: number = categoryMaxLeaf[0]?.level
    ? categoryMaxLeaf[0]?.level - currentCategoryLevel + 1
    : 1; // +1 to include the currentCategory in the depth
  const newDepthAfterChange: number = newParent.level + currentCategoryDepth;

  return newDepthAfterChange > maxAllowedDepth;
}

export async function updateCategoryBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { headers } = req;
  const {
    id: currentCategoryId,
    active = undefined,
    description,
    keywords,
    slug,
    weight,
    name,
    parentId: newParentId,
    listingPageTitle,
    listingPageSubtitle,
    listingPageImageMediaId,
    listingPageImageLink,
    listingPageImagePath,
  } = req.body;
  const parentImage: { [key: string]: string } = {};
  const existingCategoryWithSlug: ICategoryModel = await categoryModel.findOne({
    slug,
    _id: { $nin: [currentCategoryId] },
  });

  if (existingCategoryWithSlug) {
    throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.DUPLICATE);
  }

  if (listingPageImageMediaId) {
    const savedImages: UpdateCategoryResponse = await saveAttachments(
      [listingPageImageMediaId],
      headers,
    );
    parentImage.listingPageImageLink = savedImages?.[0].url;
    parentImage.listingPageImagePath = savedImages?.[0].path;
  }

  const currentCategory: ICategoryModel = await categoryModel.findById(
    currentCategoryId,
  );

  const auditedData: auditFields[] = getAuditForCategory(
    req.body,
    currentCategory,
  );

  if (
    active !== undefined &&
    active !== currentCategory.active &&
    active === false
  ) {
    const childCategories: ICategoryModel[] = await categoryModel.find(
      { parents: currentCategory._id },
      { _id: 1 },
    );
    const childIds: string[] = childCategories.map((cat) => cat._id);
    const count: number = await productModelV3.countDocuments({
      categoryId: { $in: [currentCategory._id, ...childIds] },
    });
    if (count && count > 0) {
      throw new HttpError(
        400,
        'You should move associated products to another category before disabling',
      );
    }
  }

  const oldParentId: string = currentCategory.parentId;
  const isParentChanged: boolean =
    (!oldParentId && !!newParentId) ||
    String(newParentId) !== String(oldParentId);

  // if parent category is changed or removed
  // 1. Update parent of current category and update parents of the children
  // 2. Update children of old parent category
  // 3. Update children of new parent category
  // 4. Update category attributes field `categoryTree`
  if (isParentChanged) {
    const newParentCategory: ICategoryModel = newParentId
      ? await categoryModel.findById(newParentId)
      : null;
    const parentsOfNewParent: string[] = (newParentCategory?.parents || []).map(
      String,
    );

    const isCurrentChildParentOfParent: boolean = parentsOfNewParent.includes(
      currentCategoryId,
    );
    const isCurrentChildSameAsParent: boolean =
      String(newParentId) === String(currentCategoryId);

    if (isCurrentChildParentOfParent) {
      throw new HttpError(
        400,
        'Child of current category cannot be selected as parent',
      );
    }

    if (isCurrentChildSameAsParent) {
      throw new HttpError(400, 'Category cannot be a parent of itself');
    }

    // We only have maximum depth of 3, here we check that if the parent change
    // is going to add some leafs after the level 3 and don't allow
    if (
      newParentId &&
      (await doesParentChangeExceedHierarchy(currentCategoryId, newParentId, 3))
    ) {
      throw new HttpError(
        400,
        'Changing parent exceeds the category tree depth to more than level 3',
      );
    }

    ////////////////////////////////////////////////////////////////////
    // Update the parent in the current category id and in all the children
    ////////////////////////////////////////////////////////////////////
    const newParents: string[] = await updateCategoryParent(
      currentCategoryId,
      newParentId,
    );

    ////////////////////////////////////////////////////////////////////
    // Put the current category being updated in the children of the new parent
    ////////////////////////////////////////////////////////////////////
    if (newParentCategory) {
      newParentCategory.children = [
        ...(newParentCategory?.children ?? []),
        currentCategoryId,
      ];
      await newParentCategory.save();
    }

    ////////////////////////////////////////////////////////////////////
    // Remove the current category from the old parent's children
    ////////////////////////////////////////////////////////////////////
    if (oldParentId) {
      const oldParentCategory: ICategoryModel = await categoryModel.findById(
        oldParentId,
      );
      const oldParentCategoryChildren: string[] = [
        ...oldParentCategory.children,
      ].map(String);

      oldParentCategory.children = pull(
        oldParentCategoryChildren,
        String(currentCategory._id),
      );

      await oldParentCategory.save();
    }

    // Move all the products of the new parent id to the current category id
    // because we don't allow the products in leaf. And if we are going to
    // put this current category as child of the parent, it will break this rule
    if (newParentId) {
      await moveProductsToCategory(newParentId, currentCategory._id);
      await moveAttributesToChildCategory(
        newParentId,
        String(currentCategory._id),
      );
      await syncUpdatedCategoryToProducts(currentCategory._id);
    }

    ////////////////////////////////////////////////////////////////////
    // Update the `categoryTree` field in the category attributes
    ////////////////////////////////////////////////////////////////////
    await categoryAttributeModel.updateMany(
      {
        categoryId: currentCategory._id,
      },
      {
        $set: {
          categoryTree: [...newParents, currentCategoryId],
        },
      },
    );
  }

  // Update the category details
  await categoryModel.updateOne(
    {
      _id: currentCategoryId,
    },
    {
      $set: {
        slug: slug ?? currentCategory.slug,
        name: name ?? currentCategory.name,
        weight: weight ?? currentCategory.weight,
        listingPageImageMediaId,
        listingPageImageLink:
          parentImage?.listingPageImageLink || listingPageImageLink,
        listingPageImagePath:
          parentImage?.listingPageImagePath || listingPageImagePath,
        listingPageSubtitle,
        listingPageTitle,
        description: description ?? currentCategory.description,
        keywords: keywords ?? currentCategory.keywords,
        parentId: newParentId,
        active: active !== undefined ? active : currentCategory.active,
      },
    },
  );

  // if it has children, update active/inactive status
  if (active !== undefined && currentCategory?.children?.length) {
    await categoryModel.updateMany(
      { parents: { $in: [currentCategory._id] } },
      {
        $set: {
          active: active ?? currentCategory.active,
        },
      },
    );
  }

  fireCategoryAuditEvent(
    CategoryAuditEventEnum.Updated,
    [currentCategory._id],
    TargetEvent.Updated,
    req,
    auditedData,
    'Category update action performed',
  );
  // @todo reindexing needed for products and categories

  res.json({ isUpdated: true });
}

async function saveAttachments(
  mediaIds: string[],
  headers: IAppHeaders,
): Promise<UpdateCategoryResponse> {
  if (mediaIds.length === 0) {
    return [];
  }

  // move the messages to the permanent location
  const { data } = await V1SaveCategoryUploadAction(
    { mediaIds },
    { headers: omit(headers, ['x-jwt-token', 'cookie']) },
  );
  return (data as UpdateCategoryResponse) || [];
}

async function syncUpdatedCategoryToProducts(categoryId: string) {
  await productModelV3.updateMany(
    { categoryId: categoryId },
    { $set: { syncedAt: new Date() } },
  );
}
