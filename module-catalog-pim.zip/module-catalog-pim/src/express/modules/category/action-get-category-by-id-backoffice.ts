import { body } from 'express-validator';
import {
  BaseValidationType,
  HttpError,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { categoryModel, ICategoryModel } from './model-category';

interface IReq extends IAppRequest {
  body: Paths.V1GetCategoryByIdBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body:
      | Paths.V1GetCategoryByIdBackofficeAction.Responses.$200
      | Paths.V1GetCategoryByIdBackofficeAction.Responses.$400,
  ) => this;
}

export const validateGetCategoryByIdBackoffice: BaseValidationType = [
  body('id').notEmpty().isMongoId(),
  reqValidationResult,
];

export async function getCategoryByIdBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { id } = req.body;

  const category: ICategoryModel = await categoryModel
    .findOne({
      _id: id,
    })
    .lean();

  if (!category) {
    throw new HttpError(404, 'Category by id was not found');
  }

  res.json(category as any);
}
