import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { categoryModel, ICategoryModel } from './model-category';

interface IReq extends IAppRequest {
  body: Paths.V1GetCategorySlugBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1GetCategorySlugBackofficeAction.Responses.$200) => this;
}

export const validateGetCategorySlugBackoffice: BaseValidationType = [
  body('name').notEmpty().isString().trim(),
  reqValidationResult,
];

export async function getCategorySlugBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { name } = req.body;

  let newSlug: string = name
    .toLowerCase()
    .replace(/[^a-z0-9 -]/g, '') // remove invalid chars
    .replace(/\s+/g, '-') // collapse whitespace and replace by -
    .replace(/-+/g, '-'); // collapse dashes

  let existingCategoryWithSlug: ICategoryModel = await categoryModel.findOne({
    slug: newSlug,
  });

  while (existingCategoryWithSlug) {
    // check for postfix number
    const slugParts: string[] = existingCategoryWithSlug.slug.split('-');
    const lastPart: string = slugParts[slugParts.length - 1];
    const postfixNumber: number = Number(lastPart);

    if (Number.isInteger(postfixNumber)) {
      // increment and check if it's unique
      slugParts[slugParts.length - 1] = String(postfixNumber + 1);
      newSlug = slugParts.join('-');
    } else {
      // add postfix number => 1
      slugParts.push('1');
      newSlug = slugParts.join('-');
    }

    existingCategoryWithSlug = await categoryModel.findOne({ slug: newSlug });
  }

  res.json({ slug: newSlug });
}
