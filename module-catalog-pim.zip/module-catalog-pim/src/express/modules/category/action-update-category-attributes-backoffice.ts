import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { ERRORS } from '@src/types/errors';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { validateCategoryId } from '@core/util/validators';
import camelCase from 'lodash/camelCase';
import { categoryModel, ICategoryModel } from './model-category';
import { categoryAttributeModel } from './model-category-attribute';
import { syncOneCategoryAttributes } from './action-sync-category-attribute-backoffice';
import { getAuditForCategoryAttributes } from '@express/modules/category/helpers';
import { auditFields } from '@express/modules/product/send-product-audit-event';
import {
  CategoryAuditEventEnum,
  fireCategoryAuditEvent,
} from '@express/modules/category/dispatch-category-audit-event';
import { Event as TargetEvent } from '@tradeling/emit-audit';

interface IReq extends IAppRequest {
  body: Paths.V1UpdateCategoryAttributesBoBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body:
      | Paths.V1UpdateCategoryAttributesBoBackofficeAction.Responses.$200
      | Paths.V1UpdateCategoryAttributesBoBackofficeAction.Responses.$400,
  ) => this;
}

export const validateUpdateCategoryAttributesBackoffice: BaseValidationType = [
  body('categoryId')
    .notEmpty()
    .withMessage(ERRORS.MISSING)
    .isString()
    .custom(validateCategoryId)
    .withMessage(ERRORS.INVALID)
    .trim(),
  body('attributes').isArray().withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function updateCategoryAttributesBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { categoryId, attributes } = req.body;

  const category: ICategoryModel = await categoryModel.findOne({
    _id: categoryId,
  });

  const auditedFields: auditFields[] = await getAuditForCategoryAttributes(
    attributes,
    category._id,
  );

  // trim and remove whitespaces
  attributes.forEach(
    (attribute: Components.Schemas.V1CategoryAttribute): void => {
      if (attribute?.allowedValues?.length) {
        attribute.allowedValues = attribute.allowedValues
          .map((value: string): string => value.replace(/\s+/g, ' ').trim())
          .filter((value: string): boolean => !!value);
      }

      if (attribute?.label?.en) {
        const attributeLabel: string = attribute?.label?.en
          ?.trim()
          ?.toLowerCase();

        attribute.code = camelCase(
          attributeLabel.replace(/[^\sa-zA-Z0-9]+/g, ''),
        );
      }
    },
  );

  await categoryAttributeModel.updateOne(
    {
      categoryId,
    },
    {
      $set: {
        attributes,
        categoryId: category._id,
        categoryTree: [...(category?.parents || []), category._id],
      } as any,
    },
    {
      upsert: true,
    },
  );

  // sync category data
  await syncOneCategoryAttributes([categoryId]);

  fireCategoryAuditEvent(
    CategoryAuditEventEnum.AttributeChange,
    [category._id],
    TargetEvent.Updated,
    req,
    auditedFields,
    'Category attributes update action performed',
  );

  res.json({ isUpdated: true });
}
