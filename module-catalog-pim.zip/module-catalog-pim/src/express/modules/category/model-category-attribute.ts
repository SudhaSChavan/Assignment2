import mongoose from 'mongoose';
import { logger } from '@core/util/logger';

export enum AttributeTypes {
  Country = 'country',
  Text = 'text',
  Textarea = 'textarea',
  Checkbox = 'checkbox',
  Date = 'date',
  Select = 'select',
  MultiSelect = 'multi_select',
  Number = 'number',
  Url = 'url',
}

export type CategoryAttributeType = {
  id?: string;
  code: string;
  categoryIds?: string[];
  type:
    | AttributeTypes.Text
    | AttributeTypes.Country
    | AttributeTypes.Textarea
    | AttributeTypes.Checkbox
    | AttributeTypes.Date
    | AttributeTypes.Select
    | AttributeTypes.MultiSelect
    | AttributeTypes.Number
    | AttributeTypes.Url;
  default?: any;
  allowedValues?: any;
  strict?: boolean;
  required: boolean;
  label: {
    en: string;
    ar?: string;
  };
  help: {
    en: string;
    ar?: string;
  };
  valueHelp?: {
    en: string;
    ar?: string;
  };
  example?: string;
  isFilterable?: boolean;
  isLocalized?: boolean;
  showCount?: boolean;
  minValue?: number;
  maxValue?: number;
  isInteger?: boolean;
  metadata?: Record<string, any>;
};

export interface ICategoryAttributeDocument {
  categoryId: string; // Category to which these attributes belong
  categoryTree: string[]; // List of category parents in this attribute
  attributes: CategoryAttributeType[]; // JSON schema properties
  createdAt: string;
  updatedAt: string;
}

export interface ICategoryAttributeModel
  extends ICategoryAttributeDocument,
    mongoose.Document {}

const categoryAttributeSchema: mongoose.Schema = new mongoose.Schema(
  {
    categoryId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Category',
      required: true,
    },
    categoryTree: {
      type: [String],
      required: true,
    },
    attributes: [
      {
        id: {
          type: mongoose.SchemaTypes.ObjectId,
          auto: true,
        },
        sort: {
          type: Number,
          default: 0,
        },
        code: {
          type: String,
        },
        type: {
          type: String,
        },
        default: {
          type: mongoose.SchemaTypes.Mixed,
        },
        allowedValues: [mongoose.SchemaTypes.Mixed],
        strict: {
          type: mongoose.SchemaTypes.Boolean,
        },
        required: {
          type: mongoose.SchemaTypes.Boolean,
        },
        label: {
          en: {
            type: String,
            trim: true,
          },
          ar: String,
        },
        help: {
          en: String,
          ar: String,
        },
        valueHelp: {
          en: String,
          ar: String,
        },
        example: {
          type: String,
        },
        metadata: {
          type: Object,
        },
        isFilterable: {
          type: mongoose.SchemaTypes.Boolean,
          default: false,
        },
        isLocalized: {
          type: mongoose.SchemaTypes.Boolean,
          default: false,
        },
        showCount: {
          type: mongoose.SchemaTypes.Boolean,
          default: false,
        },
        minValue: Number,
        maxValue: Number,
        isInteger: Boolean,
      },
    ],
  },
  {
    versionKey: false,
    timestamps: true,
    collection: 'categoryAttribute',
  },
);

categoryAttributeSchema.index({ categoryId: 1 });
categoryAttributeSchema.index({ categoryTree: 1 });

export const categoryAttributeModel: mongoose.Model<ICategoryAttributeModel> = mongoose.model<ICategoryAttributeModel>(
  'CategoryAttribute',
  categoryAttributeSchema,
);

categoryAttributeModel.on('index', (err) => {
  if (err) {
    logger.error(err);
  }
});
