import { body } from 'express-validator';
import { map, keyBy } from 'lodash';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { ERRORS } from '@src/types/errors';
import {
  categoryAttributeModel,
  ICategoryAttributeModel,
} from './model-category-attribute';
import { categoryModel, ICategoryModel } from './model-category';

interface IReq extends IAppRequest {
  body: Paths.V1BulkUpdateCategoryAttributesBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body:
      | Paths.V1BulkUpdateCategoryAttributesBackofficeAction.Responses.$200
      | Paths.V1BulkUpdateCategoryAttributesBackofficeAction.Responses.$400,
  ) => this;
}

export const validateBulkUpdateCategoryAttributesBackoffice: BaseValidationType = [
  body('categoryIds').isArray().withMessage(ERRORS.INVALID),
  body('categoryIds.*').notEmpty().isMongoId().withMessage(ERRORS.INVALID),
  body('attribute.code').notEmpty().isString().withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function bulkUpdateCategoryAttributesBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { categoryIds = [], attribute } = req.body;

  const categories: string[] = await getCategoriesChildren(categoryIds);

  await updateCategoryAttributes(categories, attribute);

  res.json({
    isUpdated: true,
  });
}

async function updateCategoryAttributes(
  categoryIds: string[],
  attribute: any,
): Promise<void> {
  const categoryAttributes: ICategoryAttributeModel[] = await categoryAttributeModel.find(
    {
      categoryId: { $in: categoryIds },
    },
  );

  const existingCategoryIds: string[] = map(categoryAttributes, 'categoryId');
  const notExistingCategoryIds: string[] = categoryIds.filter(
    (categoryId) =>
      !map(existingCategoryIds, String).includes(categoryId.toString()),
  );

  const categories: ICategoryModel[] = await categoryModel.find({
    _id: { $in: notExistingCategoryIds },
  });

  const categoriesObj: any = keyBy(categories, '_id');
  for (const categoryId of notExistingCategoryIds) {
    await categoryAttributeModel.create({
      categoryId,
      categoryTree: [categoryId, ...categoriesObj[categoryId].parents],
      attributes: [
        {
          ...attribute,
          isFilterable: true,
        },
      ],
    });
  }
  // pull the attribute from those categories
  await categoryAttributeModel.updateMany(
    {
      categoryId: { $in: existingCategoryIds },
    },
    {
      // @ts-ignore
      $pull: { attributes: { code: attribute.code } },
    },
  );

  await categoryAttributeModel.updateMany(
    {
      categoryId: { $in: existingCategoryIds },
    },
    {
      $push: {
        attributes: {
          ...attribute,
          // @ts-ignore
          isFilterable: true,
        },
      },
    },
  );

  // update not selected categories to be not filterable
  await categoryAttributeModel.updateMany(
    {
      'attributes.code': attribute.code,
      categoryId: { $nin: categoryIds },
    },
    {
      $set: {
        'attributes.$.isFilterable': false,
      },
    },
  );
}

async function getCategoriesChildren(categoryIds: string[]): Promise<string[]> {
  // get categories with it's children
  return categoryModel
    .find({
      $or: [{ parents: { $in: categoryIds } }, { _id: { $in: categoryIds } }],
    })
    .distinct('_id')
    .lean();
}
