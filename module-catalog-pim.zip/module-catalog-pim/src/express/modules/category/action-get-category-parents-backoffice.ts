import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { validateCategoryId } from '@core/util/validators';
import { ERRORS } from '@src/types/errors';
import { categoryModel } from './model-category';

interface IReq extends IAppRequest {
  body: Paths.V1GetCategoryParentsBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body:
      | Paths.V1GetCategoryParentsBackofficeAction.Responses.$200
      | Paths.V1GetCategoryParentsBackofficeAction.Responses.$400,
  ) => this;
}

export const validateGetCategoryParentsBackoffice: BaseValidationType = [
  body('id').notEmpty().custom(validateCategoryId).withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function getCategoryParentsBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { id: categoryId } = req.body;

  const category: Components.Schemas.V1Category = await categoryModel.findById(
    categoryId,
  );

  const parentIds: string[] = category.parents;
  let parentCategories: Components.Schemas.V1Category[] = [];

  if (parentIds && parentIds.length !== 0) {
    parentCategories = await categoryModel.find(
      {
        _id: {
          $in: parentIds,
        },
      },
      {},
      {
        sort: {
          level: 1,
        },
      },
    );
  }

  res.json([...parentCategories, category] as any);
}
