import { Model } from 'mongoose';
import { ICategoryDocument, ICategoryModel } from '../model-category';
import { ICategoryRepository } from './category-repository';
export class CategoryRepositoryMongo implements ICategoryRepository {
  constructor(private model: Model<ICategoryModel>) {}

  async getChildren(
    parentIds: string[],
  ): Promise<(ICategoryDocument & { _id: string })[]> {
    return this.model
      .find({
        parents: {
          $in: parentIds,
        },
      })
      .lean();
  }

  async getByIds(
    ids: string[],
  ): Promise<(ICategoryDocument & { _id: string })[]> {
    return this.model.find({ _id: { $in: ids } }).lean();
  }
}
