import { ICategoryDocument } from '../model-category';

export type CategoryDocument = ICategoryDocument & { _id: string };
export interface ICategoryRepository {
  getChildren(
    parentIds: string[],
  ): Promise<(ICategoryDocument & { _id: string })[]>;
  getByIds(ids: string[]): Promise<CategoryDocument[]>;
}
