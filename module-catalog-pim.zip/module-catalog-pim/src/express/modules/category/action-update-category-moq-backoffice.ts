import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils';

import { categoryModel, ICategoryModel } from './model-category';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import {
  CategoryAuditEventEnum,
  fireCategoryAuditEvent,
} from '@express/modules/category/dispatch-category-audit-event';
import { Event as TargetEvent } from '@tradeling/emit-audit';
import { auditFields } from '@express/modules/product/send-product-audit-event';
interface IReq extends IAppRequest {
  body: Paths.V1UpdateCategoryMoqBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body: Paths.V1UpdateCategoryMoqBackofficeAction.Responses.$200,
  ) => this;
}

export const validateUpdateCategoryMoqBackoffice: BaseValidationType = [
  body('categoryIds').isArray().notEmpty(),
  body('categoryIds.*').notEmpty().isMongoId(),
  body('moq').notEmpty().isInt({ gt: 0 }),
  reqValidationResult,
];

export async function updateCategoryMoqBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { categoryIds, moq } = req.body;

  await fireAuditForCategoriesMoq(req);
  await categoryModel.updateMany(
    {
      $or: [
        {
          parents: {
            $in: categoryIds,
          },
        },
        {
          _id: {
            $in: categoryIds,
          },
        },
      ],
    },
    {
      $set: {
        moq,
      },
    },
  );
  await fireAuditForCategoriesMoq(req);
  res.json({
    isUpdated: true,
  });
}

async function fireAuditForCategoriesMoq(req: IReq): Promise<void> {
  const { categoryIds, moq } = req.body;

  const categories: ICategoryModel[] = await categoryModel.find({
    $or: [
      {
        parents: {
          $in: categoryIds,
        },
      },
      {
        _id: {
          $in: categoryIds,
        },
      },
    ],
  });

  for (const category of categories) {
    if (category.moq && moq && category.moq !== moq) {
      fireCategoryAuditEvent(
        CategoryAuditEventEnum.Updated,
        [category._id],
        TargetEvent.Updated,
        req,
        {
          name: 'moq',
          old: category.moq,
          new: moq,
        },
        'Category attribute deletion action performed',
      );
    }
  }
}
