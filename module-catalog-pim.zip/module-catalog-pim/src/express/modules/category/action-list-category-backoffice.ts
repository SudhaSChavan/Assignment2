import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { ERRORS } from '@src/types/errors';
import { appConfig } from '@src/config/env';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { categoryModel } from './model-category';

interface IReq extends IAppRequest {
  body: Paths.V1ListCategoryBoAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body:
      | Paths.V1ListCategoryBoAction.Responses.$200
      | Paths.V1ListCategoryBoAction.Responses.$400,
  ) => this;
}

export const validateListCategoriesBackoffice: BaseValidationType = [
  body('filter.parentId')
    .optional({ nullable: true })
    .isString()
    .withMessage(ERRORS.INVALID),
  body('filter.includeAncestors')
    .optional()
    .isBoolean()
    .withMessage(ERRORS.INVALID),
  body('filter.slug').optional().isString().withMessage(ERRORS.INVALID),
  body('filter.isLead').optional().isBoolean().withMessage(ERRORS.INVALID),
  body('filter.websiteCode')
    .optional({ nullable: true })
    .isString()
    .withMessage(ERRORS.INVALID),
  body('filter.level')
    .optional({ nullable: true })
    .isNumeric()
    .withMessage(ERRORS.INVALID),
  body('filter.text')
    .optional({ nullable: true })
    .isString()
    .withMessage(ERRORS.INVALID),
  body('filter.status')
    .optional({ nullable: true })
    .isString()
    .withMessage(ERRORS.INVALID),
  body('filter.ids.*')
    .optional({ nullable: true })
    .isString()
    .withMessage(ERRORS.INVALID),
  body('page').optional().isInt({ gt: 0 }).withMessage(ERRORS.INVALID),
  body('size')
    .optional()
    .isInt({ lt: appConfig.category.listMaxLimit + 1, gt: 0 })
    .withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function listCategoryBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const {
    page = 1,
    size = appConfig.category.listDefaultLimit,
    filter: {
      parentId = undefined,
      includeAncestors = undefined,
      level = undefined,
      ids = undefined,
      term = undefined,
      status = undefined,
      websiteCode = undefined,
      slug = undefined,
      isLeaf,
    } = {},
  } = req.body;
  let active: boolean;

  if (status) {
    active = status === 'active';
  }

  let query: Record<string, any> = {
    ...(websiteCode !== undefined ? { websiteCode } : {}),
    ...(ids ? { _id: { $in: ids } } : {}),
    ...(typeof level === 'number' ? { level } : {}),
    ...(active !== undefined ? { active } : {}),
    ...(term
      ? {
          'name.en': {
            $regex: term,
            $options: 'i',
          },
        }
      : {}),
  };

  if (includeAncestors) {
    query = {
      ...query,
      ...(parentId !== undefined ? { parents: parentId } : {}),
    };
  } else {
    query = { ...query, ...(parentId !== undefined ? { parentId } : {}) };
  }

  if (slug) {
    query = { ...query, slug: slug };
  }

  if (isLeaf) {
    query = { ...query, children: { $eq: [] } };
  }

  const totalRecords: number = await categoryModel.countDocuments(query);
  const categories: Components.Schemas.V1CategoryBackoffice[] = await categoryModel
    .find(
      query,
      {},
      {
        skip: (page - 1) * size,
        limit: size,
        sort: {
          level: 0,
          'name.en': 1,
        },
      },
    )
    .lean();

  res.json({
    currentPage: page,
    totalPages: Math.ceil(totalRecords / size),
    totalRecords,
    size,
    categories,
  });
}
