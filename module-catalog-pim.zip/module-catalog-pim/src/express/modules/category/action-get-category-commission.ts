import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import {
  categoryCommissionModel,
  ICategoryCommissionModel,
} from './model-category-commission';

interface IReq extends IAppRequest {
  body: Paths.V1GetCategoryCommissionAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1GetCategoryCommissionAction.Responses.$200) => this;
}

export const validateGetCategoryCommission: BaseValidationType = [
  body('categoryIds').isArray(),
  reqValidationResult,
];

// @todo add secret to protect
export async function getCategoryCommissionAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { categoryIds } = req.body;

  const responseObject: any = {};
  const records: ICategoryCommissionModel[] = await categoryCommissionModel
    .find({ categoryId: { $in: categoryIds } })
    .lean();
  for (const record of records) {
    responseObject[record.categoryId] = record.commission;
  }

  res.json(responseObject);
}
