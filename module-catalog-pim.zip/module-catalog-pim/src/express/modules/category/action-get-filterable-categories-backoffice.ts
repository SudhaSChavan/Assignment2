import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';

import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { ERRORS } from '@src/types/errors';
import { categoryAttributeModel } from './model-category-attribute';
import { categoryModel } from './model-category';

interface IReq extends IAppRequest {
  body: Paths.V1GetFilterableCategoryBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body:
      | Paths.V1GetFilterableCategoryBackofficeAction.Responses.$200
      | Paths.V1GetFilterableCategoryBackofficeAction.Responses.$400,
  ) => this;
}

export const validateGetFilterableCategoriesBackoffice: BaseValidationType = [
  body('categoryAttributeCode')
    .notEmpty()
    .isString()
    .withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function getFilterableCategoriesBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { categoryAttributeCode } = req.body;

  const categoryIds: string[] = await getFilterableCategoryAttributes(
    categoryAttributeCode,
  );
  const categoriesWithMaxLevel: string[] = await getCategoriesWithMaxLevel(
    2,
    categoryIds,
  );

  res.json(categoriesWithMaxLevel);
}

async function getFilterableCategoryAttributes(
  categoryAttributeCode: string,
): Promise<string[]> {
  // get filterable categories with this attributes
  return categoryAttributeModel
    .find({
      attributes: {
        $elemMatch: {
          code: categoryAttributeCode,
          isFilterable: true,
        },
      },
    })
    .distinct('categoryId')
    .lean();
}

async function getCategoriesWithMaxLevel(
  maxLevel: number,
  categoryIds: string[],
): Promise<string[]> {
  // return only categories with specific max level
  return categoryModel
    .find({
      _id: { $in: categoryIds },
      level: { $lte: maxLevel },
    })
    .distinct('_id')
    .lean();
}
