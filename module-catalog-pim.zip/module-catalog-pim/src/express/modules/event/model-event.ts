import mongoose, { Document, Model, Schema } from 'mongoose';
import { KeyValStr } from '@tradeling/web-js-utils';
import { logger } from '@core/util/logger';

export interface IEventDocument {
  name: string;
  description: string;

  discountVerticals: ('product_discount' | 'order_discount')[];
  discountType?: ('percentage_off' | 'free_product')[];
  discountMinimum?: number;
  validFrom: string;
  validTo?: string;

  categoryIds: string[];
  brands?: string[];
  // Number of days sellers can submit products
  sellerSubmissionDeadline?: number;

  landingPageUrl?: string;
  entryPoints?: ('home_page' | 'category_page')[];
  bannerImages?: IBannerImageDocument[];

  needApproval: boolean;
  metadata?: { [key: string]: any };
  reqHeaders?: { [key: string]: any };
  userDetail: {
    userId: string;
    firstName: string;
    lastName: string;
    email: string;
  };
  createdAt?: string;
  updatedAt?: string;
  deactivatedAt?: string;
}

export interface IBannerImageDocument {
  type?: string;
  attachments?: {
    id?: string;
    url?: string;
  }[];
  metadata?: KeyValStr;
}

export interface IEventModel extends IEventDocument, Document {}

const eventSchema: Schema<IEventModel> = new Schema(
  {
    name: {
      type: String,
      required: true,
      maxlength: 250,
      trim: true,
    },
    description: {
      type: String,
      required: true,
      maxlength: 250,
      trim: true,
    },
    discountVerticals: {
      type: [String],
      required: true,
      enum: ['product_discount', 'order_discount'],
    },
    discountType: {
      type: [String],
      required: true,
      enum: ['free_product', 'percentage_off'],
    },
    discountMinimum: {
      type: Number,
    },
    validFrom: {
      type: Date,
      required: true,
      default: Date.now,
    },
    validTo: {
      type: Date,
      required: false,
    },
    categoryIds: {
      type: [String],
    },
    brands: {
      type: [String],
    },
    sellerSubmissionDeadline: {
      type: Number,
    },
    landingPageUrl: {
      type: String,
    },
    entryPoints: {
      type: [String],
    },
    status: {
      type: [String],
    },
    bannerImages: {
      type: [
        {
          type: {
            type: String,
          },
          attachments: [
            {
              id: String,
              url: String,
              name: String,
            },
          ],
          metadata: Schema.Types.Mixed,
        },
      ],
    },
    needApproval: {
      type: Boolean,
      required: true,
      default: true,
    },
    metadata: {
      type: Object,
      default: null,
    },
    reqHeaders: {
      type: Object,
      default: null,
    },
    userDetail: {
      type: Object,
    },
    deactivatedAt: {
      type: Date,
      default: null,
    },
  },
  {
    id: false,
    strict: true,
    versionKey: false,
    timestamps: true,
    collection: 'event',
  },
);

export const eventModel: Model<IEventModel> = mongoose.model<IEventModel>(
  'Event',
  eventSchema,
);

eventModel.on('index', (err) => {
  if (err) {
    logger.error(err);
  }
});
