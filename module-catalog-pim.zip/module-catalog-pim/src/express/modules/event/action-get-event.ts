import { body } from 'express-validator';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { eventModel, IEventDocument } from './model-event';

interface IReq extends IAppRequest {
  body: Paths.V1GetEventAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1GetEventAction.Responses.$200) => this;
}

export const validateGetEvent: BaseValidationType = [
  body('id').isMongoId(),
  reqValidationResult,
];

export async function getEventAction(req: IReq, res: IRes): Promise<void> {
  const { id } = req.body;
  const event: IEventDocument = await eventModel.findById(id).lean();

  res.json(event);
}
