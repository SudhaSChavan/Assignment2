import {
  BaseValidationType,
  HttpError,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { body } from 'express-validator';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { sanitizeHeaders } from '@core/util/common';
import { DiscountType, DiscountVertical } from './type';
import { eventModel } from './model-event';
import { IBaseAppUser } from '@tradeling/web-js-utils';
import {
  toStartOfDay,
  toEndOfDay,
} from './action-create-event-backoffice/helper';
import { StatusCodes } from 'http-status-codes';

interface IReq extends IAppRequest {
  body: Paths.V1CreateEventBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1CreateEventBackofficeAction.Responses.$200) => this;
}

export const validateCreateEventBackoffice: BaseValidationType = [
  //
  body('name').isString().notEmpty().isLength({ max: 250 }),
  body('description').isString().notEmpty().isLength({ max: 250 }),
  body('discountVerticals').isString().isIn(Object.values(DiscountVertical)),
  body('discountType').isArray().isIn(Object.values(DiscountType)),
  body('discountMinimum').isNumeric().optional().isLength({ min: 0, max: 100 }),
  body('validFrom').notEmpty().isISO8601({ strict: true }),
  body('validTo').optional().isISO8601({ strict: true }),
  body('categoryIds').isArray().optional(),
  body('brands').isArray().optional(),
  body('sellerSubmissionDeadline').isNumeric().optional(),
  body('landingPageUrl').isString().isLength({ max: 250 }).optional(),
  body('entryPoints').isArray().optional(),
  body('bannerImages').isArray().optional(),
  body('needApproval').isBoolean(),
  reqValidationResult,
];

export async function createEventBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  const { userId, userJwtDecoded, headers } = req;

  const {
    name,
    description,
    discountVerticals,
    discountType,
    discountMinimum,
    categoryIds,
    brands,
    sellerSubmissionDeadline,
    landingPageUrl,
    entryPoints,
    bannerImages,
    needApproval,
  } = req.body;

  let { validFrom, validTo } = req.body;

  validFrom = toStartOfDay(validFrom);
  validTo = toEndOfDay(validTo);

  if (validTo && new Date(validTo) < new Date(validFrom)) {
    throw new HttpError(StatusCodes.BAD_REQUEST, 'Invalid validTo date');
  }

  await eventModel.create({
    name,
    description,
    discountVerticals,
    discountType,
    discountMinimum,
    validFrom: validFrom ? validFrom : new Date(),
    ...(validTo ? { validTo } : {}),
    categoryIds,
    brands,
    sellerSubmissionDeadline,
    landingPageUrl,
    entryPoints,
    bannerImages,
    needApproval,
    reqHeaders: sanitizeHeaders(headers),
    metadata: {},
    userDetail: {
      userId,
      email: (userJwtDecoded as IBaseAppUser)?.email,
      lastName: (userJwtDecoded as IBaseAppUser)?.lastName,
      firstName: (userJwtDecoded as IBaseAppUser)?.firstName,
    },
  });

  res.json({ isCreated: true });
}
