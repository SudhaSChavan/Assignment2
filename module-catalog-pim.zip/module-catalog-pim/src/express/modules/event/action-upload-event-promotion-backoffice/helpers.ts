import { HttpError } from '@tradeling/web-js-utils';
import Excel, { CellValue } from 'exceljs';
import { StatusCodes } from 'http-status-codes';
import {
  find,
  invert,
  isEmpty,
  isNumber,
  isString,
  keyBy,
  set,
  toNumber,
  round,
} from 'lodash';
import { IAppRequest } from '@src/types/app-request';
import { DraftCell } from '../../product/types';
import {
  IProductDocumentV3,
  IProductModelV3,
  productModelV3,
} from '../../product/model-product-v3';

export function sanitizeField(
  value: string,
  sanitizers: FieldSanitizer[],
): { value: any; error?: Error } {
  try {
    return {
      value: sanitizers.reduce(
        (newValue: any, sanitizer: FieldSanitizer): any => sanitizer(newValue),
        value,
      ),
    };
  } catch (error) {
    return {
      value: undefined,
      error,
    };
  }
}

export function validateField(
  value: string | any,
  validators: FieldValidator[],
): boolean {
  try {
    return validators.every((validator: FieldValidator): boolean =>
      validator(value),
    );
  } catch (error) {
    return false;
  }
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
export function trim(value: any): string {
  return String(value).trim();
}

export type ProductUploadError = Pick<ProductUploadRow, 'fields' | 'line'> & {
  error: any;
};

export function notEmpty(value: any): boolean {
  return typeof value === 'string' && value.length > 0;
}

export function toDecimal(precision: number): (value: string) => number {
  return (value: string) => round(Number(value), precision);
}

export const simplePriceProductTemplate: string = 'simple-price-product';
export const simpleProductTemplate: string = 'simple-product';
export const configurableProductTemplate: string = 'configurable-product';
export const simplePriceListTemplate: string = 'simple-price-list';
export const configurablePriceListTemplate: string = 'configurable-price-list';

export type TemplateType =
  | typeof simpleProductTemplate
  | typeof configurableProductTemplate
  | typeof simplePriceListTemplate
  | typeof configurablePriceListTemplate;
type FieldSanitizer = (value: any) => any;
type FieldValidator = (value: any) => boolean;
export type FieldType = {
  field: string;
  label: string;
  required: boolean;
  enum?: any[];
  width?: number;
  example?: any;
  valueHelp?: string;
  instruction?: string;
  sanitizers: FieldSanitizer[];
  validators: FieldValidator[];
  invalidValueMessage?: string;
  dataFormatter?: (value: any) => any;
  defaultValue?: any;
  template?: TemplateType[];
  cellValidation?: {
    type: string;
    allowBlank: boolean;
    formulae: string[];
    valuesList: string[];
  };
};

export interface IMediaFile extends Express.Multer.File {}

export enum PromotionType {
  PriceOff = 'price_off',
  FreeProduct = 'free_product',
  PercentageOff = 'percentage_off',
}

export async function getWorkbook(filePath: string): Promise<Excel.Workbook> {
  const workbook: Excel.Workbook = new Excel.Workbook();

  await workbook.xlsx.readFile(filePath).catch((): void => {
    throw new HttpError(StatusCodes.BAD_REQUEST, 'invalid xlsx file'); // map parsing error to 400 Bad Request
  });

  const worksheet: Excel.Worksheet = workbook.getWorksheet(1);

  if (!worksheet) {
    throw new HttpError(StatusCodes.BAD_REQUEST, 'no worksheets found');
  }

  if (worksheet.rowCount <= 1) {
    throw new HttpError(StatusCodes.BAD_REQUEST, 'no data found');
  }

  return workbook;
}

export function getRawData(worksheet: Excel.Worksheet): string[][] {
  const rows: any[] = worksheet.getSheetValues();
  const result: string[][] = [];

  // first row is undefined and second for headers, so skip them
  for (let i: number = 2; i < rows.length; i++) {
    const row: any[] = rows[i];

    if (row && row.length) {
      // each row looks like:
      // [undefined, cell1, cell2, cell3, ...]
      // so we need to remove first undefined and cast everything else to strings
      const allExceptFirst: Excel.CellValue[] = row.slice(1);

      result.push(
        allExceptFirst.map((value: CellValue): string => {
          if (String(value) !== '[object Object]') {
            return String(value);
          } else if ((value as Excel.CellRichTextValue)?.richText) {
            return String(
              (value as Excel.CellRichTextValue)?.richText
                .map((textItem: Excel.RichText) => textItem.text)
                .join(''),
            );
          } else if ((value as Excel.CellHyperlinkValue)?.text) {
            return String((value as Excel.CellHyperlinkValue)?.text);
          } else if ((value as Excel.CellFormulaValue).result) {
            return String((value as Excel.CellFormulaValue)?.result);
          } else if ((value as Excel.CellSharedFormulaValue).result) {
            return String((value as Excel.CellSharedFormulaValue)?.result);
          } else if ((value as Excel.CellErrorValue).error) {
            return String((value as Excel.CellErrorValue)?.error);
          }

          return String(value);
        }),
      );
    }
  }

  return result;
}

export function getEventPromotionProductUploadFields(
  type: PromotionType,
): FieldType[] {
  const fields: FieldType[] = [
    {
      field: 'promotionType',
      label: 'Promotion type',
      instruction: 'Type of the promotion',
      example: 'Percentage Off',
      valueHelp: 'String value',
      required: true,
      width: 10,
      sanitizers: [trim],
      validators: [isString],
      invalidValueMessage:
        'promotionType must be one of "Percentage Off" or "Free Product"',
    },
    {
      field: 'promoProductId',
      label: 'Promo product ID',
      instruction: 'ID of the product in catalog',
      example: '603762d82ab0462593f7d979',
      valueHelp: 'String value',
      required: true,
      width: 10,
      sanitizers: [trim],
      validators: [isString, notEmpty],
      invalidValueMessage: 'promoProductId must be a string',
    },
    {
      field: 'promoProductQty',
      label: 'Promo product quantity',
      instruction: 'Quantity of the promoted product',
      example: 12,
      valueHelp: 'Numeric value',
      required: false,
      width: 10,
      sanitizers: [trim, toNumber],
      validators: [isNumber],
      invalidValueMessage: 'promoProductQty must be a numeric value',
    },
    {
      field: 'discountPerUnit',
      label: 'Discount per unit (%)',
      instruction: 'Discount for promoted product',
      example: 20,
      valueHelp: 'Numeric value',
      required: type === PromotionType.PercentageOff,
      width: 10,
      sanitizers: [trim, toDecimal(2)],
      validators: [isNumber],
      invalidValueMessage: 'discountPerUnit must be a numeric value',
    },
    {
      field: 'freeProductId',
      label: 'Free product ID',
      instruction: 'ID of the product to be given free',
      example: '603762d82ab0462593f7d979',
      valueHelp: 'String value',
      required: type === PromotionType.FreeProduct,
      width: 10,
      sanitizers: [trim],
      validators: [isString, notEmpty],
      invalidValueMessage: 'freeProductId must be a string value',
    },
    {
      field: 'freeProductQty',
      label: 'Free product quantity',
      instruction: 'Quantity of the product to be given free',
      example: 20,
      valueHelp: 'Numeric value',
      required: type === PromotionType.FreeProduct,
      width: 10,
      sanitizers: [trim, toDecimal(2)],
      validators: [isNumber],
      invalidValueMessage: 'freeProductQty must be a numeric value',
    },
  ];

  return fields;
}

export type ProductUploadRow = {
  row: DraftCell[];
  fields: {
    promotionType: PromotionType;
    promoProductId: string;
    promoProductQty: number;
    freeProductId?: string;
    freeProductQty?: string;
    discountPerUnit?: string;
  };
  line: number;
};

export async function processEventPromotionProducts(data: {
  rows: ProductUploadRow[];
  eventId: string;
  req: IAppRequest;
}): Promise<ProductUploadError[]> {
  const { rows, eventId, req } = data;
  const { userId } = req;
  const productIds: string[] = [];

  rows.forEach((row) => {
    productIds.push(row.fields.promoProductId);
    if (
      row.fields.promotionType.toLowerCase().split(' ').join('_') ===
      PromotionType.FreeProduct
    ) {
      productIds.push(row.fields.freeProductId);
    }
  });

  const products: IProductModelV3[] = await productModelV3
    .find(
      { _id: { $in: productIds } },
      { name: 1, marketPrices: 1, supplierCompanyId: 1, supplierId: 1 },
    )
    .lean();
  const keyByProducts: Record<string, IProductDocumentV3> = keyBy(
    products,
    '_id',
  );
  const errors: ProductUploadError[] = [];

  for (const row of rows) {
    // TODO: Update after the migration. Commented it to fix the build for now
    /*
      const cartProduct: any = keyByProducts[row.fields.promoProductId];
      const preparedData: Promotion.Paths.V1InternalCreatePromotionFromEventAction.RequestBody = {
        eventId,
        supplierCompanyId: cartProduct.supplierCompanyId,
        supplierId: cartProduct.supplierId,
        promotion: {
          ...preparePromotionData(row.fields, keyByProducts),
          metadata: {
            uploadedBy: {
              userId,
            },
          },
        },
      };
      await V1InternalCreatePromotionFromEventAction(preparedData, {
        headers: {
          'x-country': 'ae',
          'x-language': 'en',
          'x-is-internal-request': 1,
          'x-t-secret': getInternalApiSecret({ to: 'module-promotion' }),
        },
      }).catch((error: AxiosError): any => {
        errors.push({ fields: row.fields, line: row.line, error: error.response.data });
        logger.error(`Error create event promotion ${error.message}`);
        return [];
      });
  */
  }

  return errors;
}

type MarketPrice = {
  marketCode: string;
  marketLabel: string;
  marketCurrency: string;
  prices: {
    priceCode: string;
    isActive?: boolean;
    sku?: string;
    media?: string[];
    tiers: {
      tierCode?: string;
      minQty?: number;
      maxQty?: number;
      price?: number;
      retailPrice?: number;
    }[];
  }[];
};

function getMinQtyForProduct(product: any): number {
  const marketPrices: MarketPrice =
    find(product?.marketPrices, (o: any) => o.marketCode === 'AE') ||
    find(product?.marketPrices, (o: MarketPrice) => o.marketCode === 'INTL');

  const prices: MarketPrice['prices'][0] = marketPrices?.prices[0];

  const firstPriceTier: MarketPrice['prices'][0]['tiers'][0] = prices.tiers[0];
  return firstPriceTier.minQty;
}

export function formatErrors(
  rowErrors: ProductUploadRow[],
): ProductUploadError[] {
  return rowErrors.map(
    (rowError: ProductUploadRow): ProductUploadError => {
      return {
        fields: rowError.fields,
        line: rowError.line,
        error: {
          status: StatusCodes.BAD_REQUEST,
          message: 'INVALID_VALUE',
          name: 'Error',
          errors: rowError.row.filter((r) => r.error),
        },
      };
    },
  );
}

export async function parseExcelCells(
  file: IMediaFile,
): Promise<{
  rawData: string[][];
  headersIndexMap: Record<string, string>;
}> {
  const workbook: Excel.Workbook = await getWorkbook(file.path);
  const dataSheet: Excel.Worksheet = workbook.getWorksheet(1);
  const rawData: string[][] = getRawData(dataSheet);
  const headersIndexMap: Record<string, string> = invert(
    dataSheet.getRow(1).values as { [key: string]: Excel.CellValue },
  );
  return { rawData, headersIndexMap };
}

export function processRawDataCells(
  rawData: string[][],
  headersIndexMap: Record<string, string>,
): {
  validProductUploadRows: ProductUploadRow[];
  invalidProductUploadRows: ProductUploadRow[];
} {
  let anyCellInvalid: boolean = false;
  const validProductUploadRows: ProductUploadRow[] = [];
  const invalidProductUploadRows: ProductUploadRow[] = [];

  rawData.forEach((row: any, counter: number): void => {
    const uploadDraftRow: DraftCell[] = [];
    const draftFields: ProductUploadRow['fields'] = {
      promoProductId: null,
      promoProductQty: null,
      promotionType: null,
    };

    // reset invalid counter on each new row
    anyCellInvalid = false;

    const promotionType: PromotionType = row[0]
      ?.toLowerCase()
      .split(' ')
      .join('_');
    getEventPromotionProductUploadFields(promotionType).forEach(
      (field: FieldType): any => {
        const rawDataIndex: number = Number(headersIndexMap[field.label]) - 1;
        let value: string = row[rawDataIndex];
        const uploadRowCell: DraftCell = {
          field: field.field,
          error: null,
          label: field.label,
          value: value,
        };

        if (isEmpty(value)) {
          if (field.required) {
            uploadRowCell.error = 'Field is required';
          } else if (field.defaultValue) {
            value = field.defaultValue;
          }
        } else {
          const sanitized: any = sanitizeField(value, field.sanitizers);
          if (sanitized && sanitized.error) {
            uploadRowCell.error = String(sanitized.error.message).substr(
              0,
              100,
            );
          } else {
            value = sanitized.value;
          }

          const isValid: boolean = validateField(value, field.validators);
          if (!isValid) {
            uploadRowCell.error = field.invalidValueMessage || 'Invalid value';
          }
        }

        if (!!uploadRowCell.error) {
          anyCellInvalid = true;
        }

        set(draftFields, field.field, value);
        uploadDraftRow.push(uploadRowCell);
      },
    );

    if (anyCellInvalid) {
      invalidProductUploadRows.push({
        row: uploadDraftRow,
        fields: draftFields,
        line: counter + 2,
      });
    } else {
      validProductUploadRows.push({
        row: uploadDraftRow,
        fields: draftFields,
        line: counter + 2,
      });
    }
  });

  return {
    invalidProductUploadRows,
    validProductUploadRows,
  };
}
