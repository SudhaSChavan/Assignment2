import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { eventModel, IEventModel } from './model-event';
import { FilterQuery } from 'mongoose';
import { ERRORS } from '@src/types/errors';
import { generateListEventQuery } from './action-list-event-backoffice/helpers';

interface IReq extends IAppRequest {
  body: Paths.V1ListEventBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1ListEventBackofficeAction.Responses.$200) => this;
}

export const validateListEventRequestBackoffice: BaseValidationType = [
  body('page').optional().isInt({ gt: 0 }).withMessage(ERRORS.INVALID),
  body('limit').optional().isInt({ max: 1000 }),
  body('filter.from').optional().isInt(),
  body('filter.to').optional().isInt(),
  body('filter.name').optional().isString().withMessage(ERRORS.INVALID),
  body('filter.status')
    .optional({ nullable: true })
    .isString()
    .isIn(['active', 'scheduled', 'expired', 'all'])
    .withMessage(ERRORS.INVALID),
  reqValidationResult,
];

export async function listEventBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<IRes> {
  const {
    body: { page = 1, limit = 50, filter = {} },
  } = req;

  const recordsToSkip: number = (page - 1) * limit;

  const query: FilterQuery<IEventModel> = await generateListEventQuery(filter);

  const events: IEventModel[] = await eventModel
    .find(
      query,
      {},
      {
        sort: {
          createdAt: -1,
        },
        skip: recordsToSkip,
        limit,
      },
    )
    .lean();

  const totalCount: number = await eventModel.countDocuments();

  return res.json({
    total: totalCount,
    limit,
    currentPage: page,
    lastPage: Math.ceil(totalCount / limit) || 1,
    data: events as any,
  });
}
