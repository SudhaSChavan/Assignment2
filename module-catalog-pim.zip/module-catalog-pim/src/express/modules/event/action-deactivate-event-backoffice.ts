import { body } from 'express-validator';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { eventModel } from './model-event';

interface IReq extends IAppRequest {
  body: Paths.V1DeactivateEventBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1DeactivateEventBackofficeAction.Responses.$200) => this;
}

export const validateDeactivateEventBackoffice: BaseValidationType = [
  body('id').isMongoId(),
  reqValidationResult,
];

export async function deactivateEventBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<IRes> {
  const { id } = req.body;

  const { nModified } = await eventModel.updateOne(
    {
      _id: id,
    },
    {
      deactivatedAt: new Date() as any,
    },
  );

  return res.json({
    isDeactivated: nModified > 0,
  });
}
