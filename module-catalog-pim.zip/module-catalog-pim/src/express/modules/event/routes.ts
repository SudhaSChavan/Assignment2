import { Router } from 'express';
import { Router as IRouter } from 'express-serve-static-core';
import { backOfficeUserMw } from '@src/config/middleware/is-backoffice-user';
import { isAuthenticatedMw } from '@tradeling/web-js-utils';
import { catchAsyncErrors } from '@core/util/router';
import { getEventAction, validateGetEvent } from './action-get-event';
import {
  listPersonalizedEventsAction,
  validateListPersonalizedEvents,
} from './action-list-personalized-events';
import {
  validateCreateEventBackoffice,
  createEventBackofficeAction,
} from './action-create-event-backoffice';
import {
  validateDeactivateEventBackoffice,
  deactivateEventBackofficeAction,
} from './action-deactivate-event-backoffice';
import {
  validateListEventRequestBackoffice,
  listEventBackofficeAction,
} from './action-list-event-backoffice';
import {
  validateUploadEventPromotionProductBackoffice,
  uploadEventPromotionProductBackofficeAction,
} from './action-upload-event-promotion-product-backoffice';
import { multerHandler } from '@src/config/middleware/multer-mw';

const router: IRouter = Router();

router.post(
  '/v1-list-personalized-events',
  isAuthenticatedMw(),
  validateListPersonalizedEvents,
  catchAsyncErrors(listPersonalizedEventsAction),
);
router.post(
  '/v1-get-event',
  isAuthenticatedMw(),
  validateGetEvent,
  catchAsyncErrors(getEventAction),
);
router.post(
  '/v1-create-event-backoffice',
  backOfficeUserMw([]),
  validateCreateEventBackoffice,
  catchAsyncErrors(createEventBackofficeAction),
);
router.post(
  '/v1-deactivate-event-backoffice',
  backOfficeUserMw([]),
  validateDeactivateEventBackoffice,
  catchAsyncErrors(deactivateEventBackofficeAction),
);
router.post(
  '/v1-list-event-backoffice',
  backOfficeUserMw([]),
  validateListEventRequestBackoffice,
  catchAsyncErrors(listEventBackofficeAction),
);
router.post(
  '/v1-upload-event-promotion-product-backoffice',
  backOfficeUserMw([]),
  multerHandler,
  validateUploadEventPromotionProductBackoffice,
  catchAsyncErrors(uploadEventPromotionProductBackofficeAction),
);

export { router as eventRoutes };
