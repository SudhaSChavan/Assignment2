import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import {
  BaseValidationType,
  reqValidationResult,
} from '@tradeling/web-js-utils/dist';
import { FilterQuery } from 'mongoose';
import { isBefore, subDays } from 'date-fns';
import { InternalReviewStatuses } from '../product/types';
import { eventModel, IEventDocument } from './model-event';
import { productModelV3 } from '../product/model-product-v3';

interface IReq extends IAppRequest {
  body: Paths.V1ListPersonalizedEventsAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (body: Paths.V1ListPersonalizedEventsAction.Responses.$200) => this;
}

export const validateListPersonalizedEvents: BaseValidationType = [
  reqValidationResult,
];

function mapAggregatedCategories(categories: any): string[] {
  const aggregatedCategories: [{ _id: string; parents: string[] }] = categories;
  let allCategories: string[] = [];

  for (const cat of aggregatedCategories) {
    allCategories = [
      ...allCategories,
      String(cat._id),
      ...cat.parents.map(String),
    ];
  }

  return Array.from(new Set(allCategories));
}

export async function listPersonalizedEventsAction(
  req: IReq,
  res: IRes,
): Promise<void> {
  // Show only if `selected categories` are matching `approved products' categories of supplier`
  const aggregatedResult: any = await productModelV3.aggregate([
    {
      $match: {
        createdSupplierCompanyId: req.supplierCompanyId,
        internalReviewStatus: InternalReviewStatuses.Accepted,
      },
    },
    { $group: { _id: null, uniqueCategories: { $addToSet: '$categoryId' } } },
    {
      $lookup: {
        from: 'category',
        let: { leafCategories: '$uniqueCategories' },
        pipeline: [
          {
            $match: {
              $expr: {
                $in: ['$_id', '$$leafCategories'],
              },
            },
          },
          { $project: { parents: 1 } },
        ],
        as: 'allCategories',
      },
    },
  ]);

  const allCategories: any = aggregatedResult[0]?.allCategories || [];
  const uniqueCategories: string[] = mapAggregatedCategories(allCategories);
  const eventConditions: FilterQuery<IEventDocument> = {
    $and: [
      //
      { deactivatedAt: null },
      {
        $or: [
          { categoryIds: null },
          { categoryIds: [] },
          { categoryIds: { $in: uniqueCategories } },
        ],
      },
    ],
  };

  const events: IEventDocument[] = (
    await eventModel
      .find(eventConditions, { userDetail: 0, reqHeaders: 0 })
      .lean()
  )
    // filter out based on submission deadlines
    .filter((event) => {
      const { sellerSubmissionDeadline = 0, validFrom } = event;
      const today: Date = new Date();
      const deadline: Date = subDays(
        new Date(validFrom),
        sellerSubmissionDeadline,
      );

      return isBefore(today, deadline);
    });

  res.json({
    events,
  });
}
