export enum DiscountVertical {
  ProductDiscount = 'product_discount',
  OrderDiscount = 'order_discount',
}

export enum DiscountType {
  PercentageOff = 'percentage_off',
  FreeProduct = 'free_product',
}
