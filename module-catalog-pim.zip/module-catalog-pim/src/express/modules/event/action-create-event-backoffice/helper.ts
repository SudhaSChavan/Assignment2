export function toEndOfDay(date: string): string {
  return date?.replace(
    /(\d{4})-(\d{2})-(\d{2}).*/,
    (fullMatch: string, year: string, month: string, day: string) => {
      return `${year}-${month}-${day}T23:59:59.000Z`;
    },
  );
}

export function toStartOfDay(date: string): string {
  return date?.replace(
    /(\d{4})-(\d{2})-(\d{2}).*/,
    (fullMatch: string, year: string, month: string, day: string) => {
      return `${year}-${month}-${day}T00:00:00.000Z`;
    },
  );
}
