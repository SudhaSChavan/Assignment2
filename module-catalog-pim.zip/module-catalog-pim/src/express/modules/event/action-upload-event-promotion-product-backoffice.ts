import {
  BaseValidationType,
  reqValidationResult,
  validateFileUpload,
} from '@tradeling/web-js-utils/dist';
import { body } from 'express-validator';
import { appConfig } from '@src/config/env';
import { IAppRequest } from '@src/types/app-request';
import { IAppResponse } from '@src/types/app-response';
import { IMediaFile } from './action-upload-event-promotion-backoffice/helpers';
import {
  formatErrors,
  parseExcelCells,
  processEventPromotionProducts,
  processRawDataCells,
  ProductUploadError,
} from './action-upload-event-promotion-backoffice/helpers';

interface IReq extends IAppRequest {
  body: Paths.V1UploadEventPromotionProductBackofficeAction.RequestBody;
}

interface IRes extends IAppResponse {
  json: (
    body: Paths.V1UploadEventPromotionProductBackofficeAction.Responses.$200,
  ) => this;
}

export const validateUploadEventPromotionProductBackoffice: BaseValidationType = [
  body('eventId').notEmpty().isString(),
  validateFileUpload({
    maxFileSize: appConfig.product.maxFileSizeBytes,
    extensions: ['xlsx'],
    maxFiles: 1,
  }),
  reqValidationResult,
];

export async function uploadEventPromotionProductBackofficeAction(
  req: IReq,
  res: IRes,
): Promise<IRes> {
  const { eventId } = req.body;
  const { files }: { files: IMediaFile[] } = req.body as any;

  const { rawData, headersIndexMap } = await parseExcelCells(files[0]);
  const {
    invalidProductUploadRows,
    validProductUploadRows,
  } = processRawDataCells(rawData, headersIndexMap);

  const totalCount: number =
    validProductUploadRows.length + invalidProductUploadRows.length;
  const errors: ProductUploadError[] = await processEventPromotionProducts({
    rows: validProductUploadRows,
    eventId,
    req,
  });
  const successCount: number = validProductUploadRows.length - errors.length;
  const invalidCount: number = invalidProductUploadRows.length + errors.length;
  const allErrors: ProductUploadError[] = [
    ...errors,
    ...formatErrors(invalidProductUploadRows),
  ];
  return res.json({
    errors: allErrors,
    successCount,
    invalidCount,
    totalCount,
  });
}
