import { FilterQuery } from 'mongoose';
import { IEventModel } from '../model-event';

export async function generateListEventQuery(
  filter: Paths.V1ListEventBackofficeAction.RequestBody['filter'],
): Promise<FilterQuery<IEventModel>> {
  const { from = null, to = null, name = null, status = null } = filter;

  const isActiveFilterParam: Record<
    'active' | 'scheduled' | 'expired' | 'all',
    { [index: string]: any }
  > = {
    active: {
      $and: [
        {
          validFrom: { $lte: new Date() },
          $or: [{ validTo: { $gte: new Date() } }, { validTo: { $eq: null } }],
        },
        {
          deactivatedAt: null,
        },
      ],
    },
    scheduled: {
      $and: [
        {
          validFrom: { $gt: new Date() },
        },
        {
          deactivatedAt: null,
        },
      ],
    },
    expired: {
      $or: [
        {
          validTo: { $lt: new Date() },
        },
        {
          deactivatedAt: { $ne: null },
        },
      ],
    },
    all: {},
  };

  const query: FilterQuery<IEventModel> = {
    $and: [status ? { ...(isActiveFilterParam as any)[status] } : {}],
  };

  if (name)
    query.$and.push({
      name: {
        $regex: name,
        $options: 'i',
      },
    });

  if (from || to) {
    const fromDt: Date = new Date(0);
    fromDt.setUTCSeconds(from as any);

    const toDt: Date = new Date(0);
    toDt.setUTCSeconds(to as any);

    if (from && to) {
      query.$and.push({
        validFrom: { $gte: fromDt as any },
        validTo: { $lte: toDt as any },
      });
    } else if (from) {
      query.$and.push({
        validFrom: { $gte: fromDt as any },
      });
    } else if (to) {
      query.$and.push({
        validTo: { $lte: toDt as any },
      });
    }
  }

  return query;
}
