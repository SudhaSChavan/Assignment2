import { Application } from 'express-serve-static-core';
import { mediaRoutes } from '../modules/media/routes';
import { healthRoutes } from '../modules/health/routes';
import { productRoutes } from '../modules/product/routes';
import { categoryRoutes } from '../modules/category/routes';
import { supplierRoutes } from '../modules/supplier/routes';
import { uploadRoutes } from '../modules/upload/routes';
import { eventRoutes } from '../modules/event/routes';
import { offerRoutes } from '../modules/offer/routes';
import { collectionRoutes } from '../modules/collection/routes';

export function initRouter(app: Application): void {
  app.use('/', healthRoutes);

  app.use('/', mediaRoutes);

  app.use('/', productRoutes);

  app.use('/', categoryRoutes);

  app.use('/', supplierRoutes);

  app.use('/', uploadRoutes);

  app.use('/', eventRoutes);

  app.use('/', offerRoutes);

  app.use('/', collectionRoutes);
}
