export enum ERRORS {
  INVALID = 'invalid',
  DIMENSION_INVALID = 'dimension_invalid',
  MISSING = 'missing',
  DUPLICATE = 'duplicate',
  NOT_FOUND = 'not_found',
  NOT_ALLOWED = 'not_allowed',
}
