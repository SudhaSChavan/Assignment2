import { IBaseAppResponse } from '@tradeling/web-js-utils/dist';

// error middleware formatter
export interface IAppResponse extends IBaseAppResponse {}
