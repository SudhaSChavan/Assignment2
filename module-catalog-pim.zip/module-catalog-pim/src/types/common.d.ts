export type KeyValAny = {
  [key: string]: any;
};

export interface IMediaFile extends Express.Multer.File {
  success?: boolean;
}
