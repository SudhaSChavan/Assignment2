import {
  IBaseAppHeaders,
  IBaseAppRequest,
  IBaseAppUser,
} from '@tradeling/web-js-utils/dist';

export interface IAppHeaders extends IBaseAppHeaders {}

export interface IAppRequest extends IBaseAppRequest {
  headers: IAppHeaders;
  platform: string;
  user: IBaseAppUser;
}
