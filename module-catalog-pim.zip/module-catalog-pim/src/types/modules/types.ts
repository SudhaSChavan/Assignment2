export const EDUKAAN_WEBSITE: string = 'edukaan';
export const TCOM_WEBSITE: string = 'tcom';
