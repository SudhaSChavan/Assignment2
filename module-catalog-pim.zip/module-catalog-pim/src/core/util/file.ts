import { extname } from 'path';
import {
  allowedDocExtensions,
  allowedImageExtensions,
  allowedVideoExtensions,
} from '@src/config/env';

export type ValidFileType = 'document' | 'image' | 'video';

/**
 * Gets extension for the given file name
 * @param fileName
 */
export function getExtension(fileName: string): string {
  return extname(fileName).toLowerCase().replace('.', '');
}

/**
 * Gets the type from the given filename
 * @param fileName
 */
export function getFileType(fileName: string): ValidFileType {
  const extension: string = getExtension(fileName);

  switch (true) {
    case allowedImageExtensions.includes(extension):
      return 'image';
    case allowedVideoExtensions.includes(extension):
      return 'video';
    case allowedDocExtensions.includes(extension):
      return 'document';
  }
}
