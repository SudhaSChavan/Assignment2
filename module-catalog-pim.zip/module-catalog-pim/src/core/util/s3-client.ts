import AWS from 'aws-sdk';
import S3, { ClientConfiguration } from 'aws-sdk/clients/s3';
import { appConfig } from '@src/config/env';

const config: ClientConfiguration = {
  s3ForcePathStyle: true,
  region: appConfig.s3.region,
  accessKeyId: appConfig.s3.accessKeyId,
  secretAccessKey: appConfig.s3.secretAccessKey,
};

export const awsS3Client: S3 = new AWS.S3(config);
