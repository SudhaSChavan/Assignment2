//  GLOBAL COMMON / UTIL functions   //
// --------------------------------- //
//  DON'T ADD Common or UTIL HERE!   //
// --------------------------------- //
// ADD Common / util folder - module //
// Scoped for the functions folders  //
// --------------------------------- //
import { Tracer } from 'tracer';
import { AsyncLocalStorage } from 'async_hooks';
import { ILogger, NullableLogger, TracerLogger } from '@tradeling/web-js-utils';
import { appConfig } from '@src/config/env';

const loggerContext: AsyncLocalStorage<
  Map<string, any>
> = new AsyncLocalStorage();
const config: Tracer.LoggerConfig = {
  preprocess: (data) => {
    const store: Map<string, any> = loggerContext.getStore();
    const xTraceId: string = store?.get('xTraceId');
    if (xTraceId) {
      data.args = [`x-trace-id ${xTraceId}`, ...data.args];
    }
  },
  dateformat: "UTC:yyyy-mm-dd'T'HH:MM:ss.l'Z'",
};

const logger: ILogger = appConfig.isTesting ? NullableLogger : TracerLogger;

logger.setEnv('Development');
logger.setConfig(config);

export { logger, loggerContext };
