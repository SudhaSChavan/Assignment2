import Schema from 'mongoose';
import { StatusCodes } from 'http-status-codes';

import {
  forEach,
  get,
  isEmpty,
  isEqual,
  last,
  map,
  round,
  uniqBy,
} from 'lodash';
import {
  BaseValidationType,
  HttpError,
  reqValidationResult,
} from '@tradeling/web-js-utils';
import {
  body,
  CustomValidator,
  Meta,
  ValidationChain,
} from 'express-validator';

import { ERRORS } from '@src/types/errors';
import {
  categoryModel,
  ICategoryModel,
} from '@express/modules/category/model-category';
import { IMediaModel, mediaModel } from '@express/modules/media/model-media';
import { IMediaFile } from '@express/modules/media/types';
import { getExtension } from './file';
import {
  paymentOptions,
  ProductMediaType,
} from '@express/modules/product/types';
import {
  stripHtml,
  TransportationModeValues,
} from '@express/modules/upload/helpers';
import { longDescriptionSanitizer } from '@express/modules/product/helpers';
import {
  IProductModelV3,
  productModelV3,
} from '@express/modules/product/model-product-v3';
import { appConfig, isMarginGuardrailsEnabled } from '@src/config/env';
import { offerModelV3 } from '@express/modules/offer/model-offers-v3';
import { getCommissionValue } from '@express/modules/util/helpers';

export async function validateCategoryId(
  categoryId: string | undefined,
): Promise<Error | undefined> {
  if (!categoryId) {
    return;
  }

  // @ts-ignore
  if (!Schema.Types.ObjectId.isValid(categoryId)) {
    throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.INVALID);
  }

  const category: boolean = await categoryModel.exists({ _id: categoryId });

  if (!category) {
    throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.NOT_FOUND);
  }
}

/**
 * Validates if the keywords are valid or not
 */
export function validateKeywords(keywords: string[]): boolean {
  return (
    Array.isArray(keywords) &&
    keywords.every((k: string): boolean => typeof k === 'string')
  );
}

export async function validateMedia(
  mediaItems?: ProductMediaType[],
): Promise<Error | ProductMediaType[]> {
  if (!mediaItems || mediaItems.length === 0) {
    return;
  }

  mediaItems = uniqBy(mediaItems, ({ id }: ProductMediaType): string => id);

  // If there are any invalid object ids in the mediaIds
  // @ts-ignore
  if (
    mediaItems.some(
      // @ts-ignore
      ({ id }: ProductMediaType): boolean => !Schema.Types.ObjectId.isValid(id),
    )
  ) {
    throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.INVALID);
  }

  const mediaIds: string[] = map(mediaItems, 'id');

  const foundMedia: IMediaModel[] = await mediaModel.find({
    _id: {
      $in: mediaIds,
    },
  });

  // If all the media items were not found in database
  if (foundMedia.length !== mediaItems.length) {
    throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.NOT_FOUND);
  }

  return mediaItems;
}

export function validateFileUpload({
  maxFileSize,
  extensions,
  maxFiles,
}: {
  maxFileSize: number;
  extensions: string[];
  maxFiles?: number;
}): ValidationChain {
  return body('validatorFiles').custom((files: IMediaFile[]): boolean => {
    if (!files || files.length === 0) {
      throw new HttpError(StatusCodes.BAD_REQUEST, `No files uploaded`);
    }

    if (maxFiles && files.length > maxFiles) {
      throw new HttpError(
        StatusCodes.BAD_REQUEST,
        `Too many files: ${files.length}. Allowed: ${maxFiles}`,
      );
    }

    for (let counter: number = 0; counter < files.length; counter++) {
      const file: IMediaFile = files[counter];
      const ext: string = getExtension(file.originalname);

      if (!extensions.includes(ext)) {
        throw new HttpError(
          StatusCodes.BAD_REQUEST,
          `Invalid extension: ${ext}. Allowed: ${extensions.join(', ')}`,
        );
      }

      if (file.size > maxFileSize) {
        throw new HttpError(
          StatusCodes.BAD_REQUEST,
          `File is too big: ${(file.size / Math.pow(1024, 2)).toFixed(
            2,
          )} MB. Maximum allowed size: ${(
            maxFileSize / Math.pow(1024, 2)
          ).toFixed(2)} MB`,
        );
      }
    }

    return true;
  });
}

function getSiblingPath(path: string, offset: number): string {
  return path.replace(
    /(\d)]$/,
    (match, elementIndex) => `${Number(elementIndex) + offset}]`,
  );
}

type TiersType = Components.Schemas.V1Tier;

export const tiersValidatorV3: BaseValidationType = [
  body('tiers[0].minQty') //at first tier to match the minQty with available stock
    .isInt({ gt: 0 })
    .withMessage('Min Qty should not be zero or decimal value')
    .notEmpty(),

  // custom validation for offers.*.subSupplierCompanies -- cost price should be required if supplierCompanyId eq "332221"
  body('tiers.*').custom(async (value, { req, location, path }) => {
    const supplierCompanyId = req?.supplierCompanyId;
    const offer = await offerModelV3
      .findOne({
        productId: req.body.id,
      })
      .lean();

    const lastSupplierObj: any = last(offer.subSupplierCompanies);
    const costPrice = parseFloat(lastSupplierObj?.costPrice);
    const rebate = parseFloat(lastSupplierObj?.rebate);
    if (
      isMarginGuardrailsEnabled &&
      appConfig.tradelingExpressIds.includes(supplierCompanyId)
    ) {
      if (!costPrice) {
        throw new Error('cost price is required');
      }
      // min price will be eq cost price + 2.5 %
      const MinPrice = getCommissionValue(costPrice, rebate);
      forEach(req?.body?.tiers, (tier) => {
        const price = tier?.price || 0;
        if (price < MinPrice) {
          throw new Error(`price should be greater than or equal ${MinPrice}`);
        }
      });
    }

    return true;
  }),

  body('tiers.*.minQty')
    .isInt({ gt: 0 })
    .withMessage('Min Qty should not be zero or decimal value')
    .notEmpty()
    .custom(async (minQty: number, { req }) => {
      const category: ICategoryModel = await categoryModel.findById(
        req?.body?.categoryId,
      );
      if (category?.moq > minQty && req?.body?.unit != 'carton') {
        throw new Error('Min Qty should be more than MOQ');
      }
      return true;
    }),
  body('tiers.*.maxQty').optional({ nullable: true }).isFloat({ min: 0 }),
  body('tiers.*.price')
    .isFloat({ min: 0 })
    .notEmpty()
    .customSanitizer((value) => {
      return value && round(value, 2);
    }),
  body('tiers.*.retailPrice')
    .optional({ nullable: true })
    .isFloat({ min: 0 })
    .customSanitizer((value) => {
      return value && round(value, 2);
    }),
  body('tiers.*')
    .customSanitizer((tier: TiersType, { req, location, path }) => {
      const nextTier: TiersType = get(req[location], getSiblingPath(path, +1));
      if (tier.price === tier.retailPrice) {
        delete tier.retailPrice;
      }
      return {
        ...tier,
        maxQty: nextTier ? nextTier.minQty : 1000000,
      };
    })
    .custom((tier: TiersType, { req, location, path }) => {
      if (tier.retailPrice && Number(tier.retailPrice) < tier.price) {
        throw new Error('retail price cannot be lower than price');
      }
      return true;
    })
    .custom((tier: TiersType, { req, location, path }) => {
      const previousTier: TiersType = get(
        req[location],
        getSiblingPath(path, -1),
      );
      if (previousTier && tier.minQty <= previousTier.minQty) {
        throw new Error('minQty must be greater than previous tier');
      }
      return true;
    }),
];

export const offersRFQValidatorsV3: BaseValidationType = [
  body('offers.*.market.currency').isString().notEmpty(),
  body('offers.*.delivery.*').notEmpty(),
  body('offers.*.delivery.leadTimeUnit').notEmpty().isString().isIn(['days']),
  body('offers.*.delivery.leadTimeValue').notEmpty().isNumeric(),
  body('offers.*.market.tiers[0].minQty') //at first tier to match the minQty with available stock
    .isInt({ gt: 0 })
    .withMessage('Min Qty should not be zero or decimal value')
    .notEmpty(),
  body('offers.*.market.tiers.*.minQty')
    .isInt({ gt: 0 })
    .withMessage('Min Qty should not be zero or decimal value')
    .notEmpty(),
  body('offers.*.market.tiers.*.maxQty')
    .optional({ nullable: true })
    .isFloat({ min: 0 }),
  body('offers.*.market.tiers.*.price')
    .isFloat({ min: 0 })
    .notEmpty()
    .customSanitizer((value) => {
      return value && round(value, 2);
    }),
  body('offers.*.market.tiers.*.retailPrice')
    .optional({ nullable: true })
    .isFloat({ min: 0 })
    .customSanitizer((value) => {
      return value && round(value, 2);
    }),
  body('offers.*.market.tiers.*')
    .customSanitizer((tier: TiersType, { req, location, path }) => {
      const nextTier: TiersType = get(req[location], getSiblingPath(path, +1));
      if (tier.price === tier.retailPrice) {
        delete tier.retailPrice;
      }
      return {
        ...tier,
        maxQty: nextTier ? nextTier.minQty : 1000000,
      };
    })
    .custom((tier: TiersType, { req, location, path }) => {
      if (tier.retailPrice && Number(tier.retailPrice) < tier.price) {
        throw new Error('retail price cannot be lower than price');
      }
      return true;
    })
    .custom((tier: TiersType, { req, location, path }) => {
      const previousTier: TiersType = get(
        req[location],
        getSiblingPath(path, -1),
      );
      if (previousTier && tier.minQty <= previousTier.minQty) {
        throw new Error('minQty must be greater than previous tier');
      }
      return true;
    }),
];

export const updateV3OfferValidators: BaseValidationType = [
  body('_id').notEmpty().isString().isMongoId(),
  body('productId').notEmpty().isString().isMongoId(),
  body('isActive').notEmpty().isBoolean(),
  body('isDefault').notEmpty().isBoolean(),
  body('market.code').notEmpty().isString(),
  body('market.label').optional().isString(),
  body('market.currency').notEmpty().isString(),
  body('delivery.*').notEmpty(),
  body('delivery.hasCustomDeliveryDay').notEmpty().isBoolean(),
  body('delivery.leadTimeUnit').notEmpty().isString().isIn(['days']),
  body('delivery.leadTimeValue').notEmpty().isNumeric(),
  body('market.tiers').isArray().notEmpty(),
  body('market.tiers.*.minQty').notEmpty().isFloat({ min: 0 }),
  body('market.tiers.*.maxQty')
    .optional({ nullable: true })
    .isFloat({ min: 0 }),
  body('market.tiers.*.price')
    .isFloat({ min: 0 })
    .notEmpty()
    .customSanitizer((value) => {
      return value && round(value, 2);
    }),
  body('market.tiers.*.retailPrice')
    .optional({ nullable: true })
    .isFloat({ min: 0 })
    .customSanitizer((value) => {
      return value && round(value, 2);
    }),

  // custom validation for offers.*.subSupplierCompanies -- cost price should be required if supplierCompanyId eq "332221"
  body('subSupplierCompanies').custom((value, { req, location, path }) => {
    const supplierCompanyId = req?.body?.supplierCompanyId;
    const lastSupplierObj: any = last(req?.body?.subSupplierCompanies);
    const costPrice = parseFloat(lastSupplierObj?.costPrice);
    const rebate = parseFloat(lastSupplierObj?.rebate);
    if (rebate > 50) {
      throw new Error('Rebate should be less than 50 %');
    }
    // skip if the user has a permission to override the guardrails
    if (req.headers['x-override-guardrails'] === 'true') {
      return true;
    }

    if (
      isMarginGuardrailsEnabled &&
      appConfig.tradelingExpressIds.includes(supplierCompanyId)
    ) {
      if (!costPrice) {
        throw new Error('cost price is required');
      }
      // min price will be eq cost price + 2.5 %
      const MinPrice = getCommissionValue(costPrice, rebate);

      forEach(req?.body?.market?.tiers, (tier) => {
        const price = tier?.price || 0;
        if (price < MinPrice) {
          throw new Error(`price should be greater than or equal ${MinPrice}`);
        }
      });
    }

    return true;
  }),

  body('market.tiers.*')
    .customSanitizer((tier: TiersType, { req, location, path }) => {
      const nextTier: TiersType = get(req[location], getSiblingPath(path, +1));
      if (tier.price === tier.retailPrice) {
        delete tier.retailPrice;
      }
      return {
        ...tier,
        maxQty: nextTier ? nextTier.minQty : 1000000,
      };
    })
    .custom((tier: TiersType, { req, location, path }) => {
      if (tier.retailPrice && Number(tier.retailPrice) < tier.price) {
        throw new Error('retail price cannot be lower than price');
      }
      return true;
    })
    .custom((tier: TiersType, { req, location, path }) => {
      const previousTier: TiersType = get(
        req[location],
        getSiblingPath(path, -1),
      );
      if (previousTier && tier.minQty <= previousTier.minQty) {
        throw new Error('minQty must be greater than previous tier');
      }
      return true;
    }),
  reqValidationResult,
];

export const offersValidatorsV3: BaseValidationType = [
  body('offers.*.market.currency').isString().notEmpty(),
  body('offers.*.delivery.*').notEmpty(),
  body('offers.*.delivery.leadTimeUnit').notEmpty().isString().isIn(['days']),
  body('offers.*.delivery.leadTimeValue').notEmpty().isNumeric(),

  // custom validation for offers.*.subSupplierCompanies -- cost price should be required if supplierCompanyId eq "332221"
  body('offers.*.subSupplierCompanies').custom(
    async (value, { req, location, path }) => {
      // check if it's product update and price is not changes then ignore the validation
      if (req.body?.name) {
        // fetch product update object
        const oldOffers = await offerModelV3.findOne({
          productId: req.body._id,
        });
        const newOfferData = req.body?.offers?.[0];

        // pick only price field from market tiers
        const oldPrice = oldOffers?.market?.tiers?.map((tier) => tier.price);
        const newPrice = newOfferData?.market?.tiers?.map((tier) => tier.price);

        // compare two objects and check if price is changed or not
        const isPriceNotChanged = isEqual(oldPrice, newPrice);
        // cover the create part...
        if (isEmpty(oldOffers) || isPriceNotChanged) {
          // skip this validation - in case of no price change skip the validation
          return true;
        }
      }
      const supplierCompanyId = req?.supplierCompanyId;
      const lastSupplierObj: any = last(
        req?.body?.offers?.[0]?.subSupplierCompanies,
      );
      const costPrice = parseFloat(lastSupplierObj?.costPrice);
      const rebate = parseFloat(lastSupplierObj?.rebate);
      if (
        isMarginGuardrailsEnabled &&
        appConfig.tradelingExpressIds.includes(supplierCompanyId)
      ) {
        if (!costPrice) {
          throw new Error('cost price is required');
        }
        // min price will be eq cost price + 2.5 %
        const MinPrice = getCommissionValue(costPrice, rebate);

        forEach(req?.body?.offers?.[0]?.market?.tiers, (tier) => {
          const price = tier?.price || 0;
          if (price < MinPrice) {
            throw new Error(
              `price should be greater than or equal ${MinPrice}`,
            );
          }
        });
      }

      return true;
    },
  ),

  body('offers.*.market.tiers[0].minQty') //at first tier to match the minQty with available stock
    .isInt({ gt: 0 })
    .withMessage('Min Qty should not be zero or decimal value')
    .notEmpty(),
  body('offers.*.market.tiers.*.minQty')
    .isInt({ gt: 0 })
    .withMessage('Min Qty should not be zero or decimal value')
    .notEmpty()
    .custom(async (minQty: number, { req }) => {
      const category: ICategoryModel = await categoryModel.findById(
        req?.body?.categoryId,
      );
      if (category?.moq > minQty && req?.body?.unit != 'carton') {
        throw new Error(`Min Qty should be more than MOQ ${category?.moq}`);
      }
      return true;
    }),
  body('offers.*.market.tiers.*.maxQty')
    .optional({ nullable: true })
    .isFloat({ min: 0 }),
  body('offers.*.market.tiers.*.price')
    .isFloat({ min: 0 })
    .notEmpty()
    .customSanitizer((value) => {
      return value && round(value, 2);
    }),
  body('offers.*.market.tiers.*.retailPrice')
    .optional({ nullable: true })
    .isFloat({ min: 0 })
    .customSanitizer((value) => {
      return value && round(value, 2);
    }),
  body('offers.*.market.tiers.*')
    .customSanitizer((tier: TiersType, { req, location, path }) => {
      const nextTier: TiersType = get(req[location], getSiblingPath(path, +1));
      if (tier.price === tier.retailPrice) {
        delete tier.retailPrice;
      }
      return {
        ...tier,
        maxQty: nextTier ? nextTier.minQty : 1000000,
      };
    })
    .custom((tier: TiersType, { req, location, path }) => {
      if (tier.retailPrice && Number(tier.retailPrice) < tier.price) {
        throw new Error('retail price cannot be lower than price');
      }
      return true;
    })
    .custom((tier: TiersType, { req, location, path }) => {
      const previousTier: TiersType = get(
        req[location],
        getSiblingPath(path, -1),
      );
      if (previousTier && tier.minQty <= previousTier.minQty) {
        throw new Error('minQty must be greater than previous tier');
      }
      return true;
    }),
];

function optionalTypeValidator(value: any, type: string) {
  if (value) {
    return typeof value === type;
  }
  return true;
}

export const validateProductSku: CustomValidator = async (
  sku: string,
  meta: Meta,
): Promise<boolean> => {
  const { id } = meta.req.body;

  const existingProduct: IProductModelV3 = await productModelV3.findOne({
    sku,
    supplierCompanyId: meta.req.supplierCompanyId,
    ...(id ? { _id: { $ne: id } } : {}),
  });
  if (existingProduct) {
    throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.DUPLICATE);
  }

  return true;
};

export const productBasicInformationValidatorV3: BaseValidationType = [
  body('parentSku') //
    .optional()
    .isString(),
  body('name.en') //
    .isString()
    .isLength({ min: 15, max: 200 })
    .withMessage(ERRORS.INVALID)
    .trim()
    .customSanitizer(stripHtml),
  body('name.ar') //
    .trim()
    .customSanitizer((value) => {
      if (value?.length >= 1) {
        return value;
      }
    })
    .optional()
    .isString()
    .isLength({ max: 200, min: 15 })
    .withMessage(ERRORS.INVALID)
    .customSanitizer(stripHtml),
];
export const productValidatorsV3: BaseValidationType = [
  ...productBasicInformationValidatorV3,
  body('sku') //
    .notEmpty()
    .custom(validateProductSku)
    .isString(),
  body('shortDescription.en') //
    .if(
      (value: any, { req }: any) =>
        req?.store?.website?.websiteCode !== 'edukaan',
    )
    .isString()
    .withMessage(ERRORS.INVALID)
    .trim()
    .withMessage(ERRORS.INVALID)
    .isLength({ min: 3, max: 1006 })
    .customSanitizer(stripHtml),
  body('shortDescription.ar') //
    .optional()
    .isString()
    .withMessage(ERRORS.INVALID)
    .isLength({ max: 1006 })
    .withMessage('Maximum allowed length is 320')
    .trim()
    .customSanitizer(stripHtml),
  body('longDescription.en') //
    .optional()
    .isString()
    .withMessage(ERRORS.INVALID)
    .trim()
    .customSanitizer(longDescriptionSanitizer),
  body('longDescription.ar') //
    .optional()
    .isString()
    .withMessage(ERRORS.INVALID)
    .trim()
    .customSanitizer(longDescriptionSanitizer),
  body('additionalAttributes') //
    .optional()
    .isArray({ max: 20 })
    .withMessage(ERRORS.INVALID),
  body('keywords.en') //
    .exists()
    .isArray({ max: appConfig.product.maxKeywordsLimit || 50 })
    .custom(validateKeywords),
  body('keywords.ar') //
    .optional()
    .isArray({ max: appConfig.product.maxKeywordsLimit || 50 })
    .custom(validateKeywords),
  body('media') //
    .optional()
    .isArray({ max: appConfig.product.maxMediaLimit || 10 })
    .custom(validateMedia),
  body('media.*.id') //
    .isString()
    .notEmpty(),
  body('media.*.sort') //
    .optional({ nullable: true })
    .isInt(),
  body('media.*.type') //
    .isString()
    .isIn(['image', 'video', 'document'])
    .notEmpty(),
  body('media.*.title') //
    .optional()
    .isString(),
  body('dimensions.lengthUnit') //
    .custom((value) => optionalTypeValidator(value, 'string'))
    .notEmpty()
    .withMessage('unit length required'),
  body('dimensions.widthUnit') //
    .custom((value) => optionalTypeValidator(value, 'string'))
    .notEmpty()
    .withMessage('unit width required'),
  body('dimensions.heightUnit') //
    .custom((value) => optionalTypeValidator(value, 'string'))
    .notEmpty()
    .withMessage('unit height required'),
  body('dimensions.weightUnit') //
    .custom((value) => optionalTypeValidator(value, 'string'))
    .notEmpty()
    .withMessage('unit weight required'),
  body('dimensions.length') //
    .custom((value) => optionalTypeValidator(value, 'number'))
    .isFloat()
    .custom((val) => val > 0)
    .notEmpty()
    .withMessage('length field required'),
  body('dimensions.width') //
    .custom((value) => optionalTypeValidator(value, 'number'))
    .isFloat()
    .custom((val) => val > 0)
    .notEmpty()
    .withMessage('width field required'),
  body('dimensions.height') //
    .custom((value) => optionalTypeValidator(value, 'number'))
    .isFloat()
    .custom((val) => val > 0)
    .notEmpty()
    .withMessage('height field required'),
  body('dimensions.weight') //
    .custom((value) => optionalTypeValidator(value, 'number'))
    .isFloat()
    .custom((val) => val > 0)
    .notEmpty()
    .withMessage('weight field required'),
  body('categoryId') //
    .exists()
    .custom(validateCategoryId),
  // body('type') //
  //   .isString()
  //   .notEmpty()
  //   .isIn(['simple', 'configurable']),
  body('configurationAttributes.*.code') //
    .isString()
    .notEmpty(),
  body('configurationAttributes.*.label') //
    .optional()
    .isString(),
  body('configurationAttributes.*.options.*')
    .if(
      (value: any, { req, location, path }: any) =>
        req.body.type === 'configurable',
    )
    .isString(),
  body('configurationAttributes.*.value') //
    .optional()
    .isString(),
  body('unit') //
    .isString()
    .notEmpty(),
  body('paymentOptions.*') //
    .optional()
    .isString()
    .isIn(map(paymentOptions, 'code')),
  body('transportationMode') //
    .notEmpty()
    .isString()
    .isIn(TransportationModeValues),
  body('isInStock') //
    .isBoolean(),
  body('tags') //
    .isArray()
    .optional(),
  body('tags.*') //
    .isString(),
  body('attributes.htsCode')
    .optional()
    .isString()
    .isLength({ min: 8, max: 16 }),
  body('collectionIds') //
    .if(
      (value: any, { req }: any) =>
        req?.store?.website?.websiteCode === 'edukaan',
    )
    .isArray(),
  ...offersValidatorsV3,
];
export const productRfqValidatorsV3: BaseValidationType = [
  body('sku') //
    .notEmpty()
    .custom(validateProductSku)
    .isString(),
  body('parentSku') //
    .optional()
    .isString(),
  body('name.en') //
    .isString()
    .isLength({ min: 15, max: 200 })
    .withMessage(ERRORS.INVALID)
    .trim()
    .customSanitizer(stripHtml),
  body('name.ar') //
    .trim()
    .customSanitizer((value) => {
      if (value?.length >= 1) {
        return value;
      }
    })
    .optional()
    .isString()
    .isLength({ max: 200, min: 15 })
    .withMessage(ERRORS.INVALID)
    .customSanitizer(stripHtml),
  body('shortDescription.en') //
    .if(
      (value: any, { req }: any) =>
        req?.store?.website?.websiteCode !== 'edukaan',
    )
    .isString()
    .withMessage(ERRORS.INVALID)
    .trim()
    .withMessage(ERRORS.INVALID)
    .isLength({ min: 3, max: 1006 })
    .customSanitizer(stripHtml),
  body('shortDescription.ar') //
    .optional()
    .isString()
    .withMessage(ERRORS.INVALID)
    .isLength({ max: 1006 })
    .withMessage('Maximum allowed length is 320')
    .trim()
    .customSanitizer(stripHtml),
  body('longDescription.en') //
    .optional()
    .isString()
    .withMessage(ERRORS.INVALID)
    .trim()
    .customSanitizer(longDescriptionSanitizer),
  body('longDescription.ar') //
    .optional()
    .isString()
    .withMessage(ERRORS.INVALID)
    .trim()
    .customSanitizer(longDescriptionSanitizer),
  body('additionalAttributes') //
    .optional()
    .isArray({ max: 20 })
    .withMessage(ERRORS.INVALID),
  body('keywords.en') //
    .exists()
    .isArray({ max: appConfig.product.maxKeywordsLimit || 50 })
    .custom(validateKeywords),
  body('keywords.ar') //
    .optional()
    .isArray({ max: appConfig.product.maxKeywordsLimit || 50 })
    .custom(validateKeywords),
  body('media') //
    .optional()
    .isArray({ max: appConfig.product.maxMediaLimit || 10 })
    .custom(validateMedia),
  body('media.*.id') //
    .isString()
    .notEmpty(),
  body('media.*.sort') //
    .optional({ nullable: true })
    .isInt(),
  body('media.*.type') //
    .isString()
    .isIn(['image', 'video', 'document'])
    .notEmpty(),
  body('media.*.title') //
    .optional()
    .isString(),
  body('dimensions.lengthUnit') //
    .custom((value) => optionalTypeValidator(value, 'string'))
    .notEmpty()
    .withMessage('unit length required'),
  body('dimensions.widthUnit') //
    .custom((value) => optionalTypeValidator(value, 'string'))
    .notEmpty()
    .withMessage('unit width required'),
  body('dimensions.heightUnit') //
    .custom((value) => optionalTypeValidator(value, 'string'))
    .notEmpty()
    .withMessage('unit height required'),
  body('dimensions.weightUnit') //
    .custom((value) => optionalTypeValidator(value, 'string'))
    .notEmpty()
    .withMessage('unit weight required'),
  body('dimensions.length') //
    .custom((value) => optionalTypeValidator(value, 'number'))
    .isFloat()
    .custom((val) => val > 0)
    .notEmpty()
    .withMessage('length field required'),
  body('dimensions.width') //
    .custom((value) => optionalTypeValidator(value, 'number'))
    .isFloat()
    .custom((val) => val > 0)
    .notEmpty()
    .withMessage('width field required'),
  body('dimensions.height') //
    .custom((value) => optionalTypeValidator(value, 'number'))
    .isFloat()
    .custom((val) => val > 0)
    .notEmpty()
    .withMessage('height field required'),
  body('dimensions.weight') //
    .custom((value) => optionalTypeValidator(value, 'number'))
    .isFloat()
    .custom((val) => val > 0)
    .notEmpty()
    .withMessage('weight field required'),
  body('categoryId') //
    .exists()
    .custom(validateCategoryId),
  // body('type') //
  //   .isString()
  //   .notEmpty()
  //   .isIn(['simple', 'configurable']),
  body('configurationAttributes.*.code') //
    .isString()
    .notEmpty(),
  body('configurationAttributes.*.label') //
    .optional()
    .isString(),
  body('configurationAttributes.*.options.*')
    .if(
      (value: any, { req, location, path }: any) =>
        req.body.type === 'configurable',
    )
    .isString(),
  body('configurationAttributes.*.value') //
    .optional()
    .isString(),
  body('unit') //
    .isString()
    .notEmpty(),
  body('paymentOptions.*') //
    .optional()
    .isString()
    .isIn(map(paymentOptions, 'code')),
  body('transportationMode') //
    .notEmpty()
    .isString()
    .isIn(TransportationModeValues),
  body('isInStock') //
    .isBoolean(),
  body('tags') //
    .isArray()
    .optional(),
  body('tags.*') //
    .isString(),
  body('collectionIds') //
    .if(
      (value: any, { req }: any) =>
        req?.store?.website?.websiteCode === 'edukaan',
    )
    .isArray(),
  ...offersRFQValidatorsV3,
];
