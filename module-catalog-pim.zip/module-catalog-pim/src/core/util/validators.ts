import Schema from 'mongoose';
import { StatusCodes } from 'http-status-codes';
import { HttpError } from '@tradeling/web-js-utils';
import { body, ValidationChain } from 'express-validator';

import { ERRORS } from '@src/types/errors';
import { categoryModel } from '@express/modules/category/model-category';
import { IMediaFile } from '@express/modules/media/types';
import { getExtension } from './file';

/**
 * Validates if the given category id is valid and exists
 */
export async function validateCategoryId(
  categoryId: string | undefined,
): Promise<Error | undefined> {
  if (!categoryId) {
    return;
  }

  // @ts-ignore
  if (!Schema.Types.ObjectId.isValid(categoryId)) {
    throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.INVALID);
  }

  const category: boolean = await categoryModel.exists({ _id: categoryId });

  if (!category) {
    throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.NOT_FOUND);
  }
}

/**
 * Validates if the keywords are valid or not
 */
export function validateKeywords(keywords: string[]): boolean {
  return (
    Array.isArray(keywords) &&
    keywords.every((k: string): boolean => typeof k === 'string')
  );
}

export function validateFileUpload({
  maxFileSize,
  extensions,
  maxFiles,
}: {
  maxFileSize: number;
  extensions: string[];
  maxFiles?: number;
}): ValidationChain {
  return body('validatorFiles').custom((files: IMediaFile[]): boolean => {
    if (!files || files.length === 0) {
      throw new HttpError(StatusCodes.BAD_REQUEST, `No files uploaded`);
    }

    if (maxFiles && files.length > maxFiles) {
      throw new HttpError(
        StatusCodes.BAD_REQUEST,
        `Too many files: ${files.length}. Allowed: ${maxFiles}`,
      );
    }

    for (let counter: number = 0; counter < files.length; counter++) {
      const file: IMediaFile = files[counter];
      const ext: string = getExtension(file.originalname);

      if (!extensions.includes(ext)) {
        throw new HttpError(
          StatusCodes.BAD_REQUEST,
          `Invalid extension: ${ext}. Allowed: ${extensions.join(', ')}`,
        );
      }

      if (file.size > maxFileSize) {
        throw new HttpError(
          StatusCodes.BAD_REQUEST,
          `File is too big: ${(file.size / Math.pow(1024, 2)).toFixed(
            2,
          )} MB. Maximum allowed size: ${(
            maxFileSize / Math.pow(1024, 2)
          ).toFixed(2)} MB`,
        );
      }
    }

    return true;
  });
}

export function validateLevel(level: number): boolean {
  if (level >= 0 && level <= 3) {
    return true;
  }

  throw new HttpError(StatusCodes.BAD_REQUEST, ERRORS.INVALID);
}
