// Joins URL without spaces
export function joinUrl(baseUrl: string, destinationUrl: string): string {
  const normalizedBaseUrl: string = (baseUrl || '').replace(/\/+$/, '');
  const normalizedDestPath: string = (destinationUrl || '').replace(/^\/+/, '');

  return `${normalizedBaseUrl}/${normalizedDestPath}`;
}
