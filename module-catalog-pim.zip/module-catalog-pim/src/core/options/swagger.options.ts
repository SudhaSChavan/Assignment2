import { DocumentBuilder, OpenAPIObject } from '@nestjs/swagger';
import { appConfig } from '@src/config/env/index';

export const swaggerOptions: Omit<
  OpenAPIObject,
  'paths'
> = new DocumentBuilder()
  .setTitle(appConfig.swaggerTitle)
  .setDescription(appConfig.swaggerDescription)
  .setVersion(appConfig.swaggerVersion)
  .build();
