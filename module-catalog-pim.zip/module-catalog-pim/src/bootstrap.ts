import { appConfig } from '@src/config/env/index';
import { join } from 'path';
import { readFileSync, writeFileSync } from 'fs';
import { merge } from 'lodash';
import express from 'express';
import { NestFactory } from '@nestjs/core';
import { ValidationPipe, VersioningType } from '@nestjs/common';
import { OpenAPIObject, SwaggerModule } from '@nestjs/swagger';
import {
  ExpressAdapter,
  NestExpressApplication,
} from '@nestjs/platform-express';
import { AllExceptionsFilter, TradelingLogger } from '@tradeling/nest-js-utils';
import { expressApp } from '@express/express-server';
import { swaggerOptions } from '@core/options/swagger.options';
import { AppModule } from './app.module';
import { logger } from '@tradeling/core';

async function bootstrap() {
  const app: any = await NestFactory.create<NestExpressApplication>(
    AppModule,
    new ExpressAdapter(expressApp),
    {
      logger: new TradelingLogger(),
    },
  );

  if (appConfig.isDevelopment) {
    app.use(express.static(`/tmp/${appConfig.name}`));
  }

  // app.enableShutdownHooks();
  app.useGlobalFilters(new AllExceptionsFilter(logger));
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
      errorHttpStatusCode: 422,
      forbidUnknownValues: true,
      transformOptions: {
        enableImplicitConversion: true,
        exposeDefaultValues: true,
      },
    }),
  );
  app.enableVersioning({ type: VersioningType.URI });

  if (appConfig.isDevelopment) {
    const completeSwagger: any = generateSwagger(app);
    // swagger.json is available at /docs-json
    SwaggerModule.setup('docs', app, completeSwagger);
  }
  logger.info('Application bootstrapped ...!');
  return app;
}

function generateSwagger(app: NestExpressApplication): OpenAPIObject {
  logger.info('generating swagger, by merging legacy and new swagger');
  const swaggerDocument: any = SwaggerModule.createDocument(
    app,
    swaggerOptions,
  );
  // TODO: search for a better way to merge
  const legacySwagger: any = readFileSync(
    join(process.cwd(), 'swagger', 'swagger.legacy.json'),
    'utf-8',
  );
  const completeSwagger: OpenAPIObject = merge(
    JSON.parse(legacySwagger),
    swaggerDocument,
  );
  writeFileSync(
    join(process.cwd(), 'swagger', 'swagger.json'),
    JSON.stringify(completeSwagger, null, 2),
    'utf-8',
  );
  return completeSwagger;
}

export const appInstancePromise: Promise<NestExpressApplication> = bootstrap();
