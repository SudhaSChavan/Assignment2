import path from 'path';
import { existsSync, readdirSync, readFileSync } from 'fs';

import { logger } from '../src/core/utils/logger';
import { name as packageName } from '../package.json';

const modulesPath: string = path.resolve(`${__dirname}/../src/modules`);

const modules: string[] = readdirSync(modulesPath);

for (let module of modules) {
  let moduleQueueMessagePath: string = `${modulesPath}/${module}/queue-message`;

  // If module does not have queue
  // messages continue
  if (!existsSync(moduleQueueMessagePath)) continue;

  const moduleQueueMessages: string[] = readdirSync(moduleQueueMessagePath);

  const errors: string[] = [];
  for (let moduleQueueMessage of moduleQueueMessages) {
    const moduleQueueMessageFilePath = `${moduleQueueMessagePath}/${moduleQueueMessage}`;

    // Validate file name
    const isValidQueueMessageFileName: boolean = /^queue-message-v[0-9]+[a-z0-9]*(-?[a-z0-9])*(\.[a-z]+)*$/.test(moduleQueueMessage);
    if (!isValidQueueMessageFileName) {
      errors.push(`${moduleQueueMessage} is not a valid queue message file name in ${moduleQueueMessageFilePath}`);
    }

    // Validate queue message file has subject
    const moduleQueueMessageFileContent: string = readFileSync(moduleQueueMessageFilePath, { encoding: 'utf8' });

    const queueMessageFileHasSubject: boolean = /export const V(0-9)*[a-zA-Z0-9]+Subject*/.test(moduleQueueMessageFileContent);
    if (!queueMessageFileHasSubject) {
      errors.push(`${moduleQueueMessage} has no subject in ${moduleQueueMessageFilePath}`);
    }

    // Validate queue message subject format
    if (queueMessageFileHasSubject) {
      const subjectRegex: RegExp = new RegExp(`export const V(0-9)*[a-zA-Z0-9]+Subject: string = '${packageName}\\.v[0-9]+(-?[a-z0-9])*';`);
      const queueMessageHasValidSubject: boolean = subjectRegex.test(moduleQueueMessageFileContent);
      if (!queueMessageHasValidSubject) {
        errors.push(`${moduleQueueMessage} has not a valid subject title in ${moduleQueueMessageFilePath}`);
      }
    }

    // Validate queue message file has message
    // data interface
    const queueMessageFileHasMessageData: boolean = /export interface V(0-9)*[a-zA-Z0-9]+MessageData*/.test(moduleQueueMessageFileContent);
    if (!queueMessageFileHasMessageData) {
      errors.push(`${moduleQueueMessage} has no message data interface in ${moduleQueueMessageFilePath}`);
    }

    const queueMessageFileHasReplyData: boolean = /export interface V(0-9)*[a-zA-Z0-9]+ReplyData*/.test(moduleQueueMessageFileContent);
    if (!queueMessageFileHasReplyData) {
      errors.push(`${moduleQueueMessage} has no reply data interface in ${moduleQueueMessageFilePath}`);
    }
  }

  if (errors.length) {
    errors.forEach((error: string) => logger.error(error));
    process.exit(1);
  }
}
