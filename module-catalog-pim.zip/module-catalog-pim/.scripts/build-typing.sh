#!/usr/bin/env bash
my_dir="$(dirname "$0")"

${my_dir}/json2ts.sh && TS_NODE_PROJECT=./tsconfig.json ts-node -r tsconfig-paths/register ${my_dir}/dtsgen.ts
