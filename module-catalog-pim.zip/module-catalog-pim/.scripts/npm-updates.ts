import { run } from 'npm-check-updates';
const packageFile = require(process.cwd() + '/package.json');

(async () => {
  const upgraded: any = await run({
    // Pass any cli option
    packageFile: process.cwd() + '/package.json',
    upgrade: false,
    packageManager: 'yarn',
    filter: '@tradeling/*',
    jsonUpgraded: false,
  });

  if (Object.keys(upgraded).length){
    console.table(upgraded);
    throw new Error('Updates available, Please make sure to update project dependencies');
  }
})();