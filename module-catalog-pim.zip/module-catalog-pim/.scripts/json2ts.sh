#!/usr/bin/env bash

BASEDIR=$(dirname "$0")

PROVIDERS_PATH="${BASEDIR}/../src/providers/**/schema/*.json"

# Generate typings if path exists
if [[ "$(find ${PROVIDERS_PATH} 2>/dev/null | wc -l)" -gt 0 ]]; then
  for FILE_PATH in ${PROVIDERS_PATH}; do

    FILE_NAME=$(basename "${FILE_PATH}")
    FILENAME_DIR=$(dirname "${FILE_PATH}")
    INPUT_PATH=${FILE_PATH}
    OUTPUT_PATH="${FILENAME_DIR}/../types/${FILE_NAME%.*}.d.ts"

    npx json2ts "${INPUT_PATH}" "${OUTPUT_PATH}"

  done
fi
