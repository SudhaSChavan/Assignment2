import path from 'path';
import recursive from 'recursive-readdir';

import { logger } from '../src/core/utils/logger';

(async () => {
  const srcPathFromRoot: string = path.resolve(`${__dirname}/../src`);

  let filesPathFromRoot: string[] = await recursive(srcPathFromRoot);

  const errors: string[] = [];
  for (let filePathFromRoot of filesPathFromRoot) {
    // Start path from src
    const filePathFromSrc: string = filePathFromRoot.replace(`${srcPathFromRoot}/`, '');

    const filePathParts: string[] = filePathFromSrc.split('/');

    for (let fileOrDirectoryName of filePathParts) {
      const isValidFileOrDirectoryName: boolean = /^[a-z0-9]*(-?[a-z0-9])*(\.[a-z]+)*$/.test(fileOrDirectoryName);
      if (isValidFileOrDirectoryName) continue;

      const fileOrDirectoryPathFromRoot: string = filePathFromRoot.substr(0, filePathFromRoot.indexOf(fileOrDirectoryName));

      const errorMessage: string = `${fileOrDirectoryName} is not a valid file or directory name in ${fileOrDirectoryPathFromRoot}${fileOrDirectoryName}`;
      if (errors.includes(errorMessage)) continue;

      errors.push(errorMessage);
    }
  }

  if (errors.length) {
    errors.forEach((error: string) => logger.error(error));
    process.exit(1);
  }
})();
