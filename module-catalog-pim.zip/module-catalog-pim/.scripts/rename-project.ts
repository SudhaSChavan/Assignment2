/* tslint:disable:non-literal-fs-path */
import fs, { writeFileSync } from 'fs';
import path from 'path';
// @ts-ignore
import replace from 'replace';
import { sync as rimrafSync } from 'rimraf';

import { logger } from '../src/util/logger';

type ReplaceTextInFile = {
  texts: string[];
  filePath: string;
};

const appName: string = process.argv[2];

if (!appName) {
  throw new Error('❎  App name argument is required!');
}

const swaggerFilePath: string = path.resolve(`${__dirname}/../swagger/swagger.json`);
const swaggerDefinitionFilePath: string = path.resolve(`${__dirname}/../src/types/modules/swagger.d.ts`);

const pathsToRemove: string[] = [
  path.resolve(`${__dirname}/../src/modules/example`),
  path.resolve(`${__dirname}/../src/modules/remote-post`),
  path.resolve(`${__dirname}/../src/modules/nats-example`),
  path.resolve(`${__dirname}/../.git`),
  path.resolve(`${__dirname}/../docs/using-sdk`),
  path.resolve(`${__dirname}/../src/modules/todo`),
  swaggerFilePath,
  path.resolve(`${__dirname}/../__tests__/todo.test.ts`),
  swaggerDefinitionFilePath,
];

pathsToRemove.forEach((pathToRemove: string) => rimrafSync(pathToRemove));
logger.info('✅  Successfully removed useless files!');

writeFileSync(swaggerFilePath, '', { encoding: 'utf8' });
writeFileSync(swaggerDefinitionFilePath, '', { encoding: 'utf8' });
logger.info('✅  Successfully created files!');

// Replace text inside files
let replaceIgnorePaths: string[] = [
  '../dist',
  '../.idea',
  '../.scripts',
  '../node_modules',
  '../yarn.lock',
  '../package-lock.json',
];

replaceIgnorePaths.map((replaceIgnorePath: string, index: number) => {
  replaceIgnorePaths[index] = path.resolve(`${__dirname}/${replaceIgnorePath}`);
});
replace({
  silent: true,
  recursive: true,
  regex: 'module-catalog-search',
  replacement: appName,
  exclude: replaceIgnorePaths.join(','),
  paths: [path.resolve(`${__dirname}/..`)],
});
replace({
  silent: true,
  recursive: true,
  regex: 'template_ts',
  exclude: replaceIgnorePaths.join(','),
  paths: [path.resolve(`${__dirname}/..`)],
  replacement: `${appName.replace('-', '_')}`,
});
logger.info('✅  Successfully replace text in files!');

const replaceTextInFiles: ReplaceTextInFile[] = [
  {
    filePath: path.resolve(`${__dirname}/../src/routes/index.ts`),
    texts: [
      'app.use(\'/\', postRoutes);',
      'app.use(\'/\', exampleRoutes);',
      'import { exampleRoutes } from \'../modules/example/routes\';',
      'import { postRoutes } from \'../modules/remote-post/routes\';',
      'import { todoRoutes } from \'../modules/todo/routes\';',
      'import { natsExampleRoutes } from \'../modules/nats-example/routes\';',
      'app.use(\'/\', todoRoutes);',
      'app.use(\'/\', natsExampleRoutes);',
    ],
  },
];

try {
  replaceTextInFiles.forEach((file: ReplaceTextInFile) => {
    // Get file content
    let fileText: string = fs.readFileSync(file.filePath, 'utf-8');

    file.texts.forEach((text: string) => {
      fileText = fileText.replace(text, '');
    });

    // Write back to file
    fs.writeFileSync(file.filePath, fileText);
  });
} catch (err) {
  throw new Error(`Error happened while replacing lines inside files. ${err.message}`);
}
logger.info('✅  Successfully removed lines from files!');

console.log('');
logger.info('✅  Successfully updated all files!');
