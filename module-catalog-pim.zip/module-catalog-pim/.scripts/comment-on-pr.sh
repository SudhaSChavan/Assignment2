#!/usr/bin/env bash


curl -s -H "Authorization: token ${GH_TOKEN}" \
 -X POST -d '{"body": "Your Message to Comment"}' \
 "https://api.github.com/repos/${GH_OWNER_REPO}/issues/${PR_NUMBER}/comments"
