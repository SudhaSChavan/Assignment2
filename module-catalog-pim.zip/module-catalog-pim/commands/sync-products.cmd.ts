import { Command } from '@src/types/command';
import { FilterQuery } from 'mongoose';
import { IProductModelV3, productModelV3 } from '@express/modules/product/model-product-v3';
import { logger } from '@core/util/logger';
import { InternalReviewStatusType } from '@express/modules/product/types';
import { map } from 'lodash';
import { EE } from '../src/config/event/emitter';
import {createSyncEvent, ProductSyncEvent, ProductSyncEventType} from '@express/modules/product/sync-hlper';

type SyncProductsType = {
  supplierCompanyId: string;
  page: number;
  state: 'online' | 'offline' | 'deleted';
  internalReviewStatus: InternalReviewStatusType;
  categoryId: string;
  isInStock: boolean;
};

export const syncProductsCommand: Command = {
  signature: 'products:sync',
  title: 'Sync products to elasticsearch',
  description: 'Sync products to elasticsearch',

  run: async ({ supplierCompanyId, page = 1, state, internalReviewStatus, isInStock, categoryId }: SyncProductsType): Promise<void> => {
    const limit: number = 1000;
    const skip: number = (page - 1) * limit;

    await new Promise((resolve) => {
      setTimeout(resolve, 1000);
    });

    if (!supplierCompanyId && !categoryId) {
      logger.error('Please provide a filter');
      process.exit(1);
    }

    const query: FilterQuery<IProductModelV3> = {};

    if (supplierCompanyId) {
      query.supplierCompanyId = supplierCompanyId;
    }

    if (categoryId) {
      query.categoryId = categoryId;
    }

    if (state) {
      query.state = state;
    }

    if (internalReviewStatus) {
      query.internalReviewStatus = internalReviewStatus;
    }

    if (isInStock) {
      query.isInStock = isInStock;
    }

    const products: IProductModelV3[] = await productModelV3.find(query, {}, { skip });
    const productIds: string[] = map(products, '_id');

    await createSyncEvent( { req: null, productIds, priority: 'highest' } as ProductSyncEventType);
  },
};
