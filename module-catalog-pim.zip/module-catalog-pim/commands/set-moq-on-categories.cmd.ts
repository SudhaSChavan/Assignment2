import { Command } from '@src/types/command';
import { categoryModel } from '@express/modules/category/model-category';

export const migrateVariantProducts: Command = {
  signature: 'category:update-moq',
  title: 'Set MOQ on categories',
  description: 'Set MOQ on categories',

  async run(): Promise<void> {
    await categoryModel.updateMany(
      {
        moq: {
          $exists: false,
        },
      },
      {
        $set: {
          moq: 1,
        },
      },
    );
  },
};
