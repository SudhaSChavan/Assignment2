import csv from 'csvtojson';
import { Types } from 'mongoose';
import { logger } from '@core/util/logger';
import { map, get } from 'lodash';
import { Command } from '@src/types/command';
import { IProductModelV3, productModelV3 } from '@express/modules/product/model-product-v3';
import { mediaModel } from '@express/modules/media/model-media';
import { offerModelV3 } from '@express/modules/offer/model-offers-v3';
import { createSyncEvent, ProductSyncEventType } from '@express/modules/product/sync-hlper';
import { ProductSyncRequestFrom } from '@express/modules/product/types';

type ProductFromFile = {
  'product ID': string;
};

type CommandParamsType = {
  toSupplierCompanyId: string;
  toSupplierId: string;
  toUserId: string;
  productsCsvFilePath: string;
};

type AggregateMediaId = {
  mediaIds: string[];
};

export const moveProductsToSupplierCommand: Command = {
  signature: 'productsV3:move-to-supplier',
  title: 'Move products to supplier with newly revamped variants',
  description: `-------------------------------------
                product products to supplier and sync v3
                params can take values to filter the results
                valid values are:
                - toSupplierCompanyId => string (e.g 5f612519b4fe5dfb07d31803)
                - toSupplierId => string (e.g 5ed916a493042f001b588883)
                - toUserId => string (e.g 5ed916a493042f001b588883)
                - productsCsvFilePath => path/to/csv

                example
                 yarn command productsV3:move-to-supplier --productsCsvFilePath=/Users/arslan.hameed/Downloads/move-v3-products.csv --toSupplierId=5ed916a593042f001b588886 --toSupplierCompanyId=5ed916a493042f001b588883 --toUserId=5ed916a493042f001b588883

                ------------------------------------
  `,

  async run(params: CommandParamsType): Promise<void> {
    const { toSupplierCompanyId, toSupplierId, toUserId, productsCsvFilePath } = params;

    if (!productsCsvFilePath) {
      logger.error('V3 Move Products to Supplier Command: The productsCsvFilePath option is required!');
      process.exit(1);
    }

    if (!toSupplierCompanyId) {
      logger.error('V3 Move Products to Supplier Command: The toSupplierCompanyId option is required!');
      process.exit(1);
    }
    if (!toSupplierId) {
      logger.error('V3 Move Products to Supplier Command: The toSupplierId option is required!');
      process.exit(1);
    }
    if (!toUserId) {
      logger.error('V3 Move Products to Supplier Command: The toUserId option is required!');
      process.exit(1);
    }

    const productsFromCsv: ProductFromFile[] = await csv({
      trim: true,
    }).fromFile(productsCsvFilePath);

    // Get only product ids from the
    // csv file
    const productIdsFromCsv: string[] = map(productsFromCsv, 'product ID');
    if (!productIdsFromCsv.length) {
      logger.error('V3 Move Products to Supplier Command: No product to found to update!');
      process.exit(1);
    }

    // Get all variants/products for the given
    const foundProducts: IProductModelV3[] = await productModelV3.find(
      {
        _id: {
          $in: productIdsFromCsv,
        },
      },
      {
        _id: 1,
      },
    );

    const productIds: string[] = map(foundProducts, '_id');
    logger.info(`V3 Move Products to Supplier Command: Total products to update ${productsFromCsv.length}! with product ID ${JSON.stringify(productIds)}`);

    logger.info('V3 Move Products to Supplier Command: Updating products');
    await productModelV3.updateMany(
      {
        _id: { $in: map(productIds, Types.ObjectId) as any },
      },
      {
        $set: { supplierCompanyId: toSupplierCompanyId },
      },
    );

    // Get media ids from products
    logger.info('V3 Move Products to Supplier Command: Getting media ids from product collection');
    const mediaIdsFromProducts: AggregateMediaId[] = await productModelV3.aggregate([
      {
        $match: {
          _id: { $in: map(productIds, Types.ObjectId) },
        },
      },
      { $unwind: '$media' },
      {
        $group: {
          _id: null,
          mediaIds: { $addToSet: '$media.id' },
        },
      },
      {
        $project: {
          _id: 0,
          mediaIds: 1,
        },
      },
    ]);

    // By default, aggregate function returns array of object,
    // so we need to get the first item which contains media
    // ids. The response of aggregate function can be empty
    // array. So, because of it we can not destruct it above.
    const mediaIdsFromProductsArr: string[] = get(mediaIdsFromProducts, '0.mediaIds', []);

    // Update supplier company inside media
    logger.info('V3 Move Products to Supplier Command: Updating media');
    await mediaModel.updateMany(
      {
        _id: { $in: mediaIdsFromProductsArr },
      },
      {
        $set: {
          supplierCompanyId: toSupplierCompanyId,
          userId: toSupplierId,
          supplierId: toUserId,
        },
      },
    );

    logger.info('V3 Move Products to Supplier Command: Updating offers');
    for (const productId of productIds) {
      // Get product from CSV
      const productFromCsv: ProductFromFile = productsFromCsv.find((productFromCsv: ProductFromFile): boolean => productFromCsv['product ID'] === productId);

      await offerModelV3.updateMany(
        {
          productId: productId,
        },
        {
          $set: {
            supplierCompanyId: toSupplierCompanyId,
            userId: toUserId,
            supplierId: toSupplierId,
          },
        },
      );
    }

    await dispatchProductsToSync(productIds);

    logger.info('V3 Move Products to Supplier Command: Provided products inside CSV are updated successfully!');
  },
};

export async function dispatchProductsToSync(productIds: string[]): Promise<void> {
  try {
    await createSyncEvent({ req: null, productIds, priority: 'highest', requestFrom: ProductSyncRequestFrom.CLi } as ProductSyncEventType);
  } catch (e) {
    console.info(e);
    logger.error(`\n V3 Move Products to Supplier Command:Could not dispatch products to sync:: # Error: ${e?.response}`);
  }
}
