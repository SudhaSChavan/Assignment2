import * as fs from 'fs';
import { existsSync } from 'fs';
import parse, { Parser } from 'csv-parse';
import { logger } from '@core/util/logger';
import { Command } from '@src/types/command';
import { categoryModel, ICategoryModel } from '@express/modules/category/model-category';
import { categoryUpdateListener } from '@express/modules/category/listener-category-update';

const slugList: any[] = [];
const bulkOperations: any[] = [];

type CommandParamsType = {
  file?: string;
  save: boolean;
  force: boolean;
  index: boolean;
  partialUpdate: boolean;
};

export const importArCategoryCsvCommand: Command = {
  signature: 'category:import-ar-csv',
  title: 'Imports AR categories csv file',
  description: 'Imports AR categories csv file',

  run: async ({ file }: CommandParamsType): Promise<void> => {
    if (!existsSync(file)) {
      logger.error('File not found');
      process.exit(1);
    }

    const categories: Parser = fs.createReadStream(file).pipe(parse({ delimiter: ',', columns: true, trim: true }));

    for await (const category of categories) {
      importCategory(category);
    }

    if (bulkOperations.length > 0) {
      const result: any = await categoryModel.bulkWrite(bulkOperations);
      logger.debug(`Query result: ${ JSON.stringify(result) }`);
      // sync to elasticsearch
      const categoriesList: ICategoryModel[] = await categoryModel.find({ slug: { $in: slugList } });
      const ids: string[] = categoriesList.map((cat: ICategoryModel) => cat._id);
      await categoryUpdateListener(ids);
    }
    logger.debug('All categories imported successfully');
  }
};

async function importCategory(category: Record<string, string>): Promise<void> {
  const {
    'name.en': nameEn,
    'name.ar': nameAr,
    'slug': slug
  } = category;

  if (!slug) {
    logger.debug(`Empty slug ${ JSON.stringify(category) }`);
    return;
  }

  const update: any = {};

  if (nameAr) {
    update['name.ar'] = nameAr.trim();
  } else {
    const category: ICategoryModel = await categoryModel.findOne({slug: slug});
    update['name.ar'] = category.name.en || nameEn || '';
  }

  if (Object.keys(update).length === 0) {
    logger.debug(`No change to import ${ JSON.stringify(category) }`);
    return;
  }

  slugList.push(slug);

  bulkOperations.push({
    updateOne: {
      filter: {
        slug: slug
      },
      update: update,
      upsert: false
    }
  });
}
