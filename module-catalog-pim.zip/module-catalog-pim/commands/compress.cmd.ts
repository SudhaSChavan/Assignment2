'use strict';

import sharp from 'sharp';
import glob from 'glob';
import fs from 'fs';
import { join, basename, extname, dirname } from 'path';
import { Command } from '@src/types/command';

export const compressCmd: Command = {
  signature: 'compress',
  title: 'Compress images',
  description: 'Pass --dir and script will replace all images in given directory with compressed JPGs, pass --ext=png to have compressed PNGs',

  async run(argv: any): Promise<void> {
    if (!argv.dir) {
      throw new Error('Need directory name');
    }

    const { count } = await compressAll(argv.dir as string, (argv.ext as string) || 'jpg');
    console.log(`\n\nProcessed ${count} images at ${argv.dir}\n`);
  },
};

async function compressAll(dir: string, ext: string): Promise<{ count: number }> {
  const filesList: string[] = glob.sync('**/*.{png,jpg,jpeg,tiff,tif}', { cwd: dir });
  let counter: number = 0;

  if (!dir) {
    throw new Error('Directory name is required');
  }

  if (ext !== 'jpg' && ext !== 'png') {
    throw new Error('Extension can be jpg or png only');
  }

  for (const inputFileName of filesList) {
    const inputPath: string = join(dir, inputFileName);
    const tempOutputPath: string = `${inputPath}-${randomString()}`;
    const outputFile: string = join(dir, dirname(inputFileName), basename(inputFileName, extname(inputFileName))) + `.${ext}`;

    console.log(`\n-> Compressing ${++counter}: ${inputFileName}`);

    if (ext === 'jpg') {
      await sharp(inputPath)
        .jpeg({
          quality: 75,
          progressive: true,
        })
        .flatten({ background: { r: 255, g: 255, b: 255 } })
        .resize({
          fit: 'inside',
          width: 2000,
          height: 2000,
          withoutEnlargement: true,
        })
        .toFile(tempOutputPath);
    } else {
      await sharp(inputPath)
        .png({
          progressive: true,
          palette: true,
          colours: 256,
          quality: 60,
        })
        .resize({
          fit: 'inside',
          width: 1600,
          height: 1600,
          withoutEnlargement: true,
        })
        .toFile(tempOutputPath);
    }

    console.log(`   Deleting old file`);
    await fs.promises.unlink(inputPath);
    console.log(`   Saving new as ${ext}: ${outputFile}`);
    await fs.promises.rename(tempOutputPath, outputFile);
  }

  return { count: filesList.length };
}

function randomString() {
  return Math.random()
    .toString(36)
    .substr(2, 3);
}
