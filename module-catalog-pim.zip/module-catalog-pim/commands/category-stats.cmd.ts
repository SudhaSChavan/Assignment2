import fs, { WriteStream } from 'fs';
import * as CSV from 'csv-string';
import { Command } from '@src/types/command';
import { logger } from '@core/util/logger';
import { categoryModel, ICategoryModel } from '@express/modules/category/model-category';
import { getCategoryTree, getCategoryUrl } from './utils/helpers';
import { productModelV3 } from '@express/modules/product/model-product-v3';

function getCategoryName(category: ICategoryModel): string {
  if (!category?.name?.en) {
    return '';
  }

  return category.name.en.replace(/\s/g, ' ');
}

export const categoryStatsCommand: Command = {
  signature: 'category-stats:export',
  title: 'Exports the category stats',
  description: 'Gets the categories and the number of products in each category',

  run: async (): Promise<void> => {
    const csvStream: WriteStream = fs.createWriteStream('live-category-stats.csv', { flags: 'a' });

    const columns: string[] = ['Category Level 1', 'Category Level 2', 'Category Level 3', 'Category Level 4', 'Number of Products', 'Level 1 URL', 'Level 2 URL', 'Level 3 URL', 'Level 4 URL'];

    csvStream.write(CSV.stringify(columns));

    // Get all the categories
    const mongoCursor: ICategoryModel[] = (await categoryModel
      .find({
        'children.0': {
          $exists: false,
        },
      })
      .cursor()) as any;

    // For all the categories, prepare the CSV file
    for await (const category of mongoCursor) {
      const categoryTree: ICategoryModel[] = await getCategoryTree(String(category._id));

      const productRow: string[] = [
        getCategoryName(categoryTree?.[0]),
        getCategoryName(categoryTree?.[1]),
        getCategoryName(categoryTree?.[2]),
        getCategoryName(categoryTree?.[3]),
        String(await productModelV3.countDocuments({ categoryId: String(category._id) })),
        getCategoryUrl(categoryTree?.[0]),
        getCategoryUrl(categoryTree?.[1]),
        getCategoryUrl(categoryTree?.[2]),
        getCategoryUrl(categoryTree?.[3]),
        getCategoryUrl(categoryTree?.[4]),
      ];

      csvStream.write(CSV.stringify(productRow));

      console.log(`Writing category: ${category?.slug}`);
    }

    csvStream.end();

    logger.info(`Done, written categories CSV file`);
  },
};
