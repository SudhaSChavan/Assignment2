/* tslint:disable:non-literal-require */
import path from 'path';
import * as fs from 'fs';
// @ts-ignore
import YAML from 'json2yaml';
import { Command } from '@src/types/command';

function normalizeValue(value: string): string {
  value = value?.replace(/^[\s'"\"]/, '');
  value = value?.replace(/[\s'"\"]$/, '');
  value = value?.replace(/['"]+/, '');

  return value;
}

function sleep(ms: number) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

export const categoryCsvYamlCommand: Command = {
  signature: 'category-csv-yaml',
  title: 'Converts category CSV to YAML',
  description: 'Converts category CSV to YAML',

  run: async (argv: Record<string, any>): Promise<void> => {
    const fileName: string = argv.file;

    const categoryFilePath: string = path.join(__dirname, './csv', fileName);
    const categoryContent: string = fs.readFileSync(categoryFilePath, { encoding: 'utf-8' });

    const separator: RegExp = /(?!\B"[^"]*),(?![^"]*"\B)/;
    const rows: string[] = categoryContent.split(/\n/);

    const categories: any = {};

    rows.map((row: string) => {
      const rowParts: string[] = row.split(separator);

      const level0: string = normalizeValue(rowParts?.[0]);
      const level1: string = normalizeValue(rowParts?.[1]);
      const level2: string = normalizeValue(rowParts?.[2]);
      const level3: string = normalizeValue(rowParts?.[3]);
      const level4: string = normalizeValue(rowParts?.[4]);

      categories[level0] = categories[level0] || {};
      if (level1) {
        categories[level0][level1] = categories[level0][level1] || {};
      }

      if (level2) {
        categories[level0][level1][level2] = categories[level0][level1][level2] || {};
      }

      if (level3) {
        categories[level0][level1][level2][level3] = categories[level0][level1][level2][level3] || {};
      }

      if (level4) {
        categories[level0][level1][level2][level3] = categories[level0][level1][level2][level3] || {};
      }
    });

    const yamlText: string = YAML.stringify(categories);
    const yamlTextNormalized: string = yamlText.replace(/\{\}/g, '');

    const yamlFilePath: string = path.join(path.join(__dirname, 'yamls'), fileName.replace('.csv', '.yml'));
    fs.writeFileSync(yamlFilePath, yamlTextNormalized);

    // Sleep to fix the issue where mongo connection is closed immediately after
    // the command which causes it to throw error that connection was closed
    // even before opening
    await sleep(2000);
  },
};
