/* tslint:disable:non-literal-require */
import path from 'path';
import glob from 'glob';
import YAML from 'yaml';
import * as fs from 'fs';
import { isArray, isObject, isString, kebabCase } from 'lodash';
import { logger } from '@core/util/logger';
import { Command } from '@src/types/command';
import { categoryModel, ICategoryModel } from '@express/modules/category/model-category';

const slugsUsed: string[] = [];
let gTotalCategories: number = 0;
let gSavedCount: number = 1;

export const seedCategoryYaml: Command = {
  signature: 'seed-category-yaml',
  title: 'Categories Command',
  description: 'Seeds all the categories',

  run: async (argv: Record<string, any>): Promise<void> => {
    const isForced: boolean = argv.force || argv._.includes('force');

    if (!isForced) {
      console.log(`
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        Seeder is disabled. If some categories were updated then running the
        seeder might mess up the IDs for products. Add the categories using the
        UI if needed.
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      `);

      process.exit(1);
    }

    // Get all the existing categories
    const existingCategories: ICategoryModel[] = await categoryModel.find({}).lean();
    yamlSlugs = existingCategories.map((category: ICategoryModel): string => category.slug);

    const categoriesDir: string = path.join(__dirname, './yamls');
    const yamlData: any = glob
      .sync('**/*.yml', { cwd: categoriesDir, realpath: true })
      .map((categoryFile: string): any => {
        return YAML.parse(fs.readFileSync(categoryFile, 'utf8'));
      })
      .reduce((result: any, current: any): any => ({ ...result, ...current }), {});

    const categories: any[] = yamlToJson(yamlData);

    //////////////////////////////////////////////////////////
    // Iterate the levels and keep saving those levels in bulk
    //////////////////////////////////////////////////////////
    logger.info('Validating categories information');
    await validateCategories(categories);

    logger.info(`Inserting categories Information for ${gTotalCategories} categories`);
    await saveCategoryChildren(categories);
  },
};

/**
 * Validates categories for if they have valid data and not missing any details
 * @param categories
 */
function validateCategories(categories: any[]): void {
  if (!categories?.length) {
    return;
  }

  categories.forEach((category: any): any => {
    const { children, ...categoryDetails } = category;

    // Name does not exist
    if (!category.name || !category.name.en) {
      throw new Error(`Name not found for category ${JSON.stringify(categoryDetails)}`);
    }

    // Slug does not exist
    if (!category.slug) {
      throw new Error(`Slug not found for category ${JSON.stringify(categoryDetails)}`);
    }

    // Slug has already been used
    if (slugsUsed.includes(category.slug)) {
      throw new Error(`Duplicate slug founds for ${JSON.stringify(categoryDetails)}`);
    }

    slugsUsed.push(category.slug);
    gTotalCategories += 1;

    validateCategories(category.children);
  });
}

/**
 * Recursively saves the category tree given
 * @param categories
 * @param parent
 */
async function saveCategoryChildren(categories: any[], parent: ICategoryModel = null): Promise<void> {
  if (categories.length === 0) {
    return;
  }

  const savedCategoryIds: string[] = [];

  // For each of the categories, transform and save them
  for (let counter: number = 0; counter < categories.length; counter++) {
    const category: any = categories[counter];
    const currName: string = category.name.en;

    // tslint:disable-next-line:ext-variable-name
    const { name: { en: parentName = '' } = {}, _id: parentId = null, parents: upperParents = [] } = parent || {};

    // All the parents for this category
    const parents: string[] = [...upperParents, ...(parentId ? [parentId] : [])];

    logger.info(`${gSavedCount}/${gTotalCategories} – ${parentName ? `▶ ${parentName}` : ''} ▶ ${currName}`.trim());

    // Insert the document
    const createdObj: ICategoryModel = await categoryModel.findOneAndUpdate(
      {
        slug: category.slug,
      },
      {
        ...category,
        parentId,
        level: parents.length,
        parents,
        children: [],
      },
      {
        runValidators: false,
        upsert: true, // Insert if not found
        new: true, // Return the inserted document
        strict: true, // Do not insert any non existing fields
      },
    );

    gSavedCount++;
    savedCategoryIds.push(createdObj._id);

    await saveCategoryChildren(category.children || [], createdObj);
  }

  // Put the saved children category ids in parent
  if (parent) {
    parent.children = savedCategoryIds;

    await parent.save({
      validateBeforeSave: false,
    });
  }
}

function yamlToJson(value: any, weight: number = 0): any {
  if (isString(value)) {
    return {
      name: { en: value },
      description: {},
      slug: makeSlug(value),
      keywords: { en: []},
      weight,
      children: [],
    };
  } else if (isArray(value)) {
    return value.map((v: any, i: number): any => yamlToJson(v, value.length - i));
  } else if (isObject(value)) {
    return Object.keys(value).map((name: string, index: number, list: any[]): any => {
      return {
        name: { en: name },
        description: {},
        slug: makeSlug(name),
        keywords: { en: [] },
        weight: list.length - index,
        // @ts-ignore
        children: yamlToJson(value[name]),
      };
    });
  } else if (!value) {
    return null;
  }

  throw new Error('Invalid YAML');
}

let yamlSlugs: string[] = [];

function makeSlug(str: string): string {
  const kebabCased: string = kebabCase(str);

  if (yamlSlugs.includes(kebabCased)) {
    let counter: number = 1;
    let newSlug: string;

    do {
      counter++;
      newSlug = `${kebabCased}-${counter}`;
    } while (yamlSlugs.includes(newSlug));

    yamlSlugs.push(newSlug);

    return newSlug;
  }

  yamlSlugs.push(kebabCased);

  return kebabCased;
}
