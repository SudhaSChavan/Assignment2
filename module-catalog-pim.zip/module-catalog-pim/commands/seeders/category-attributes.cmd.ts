/* tslint:disable:non-literal-require */
import path from 'path';
import glob from 'glob';
import _ from 'lodash';
import { logger } from '@core/util/logger';
import { Command } from '@src/types/command';
import { categoryAttributeModel } from '@express/modules/category/model-category-attribute';
import { categoryModel, ICategoryModel } from '@express/modules/category/model-category';

export const categoryAttributeCommand: Command = {
  signature: 'category:attributes',
  title: 'Category Attribute Command',
  description: 'Seeds the category attributes',

  run: async (argv: Record<string, any>): Promise<void> => {
    const isForced: boolean = argv.force || argv._.includes('force');

    if (!isForced) {
      console.log(`
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        Seeder is disabled. If some category attributes were updated or new
        were added then running the seeder might mess up the categories/attrs
        Add the attributes using the UI in backoffice if needed.
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      `);
      process.exit(1);
    }

    // Read all the attribute files
    const attributesDir: string = path.join(__dirname, './category-attributes');
    const attributesList: any[] = glob
      .sync('**/*.json', {
        cwd: attributesDir,
        realpath: true,
      })
      .map((file: string): any => require(file));

    //////////////////////////////////////////////////////////
    // Do not allow if some categories were duplicated
    //////////////////////////////////////////////////////////
    const catDuplicateAttributes: string[] =
      _.chain(attributesList)
        .groupBy('categorySlug')
        .find((itemAttributes: Object[]): boolean => itemAttributes.length > 1)
        .map('categorySlug')
        .uniq()
        .value() || [];

    // If some category attributes were found more than once
    if (catDuplicateAttributes.length > 0) {
      throw new Error(`Categories with duplicate attribute files found \`${catDuplicateAttributes.join(', ')}\``);
    }

    const categorySlugs: string[] = _.map(attributesList, 'categorySlug');

    if (!categorySlugs.length) {
      throw new Error(`No attributes found to insert`);
    }

    const foundCategories: ICategoryModel[] = (await categoryModel.find({ slug: { $in: categorySlugs } }).lean()) as any;
    const keyedCategories: Record<string, ICategoryModel> = _.keyBy(foundCategories, 'slug');

    //////////////////////////////////////////////////////////
    // Upsert all the attributes
    //////////////////////////////////////////////////////////
    logger.info(`Upserting attributes for ${attributesList.length} categories`);
    const bulkOperations: any = attributesList.map((attributeItem: any): any => {
      const { categorySlug, ...attributeDetails } = attributeItem;
      const associatedCategory: ICategoryModel = keyedCategories?.[categorySlug] || null;

      if (!associatedCategory) {
        console.warn(`Category not found for ${categorySlug}`);

        return;
      }

      return {
        updateOne: {
          filter: {
            categoryId: associatedCategory._id,
          },
          update: {
            ...attributeDetails,
            categoryId: String(associatedCategory._id),
            categoryTree: [...associatedCategory.parents, String(associatedCategory._id)],
          },
          upsert: true,
        },
      };
    });

    const bulkWriteResult: any = await categoryAttributeModel.bulkWrite(bulkOperations);

    console.log(JSON.stringify(bulkWriteResult, null, 2));
    logger.info(`Category attributes upserted for ${attributesList.length} categories!`);
  },
};
