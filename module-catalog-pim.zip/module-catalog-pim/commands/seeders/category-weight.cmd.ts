import path from 'path';
import YAML from 'yaml';
import * as fs from 'fs';
import { Command } from '@src/types/command';
import { categoryModel } from '@express/modules/category/model-category';
import { logger } from '@core/util/logger';

export const categoryWeightCommand: Command = {
  signature: 'category:weight',
  title: 'Update Categories Weight Command',
  description: 'Update Categories Weight',

  run: async (): Promise<void> => {
    const data: any = YAML.parse(fs.readFileSync(path.join(__dirname, 'category-weight.yaml'), 'utf8'));
    const slugs = Object.keys(data);

    for (const slug of slugs) {
      await categoryModel.updateOne({ slug }, { weight: data[slug] });
    }

    logger.info(`Done, changed ${slugs.length} categories`);
  },
};
