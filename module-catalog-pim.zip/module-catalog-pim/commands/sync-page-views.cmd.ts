import { logger } from '@core/util/logger';
import { Command } from '@src/types/command';
import { syncPageViewsInBatch } from './sync-page-views/helpers';

type CommandParamsType = {
  batchSize: number;
};

export const syncPageViews: Command = {
  signature: 'products:sync-page-views',
  title: 'Sync page views count to products collection',
  description: `Sync page views count to products collection. Pass optional param batchSize. eg. --batchSize=50`,
  run: async ({ batchSize }: CommandParamsType): Promise<void> => {
    batchSize = Number(batchSize) || 100;
    await syncPageViewsInBatch(batchSize);
    logger.info('Sync page views job is completed');
  },
};
