import { Command } from '@src/types/command';
import { logger } from '@core/util/logger';
import { syncCategories } from '@express/modules/category/helpers';

export const sync: Command = {
  signature: 'category:sync',
  title: 'Sync category data',
  description: 'Sends category and category attributes data to module-catalog-search',

  async run(): Promise<void> {
    await syncCategories();
    logger.info('Done');
  },
};
