import { categoryModel, ICategoryModel } from '@express/modules/category/model-category';
import { FieldType, isMongoId, trim } from '@express/modules/upload/helpers';
import { logger } from '@core/util/logger';
import { V1ListUserAction } from '@tradeling/tradeling-sdk/account/v1-list-user-action';
import { V1GetSupplierAction } from '@tradeling/tradeling-sdk/catalog-search/v1-get-supplier-action';

const categoryCache: Record<string, ICategoryModel[]> = {};

export async function getCategoryTree(categoryId: string): Promise<ICategoryModel[]> {
  if (categoryCache[categoryId]) {
    return categoryCache[categoryId];
  }

  const category: ICategoryModel = await categoryModel.findById(categoryId);
  const parentIds: string[] = category?.parents;

  let parentCategories: ICategoryModel[] = [];

  if (parentIds && parentIds.length !== 0) {
    parentCategories = await categoryModel.find(
      {
        _id: {
          $in: parentIds,
        },
      },
      {},
      {
        sort: {
          level: 1,
        },
      },
    );
  }

  const tree: ICategoryModel[] = [...parentCategories, category];

  categoryCache[categoryId] = tree;

  return tree;
}

export function getCategoryUrl(category: ICategoryModel): string {
  if (!category?.name?.en) {
    return '';
  }

  return `https://tradeling.com/en/catalog/${category?.slug}`;
}

export function getProductUrl(product: any): string {
  return `https://tradeling.com/en/product-details/${product?._id}-${product.supplierCompanyId}`;
}

export const baseExportFields: FieldType[] = [
  {
    field: 'supplierCompanyId',
    label: 'Supplier Company ID',
    instruction: 'Company unique identifier',
    example: '12345',
    valueHelp: 'An alphanumeric string',
    required: true,
    width: 12,
    sanitizers: [trim],
    validators: [isMongoId],
    invalidValueMessage: 'String must be Mongo id',
  },
  {
    field: '_id',
    label: 'Product ID',
    instruction: 'Product unique identifier',
    example: '12345',
    valueHelp: 'An alphanumeric string',
    required: true,
    width: 12,
    sanitizers: [trim],
    validators: [isMongoId],
    invalidValueMessage: 'String must be Mongo id',
  },
  {
    field: 'categoryName0',
    label: 'Category level 0',
    instruction: '',
    example: '',
    valueHelp: '',
    required: false,
    width: 25,
    sanitizers: [],
    validators: [],
    invalidValueMessage: '',
  },
  {
    field: 'categoryName1',
    label: 'Category level 1',
    instruction: '',
    example: '',
    valueHelp: '',
    required: false,
    width: 25,
    sanitizers: [],
    validators: [],
    invalidValueMessage: '',
  },
  {
    field: 'categoryName2',
    label: 'Category level 2',
    instruction: '',
    example: '',
    valueHelp: '',
    required: false,
    width: 25,
    sanitizers: [],
    validators: [],
    invalidValueMessage: '',
  },
  {
    field: 'categoryName3',
    label: 'Category level 3',
    instruction: '',
    example: '',
    valueHelp: '',
    required: false,
    width: 25,
    sanitizers: [],
    validators: [],
    invalidValueMessage: '',
  },
  {
    field: 'productLink',
    label: 'Link',
    instruction: '',
    example: '',
    valueHelp: '',
    required: false,
    width: 25,
    sanitizers: [],
    validators: [],
    invalidValueMessage: '',
  },
  {
    field: 'companyName',
    label: 'Company name',
    instruction: '',
    example: '',
    valueHelp: '',
    required: false,
    width: 25,
    sanitizers: [],
    validators: [],
    invalidValueMessage: '',
  },
  {
    field: 'companyCountry',
    label: 'Company Country',
    instruction: '',
    example: '',
    valueHelp: '',
    required: false,
    width: 25,
    sanitizers: [],
    validators: [],
    invalidValueMessage: '',
  },
  {
    field: 'state',
    label: 'Product State',
    instruction: '',
    example: '',
    valueHelp: '',
    required: false,
    width: 25,
    sanitizers: [],
    validators: [],
    invalidValueMessage: '',
  },
];

export async function getLeafCategory(rootCategoryId: string): Promise<ICategoryModel | undefined> {
  let leafCategory: ICategoryModel;
  let level: number = 3;

  while (!leafCategory || level < 1) {
    leafCategory = await categoryModel.findOne({
      level,
      parents: { $elemMatch: { $eq: rootCategoryId } },
    });
    level--;
  }

  return leafCategory;
}

export async function getAllLeafCategories(rootCategoryId: string): Promise<ICategoryModel[]> {
  return categoryModel
    .find(
      {
        level: { $in: [2, 3] },
        parents: { $elemMatch: { $eq: rootCategoryId } },
        children: { $size: 0 },
      },
      '_id slug',
    )
    .lean();
}

export type CompanyType = {
  userId: string;
  supplierCompanyId: string;
  companyName: string;
  companyCountry: string;
};

export async function getCompanies(supplierIds: string[], jwtToken?: string): Promise<CompanyType[]> {
  const batchSize: number = 50;
  const companies: CompanyType[] = [];
  const list: string[] = [...supplierIds];

  while (list.length) {
    const ids: string[] = list.splice(0, batchSize);

    const result: any = await V1ListUserAction(
      {
        filter: { id: ids },
      },
      {
        apiEnv: 'prod',
        headers: {
          'x-country': 'ae',
          'x-language': 'en',
          'x-jwt-token':
            jwtToken ||
            'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI1ZTVlMDQ2NmViYjZhNzAwMWM0MDM0ODEiLCJlbWFpbCI6ImNoYXJiZWxAc2FkaXRhLm5ldCIsImlzRW5hYmxlZCI6dHJ1ZSwiaXNWZXJpZmllZCI6dHJ1ZSwiYnV5ZXJDb21wYW55SWQiOiI1ZTVlMDQ2NmViYjZhNzAwMWM0MDM0ODMiLCJzdXBwbGllckNvbXBhbnlJZCI6IjVlNWUwNDY2ZWJiNmE3MDAxYzQwMzQ4NCIsInJvbGVzIjpbIndvcmtzcGFjZS1vd25lciIsImxvZ2dlZC1pbi11c2VyIiwiYnV5ZXItYWRtaW4iLCJzdXBwbGllci1hZG1pbiJdLCJjcmVhdGVkQXQiOiIyMDIwLTAzLTAzVDA3OjE2OjU0LjI4NloiLCJ1cGRhdGVkQXQiOiIyMDIwLTAzLTAzVDA3OjE2OjU0LjQ1NVoiLCJpYXQiOjE1OTQwMjMxNjQsImV4cCI6MTU5NjYxNTE2NH0.J2sXpSyxQD0qZPYRp4hCscAouH19Om6VjXBvv134s4s',
        },
      },
    ).catch((e: any): void => {
      logger.error(`Unable to load users from module-account, server responded: ${e.response?.data?.message ?? e.message}`);
    });

    companies.push(
      ...(result?.data?.map(
        (d: any): CompanyType => {
          return {
            userId: d._id,
            supplierCompanyId: d.supplierCompanyId,
            companyName: d.companyName,
            companyCountry: '',
          };
        },
      ) ?? []),
    );
  }

  for (const company of companies) {
    const { company: companyName, country: companyCountry } = await getCompanyMeta(company.userId);

    if (companyName) {
      company.companyName = companyName;
    }

    if (companyCountry) {
      company.companyCountry = companyCountry;
    }
  }

  return companies;
}

export async function getCompanyMeta(id: string): Promise<{ company: string; country: string }> {
  const data: any = await V1GetSupplierAction(
    { filter: { id } },
    {
      apiEnv: 'prod',
      headers: {
        'x-country': 'ae',
        'x-language': 'en',
        'x-jwt-token':
          'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI1ZTVlMDQ2NmViYjZhNzAwMWM0MDM0ODEiLCJlbWFpbCI6ImNoYXJiZWxAc2FkaXRhLm5ldCIsImlzRW5hYmxlZCI6dHJ1ZSwiaXNWZXJpZmllZCI6dHJ1ZSwiYnV5ZXJDb21wYW55SWQiOiI1ZTVlMDQ2NmViYjZhNzAwMWM0MDM0ODMiLCJzdXBwbGllckNvbXBhbnlJZCI6IjVlNWUwNDY2ZWJiNmE3MDAxYzQwMzQ4NCIsInJvbGVzIjpbIndvcmtzcGFjZS1vd25lciIsImxvZ2dlZC1pbi11c2VyIiwiYnV5ZXItYWRtaW4iLCJzdXBwbGllci1hZG1pbiJdLCJjcmVhdGVkQXQiOiIyMDIwLTAzLTAzVDA3OjE2OjU0LjI4NloiLCJ1cGRhdGVkQXQiOiIyMDIwLTAzLTAzVDA3OjE2OjU0LjQ1NVoiLCJpYXQiOjE1OTQwMjMxNjQsImV4cCI6MTU5NjYxNTE2NH0.J2sXpSyxQD0qZPYRp4hCscAouH19Om6VjXBvv134s4s',
      },
    },
  ).catch((e) => {
    logger.error(`Unable to load users from module-catalog-search, server responded: ${e.response?.data?.message ?? e.message}`);
  });

  return {
    country: data?.data?.regCountry || ' ',
    company: data?.data?.companyName || ' ',
  };
}
