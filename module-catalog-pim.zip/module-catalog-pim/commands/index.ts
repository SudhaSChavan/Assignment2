/// <reference path="../node_modules/@tradeling/tradeling-sdk/types.d.ts" />
/// <reference path="./../src/types/modules/swagger.d.ts"/>
/// <reference path="../node_modules/@tradeling/tradeling-sdk/types.d.ts"/>
/* tslint:disable:non-literal-require */

import glob from 'glob';
import { argv } from 'yargs';
import { flatten, keyBy } from 'lodash';
import { Mongoose } from 'mongoose';
import { logger } from '@core/util/logger';
import { Command } from '@src/types/command';
import { closeNatsConnections } from '../src/config/event/queue';
import { mongoConnection } from './utils/db';

////////////////////////////////////////////////
// List of available commands
// It reads all the command files at the root
// of the directory and automatically defines them
////////////////////////////////////////////////
const gCommandFiles: string[] = glob.sync('**/*.cmd.{ts,js}', {
  cwd: __dirname,
  realpath: true,
});

// Require each of the command files
const commandImports: any[] = gCommandFiles.map((file: string): any => Object.values(require(file)));
const commands: Command[] = flatten(commandImports);
const commandSignatures: any = keyBy(commands, 'signature');

////////////////////////////////////////////////
// Common functions
////////////////////////////////////////////////
function exitWithHelp(exitCode: number = 0): void {
  logger.info(':: Available list of commands ::');
  Object.keys(commandSignatures).map((command: string) => logger.info(`↳  yarn command ${command}`));
  console.log();

  process.exit(exitCode);
}

////////////////////////////////////////////////
// Logic to run the command
////////////////////////////////////////////////

// Signature given by user
const [, , givenSignature]: string[] = process.argv;

// Command was not passed
if (!givenSignature) {
  exitWithHelp();
}

// Given command is not found
if (!commandSignatures[givenSignature]) {
  logger.error(`✖ Invalid command ${givenSignature}`);
  exitWithHelp(1);
}

const foundCommand: Command = commandSignatures[givenSignature];

logger.info('✔ Command found');
logger.info('::::::::::::::::::::::::::::::::::::::::::');
logger.info(`:: ${foundCommand.title}`);
logger.info(`:: ${foundCommand.description}`);
logger.info('::::::::::::::::::::::::::::::::::::::::::');

(async (): Promise<void> => {
  logger.info('Establishing MongoDB connection');
  const mongoObj: Mongoose = await mongoConnection;

  logger.info('Running the command');
  foundCommand
    .run(argv)
    .then(async () => {
      logger.info('Command ran successfully');
      await mongoObj.connection.close();
      closeNatsConnections();
      process.exit(0);
    })
    .catch(async (e: Error) => {
      logger.info('!!! Error occurred while running the command');
      logger.error(`!!! ${e.message}`);
      logger.error(e.stack);
      await mongoObj.connection.close();
    });
})();
