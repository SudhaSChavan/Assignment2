/* tslint:disable:non-literal-require */
import path from 'path';
import { existsSync } from 'fs';
import { Command } from '@src/types/command';
import { logger } from '@core/util/logger';

function getCategoryLeafs(parent: any = {}): any[] {
  if (parent.children.length === 0) {
    return [
      {
        name: parent.name.en,
        slug: parent.slug,
        nameBreadCrumb: parent.name.en,
        slugBreadCrumb: parent.slug,
      },
    ];
  }

  const childNames: any = [];

  for (let item of parent.children) {
    const itemChildrenNames: any = getCategoryLeafs(item);

    for (let childName of itemChildrenNames) {
      childNames.push({
        name: childName.name,
        slug: childName.slug,
        nameBreadCrumb: `${parent.name.en} >> ${childName.nameBreadCrumb}`,
        slugBreadCrumb: `${parent.slug} >> ${childName.slugBreadCrumb}`,
      });
    }
  }

  return childNames;
}

export const printCategoryLeafs: Command = {
  signature: 'category:leafs',
  title: 'Prints category leafs',
  description: 'Prints the leafs for given categories',

  async run(argv): Promise<void> {
    if (!argv.slug) {
      logger.error('Parent slug e.g. `--slug=food-and-beverage` is required');
      process.exit(1);
    }

    const categoryFile: any = path.join(__dirname, `seeders/categories/${argv.slug}.json`);

    if (!existsSync(categoryFile)) {
      logger.error(`Category file not found at: ${categoryFile}`);
      process.exit(1);
    }

    const parentCategory: any = require(categoryFile);
    const categoryLeafs: any = getCategoryLeafs(parentCategory);

    // Print each of the leaf names
    console.log(`
 ___      _______  _______  _______  _______
|   |    |       ||       ||       ||       |
|   |    |    ___||    ___||    ___||  _____|
|   |    |   |___ |   |___ |   |___ | |_____
|   |___ |    ___||    ___||    ___||_____  |
|       ||   |___ |   |___ |   |     _____| |
|_______||_______||_______||___|    |_______|
`);

    for (let leafName of categoryLeafs) {
      console.log(leafName.nameBreadCrumb + '\t' + leafName.slug);
    }

    console.log(`

-------------------------------------------------------
`);
  },
};
