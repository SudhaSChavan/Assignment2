import { chunk, Dictionary, get, isEqual, keyBy, mapValues } from 'lodash';
import { LeanDocument, UpdateQuery } from 'mongoose';
import { AxiosResponse } from 'openapi-client-axios';
import { V1InternalGetProductPageViewsCountAction } from '@tradeling/tradeling-sdk/catalog-search/v1-internal-get-product-page-views-count-action';
import { logger } from '@core/util/logger';
import { getInternalApiSecret } from '@tradeling/web-js-utils';
import { appConfig } from '@src/config/env';
import { IProductContentTranslationDocument, IProductContentTranslationModel, productContentTranslationModel } from '@express/modules/product/model-product-content-translation';
import { IProductModelV3, productModelV3 } from '@express/modules/product/model-product-v3';

type V1InternalGetProductPageViewsResponse = CatalogSearch.Paths.V1InternalGetProductPageViewsCountAction.Responses.$200 | CatalogSearch.Paths.V1InternalGetProductPageViewsCountAction.Responses.$400;

type ProductPageViewCount = CatalogSearch.Paths.V1InternalGetProductPageViewsCountAction.Responses.$200;

interface ComputedProduct {
  product: LeanDocument<IProductModelV3>;
  totalPageViews: number;
  hasTranslations: 'no' | 'partial' | 'yes';
}

async function* fetchProducts(batchSize: number) {
  let page: number = 0;
  let products: IProductModelV3[] = [];
  do {
    products = await productModelV3
      .find()
      .limit(batchSize)
      .skip(page * batchSize)
      .lean();
    yield products;
    page++;
  } while (products.length > 0);
}

async function getProductContentTranslation(ids: string[]): Promise<LeanDocument<IProductContentTranslationModel>[]> {
  return productContentTranslationModel.find({ _id: { $in: ids } }).lean();
}

function mapToProductIds(products: LeanDocument<IProductModelV3>[]): string[] {
  return products.map((product) => product?._id?.toString());
}

function mapToPageViewsMap(views: ProductPageViewCount): { [productId: string]: number } {
  return mapValues(
    keyBy(views, (v) => v.productId),
    (v) => v.pageViewsCount,
  );
}

async function fetchPageViews(ids: string[]) {
  const pageViewsResponse: AxiosResponse<V1InternalGetProductPageViewsResponse> = await V1InternalGetProductPageViewsCountAction(
    {
      productIds: ids,
    },
    {
      headers: {
        'x-country': 'ae',
        'x-language': 'en',
        'x-is-internal-request': '1',
        'x-t-secret': getInternalApiSecret({ to: 'module-catalog-search', from: appConfig.name }),
      },
    },
  );
  const views: ProductPageViewCount = pageViewsResponse.data as ProductPageViewCount;
  return mapToPageViewsMap(views);
}

async function getPageViewsMap(ids: string[]): Promise<{ [variantId: string]: number }> {
  const productIdsBatch: string[][] = chunk(ids, 100);
  const promises: Promise<{ [productId: string]: number }>[] = productIdsBatch.map(async (productIds) => fetchPageViews(productIds));
  return Promise.all(promises).then((pageViews) => {
    return Object.assign({}, ...pageViews);
  });
}

function isNameTranslated(product: LeanDocument<IProductModelV3>): boolean {
  return Boolean(product.name?.ar);
}

function isBrandTranslated(product: LeanDocument<IProductModelV3>): boolean {
  return Boolean(product.attributes?.brand?.ar);
}

function isKeywordsTranslated(product: LeanDocument<IProductModelV3>): boolean {
  return product.keywords?.en?.length === 0 || product.keywords?.en?.length === product.keywords?.ar?.length;
}

function isLongDescriptionTranslated(product: LeanDocument<IProductModelV3>): boolean {
  return Boolean(product.longDescription?.ar);
}

function isShortDescriptionTranslated(product: LeanDocument<IProductModelV3>): boolean {
  return Boolean(product.shortDescription?.ar);
}

function isCompletelyTranslated(product: LeanDocument<IProductModelV3>) {
  return isNameTranslated(product) && isBrandTranslated(product) && isKeywordsTranslated(product) && isLongDescriptionTranslated(product) && isShortDescriptionTranslated(product);
}

function isNotTranslated(product: LeanDocument<IProductModelV3>) {
  return !isNameTranslated(product) && !isBrandTranslated(product) && !isKeywordsTranslated(product) && !isLongDescriptionTranslated(product) && !isShortDescriptionTranslated(product);
}

function getTotalPageViews(variants: LeanDocument<IProductModelV3>[], pageViewsMap: { [variantId: string]: number }) {
  return variants.reduce((total, variant) => total + (pageViewsMap[variant._id.toString()] || 0), 0);
}

function isAllVariantsTranslated(product: IProductModelV3) {
  return isCompletelyTranslated(product);
}

function isAllVariantsNotTranslated(product: LeanDocument<IProductModelV3>) {
  return isNotTranslated(product);
}

function getHasTranslations(product: IProductModelV3) {
  let hasTranslations: 'no' | 'partial' | 'yes' = 'partial';
  if (isAllVariantsTranslated(product)) {
    hasTranslations = 'yes';
  } else if (isAllVariantsNotTranslated(product)) {
    hasTranslations = 'no';
  }
  return hasTranslations;
}

function isProductPageViewUpdated(product: LeanDocument<IProductContentTranslationModel>, totalPageViews: number, hasTranslations: 'no' | 'partial' | 'yes'): boolean {
  return product.pageViews != totalPageViews || product.hasTranslations != hasTranslations;
}

export function isProductUpdated(product: LeanDocument<IProductModelV3>, enrichment: LeanDocument<IProductContentTranslationModel>): boolean {
  const fieldsToCompare: string[] = [
    'name.en',
    'name.ar',
    'shortDescription.en',
    'shortDescription.ar',
    'longDescription.en',
    'longDescription.ar',
    'keywords.en',
    'keywords.ar',
    'attributes.brand.en',
    'attributes.brand.ar',
    'categoryId',
    'state',
    'isInStock',
    'internalReviewStatus',
    'internalReviewedAt',
    'deletedAt',
    'websiteCode',
  ];
  return fieldsToCompare.reduce((isUpdated, field) => {
    return isUpdated || !isEqual(get(product, field), get(enrichment, field));
  }, false);
}

function mapToComputedProducts(products: IProductModelV3[], pageViewsMap: { [variantId: string]: number }): ComputedProduct[] {
  return products.map((product) => {
    const totalPageViews: number = getTotalPageViews(products, pageViewsMap);
    const hasTranslations: 'no' | 'partial' | 'yes' = getHasTranslations(product);
    return {
      product,
      totalPageViews,
      hasTranslations,
    };
  });
}

function filterUpdatedProducts(products: ComputedProduct[], currentProductMap: Dictionary<LeanDocument<IProductContentTranslationModel>>): ComputedProduct[] {
  return products.filter(({ product, hasTranslations, totalPageViews }) => {
    const currentProduct: LeanDocument<IProductContentTranslationModel> = currentProductMap[product._id.toString()];
    return !currentProduct || isProductPageViewUpdated(currentProduct, totalPageViews, hasTranslations) || isProductUpdated(product, currentProduct);
  });
}

function mapToProductUpdateOperations(products: ComputedProduct[]): UpdateQuery<IProductContentTranslationDocument>[] {
  return products.map((productUpdate) => {
    return {
      updateOne: {
        filter: {
          _id: productUpdate.product._id,
        },
        update: {
          name: productUpdate.product.name,
          shortDescription: productUpdate.product.shortDescription,
          longDescription: productUpdate.product.longDescription,
          attributes: {
            brand: productUpdate.product.attributes?.brand,
          },
          keywords: productUpdate.product.keywords,
          categoryId: productUpdate.product.categoryId,
          state: productUpdate.product.state,
          isInStock: productUpdate.product.isInStock,
          internalReviewStatus: productUpdate.product.internalReviewStatus,
          internalReviewedAt: (productUpdate.product as any).internalReviewedAt,
          websiteCode: productUpdate.product.websiteCode,
          pageViews: productUpdate.totalPageViews,
          hasTranslations: productUpdate.hasTranslations,
          deletedAt: productUpdate.product.deletedAt || null,
        },
        upsert: true,
      },
    } as UpdateQuery<IProductModelV3>;
  });
}

async function updateProductPageViews(products: IProductModelV3[], pageViewsMap: { [variantId: string]: number }): Promise<{ modifiedCount: number; insertedCount: number }> {
  const currentProducts: LeanDocument<IProductContentTranslationModel>[] = await getProductContentTranslation(mapToProductIds(products));
  const currentProductMap: Dictionary<LeanDocument<IProductContentTranslationModel>> = keyBy(currentProducts, (pageView) => pageView._id.toString());
  const computed: ComputedProduct[] = mapToComputedProducts(products, pageViewsMap);
  const productUpdatesToExecute: ComputedProduct[] = filterUpdatedProducts(computed, currentProductMap);
  if (productUpdatesToExecute.length > 0) {
    const result: any = await productContentTranslationModel.bulkWrite(mapToProductUpdateOperations(productUpdatesToExecute));
    return { modifiedCount: result.modifiedCount, insertedCount: result.insertedCount };
  }
  return { modifiedCount: 0, insertedCount: 0 };
}

export async function syncPageViewsInBatch(batchSize: number): Promise<void> {
  let batch: number = 0;
  let totalUpdated: number = 0;
  let totalInserted: number = 0;
  let totalProcessed: number = 0;
  for await (const products of fetchProducts(batchSize)) {
    // get productIds from products
    const pageViewsMap: { [variantId: string]: number } = await getPageViewsMap(mapToProductIds(products));
    const { modifiedCount, insertedCount } = await updateProductPageViews(products, pageViewsMap);
    totalUpdated += modifiedCount;
    totalInserted += insertedCount;
    totalProcessed += products.length;
    batch++;
    logger.info(`batch:${batch} completed. Updated: ${modifiedCount} products`);
  }
  logger.info(`Total processed: ${totalProcessed} products`);
  logger.info(`Total inserted: ${totalInserted} products`);
  logger.info(`Total updated: ${totalUpdated} products`);
  return;
}
