import { FilterQuery, QueryCursor, Types } from 'mongoose';
import { Command } from '@src/types/command';
import { logger } from '@core/util/logger';
import { IProductModelV3, productModelV3, ProductState } from '@express/modules/product/model-product-v3';
import { createSyncEvent, ProductSyncEventType } from '@express/modules/product/sync-hlper';
import { ProductSyncRequestFrom } from '@express/modules/product/types';
import { redis as redisClient } from '../src/config/redis';
import { isEmpty, map } from 'lodash';

const batchSize: number = 1000;

type CommandParamsType = {
  page: number;
  supplierCompanyId?: string;
  ids?: string;
  categoryId?: string;
  apply?: string;
  query?: string;
  websiteCode?: string;
  state?: ProductState;
  fromDate?: Date;
  toDate?: Date;
};

export const productSyncV3: Command = {
  signature: 'product-sync:v3',
  title: 'product sync against certain params like (supplierCompanyId, websiteCode, page, fromDate), toDate',
  description: `-------------------------------------
                product sync v3
                params can take values to filter the results
                valid values are:
                - page  => number (e.g 1)
                - supplierCompanyId => string (e.g 5f612519b4fe5dfb07d31803)
                - fromDate => with the following format 2020-09-13
                - toDate => with the following format 2020-09-13
                - websiteCode => string (e.g tcom)

                example
                yarn command product-sync:v3 --page=1 --supplierCompanyId=5e08ad5c092c1b7d8e9e3040 --fromDate=2022-10-04

                ------------------------------------
  `,

  run: async function (params: CommandParamsType): Promise<void> {
    const { supplierCompanyId, websiteCode, fromDate, toDate, state, ids, query, categoryId, apply } = params;

    const idsAsMongoIds: string[] = ids?.split(',').map((id) => id.trim());
    const catIdsAsMongoIds: string[] = categoryId?.split(',').map((id) => id.trim());
    console.error(catIdsAsMongoIds);

    let condition: FilterQuery<IProductModelV3> = {
      // get the ids comma separated and convert it to array convert the ids to  mongodb ObjectId
      ...(ids ? { _id: { $in: map(idsAsMongoIds, Types.ObjectId) as any } } : {}),
      ...(categoryId ? { categoryId: { $in: map(catIdsAsMongoIds, Types.ObjectId) as any } } : {}),
      ...(state ? { state } : {}),
      ...(supplierCompanyId ? { supplierCompanyId } : {}),
      ...(websiteCode ? { websiteCode } : {}),
      ...(fromDate ? { updatedAt: { $gte: new Date(fromDate).toString() } } : {}),
      ...(toDate ? { updatedAt: { $lte: new Date(toDate).toString() } } : {}),
    };

    // escape all if you have query...
    if (query) {
      condition = JSON.parse(query);
    }
    const totalDocument: number = await productModelV3.countDocuments(condition);
    logger.info(`products sync command :: ${totalDocument} number of products found against params ${JSON.stringify(condition)}`);

    if (isEmpty(condition)) {
      logger.error(`##### cannot execute the sync with empty query #####`);

      process.exit(1);
    }

    if (apply !== 'true') {
      logger.info(`##### apply is not true, exiting #####`);
      logger.info(`products sync command :: ${totalDocument} number of products found against params ${JSON.stringify(condition)}`);

      process.exit(1);
    }

    const mongoCursor: QueryCursor<any> = productModelV3.find(condition, {}, {}).cursor();

    let count: number = 0;
    let batch: string[] = [];

    logger.info(`Syncing  ${batchSize} products`);

    for await (const product of mongoCursor) {
      count++;
      batch.push(product);
      if (batch.length >= batchSize) {
        logger.info(`Syncing ${batch.length} -- ${batchSize} products`);
        await syncProducts(batch);
        // random sleep between 5- 10 sec
        await new Promise((resolve) => {
          // sleep between 5 to 15 sec
          const sleepTime: number = Math.floor(Math.random() * (15 - 5) + 5);
          console.error('## sleep ******** ', sleepTime);
          setTimeout(resolve, sleepTime * 1000);
        });
        batch = [];
      }
    }
    await syncProducts(batch);

    process.exit(0);
  },
};

async function syncProducts(variants: any[]): Promise<void> {
  let ids = [];
  for (const variant of variants) {
    // check if it's on cache or not

    const variantId: string = variant._id.toString();
    // check if its cached ... skip it

    const cacheKey: string = `bulk_sync_${variantId}`;
    const hasCache: number = await redisClient.exists(cacheKey);

    if (hasCache) {
      logger.info(`SKIP sync command :: product id ${variantId} is already cached`);
      continue;
    }
    await redisClient.set(cacheKey, 'XXX', 'EX', 130000);
    logger.info(`product sync command :: product id ${variant._id} is being synced`);

    ids.push(variantId);
  }

  await createSyncEvent({ req: null, productIds: ids, priority: 'highest', requestFrom: ProductSyncRequestFrom.CLi } as ProductSyncEventType);
}
